`timescale 1ns / 1ps


module BondedInteractions_tb;

parameter  DataByteWidth_n    = 5'd18;  //width of the memories containing neigboring box data, i.e., coordinates and meta-data
parameter  metaAtomNr_len     = 16;      //length of atom number in meta data; starts at 0. 2bit reserve

parameter  nProteinAtom       = 12;
parameter  DDR3_ADDR_WIDTH    = 29; 
parameter  DDR3_DATA_WIDTH    = 256;
parameter  FF_LENGTH          = 36;      //2 more than maximum number of dihedrall interactions. Latter is floor(256/(nProteinAtom+1))=19. One extra bit is needed
                                         //for [ pairs ] definition of Gromacs force field, which requires extra treatment of non-bonded forces          
parameter  FF_WIDTH           = 6;       //2^FF_WIDTH = Log2(FF_LENGTH)+1
parameter  nCLOSEATOM         = 21;      //maximum number of closeAtoms, which is floor(256/(nProteinAtom+1)). 21 is sufficient for villin headpiece; can be increased to maximum 32                                         
parameter  CLOSEATOM_WIDTH    = 5;        //CLOSEATOM_WIDTH=Floor(Log2(nCLOSEATOM))+1   



//parameters for water
reg         [16:0]             r0Stretch = 17'd50267;              //17'h10000 corresponds to 1 defined relative to r_ref=rcut/8, range 0...2. With rcut=1.043 and r0=0.1 ->r0=0.767018 * 2^16 
reg         [16:0]             kStretch = 17'd7422;                //17'h04000 corresponds to 1, range 0...8. With dt=1, k=453000 kJ/mol/nm^2  -> 0.453*2^14
reg         [16:0]             phi0Bend = 17'd79714;               //18'h20000 corresponds to 1, range 0...1 mappend onto 0..180°. phi0=109.47  -> phi0=0.60817 * 2^17
reg         [16:0]             kBend = 17'd2836;                   //17'h10000 corresponds to 1/128, range 0..1/64.  k=367.8 kJ/mol. with rcut=1.043 and dt=1fs-> k=3.38098 *10^-4 *128*2^16
reg         [17:0]             k1Dihed=18'h10000,k2Dihed=18'h08000,k3Dihed=18'h04000;



reg [7:0]          state1=1'b0;
reg [9:0]          cnt=1'b0;
reg                MDReset=1'b1;
reg                iHalf       = 1'b0;
reg                start_i2    = 1'b0; 

reg [71+nProteinAtom:0]       dataProteinAtom; 
reg                           dataProteinAtom_valid;
reg [metaAtomNr_len-1:0]   dataHome;
//reg [71+nProteinAtom:0]   dataHome;

//clocks
reg                IOclk       = 1'b0;
reg                CalcClk     = 1'b0; 
reg                clk200MHz   = 1'b0;
always #5        IOclk        = ~IOclk; 
always #2.5      clk200MHz    = ~clk200MHz ;  //2.5
always #1.667    CalcClk      = ~CalcClk ; 





reg [7:0]          cnt1=1'b0;
reg [7:0]          cnt2=1'b0;
reg                             ForceField_rcv=1'b0;
reg  [DDR3_DATA_WIDTH - 1:0]    ForceField_data=1'b0;
reg  [nProteinAtom-1:0]         ForceField_atom=1'b0;
wire                            slowDown;


always @(posedge IOclk) begin
  case(state1) 
    0: begin
      cnt <= cnt + 1'b1;
      if (cnt==10'h20) begin
        state1        <= state1+1;
      end  
    end
    1: begin
       MDReset   <= 1'b0;
       state1     <= state1+1;
    end
    2: begin                                                                //write chain of 4 atoms into ProteinAtom, dihedral phi= 90° and centralbond length 24'h020000 
      dataProteinAtom_valid <= 1'b1;
      dataProteinAtom       <= {11'h1,24'h010000,24'h020000,24'h000000};    
      state1                 <= state1+1;
    end
    3: begin
      dataProteinAtom       <= {11'h2,24'h020000,24'h000000,24'h020000}; 
      state1                <= state1+1;
    end
    4: begin
      dataProteinAtom       <= {11'h3,24'h040000,24'h000000,24'h000000}; 
      state1                <= state1+1;
    end  
    5: begin
      dataProteinAtom       <= {11'h4,24'h050000,24'h000000,24'h020000};  
      state1                <= state1+1;
    end  
    6: begin
      dataProteinAtom       <= {11'h5,24'h070000,24'h070000,24'h070000};   //isololated atom without bond
      state1                <= state1+1;
    end   
    7: begin
      dataProteinAtom_valid <= 1'b0;
      iHalf                 <= ~iHalf;
      state1                <= state1+1;
      cnt2                  <= 1'b0;
      cnt1                  <= 1'b0;
    end
    8: begin                                //write force field data
      cnt2      <= 1'b0;
      state1    <= state1 + 1'b1; 
    end
    9: begin
      cnt2            <= cnt2 + 1'b1;
      ForceField_rcv  <= 1'b1;
      ForceField_atom <= cnt1;
      case (cnt2)
        0: begin                                    //first line lists close atoms                       
          case(cnt1)
            1: ForceField_data <= {16'h4,16'h8003,16'h2}; 
            2: ForceField_data <= {16'h4,16'h3,16'h1};       
            3: ForceField_data <= {16'h4,16'h2,16'h1};      
            4: ForceField_data <= {16'h3,16'h2,16'h1};     
            5: ForceField_data <= {16'h10,16'hf,16'he,16'h800d,16'hc,16'hb,16'ha,16'h8009,16'h8,16'h7,16'h6,16'h8005,16'h4,16'h3,16'h2,16'h8001};                       
            default: ForceField_data <= 1'b0;
          endcase
        end
        1: begin
          case(cnt1)
            5: ForceField_data <= {16'h8015,16'h14,16'h13,16'h12,16'h8011};
            default: ForceField_data <= 1'b0; 
          endcase
        end 
        2: begin
          case(cnt1)
            1: ForceField_data <= {6'b0,k3Dihed,6'b0,k2Dihed,6'b0,k1Dihed,1'b0,5'h3,5'h2,5'h1,1'b0,1'b0,kBend,phi0Bend,6'h2,6'h1,kStretch,r0Stretch,6'h1};    
            2: ForceField_data <= {6'b0,k3Dihed/2,6'b0,k2Dihed/2,6'b0,k1Dihed/2,1'b1,5'h3,5'h2,5'h1,1'b0,1'b0,kBend,phi0Bend,6'h3,6'h2,kStretch,r0Stretch,6'h1};    
            3: ForceField_data <= {6'b0,k3Dihed/4,6'b0,k2Dihed/4,6'b0,k1Dihed/4,1'b1,5'h1,5'h2,5'h3,1'b0,1'b0,kBend,phi0Bend,6'h1,6'h2,kStretch,r0Stretch,6'h2};  
            4: ForceField_data <= {6'b0,k3Dihed/8,6'b0,k2Dihed/8,6'b0,k1Dihed/8,1'b0,5'h1,5'h2,5'h3,1'b0,1'b0,kBend,phi0Bend,6'h2,6'h3,kStretch,r0Stretch,6'h3};    
            5: ForceField_data <= 1'b0;                         
            default: ForceField_data <= 1'b0;
          endcase       
        end
        3: begin
          case(cnt1)
            2: ForceField_data <= {6'b0,k1Dihed,6'b0,k3Dihed,6'b0,k2Dihed,1'b0,5'h1,5'h2,5'h3,1'b1,1'b0,kBend,phi0Bend,6'h1,6'h2,kStretch,r0Stretch,6'h2};    
            3: ForceField_data <= {6'b0,k1Dihed,6'b0,k3Dihed,6'b0,k2Dihed,1'b0,5'h1,5'h2,5'h3,1'b1,1'b0,kBend,phi0Bend,6'h3,6'h2,kStretch,r0Stretch,6'h3};  
            default: ForceField_data <= 1'b0;
          endcase       
        end
        4,7,10,13,16,19,22,25,28: begin
           case(cnt1)
           2: ForceField_data <= {6'b0,k1Dihed,6'b0,k3Dihed,6'b0,k2Dihed,1'b0,5'h3,5'h1,5'h2,88'b0}; 
           3: ForceField_data <= {6'b0,k1Dihed,6'b0,k3Dihed,6'b0,k2Dihed,1'b0,5'h3,5'h1,5'h2,88'b0};   
           default: ForceField_data <= 1'b0;
          endcase 
        end        
        5,8,11,14,17,20,23,26,29: begin
          case(cnt1)
            2: ForceField_data <= {6'b0,k1Dihed,6'b0,k3Dihed,6'b0,k2Dihed,1'b0,5'h2,5'h3,5'h1,88'b0}; 
            3: ForceField_data <= {6'b0,k1Dihed,6'b0,k3Dihed,6'b0,k2Dihed,1'b0,5'h2,5'h3,5'h1,88'b0};  
            default: ForceField_data <= 1'b0;
          endcase         
        end
        6,9,12,15,18,21,24,27,30: begin
          case(cnt1)
            2: ForceField_data <= {6'b0,k1Dihed,6'b0,k3Dihed,6'b0,k2Dihed,1'b0,5'h1,5'h2,5'h3,88'b0};  
            3: ForceField_data <= {6'b0,k1Dihed,6'b0,k3Dihed,6'b0,k2Dihed,1'b0,5'h1,5'h2,5'h3,88'b0};  
            default: ForceField_data <= 1'b0;
          endcase         
        end
        31: begin
          case(cnt1)  
            default: ForceField_data <= 1'b0;
          endcase  
        end
        default: begin
          ForceField_data <= 1'b0; 
        end
      endcase
      state1          <= state1 + 1'b1; 
    end
    10,11,12: begin
      ForceField_rcv <= 1'b0;
      state1         <= state1 + 1'b1; 
    end
    13: begin
      if(cnt2==FF_LENGTH) begin
        state1 <= state1 + 1'b1;
      end else begin
        state1 <= 9;
      end  
    end
    14: begin
      cnt1 <= cnt1 + 1'b1;
      if(cnt1==6) begin
        state1 <= state1 + 1'b1;
        cnt    <= 1'b0;
      end  
      else        state1 <= 8;
    end
    15: begin
      cnt <= cnt + 1'b1;
      if (cnt==10'h60) begin
        state1        <= state1+1;
      end  
    end  
    16: begin
      cnt=1'b0;
      state1          <= state1+1;
    end
    17: begin  
      cnt            <= cnt+1'b1;                                                     //start force calculation
      start_i2       <= 1'b1;
      dataHome       <= 16'h1;    
      state1         <= state1+1;
    end
    18: begin
      start_i2       <= 1'b0;  
      state1         <= state1+1;
    end
    19: begin                                                       
      start_i2       <= 1'b1;
      dataHome       <= 16'h2;     
      state1          <= state1+1;
    end
    20: begin
      start_i2       <= 1'b0;  
      state1          <= state1+1;
    end
    21: begin                                                       
      start_i2       <= 1'b1;
      dataHome       <= 16'h3;    
      state1          <= state1+1;
    end
    22: begin
      start_i2       <= 1'b0;  
      state1          <= state1+1;
    end   
    23: begin                                                       
      start_i2       <= 1'b1;
      dataHome       <= 16'h4;    
      state1          <= state1+1;
    end
    24: begin
      start_i2       <= 1'b0;  
      state1          <= state1+1;
    end
    25: begin                                                       
      start_i2       <= 1'b1;
      dataHome       <= 16'h5;   
      state1          <= state1+1;
    end
    26: begin
      start_i2       <= 1'b0;  
      state1          <= state1+1;
    end
    
    27: begin                                                       
      start_i2       <= 1'b1;
      dataHome       <= 16'h4;   
      state1          <= state1+1;
    end
    28: begin
      start_i2       <= 1'b0;  
      state1          <= state1+1;
    end

    29: begin                                                       
      start_i2       <= 1'b1;
      dataHome       <= 16'h3;   
      state1          <= state1+1;
    end
    30: begin
      start_i2       <= 1'b0;  
      state1          <= state1+1;
    end

   31: begin                                                       
      start_i2       <= 1'b1;
      dataHome       <= 16'h2;   
      state1          <= state1+1;
    end
    32: begin
      start_i2       <= 1'b0;  
      state1          <= state1+1;
    end
    
   33: begin                                                       
      start_i2       <= 1'b1;
      dataHome       <= 16'h1;   
      state1          <= state1+1;
    end
    34: begin
      start_i2       <= 1'b0;  
      state1          <= state1+1;
    end    
    
  endcase
end  



wire        [95:0]    force_Stretch;
BondedInteractions
#(  
.DataByteWidth_n    (DataByteWidth_n),   
.metaAtomNr_len     (metaAtomNr_len),
.nProteinAtom       (nProteinAtom),
.DDR3_DATA_WIDTH    (DDR3_DATA_WIDTH),
.FF_LENGTH          (FF_LENGTH),
.FF_WIDTH           (FF_WIDTH),  
.nCLOSEATOM         (nCLOSEATOM),      
.CLOSEATOM_WIDTH    (CLOSEATOM_WIDTH)             
) BondedInteractions
(
.IOclk                 (IOclk),
.clk200MHz             (clk200MHz),               
.sys_clk               (clk200MHz), 
.MDReset               (MDReset),                   //on IOclk                                           
//input from ReadCommand to write force field data into DDR3 RAM; is new
.ForceField_rcv        (ForceField_rcv),                                                         //commented out for dimer
.ForceField_data       (ForceField_data),
.ForceField_atom       (ForceField_atom),                  
//write into BRAM
.iHalf                 (iHalf),                     //iHalf on IOclk
.dataProteinAtom       (dataProteinAtom),                                                           
.dataProteinAtom_valid (dataProteinAtom_valid),                
//Calculation pipeline                            
.start_i2              (start_i2),                   //on CalcClk
.dataHome              (dataHome),                   ////ATTENTION: HAS CHANGED
.slowDown              (slowDown),
.fifoAllForcesOut      (1'b0),          //trigger output FIFO to send data, on IOclk
 //output of stretch calculation
.forceStretchReady     (),         //force stretch calculation done, on IOclk
.forceStretchFifo      ()            //calculated forces, on IOclk, read out with fifoAllForcesOut,  
);



endmodule
