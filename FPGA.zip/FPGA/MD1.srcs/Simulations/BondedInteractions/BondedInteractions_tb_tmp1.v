`timescale 1ns / 1ps


module BondedInteractions_tb;

parameter  DataByteWidth_n    = 5'd18;  //width of the memories containing neigboring box data, i.e., coordinates and meta-data
parameter  metaAtomNr_len     = 16;      //length of atom number in meta data; starts at 0. 2bit reserve

parameter  nProteinAtom       = 12;
parameter  DDR3_ADDR_WIDTH    = 29; 
parameter  DDR3_DATA_WIDTH    = 256;
parameter  FF_LENGTH          = 36;      //2 more than maximum number of dihedrall interactions. Latter is floor(256/(nProteinAtom+1))=19. One extra bit is needed
                                         //for [ pairs ] definition of Gromacs force field, which requires extra treatment of non-bonded forces          
parameter  FF_WIDTH           = 6;       //2^FF_WIDTH = Log2(FF_LENGTH)+1
parameter  nCLOSEATOM         = 21;      //maximum number of closeAtoms, which is floor(256/(nProteinAtom+1)). 21 is sufficient for villin headpiece; can be increased to maximum 32                                         
parameter  CLOSEATOM_WIDTH    = 5;        //CLOSEATOM_WIDTH=Floor(Log2(nCLOSEATOM))+1   

//reduced paramters to replace DDR3 by BRAM
/*
parameter  nProteinAtom       = 9;
//parameter  DDR3_ADDR_WIDTH    = 12; 
parameter  DDR3_DATA_WIDTH    = 64;
parameter  FF_LENGTH          = 8;      //2 more than maximum number of dihedrall interactions. Latter is floor(256/(nProteinAtom+1))=19. One extra bit is needed
                                         //for [ pairs ] definition of Gromacs force field, which requires extra treatment of non-bonded forces          
parameter  FF_WIDTH           = 3;       //2^FF_WIDTH = Log2(FF_LENGTH)+1
parameter  nCLOSEATOM         = 6;      //maximum number of closeAtoms, which is floor(256/(nProteinAtom+1)). 21 is sufficient for villin headpiece; can be increased to maximum 32                                         
parameter  CLOSEATOM_WIDTH    = 5;        //CLOSEATOM_WIDTH=Floor(Log2(nCLOSEATOM))+1   
*/

reg         [16:0]             r0Stretch = 17'hc000;              //17'h10000 corresponds to 1 defined relative to r_ref=rcut/8, range 0...2. 
reg         [16:0]             kStretch = 17'h5000;                //17'h04000 corresponds to 1, range 0...8. 

reg [7:0]          state1=1'b0;
reg [9:0]          cnt=1'b0;
reg                MDReset=1'b1;
reg                iHalf       = 1'b0;
reg                start_i2    = 1'b0; 

reg [71+nProteinAtom:0]       dataProteinAtom; 
reg                           dataProteinAtom_valid;
//reg [nProteinAtom-1:0]   dataHome;
reg [71+nProteinAtom:0]   dataHome;

//clocks
reg                IOclk       = 1'b0;
reg                CalcClk     = 1'b0; 
reg                clk200MHz   = 1'b0;
always #5        IOclk        = ~IOclk; 
always #2.5      clk200MHz    = ~clk200MHz ;  //2.5
always #1.667    CalcClk      = ~CalcClk ; 





reg [7:0]          cnt1=1'b0;
reg [7:0]          cnt2=1'b0;
reg                             ForceField_rcv=1'b0;
reg  [DDR3_DATA_WIDTH - 1:0]    ForceField_data=1'b0;
reg  [nProteinAtom-1:0]         ForceField_atom=1'b0;
wire                            slowDown;


always @(posedge IOclk) begin
  case(state1) 
    0: begin
      cnt <= cnt + 1'b1;
      if (cnt==10'h20) begin
        state1        <= state1+1;
      end  
    end
    1: begin
       MDReset   <= 1'b0;
       state1     <= state1+1;
    end
    2: begin                                                                //write one "water" into ProteinAtom, angle 90° and bond length 24'h020000 
      dataProteinAtom_valid <= 1'b1;
      dataProteinAtom       <= {11'h4,24'h000100,24'h000000,24'h000000};    
      state1                 <= state1+1;
    end
    3: begin
      dataProteinAtom       <= {11'h5,24'h000000,24'h000000,24'h020000}; 
      state1                <= state1+1;
    end
    4: begin
      dataProteinAtom       <= {11'h6,24'h000000,24'h020000,24'h000000}; 
      state1                <= 6;  //state1+1;
    end
 /*   
    5: begin
      dataProteinAtom       <= {11'h4,24'h001000,24'h001000,24'h001000};   //isololated atom without bond
      state1                <= state1+1;
    end
*/    
    6: begin
      dataProteinAtom_valid <= 1'b0;
      iHalf                 <= ~iHalf;
      state1                <= state1+1;
      cnt2                  <= 1'b0;
      cnt1                  <= 1'b0;
    end
    7,8: begin                                //write force field data
      cnt2      <= 1'b0;
      state1    <= state1 + 1'b1; 
    end
    9: begin
      cnt2            <= cnt2 + 1'b1;
      ForceField_rcv  <= 1'b1;
      ForceField_atom <= cnt1;
      case (cnt2)
        0: begin                                    //first line lists close atoms                       
          case(cnt1)
            1: ForceField_data <= {16'h2,16'h3};    //atoms 2 and 3 are close to atom 1
            2: ForceField_data <= {16'h1,16'h3};    //atoms 1 and 3 are close to atom 2
            3: ForceField_data <= {16'h1,16'h2};    //atoms 1 and 2 are close to atom 3
            4: ForceField_data <= 1'b0;             //atoms 4 has now close atoms
            default: ForceField_data <= 1'b0;
          endcase
        end
        1: begin
          ForceField_data <= 1'b0; 
        end 
        2: begin
          case(cnt1)
            1: ForceField_data <= {kStretch,r0Stretch,6'h1};    //atom 1 is bound to atom'1, where atom'1 is defined in first line, i.e. atom3
            2: ForceField_data <= {kStretch,r0Stretch,6'h2};    //atom 2 is bound to atom'2
            3: ForceField_data <= {kStretch,r0Stretch,6'h2};    //atom 3 is bound to atom'2
            4: ForceField_data <= 1'b0;                         //atom4 has no close neighbors
            default: ForceField_data <= 1'b0;
          endcase       
        end
        3: begin
          case(cnt1)
            1: ForceField_data <= {kStretch,r0Stretch,6'h2};    //atom 1 is bound to atom'2, where'2 is defined in first line, i.e. atom2
            default: ForceField_data <= 1'b0;
          endcase       
        end
        default: begin
          ForceField_data <= 1'b0; 
        end
      endcase
      state1          <= state1 + 1'b1; 
    end
    10,11,12: begin
      ForceField_rcv <= 1'b0;
      state1         <= state1 + 1'b1; 
    end
    13: begin
      if(cnt2==FF_LENGTH) begin
        state1 <= state1 + 1'b1;
      end else state1 <= 9;
    end
    14: begin
      cnt1 <= cnt1 + 1'b1;
      if(cnt1==4) begin
        state1 <= state1 + 1'b1;
        cnt    <= 1'b0;
      end  
      else        state1 <= 7;
    end
    15: begin
      cnt <= cnt + 1'b1;
      if (cnt==10'h60) begin
        state1        <= state1+1;
      end  
    end  
    16: begin
      cnt=1'b0;
      state1          <= state1+1;
    end
    17: begin  
      cnt            <= cnt+1'b1;                                                     //start force calculation
      start_i2       <= 1'b1;
 //     dataHome       <= {11'h1};    //for atom1; coordinates will be discarded
      dataHome       <= {11'h4,24'h000100,24'h000000,24'h000000};  
      state1         <= state1+1;
    end
    18: begin
      start_i2       <= 1'b0;  
      state1         <= state1+1;
    end
    19: begin                                                       
      start_i2       <= 1'b1;
 //     dataHome       <= {11'h2};    //for atom2
      dataHome       <= {11'h5,24'h000000,24'h000000,24'h020000};   
      state1          <= state1+1;
    end
    20: begin
      start_i2       <= 1'b0;  
      state1          <= state1+1;
    end
    21: begin                                                       
      start_i2       <= 1'b1;
//      dataHome       <= {11'h3};    //for atom3
      dataHome       <= {11'h6,24'h000000,24'h020000,24'h000000}; 
      state1          <= state1+1;
    end
    22: begin
      start_i2       <= 1'b0;  
      state1          <= state1+1;
    end
/*    
    23: begin                                                       
      start_i2       <= 1'b1;
      dataHome       <= {11'h4};    //for atom4
      state1          <= state1+1;
    end
    24: begin
      start_i2       <= 1'b0;  
      state1          <= state1+1;
    end
*/ 
    
    
  endcase
end  



wire        [95:0]    force_Stretch;
BondedInteractions
#(  
.DataByteWidth_n    (DataByteWidth_n),   
.metaAtomNr_len     (metaAtomNr_len),
.nProteinAtom       (nProteinAtom),
.DDR3_DATA_WIDTH    (DDR3_DATA_WIDTH),
.FF_LENGTH          (FF_LENGTH),
.FF_WIDTH           (FF_WIDTH),  
.nCLOSEATOM         (nCLOSEATOM),      
.CLOSEATOM_WIDTH    (CLOSEATOM_WIDTH)             
) BondedInteractions
(
.IOclk                 (IOclk),
.clk200MHz             (clk200MHz),               
.sys_clk               (clk200MHz), 
.MDReset               (MDReset),                   //on IOclk                                           
//input from ReadCommand to write force field data into DDR3 RAM; is new
.ForceField_rcv        (ForceField_rcv),                                                         //commented out for dimer
.ForceField_data       (ForceField_data),
.ForceField_atom       (ForceField_atom),                  
//write into BRAM
.iHalf                 (iHalf),                     //iHalf on IOclk
.dataProteinAtom       (dataProteinAtom),                                                           
.dataProteinAtom_valid (dataProteinAtom_valid),                
//Calculation pipeline                            
.start_i2              (start_i2),                   //on CalcClk
.dataHome              (dataHome),                   ////ATTENTION: HAS CHANGED
.slowDown              (slowDown),
.fifoAllForcesOut      (1'b0),          //trigger output FIFO to send data, on IOclk
 //output of stretch calculation
.forceStretchReady     (),         //force stretch calculation done, on IOclk
.forceStretchFifo      ()            //calculated forces, on IOclk, read out with fifoAllForcesOut,  
);



endmodule
