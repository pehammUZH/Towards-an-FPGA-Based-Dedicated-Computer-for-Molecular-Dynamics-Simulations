`timescale 1ns / 1ps

module BroadcastAtom_testbench();

parameter DataByteWidth   =5'd27;
parameter DataByteWidth_n =5'd18;
parameter nBox            =5'd27;
parameter nSide           =4'd4;           //will reveal nSide**3 atoms
parameter dq              =(2**22)/nSide;    
parameter delayETH        =86;              //two request of DataHome will bunch together
parameter nBlock          =50;             //length of a block to be sent at once by UDP; maximum is 1.5kByte
parameter ForceLUTWidth   = 9;   //length of Force LUT data line

//input/output for MD claculation
reg                             InitCalc =1'b0; 
reg  [15:0]                     nstep    =16'd4; 
wire [15:0]                     istep;



reg                              e_clk      = 1'b0;
reg                              IOclk      = 1'b0;
reg                              CalcClk    = 1'b0;
assign                           e3_clk   = e_clk;
assign                           e4_clk   = e_clk;
assign                           e1_clk   = e_clk;

reg  [DataByteWidth*8-1:0]       DataIn     = 1'b0;
reg                              DataIn_req = 1'b0;
reg                              nAtomReset = 1'b0;




//***********************************************************************
//clocks
always #4     e_clk = ~e_clk; 
always #5     IOclk = ~IOclk; 
always #1.786  CalcClk = ~CalcClk; 


//write data into boxes
reg   [2:0]   ix=1'b0,iy=1'b0,iz=1'b0;
reg   [7:0]   iAll=1'b0;
reg   [4:0]   wait_cnt=1'b0;
wire [23:0]   x=ix*dq+dq/2;
//wire [23:0]   x= (ix==2&&iy==1&&iz==0) ? ix*dq+dq/2+2**21 : ix*dq+dq/2;  //outside home box
wire [23:0]   y=iy*dq+dq/2;
wire [23:0]   z=iz*dq+dq/2;
reg  [3:0]    testState=1'b0;
wire [23:0]   vx=24'h700000;
wire [23:0]   vy=24'h0;
wire [23:0]   vz=24'h0;
reg  [15:0]   cntAll=1'b0;

always @(posedge e_clk) cntAll <= cntAll + 1'b1;

always @(posedge IOclk) begin
  case(testState)
  0: begin
    wait_cnt <= wait_cnt +1'b1; 
    nAtomReset <= (wait_cnt==5'h1e);  //some of the signals shouldn't be too early, since they then come before some internal reset
    DataIn_req  <= 1'b0;
    if(wait_cnt==5'h1f) testState <= 4'd1;
  end    
  1: begin
    wait_cnt <= wait_cnt +1'b1;
    DataIn_req    <= 1'b0;
    if(wait_cnt==5'h1f) begin
      DataIn_req <= 1'b1;
      DataIn     <= {vz,vy,vx,64'b0,iAll,z,y,x}; 
      iAll       <= iAll+1'b1;
      ix         <= ix+1'b1;
      if (ix<nSide-1'b1) ix <= ix+1'b1;
      else begin
        ix <= 1'b0;
        if (iy<nSide-1'b1) iy <= iy+1'b1;
        else begin
          iy <= 1'b0;
          if (iz<nSide-1'b1) iz <= iz+1'b1;
          else begin
            iz <= 1'b0;
            testState <= 4'd2;
          end  
        end
      end 
    end     
  end
  2: begin
    DataIn_req    <= 1'b0; 
    if(~Broadcast_bussy) testState <= 4'd3;
  end
  3: begin
    InitCalc    <= 1'b1; 
    testState   <= 4'd4;
  end
  4: begin
    InitCalc    <= 1'b0; 
  end
  default: ;  
endcase
end

//*********************************cross-connect nodes
reg                             AllBussy;
always @(*) begin 
  AllBussy           <= SyncOut||Broadcast_bussy;
end  


//***************************************Node 1*********************************
wire [7:0]                       e3_txd, e4_txd;
wire                             e3_tx_en, e4_tx_en;
reg  [7:0]                       e3_rxd, e4_rxd;
reg                              e3_rx_dv,e4_rx_dv;
wire [DataByteWidth_n*8-1:0]     gtp0_data_recv;
wire [DataByteWidth_n*8-1:0]     gtp1_data_recv;
wire [DataByteWidth_n*8-1:0]     gtp2_data_recv;
wire [DataByteWidth_n*8-1:0]     gtp3_data_recv;
wire [DataByteWidth_n*8-1:0]     e3_data_recv;
wire [DataByteWidth_n*8-1:0]     e4_data_recv;
reg  [DataByteWidth_n*8-1:0]     gtp0_data_recv_cp;
reg  [DataByteWidth_n*8-1:0]     gtp1_data_recv_cp;
reg  [DataByteWidth_n*8-1:0]     gtp2_data_recv_cp;
reg  [DataByteWidth_n*8-1:0]     gtp3_data_recv_cp;
reg  [DataByteWidth_n*8-1:0]     e3_data_recv_cp;
reg  [DataByteWidth_n*8-1:0]     e4_data_recv_cp;
wire [(DataByteWidth)*8-1:0]     DataHome;
wire [nBox-1:0]                  data_valid;
reg  [(DataByteWidth)*8-1:0]     DataHome_cp;
reg  [nBox-1:0]                  data_valid_cp;
wire [DataByteWidth*8-1:0]       newData;
wire                             newDataReady;
reg  [DataByteWidth*8-1:0]       newData_cp;
reg                              newDataReady_cp;

always @(*) begin                 //is needed to connect MDmachine to BroadcastAtom
  data_valid_cp      <= data_valid;
  DataHome_cp        <= DataHome;
  gtp0_data_recv_cp  <= gtp0_data_recv;
  gtp1_data_recv_cp  <= gtp1_data_recv;
  gtp2_data_recv_cp  <= gtp2_data_recv;
  gtp3_data_recv_cp  <= gtp3_data_recv;
  e3_data_recv_cp    <= e3_data_recv;
  e4_data_recv_cp    <= e4_data_recv;
  newData_cp         <= newData;
  newDataReady_cp    <= newDataReady;
  e3_rx_dv           <= e4_tx_en;
  e3_rxd             <= e4_txd;
  e4_rx_dv           <= e3_tx_en;
  e4_rxd             <= e3_txd;
end

BroadcastAtom
#(
.DataByteWidth  (DataByteWidth),
.nBox           (nBox)
) BroadcastAtom
(
    .IOclk                       (IOclk),  
    .ErrorReset                  (1'b0),
    .ResetStart                  (1'b0),
//ETH connections
    .e3_clk                      (e3_clk), 
    .e3_reset                    (),
    .e3_tx_en                    (e3_tx_en),          //ETH transmit enable
    .e3_txd                      (e3_txd),            //ETH transmit data
    .e3_rx_dv                    (e3_rx_dv),          //ETH receive data valid 
    .e3_rxd                      (e3_rxd),            //ETH receive data
    .e3_mdc                      (e3_mdc),            //mdc interface
    .e3_mdio                     (e3_mdio),           //mdio interface
    .speed3                      (),            //ethernet speed 00: no link, 01: 10M 02:100M 11:1000M
    .e4_clk                      (e4_clk),
    .e4_reset                    (),
    .e4_tx_en                    (e4_tx_en),          //ETH transmit enable
    .e4_txd                      (e4_txd),            //ETH transmit data
    .e4_rx_dv                    (e4_rx_dv),          //ETH receive data valid 
    .e4_rxd                      (e4_rxd),            //ETH receive data
    .e4_mdc                      (),            //mdc interface
    .e4_mdio                     (),           //mdio interface
    .speed4                      (),            //ethernet speed 00: no link, 01: 10M 02:100M 11:1000M
    .ETH_error                   (),         //={e4_rx_error,e4_tx_error,e3_rx_error,e3_tx_error}
    .ReNegotiateETH34            (1'b0),
//GTP connections
    .Q0_CLK0_GTREFCLK_PAD_N_IN   (),  //GTP clock
    .Q0_CLK0_GTREFCLK_PAD_P_IN   (e_clk),  //GTP clock
    .RXN_IN                      (),           //GTP rx pins
    .RXP_IN                      (),           //GTP rx pins  
    .TXN_OUT                     (),          //GTP tx pins
    .TXP_OUT                     (),         //GTP tx pins
    .gtp_error                   (),        //={gtp_rx_error,gtp_tx_error}
//inputs   
    .DataIn_req                  (DataIn_req),       //data to be broadcasted ready    
    .DataIn                      (DataIn),           //data to be broadcasted          
    .newData                     (newData_cp),
    .newDataReady                (newDataReady_cp),
//output results
    .Broadcast_bussy             (Broadcast_bussy),
    .data_valid                  (data_valid),
    .DataHome                    (DataHome), 
    .gtp0_data_recv_short        (gtp0_data_recv),
    .gtp1_data_recv_short        (gtp1_data_recv),
    .gtp2_data_recv_short        (gtp2_data_recv),
    .gtp3_data_recv_short        (gtp3_data_recv),
    .e3_data_recv_short          (e3_data_recv),
    .e4_data_recv_short          (e4_data_recv),
    .OutOfRangeMuxError          ()
);



MDmachine
#(
.DataByteWidth   (DataByteWidth),
.DataByteWidth_n (DataByteWidth_n),
.nBox            (nBox)
) MDmachine
(
 .IOclk            (IOclk),  
 .CalcClk          (CalcClk),
 .MDReset          (1'b0),
//inputs from BraodcastAtom to write data into boxes
 .data_valid       (data_valid_cp),
 .DataHome         (DataHome_cp),       
 .gtp0_data_recv   (gtp0_data_recv_cp), 
 .gtp1_data_recv   (gtp1_data_recv_cp), 
 .gtp2_data_recv   (gtp2_data_recv_cp), 
 .gtp3_data_recv   (gtp3_data_recv_cp), 
 .e3_data_recv     (e3_data_recv_cp),   
 .e4_data_recv     (e4_data_recv_cp),  
 .overflowError    (),
//input that writes into Force LUTs 
 .wrForceLUT       (1'b0),    
 .dataForceLUT     (1'b0),  
 .adrForceLUT      (1'b0),   
 .selForceLUT      (1'b0),    
 //input/output for MD claculation
 .nAtom0           (),               
 .nAtomResetExt    (nAtomReset),           
 .AllBussy         (AllBussy),  
 .InitCalc         (InitCalc),
 .nstep            (nstep), 
 .istepOut         (),
 .SyncOut          (SyncOut),              
 .CalcBussy        (),   
 .errorRxReset     (),    
 .errorRxSync      (1'b0),               
 .newData          (newData),
 .newDataReady     (newDataReady),
//input/output to write content of boxes to MAC     
 .SendMacAdr       (1'b0),   
 .SendMacBox       (1'b0),
 .DataSendMac      ()
);




endmodule
