`timescale 1ns / 1ps

module BroadcastAtom_testbench();

parameter DataByteWidth   =5'd27;
parameter DataByteWidth_n =5'd18;
parameter nBox            =5'd27;
parameter nSide_1           =4'd4;           //will reveal nSide**3 atoms
parameter nSide_2           =4'd4;           //will reveal nSide**3 atoms
parameter nSide_3           =4'd4;           //will reveal nSide**3 atoms
parameter dq_1              =(2**22)/nSide_1;  
parameter dq_2              =(2**22)/nSide_2;  
parameter dq_3              =(2**22)/nSide_3;    
parameter delayETH        =86;              //two request of DataHome will bunch together
parameter nBlock          =50;             //length of a block to be sent at once by UDP; maximum is 1.5kByte
parameter ForceLUTWidth   = 9;   //length of Force LUT data line

//input/output for MD claculation
reg                             InitCalc =1'b0; 
reg  [15:0]                     nstep    =16'd1; 
wire [15:0]                     istep;



reg                              e_clk      = 1'b0;
reg                              IOclk      = 1'b0;
reg                              CalcClk    = 1'b0;
assign                           e3_clk   = e_clk;
assign                           e4_clk   = e_clk;
assign                           e1_clk   = e_clk;

reg  [DataByteWidth*8-1:0]       DataIn     = 1'b0;
reg                              DataIn_req_1 = 1'b0;
reg                              DataIn_req_2 = 1'b0;
reg                              DataIn_req_3 = 1'b0;
reg                              nAtomReset = 1'b0;

wire                 SyncOut_1;
wire                 Broadcast_bussy_1;
wire                 SyncOut_2;
wire                 Broadcast_bussy_2;
wire                 SyncOut_3;
wire                 Broadcast_bussy_3;
reg                  AllBussy;

reg [71:0]         dataForceLUT=1'b0;
reg                wrForceLUT=1'b0;


//************************************************************************

integer in,i,out;
integer dat0,dat1,dat2,dat3,dat4,dat5,dat6,dat7,dat8;
reg [71:0] LUTforce [0:511];

initial begin
  $display("Open file with LUT of forces");
  in = $fopen("../../../../../../LUTforce.dat","r");
  out= $fopen("../../../../../../forceout.dat","w");

  for(i=0;i<512;i=i+1) begin
    $fscanf(in,"%x %x %x %x %x %x %x %x %x",dat0,dat1,dat2,dat3,dat4,dat5,dat6,dat7,dat8);
 //   $display("%h",{dat0[3:0],dat1[7:0],dat2[7:0],dat3[7:0],dat4[7:0]});
    LUTforce[i] <= {dat0[7:0],dat1[7:0],dat2[7:0],dat3[7:0],dat4[7:0],dat5[7:0],dat6[7:0],dat7[7:0],dat8[7:0]};
  end   
  $fclose(in);
end

//***********************************************************************
always @(*) begin 
  AllBussy           <= SyncOut_1||SyncOut_2||SyncOut_3||Broadcast_bussy_1||Broadcast_bussy_2||Broadcast_bussy_3;
end  


//clocks
always #4     e_clk = ~e_clk; 
always #5     IOclk = ~IOclk; 
always #1.786   CalcClk = ~CalcClk; //1.786


//write data into boxes
reg   [2:0]   ix=1'b0,iy=1'b0,iz=1'b0;
reg   [7:0]   iAll=1'b0;
reg   [4:0]   wait_cnt=1'b0;
reg   [23:0]   x;
reg   [23:0]   y;
reg   [23:0]   z;
reg  [3:0]    testState=1'b0,testState2=1'b0;
wire [23:0]   vx=24'h0; 
wire [23:0]   vy=24'h0;
wire [23:0]   vz=24'h0;
wire [23:0]   vz_mv=24'hb80000;
reg  [15:0]   cntAll=1'b0;
reg  [8:0]    ForceCnt=1'b0;

//write forece LUT
always @(posedge IOclk) begin
  case(testState2)
  0: begin
    ForceCnt <= ForceCnt +1'b1; 
    if(ForceCnt==5'h1f) begin
      ForceCnt          <= 1'b0;
      wrForceLUT   <= 1'b1;
      dataForceLUT <= LUTforce[0];
      testState2 <= 4'd1;  
    end  
  end    
  1: begin
      ForceCnt          <= ForceCnt + 1'b1;
      dataForceLUT <= LUTforce[ForceCnt+1'b1];
      if (ForceCnt==10'h1ff) begin
        testState2 <=  4'd2;
        wrForceLUT   <= 1'b0;
      end  
  end
  endcase
end


always @(posedge IOclk) begin
  case(testState)
  0: begin
    wait_cnt <= wait_cnt +1'b1; 
    nAtomReset <= (wait_cnt==5'h1e);  //some of the signals shouldn't be too early, since they then come before some internal reset
    DataIn_req_1  <= 1'b0;
    DataIn_req_2  <= 1'b0;
    DataIn_req_3  <= 1'b0;
    ix            <= 0;
    iy            <= 0;
    iz            <= 2;
    x             <= dq_1/2;
    y             <= dq_1/2;
    z             <= 5*dq_1/2;   
    if(wait_cnt==5'h1f) begin
      testState <= 4'd1;  
    end  
  end    
  1: begin
    wait_cnt <= wait_cnt +1'b1;
    DataIn_req_1    <= 1'b0;
    if(wait_cnt==5'h1f) begin
      DataIn_req_1 <= 1'b1;
      DataIn     <= {vz,vy,vx,64'b0,iAll,z,y,x}; 
      iAll       <= iAll+1'b1;
      if (ix<nSide_1-1'b1) begin
        ix <= ix+1'b1;
        x  <= x+dq_1;
      end else begin
        ix <= 1'b0;
        x  <= dq_1/2;
        if (iy<nSide_1-1'b1) begin 
          iy <= iy+1'b1;
          y  <= y+dq_1;
        end else begin
          iy <= 1'b0;
          y  <= dq_1/2;
          if (iz<nSide_1-1'b1) begin
            iz <= iz+1'b1;
            z  <= z+dq_1;
          end else begin
            testState <= 4'd2;
          end  
        end
      end 
    end     
  end
  2: begin
    DataIn_req_1    <= 1'b0; 
    x             <= dq_2/2;
    y             <= dq_2/2;
    z             <= dq_2/2;         
    ix            <= 1'b0;
    iy            <= 1'b0;
    iz            <= 1'b0;   
    testState     <= 4'd3;
  end
  3: begin
    wait_cnt <= wait_cnt +1'b1;
    DataIn_req_2    <= 1'b0;
    if(wait_cnt==5'h1f) begin
      DataIn_req_2 <= 1'b1;
 //     if(ix==0&&iy==0&&iz==0)
 //        DataIn     <= {vz_mv,vy,vx,64'b0,iAll,z,y,x}; //vz_mv
 //     else    
         DataIn     <= {vz,vy,vx,64'b0,iAll,z,y,x}; 
      iAll       <= iAll+1'b1;
      if (ix<nSide_2-1'b1) begin
        ix <= ix+1'b1;
        x  <= x+dq_2;
      end else begin
        ix <= 1'b0;
        x  <= dq_2/2;
        if (iy<nSide_2-2'b1) begin 
          iy <= iy+1'b1;
          y  <= y+dq_2;
        end else begin
          iy <= 1'b0;
          y  <= dq_2/2;
          if (iz<nSide_2-1'b1) begin
            iz <= iz+1'b1;
            z  <= z+dq_2;
          end else begin
            testState <= 4'd4;
          end  
        end
      end 
    end 
  end 
  4: begin
    DataIn_req_2    <= 1'b0; 
    x             <= dq_3/2;
    y             <= dq_3/2;
    z             <= dq_3/2;
    ix            <= 0;
    iy            <= 0;
    iz            <= 2;   
    testState     <= 4'd5;
  end
  5: begin
    wait_cnt <= wait_cnt +1'b1;
    DataIn_req_3    <= 1'b0;
    if(wait_cnt==5'h1f) begin
      DataIn_req_3 <= 1'b1;
      DataIn     <= {vz,vy,vx,64'b0,iAll,z,y,x}; 
      iAll       <= iAll+1'b1;
      if (ix<nSide_3-1'b1) begin
        ix <= ix+1'b1;
        x  <= x+dq_3;
      end else begin
        ix <= 1'b0;
        x  <= dq_3/2;
        if (iy<nSide_3-2'b1) begin 
          iy <= iy+1'b1;
          y  <= y+dq_3;
        end else begin
          iy <= 1'b0;
          y  <= dq_3/2;
          if (iz<nSide_3-1'b1) begin
            iz <= iz+1'b1;
            z  <= z+dq_3;
          end else begin
            testState <= 4'd6;
          end   
        end
      end 
    end 
  end 
 6: begin
    DataIn_req_3    <= 1'b0; 
    if(~(Broadcast_bussy_1||Broadcast_bussy_2||Broadcast_bussy_3)) testState <= 4'd7;
  end
  7: begin
    InitCalc    <= 1'b1; 
    testState   <= 4'd8;
  end
  8: begin
    InitCalc    <= 1'b0; 
    testState   <= 4'd9;
    wait_cnt    <= 1'b0;
  end
  9: begin
    wait_cnt <= wait_cnt +1'b1; 
    if(wait_cnt==5'h1f) testState <= 4'd10;
  end
  10: begin
  //  if(istep==nstep&&~AllBussy)  testState   <= 4'd0;   //restart
  end
  
  default: ;  
endcase
end

//*********************************cross-connect nodes**************************************
wire [7:0]                       e3_txd_1;
wire [7:0]                       e4_txd_1;
wire                             e3_tx_en_1;
wire                             e4_tx_en_1;
reg  [7:0]                       e3_rxd_1;
reg  [7:0]                       e4_rxd_1;
reg                              e3_rx_dv_1;
reg                              e4_rx_dv_1;

wire [7:0]                       e3_txd_2;
wire [7:0]                       e4_txd_2;
wire                             e3_tx_en_2;
wire                             e4_tx_en_2;
reg  [7:0]                       e3_rxd_2;
reg  [7:0]                       e4_rxd_2;
reg                              e3_rx_dv_2;
reg                              e4_rx_dv_2;

wire [7:0]                       e3_txd_3;
wire [7:0]                       e4_txd_3;
wire                             e3_tx_en_3;
wire                             e4_tx_en_3;
reg  [7:0]                       e3_rxd_3;
reg  [7:0]                       e4_rxd_3;
reg                              e3_rx_dv_3;
reg                              e4_rx_dv_3;



always @(posedge e_clk)  begin            
  e4_rx_dv_2           <= e3_tx_en_1;
  e4_rxd_2             <= e3_txd_1;
  e3_rx_dv_1           <= e4_tx_en_2;
  e3_rxd_1             <= e4_txd_2;
  
  e4_rx_dv_3           <= e3_tx_en_2;
  e4_rxd_3             <= e3_txd_2;
  e3_rx_dv_2           <= e4_tx_en_3;
  e3_rxd_2             <= e4_txd_3;
 
  e4_rx_dv_1           <= e3_tx_en_3;
  e4_rxd_1             <= e3_txd_3;
  e3_rx_dv_3           <= e4_tx_en_1;
  e3_rxd_3             <= e4_txd_1;
end

//***************************************Node 1*******************************************************
wire [DataByteWidth_n*8-1:0]     gtp0_data_recv_1;
wire [DataByteWidth_n*8-1:0]     gtp1_data_recv_1;
wire [DataByteWidth_n*8-1:0]     gtp2_data_recv_1;
wire [DataByteWidth_n*8-1:0]     gtp3_data_recv_1;
wire [DataByteWidth_n*8-1:0]     e3_data_recv_1;
wire [DataByteWidth_n*8-1:0]     e4_data_recv_1;
reg  [DataByteWidth_n*8-1:0]     gtp0_data_recv_1_cp;
reg  [DataByteWidth_n*8-1:0]     gtp1_data_recv_1_cp;
reg  [DataByteWidth_n*8-1:0]     gtp2_data_recv_1_cp;
reg  [DataByteWidth_n*8-1:0]     gtp3_data_recv_1_cp;
reg  [DataByteWidth_n*8-1:0]     e3_data_recv_1_cp;
reg  [DataByteWidth_n*8-1:0]     e4_data_recv_1_cp;
wire [(DataByteWidth)*8-1:0]     DataHome_1;
wire [nBox-1:0]                  data_valid_1;
reg  [(DataByteWidth)*8-1:0]     DataHome_1_cp;
reg  [nBox-1:0]                  data_valid_1_cp;
wire [DataByteWidth*8-1:0]       newData_1;
wire                             newDataReady_1;
reg  [DataByteWidth*8-1:0]       newData_1_cp;
reg                              newDataReady_1_cp;

always @(*) begin                 //is needed to connect MDmachine to BroadcastAtom
  data_valid_1_cp      <= data_valid_1;
  DataHome_1_cp        <= DataHome_1;
  gtp0_data_recv_1_cp  <= gtp0_data_recv_1;
  gtp1_data_recv_1_cp  <= gtp1_data_recv_1;
  gtp2_data_recv_1_cp  <= gtp2_data_recv_1;
  gtp3_data_recv_1_cp  <= gtp3_data_recv_1;
  e3_data_recv_1_cp    <= e3_data_recv_1;
  e4_data_recv_1_cp    <= e4_data_recv_1;
  newData_1_cp         <= newData_1;
  newDataReady_1_cp    <= newDataReady_1;
end

BroadcastAtom
#(
.DataByteWidth  (DataByteWidth),
.nBox           (nBox)
) BroadcastAtom1
(
    .IOclk                       (IOclk),  
    .ErrorReset                  (1'b0),
    .ResetStart                  (1'b0),
//ETH connections
    .e3_clk                      (e3_clk), 
    .e3_reset                    (),
    .e3_tx_en                    (e3_tx_en_1),          //ETH transmit enable
    .e3_txd                      (e3_txd_1),            //ETH transmit data
    .e3_rx_dv                    (e3_rx_dv_1),          //ETH receive data valid 
    .e3_rxd                      (e3_rxd_1),            //ETH receive data
    .e3_mdc                      (),            //mdc interface
    .e3_mdio                     (),           //mdio interface
    .speed3                      (),            //ethernet speed 00: no link, 01: 10M 02:100M 11:1000M
    .e4_clk                      (e4_clk),
    .e4_reset                    (),
    .e4_tx_en                    (e4_tx_en_1),          //ETH transmit enable
    .e4_txd                      (e4_txd_1),            //ETH transmit data
    .e4_rx_dv                    (e4_rx_dv_1),          //ETH receive data valid 
    .e4_rxd                      (e4_rxd_1),            //ETH receive data
    .e4_mdc                      (),            //mdc interface
    .e4_mdio                     (),           //mdio interface
    .speed4                      (),            //ethernet speed 00: no link, 01: 10M 02:100M 11:1000M
    .ETH_error                   (),         //={e4_rx_error,e4_tx_error,e3_rx_error,e3_tx_error}
    .ReNegotiateETH34            (1'b0),
//GTP connections
    .Q0_CLK0_GTREFCLK_PAD_N_IN   (),  //GTP clock
    .Q0_CLK0_GTREFCLK_PAD_P_IN   (e_clk),  //GTP clock
    .RXN_IN                      (),           //GTP rx pins
    .RXP_IN                      (),           //GTP rx pins  
    .TXN_OUT                     (),          //GTP tx pins
    .TXP_OUT                     (),         //GTP tx pins
    .gtp_error                   (),        //={gtp_rx_error,gtp_tx_error}
//inputs   
    .DataIn_req                  (DataIn_req_1),       //data to be broadcasted ready    
    .DataIn                      (DataIn),           //data to be broadcasted          
    .newData                     (newData_1_cp),
    .newDataReady                (newDataReady_1_cp),
//output results
    .Broadcast_bussy             (Broadcast_bussy_1),
    .data_valid                  (data_valid_1),
    .DataHome                    (DataHome_1), 
    .gtp0_data_recv_short        (gtp0_data_recv_1),
    .gtp1_data_recv_short        (gtp1_data_recv_1),
    .gtp2_data_recv_short        (gtp2_data_recv_1),
    .gtp3_data_recv_short        (gtp3_data_recv_1),
    .e3_data_recv_short          (e3_data_recv_1),
    .e4_data_recv_short          (e4_data_recv_1),
    .OutOfRangeMuxError          ()
);



MDmachine
#(
.DataByteWidth   (DataByteWidth),
.DataByteWidth_n (DataByteWidth_n),
.nBox            (nBox)
) MDmachine1
(
 .IOclk            (IOclk),  
 .CalcClk          (CalcClk),
 .MDReset          (1'b0),
//inputs from BraodcastAtom to write data into boxes
 .data_valid       (data_valid_1_cp),
 .DataHome         (DataHome_1_cp),       
 .gtp0_data_recv   (gtp0_data_recv_1_cp), 
 .gtp1_data_recv   (gtp1_data_recv_1_cp), 
 .gtp2_data_recv   (gtp2_data_recv_1_cp), 
 .gtp3_data_recv   (gtp3_data_recv_1_cp), 
 .e3_data_recv     (e3_data_recv_1_cp),   
 .e4_data_recv     (e4_data_recv_1_cp),  
 .overflowError    (),
//input that writes into Force LUTs 
 .wrForceLUT       (wrForceLUT),    
 .dataForceLUT     (dataForceLUT),  
 .adrForceLUT      (ForceCnt),   
 .selForceLUT      (1'b0),    
 //input/output for MD claculation
 .nAtom0           (),               
 .nAtomResetExt    (nAtomReset),           
 .AllBussy         (AllBussy),  
 .InitCalc         (InitCalc),
 .nstep            (nstep), 
 .istepOut         (istep),
 .SyncOut          (SyncOut_1),              
 .CalcBussy        (),   
 .errorRxReset     (),    
 .errorRxSync      (1'b0),               
 .newData          (newData_1),
 .newDataReady     (newDataReady_1),
//input/output to write content of boxes to MAC     
 .SendMacAdr       (1'b0),   
 .SendMacBox       (1'b0),
 .DataSendMac      ()
);


//***************************************Node 2*******************************************************
wire [DataByteWidth_n*8-1:0]     gtp0_data_recv_2;
wire [DataByteWidth_n*8-1:0]     gtp1_data_recv_2;
wire [DataByteWidth_n*8-1:0]     gtp2_data_recv_2;
wire [DataByteWidth_n*8-1:0]     gtp3_data_recv_2;
wire [DataByteWidth_n*8-1:0]     e3_data_recv_2;
wire [DataByteWidth_n*8-1:0]     e4_data_recv_2;
reg  [DataByteWidth_n*8-1:0]     gtp0_data_recv_2_cp;
reg  [DataByteWidth_n*8-1:0]     gtp1_data_recv_2_cp;
reg  [DataByteWidth_n*8-1:0]     gtp2_data_recv_2_cp;
reg  [DataByteWidth_n*8-1:0]     gtp3_data_recv_2_cp;
reg  [DataByteWidth_n*8-1:0]     e3_data_recv_2_cp;
reg  [DataByteWidth_n*8-1:0]     e4_data_recv_2_cp;
wire [(DataByteWidth)*8-1:0]     DataHome_2;
wire [nBox-1:0]                  data_valid_2;
reg  [(DataByteWidth)*8-1:0]     DataHome_2_cp;
reg  [nBox-1:0]                  data_valid_2_cp;
wire [DataByteWidth*8-1:0]       newData_2;
wire                             newDataReady_2;
reg  [DataByteWidth*8-1:0]       newData_2_cp;
reg                              newDataReady_2_cp;

always @(*) begin                 //is needed to connect MDmachine to BroadcastAtom
  data_valid_2_cp      <= data_valid_2;
  DataHome_2_cp        <= DataHome_2;
  gtp0_data_recv_2_cp  <= gtp0_data_recv_2;
  gtp1_data_recv_2_cp  <= gtp1_data_recv_2;
  gtp2_data_recv_2_cp  <= gtp2_data_recv_2;
  gtp3_data_recv_2_cp  <= gtp3_data_recv_2;
  e3_data_recv_2_cp    <= e3_data_recv_2;
  e4_data_recv_2_cp    <= e4_data_recv_2;
  newData_2_cp         <= newData_2;
  newDataReady_2_cp    <= newDataReady_2;
end

BroadcastAtom
#(
.DataByteWidth  (DataByteWidth),
.nBox           (nBox)
) BroadcastAtom2
(
    .IOclk                       (IOclk),  
    .ErrorReset                  (1'b0),
    .ResetStart                  (1'b0),
//ETH connections
    .e3_clk                      (e3_clk), 
    .e3_reset                    (),
    .e3_tx_en                    (e3_tx_en_2),          //ETH transmit enable
    .e3_txd                      (e3_txd_2),            //ETH transmit data
    .e3_rx_dv                    (e3_rx_dv_2),          //ETH receive data valid 
    .e3_rxd                      (e3_rxd_2),            //ETH receive data
    .e3_mdc                      (),            //mdc interface
    .e3_mdio                     (),           //mdio interface
    .speed3                      (),            //ethernet speed 00: no link, 01: 10M 02:100M 11:1000M
    .e4_clk                      (e4_clk),
    .e4_reset                    (),
    .e4_tx_en                    (e4_tx_en_2),          //ETH transmit enable
    .e4_txd                      (e4_txd_2),            //ETH transmit data
    .e4_rx_dv                    (e4_rx_dv_2),          //ETH receive data valid 
    .e4_rxd                      (e4_rxd_2),            //ETH receive data
    .e4_mdc                      (),            //mdc interface
    .e4_mdio                     (),           //mdio interface
    .speed4                      (),            //ethernet speed 00: no link, 01: 10M 02:100M 11:1000M
    .ETH_error                   (),         //={e4_rx_error,e4_tx_error,e3_rx_error,e3_tx_error}
    .ReNegotiateETH34            (1'b0),
//GTP connections
    .Q0_CLK0_GTREFCLK_PAD_N_IN   (),  //GTP clock
    .Q0_CLK0_GTREFCLK_PAD_P_IN   (e_clk),  //GTP clock
    .RXN_IN                      (),           //GTP rx pins
    .RXP_IN                      (),           //GTP rx pins  
    .TXN_OUT                     (),          //GTP tx pins
    .TXP_OUT                     (),         //GTP tx pins
    .gtp_error                   (),        //={gtp_rx_error,gtp_tx_error}
//inputs   
    .DataIn_req                  (DataIn_req_2),       //data to be broadcasted ready    
    .DataIn                      (DataIn),           //data to be broadcasted          
    .newData                     (newData_2_cp),
    .newDataReady                (newDataReady_2_cp),
//output results
    .Broadcast_bussy             (Broadcast_bussy_2),
    .data_valid                  (data_valid_2),
    .DataHome                    (DataHome_2), 
    .gtp0_data_recv_short        (gtp0_data_recv_2),
    .gtp1_data_recv_short        (gtp1_data_recv_2),
    .gtp2_data_recv_short        (gtp2_data_recv_2),
    .gtp3_data_recv_short        (gtp3_data_recv_2),
    .e3_data_recv_short          (e3_data_recv_2),
    .e4_data_recv_short          (e4_data_recv_2),
    .OutOfRangeMuxError          ()
);

MDmachine
#(
.DataByteWidth   (DataByteWidth),
.DataByteWidth_n (DataByteWidth_n),
.nBox            (nBox)
) MDmachine2
(
 .IOclk            (IOclk),  
 .CalcClk          (CalcClk),
 .MDReset          (1'b0),
//inputs from BraodcastAtom to write data into boxes
 .data_valid       (data_valid_2_cp),
 .DataHome         (DataHome_2_cp),       
 .gtp0_data_recv   (gtp0_data_recv_2_cp), 
 .gtp1_data_recv   (gtp1_data_recv_2_cp), 
 .gtp2_data_recv   (gtp2_data_recv_2_cp), 
 .gtp3_data_recv   (gtp3_data_recv_2_cp), 
 .e3_data_recv     (e3_data_recv_2_cp),   
 .e4_data_recv     (e4_data_recv_2_cp),  
 .overflowError    (),
//input that writes into Force LUTs 
 .wrForceLUT       (wrForceLUT),    
 .dataForceLUT     (dataForceLUT),  
 .adrForceLUT      (ForceCnt),   
 .selForceLUT      (1'b0),    
 //input/output for MD claculation
 .nAtom0           (),               
 .nAtomResetExt    (nAtomReset),           
 .AllBussy         (AllBussy),  
 .InitCalc         (InitCalc),
 .nstep            (nstep), 
 .istepOut         (),
 .SyncOut          (SyncOut_2),              
 .CalcBussy        (),   
 .errorRxReset     (),    
 .errorRxSync      (1'b0),               
 .newData          (newData_2),
 .newDataReady     (newDataReady_2),
//input/output to write content of boxes to MAC     
 .SendMacAdr       (1'b0),   
 .SendMacBox       (1'b0),
 .DataSendMac      ()
);

//***************************************Node 3*******************************************************
wire [DataByteWidth_n*8-1:0]     gtp0_data_recv_3;
wire [DataByteWidth_n*8-1:0]     gtp1_data_recv_3;
wire [DataByteWidth_n*8-1:0]     gtp2_data_recv_3;
wire [DataByteWidth_n*8-1:0]     gtp3_data_recv_3;
wire [DataByteWidth_n*8-1:0]     e3_data_recv_3;
wire [DataByteWidth_n*8-1:0]     e4_data_recv_3;
reg  [DataByteWidth_n*8-1:0]     gtp0_data_recv_3_cp;
reg  [DataByteWidth_n*8-1:0]     gtp1_data_recv_3_cp;
reg  [DataByteWidth_n*8-1:0]     gtp2_data_recv_3_cp;
reg  [DataByteWidth_n*8-1:0]     gtp3_data_recv_3_cp;
reg  [DataByteWidth_n*8-1:0]     e3_data_recv_3_cp;
reg  [DataByteWidth_n*8-1:0]     e4_data_recv_3_cp;
wire [(DataByteWidth)*8-1:0]     DataHome_3;
wire [nBox-1:0]                  data_valid_3;
reg  [(DataByteWidth)*8-1:0]     DataHome_3_cp;
reg  [nBox-1:0]                  data_valid_3_cp;
wire [DataByteWidth*8-1:0]       newData_3;
wire                             newDataReady_3;
reg  [DataByteWidth*8-1:0]       newData_3_cp;
reg                              newDataReady_3_cp;

always @(*) begin                 //is needed to connect MDmachine to BroadcastAtom
  data_valid_3_cp      <= data_valid_3;
  DataHome_3_cp        <= DataHome_3;
  gtp0_data_recv_3_cp  <= gtp0_data_recv_3;
  gtp1_data_recv_3_cp  <= gtp1_data_recv_3;
  gtp2_data_recv_3_cp  <= gtp2_data_recv_3;
  gtp3_data_recv_3_cp  <= gtp3_data_recv_3;
  e3_data_recv_3_cp    <= e3_data_recv_3;
  e4_data_recv_3_cp    <= e4_data_recv_3;
  newData_3_cp         <= newData_3;
  newDataReady_3_cp    <= newDataReady_3;
end

BroadcastAtom
#(
.DataByteWidth  (DataByteWidth),
.nBox           (nBox)
) BroadcastAtom3
(
    .IOclk                       (IOclk),  
    .ErrorReset                  (1'b0),
    .ResetStart                  (1'b0),
//ETH connections
    .e3_clk                      (e3_clk), 
    .e3_reset                    (),
    .e3_tx_en                    (e3_tx_en_3),          //ETH transmit enable
    .e3_txd                      (e3_txd_3),            //ETH transmit data
    .e3_rx_dv                    (e3_rx_dv_3),          //ETH receive data valid 
    .e3_rxd                      (e3_rxd_3),            //ETH receive data
    .e3_mdc                      (),            //mdc interface
    .e3_mdio                     (),           //mdio interface
    .speed3                      (),            //ethernet speed 00: no link, 01: 10M 02:100M 11:1000M
    .e4_clk                      (e4_clk),
    .e4_reset                    (),
    .e4_tx_en                    (e4_tx_en_3),          //ETH transmit enable
    .e4_txd                      (e4_txd_3),            //ETH transmit data
    .e4_rx_dv                    (e4_rx_dv_3),          //ETH receive data valid 
    .e4_rxd                      (e4_rxd_3),            //ETH receive data
    .e4_mdc                      (),            //mdc interface
    .e4_mdio                     (),           //mdio interface
    .speed4                      (),            //ethernet speed 00: no link, 01: 10M 02:100M 11:1000M
    .ETH_error                   (),         //={e4_rx_error,e4_tx_error,e3_rx_error,e3_tx_error}
    .ReNegotiateETH34            (1'b0),
//GTP connections
    .Q0_CLK0_GTREFCLK_PAD_N_IN   (),  //GTP clock
    .Q0_CLK0_GTREFCLK_PAD_P_IN   (e_clk),  //GTP clock
    .RXN_IN                      (),           //GTP rx pins
    .RXP_IN                      (),           //GTP rx pins  
    .TXN_OUT                     (),          //GTP tx pins
    .TXP_OUT                     (),         //GTP tx pins
    .gtp_error                   (),        //={gtp_rx_error,gtp_tx_error}
//inputs   
    .DataIn_req                  (DataIn_req_3),       //data to be broadcasted ready    
    .DataIn                      (DataIn),           //data to be broadcasted          
    .newData                     (newData_3_cp),
    .newDataReady                (newDataReady_3_cp),
//output results
    .Broadcast_bussy             (Broadcast_bussy_3),
    .data_valid                  (data_valid_3),
    .DataHome                    (DataHome_3), 
    .gtp0_data_recv_short        (gtp0_data_recv_3),
    .gtp1_data_recv_short        (gtp1_data_recv_3),
    .gtp2_data_recv_short        (gtp2_data_recv_3),
    .gtp3_data_recv_short        (gtp3_data_recv_3),
    .e3_data_recv_short          (e3_data_recv_3),
    .e4_data_recv_short          (e4_data_recv_3),
    .OutOfRangeMuxError          ()
);


MDmachine
#(
.DataByteWidth   (DataByteWidth),
.DataByteWidth_n (DataByteWidth_n),
.nBox            (nBox)
) MDmachine3
(
 .IOclk            (IOclk),  
 .CalcClk          (CalcClk),
 .MDReset          (1'b0),
//inputs from BraodcastAtom to write data into boxes
 .data_valid       (data_valid_3_cp),
 .DataHome         (DataHome_3_cp),       
 .gtp0_data_recv   (gtp0_data_recv_3_cp), 
 .gtp1_data_recv   (gtp1_data_recv_3_cp), 
 .gtp2_data_recv   (gtp2_data_recv_3_cp), 
 .gtp3_data_recv   (gtp3_data_recv_3_cp), 
 .e3_data_recv     (e3_data_recv_3_cp),   
 .e4_data_recv     (e4_data_recv_3_cp),  
 .overflowError    (),
//input that writes into Force LUTs 
 .wrForceLUT       (wrForceLUT),    
 .dataForceLUT     (dataForceLUT),  
 .adrForceLUT      (ForceCnt),   
 .selForceLUT      (1'b0),    
 //input/output for MD claculation
 .nAtom0           (),               
 .nAtomResetExt    (nAtomReset),           
 .AllBussy         (AllBussy),  
 .InitCalc         (InitCalc),
 .nstep            (nstep), 
 .istepOut         (),
 .SyncOut          (SyncOut_3),              
 .CalcBussy        (),   
 .errorRxReset     (),    
 .errorRxSync      (1'b0),               
 .newData          (newData_3),
 .newDataReady     (newDataReady_3),
//input/output to write content of boxes to MAC     
 .SendMacAdr       (1'b0),   
 .SendMacBox       (1'b0),
 .DataSendMac      ()
);


endmodule
