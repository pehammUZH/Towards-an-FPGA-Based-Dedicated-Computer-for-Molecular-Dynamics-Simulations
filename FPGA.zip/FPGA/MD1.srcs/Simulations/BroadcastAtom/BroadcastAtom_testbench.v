`timescale 1ns / 1ps

module BroadcastAtom_testbench();

parameter DataByteWidth     =5'd27;
parameter DataByteWidth_n   =5'd18;
parameter EnsembleByteWidth = 5'd15;
parameter nBox               =5'd27;
parameter nSelForceLUT       = 3;       //width of SelForceLUT 
parameter vshift              = 4;       //shift of velocites vs positions. Actual shift is vshift+1, since velocities are defined +/-1, while
                                         //positions are define +/-2.   
parameter delayETH        =86;              //two request of DataHome will bunch together
parameter nBlock          =50;             //length of a block to be sent at once by UDP; maximum is 1.5kByte
parameter  metaAtomNr         = 0;       //position of atom number in meta data
parameter  metaAtomNr_len     = 18;      //its length
parameter  metaAtomTypeLJ     = 18;      //atomType for LJ
parameter  metaAtomTypeLJ_len = 5;       //its length, leave one bit of reserve
parameter  metaCharge         = 24;      //posiiton of charge in meta data
parameter  metaCharge_len     = 18;      //its length 
parameter  metaMass           = 42;      //position of mass in meta data
parameter  metaMass_len       = 6;       //its length; 
parameter  metaConstraint     = 48;      //position of contraint info in meta data
parameter  metaRoute          = 64;      //information for which box to route; 6bit needed
parameter nProteinAtom        = 12;      //2^nProteinAtom is maximum number of protein atoms, whose coordinates are strored indexed by atom number 
                                         //the calculation of bonded inteaction   

parameter nSide              = 4'd3;           //will reveal nSide**3*nMol atoms, three connected to a molecule
parameter nMol               = 3;
parameter dq                 =(2**22)/nSide;  


//input/output for MD claculation
reg                             InitCalc =1'b0; 
reg  [15:0]                     nstep    =16'd8; 
wire [15:0]                     istep;



reg                              e_clk      = 1'b0;
reg                              IOclk      = 1'b0;
reg                              CalcClk    = 1'b0;
reg                              clk200MHz  = 1'b0;
assign                           e3_clk   = e_clk;
assign                           e4_clk   = e_clk;
assign                           e1_clk   = e_clk;

reg  [DataByteWidth*8-1:0]       DataIn     = 1'b0;
reg                              DataIn_req = 1'b0;
reg                              nAtomReset = 1'b0;
reg                              AllBusy;
reg                              MDReset    = 1'b1;
reg                              WriteDataThermostat =1'b0;

reg [8:0]          cnt=1'b0;
reg [2:0]          cnt2=1'b0;
reg [11:0]         addrForceLUT=1'b0;




//************************************************************************

integer in,i,out;
integer dat0,dat1,dat2,dat3,dat4,dat5,dat6,dat7,dat8;
reg [71:0] LUTforce [0:511];

initial begin
  $display("Open file with LUT of forces");
  in = $fopen("../../../../../../LUTforceLJ.dat","r");
  out= $fopen("../../../../../../forceout.dat","w");

  for(i=0;i<512;i=i+1) begin
    $fscanf(in,"%x %x %x %x %x %x %x %x %x",dat0,dat1,dat2,dat3,dat4,dat5,dat6,dat7,dat8);
 //   $display("%h",{dat0[3:0],dat1[7:0],dat2[7:0],dat3[7:0],dat4[7:0]});
    LUTforce[i] <= {dat0[7:0],dat1[7:0],dat2[7:0],dat3[7:0],dat4[7:0],dat5[7:0],dat6[7:0],dat7[7:0],dat8[7:0]};
  end   
  $fclose(in);
end


//***********************************************************************
//clocks
always #4       e_clk = ~e_clk; 
always #5      IOclk = ~IOclk; 
always #1.786  CalcClk = ~CalcClk; 
always #2.5    clk200MHz = ~clk200MHz; 

//****************************************************************************
reg  [3:0]    testState2=1'b0;
reg  [8:0]    ForceCnt=1'b0;
reg [71:0]         dataForceLUT=1'b0;
reg                wrForceLUT=1'b0;


//write forece LUT
/*
always @(posedge IOclk) begin
  case(testState2)
  0: begin
    ForceCnt <= ForceCnt +1'b1; 
    if(ForceCnt==5'h1f) begin
      ForceCnt          <= 1'b0;
      wrForceLUT   <= 1'b1;
      dataForceLUT <= LUTforce[0];
      testState2 <= 4'd1;  
    end  
  end    
  1: begin
      ForceCnt          <= ForceCnt + 1'b1;
      dataForceLUT <= LUTforce[ForceCnt+1'b1];
      if (ForceCnt==10'h1ff) begin
        testState2 <=  4'd2;
        wrForceLUT   <= 1'b0;
      end  
  end
  endcase
end
*/

always @(posedge IOclk) begin
  case(testState2)
    0: begin
      cnt <= cnt + 1'b1;
      if (cnt==10'h20) begin
        testState2      <= 4'd1;
        cnt             <= 1'b0;
        cnt2            <= 1'b0;
        wrForceLUT      <= 1'b1;  
        addrForceLUT    <= 1'b0;
        dataForceLUT    <= LUTforce[0];                       
      end  
    end
    1: begin                     //write into LUT memory
      cnt2          <= cnt2 + 'b1;
      addrForceLUT  <= addrForceLUT + 1'b1;
      dataForceLUT  <= {9'b0,dataForceLUT[71:9]};
      if(cnt2==3'h7) begin
        cnt          <= cnt + 1'b1;
        dataForceLUT <= LUTforce[cnt+1'b1];
        if (cnt==10'h1ff) begin
          testState2 <= 4'd2;
          wrForceLUT   <= 1'b0;
        end
      end
    end      
    2: begin
      WriteDataThermostat <= 1'b1;
      testState2 <= 4'd3;
    end
    3: begin
      WriteDataThermostat <= 1'b0;
    end  
  endcase
end  


//write data into boxes
reg   [2:0]   ix=1'b0,iy=1'b0,iz=1'b0;
reg  [1:0]    iMol=1'b0;
reg   [17:0]   iAll=9'h4;
reg   [5:0]   wait_cnt=1'b0;
wire [23:0]   x=ix*dq+dq/2 + (iMol==1 ? 24'h20000 : 1'b0);
wire [23:0]   y=iy*dq+dq/2 + (iMol==2 ? 24'h20000 : 1'b0);
wire [23:0]   z=iz*dq+dq/2 + (iMol==2 ? 24'h20000 : 1'b0);
reg  [3:0]    testState=1'b0;
wire [23:0]   vx=24'h0;      //24'h020000+(iy-1.5)*24'h1000;
wire [23:0]   vy=24'h0;  //24'h020000+(iz-1.5)*24'h1000;
wire [23:0]   vz=24'h0; //24'h020000+(ix-1.5)*24'h1000;
reg  [15:0]   cntAll=1'b0;
//wire [2:0]    shake = ix[0] ? 3'h6 :3'h0;    //only every second molecule is running through shake
wire [2:0]    shake = 3'h6 ;    

always @(posedge e_clk) cntAll <= cntAll + 1'b1;

always @(posedge IOclk) begin
  case(testState)
  0: begin
    wait_cnt <= wait_cnt +1'b1; 
    if(wait_cnt==6'h28) MDReset  <= 1'b0;
    nAtomReset <= (wait_cnt==6'h2e);  //some of the signals shouldn't be too early, since they then come before some internal reset
    DataIn_req  <= 1'b0;
    if(wait_cnt==6'h2f) begin
       testState <= 4'd1;
       wait_cnt <= 1'b0;
    end   
  end    
  1: begin
    wait_cnt <= wait_cnt +1'b1;
    DataIn_req    <= 1'b0;
    if(wait_cnt==6'h1f) begin   
      wait_cnt   <= 1'b0;
      DataIn_req <= 1'b1;
      DataIn     <= {vz,vy,vx,21'b0,shake,6'h10,24'b0,iAll,z,y,x}; //constraint=shake, mass 16, charge=0, atomTyp=0
 //     DataIn     <= {vz,vy,vx,63'b0,iAll,z,y,x}; 
    //  DataIn     <= (ix==0||ix==1) ? {vz,vy,vx,63'b0,iAll,z,y,x} : {-vz+24'h000100,-vy+24'h000080,-vx-24'h000080,64'b0,iAll,z,y,x}; 
      if(iAll[1:0]==2'b10) iAll <= iAll+2'b10;    //for  water, jump over atomNr with lowest two bits 2'b11. 
      else                 iAll <= iAll+1'b1;

      if (iMol<nMol-1) iMol  <= iMol+1'b1;
      else begin
        iMol  <= 1'b0;
        if (ix<nSide-1'b1) ix <= ix+1'b1;
        else begin
          ix <= 1'b0;
          if (iy<nSide-1'b1) iy <= iy+1'b1;
          else begin
            iy <= 1'b0;
            if (iz<nSide-1'b1) iz <= iz+1'b1;
            else begin
              iz <= 1'b0;
              testState <= 4'd2;
            end  
          end  
        end
      end 
    end     
  end
  2: begin
    DataIn_req    <= 1'b0; 
    if(~Broadcast_busy&&~wrForceLUT) testState <= 4'd3;
  end
  3: begin
    InitCalc    <= 1'b1; 
    testState   <= 4'd4;
  end
  4: begin
    InitCalc    <= 1'b0; 
    testState   <= 4'd5;
  end
  5: begin
    wait_cnt <= wait_cnt +1'b1; 
    if(wait_cnt==6'h2f) testState <= 4'd6;
  end
  6: begin
     wait_cnt <= 0;
    if(istep==nstep&&~AllBusy)  testState   <= 4'd7;   //restart
  end
  7: begin
    wait_cnt <= wait_cnt +1'b1; 
    if(wait_cnt==6'h2f) testState <= 4'd2;
  end
  default: ;  
endcase
end

//*********************************cross-connect nodes
always @(*) begin 
  AllBusy           <= SyncOut||Broadcast_busy;
end  


//***************************************Node 1*********************************
wire [7:0]                       e3_txd, e4_txd;
wire                             e3_tx_en, e4_tx_en;
reg  [7:0]                       e3_rxd, e4_rxd;
reg                              e3_rx_dv,e4_rx_dv;
wire [DataByteWidth_n*8-1:0]     gtp0_data_recv;
wire [DataByteWidth_n*8-1:0]     gtp1_data_recv;
wire [DataByteWidth_n*8-1:0]     gtp2_data_recv;
wire [DataByteWidth_n*8-1:0]     gtp3_data_recv;
wire [DataByteWidth_n*8-1:0]     e3_data_recv;
wire [DataByteWidth_n*8-1:0]     e4_data_recv;
reg  [DataByteWidth_n*8-1:0]     gtp0_data_recv_cp;
reg  [DataByteWidth_n*8-1:0]     gtp1_data_recv_cp;
reg  [DataByteWidth_n*8-1:0]     gtp2_data_recv_cp;
reg  [DataByteWidth_n*8-1:0]     gtp3_data_recv_cp;
reg  [DataByteWidth_n*8-1:0]     e3_data_recv_cp;
reg  [DataByteWidth_n*8-1:0]     e4_data_recv_cp;
wire [(DataByteWidth)*8-1:0]     DataHome;
wire [nBox-1:0]                  data_valid;
reg  [(DataByteWidth)*8-1:0]     DataHome_cp;
reg  [nBox-1:0]                  data_valid_cp;
wire [DataByteWidth*8-1:0]       newData;
wire                             newDataReady;
reg  [DataByteWidth*8-1:0]       newData_cp;
reg                              newDataReady_cp;
wire [EnsembleByteWidth*8-1:0]   EnsembleData;           //temperature
wire                             EnsembleReady;                
wire [EnsembleByteWidth*8-1:0]   EnsembleNeighbor;
wire                             EnsembleNeighborValid; 
wire [71+nProteinAtom:0]         dataProteinAtom;
wire                             dataProteinAtom_valid;
 
always @(*) begin                 //is needed to connect MDmachine to BroadcastAtom
  data_valid_cp      <= data_valid;
  DataHome_cp        <= DataHome;
  gtp0_data_recv_cp  <= gtp0_data_recv;
  gtp1_data_recv_cp  <= gtp1_data_recv;
  gtp2_data_recv_cp  <= gtp2_data_recv;
  gtp3_data_recv_cp  <= gtp3_data_recv;
  e3_data_recv_cp    <= e3_data_recv;
  e4_data_recv_cp    <= e4_data_recv;
  newData_cp         <= newData;
  newDataReady_cp    <= newDataReady;
  e3_rx_dv           <= e4_tx_en;
  e3_rxd             <= e4_txd;
  e4_rx_dv           <= e3_tx_en;
  e4_rxd             <= e3_txd;
end

BroadcastAtom
#(
.DataByteWidth     (DataByteWidth),
.EnsembleByteWidth (EnsembleByteWidth),
.nBox              (nBox),
.metaAtomNr_len    (metaAtomNr_len),
.nProteinAtom      (nProteinAtom)
) BroadcastAtom
(
    .IOclk                       (IOclk),  
    .ErrorReset                  (1'b0),
    .ResetStart                  (1'b0),
//ETH connections
    .e3_clk                      (e3_clk), 
    .e3_reset                    (),
    .e3_tx_en                    (e3_tx_en),          //ETH transmit enable
    .e3_txd                      (e3_txd),            //ETH transmit data
    .e3_rx_dv                    (e3_rx_dv),          //ETH receive data valid 
    .e3_rxd                      (e3_rxd),            //ETH receive data
    .e3_mdc                      (e3_mdc),            //mdc interface
    .e3_mdio                     (e3_mdio),           //mdio interface
    .speed3                      (),            //ethernet speed 00: no link, 01: 10M 02:100M 11:1000M
    .e4_clk                      (e4_clk),
    .e4_reset                    (),
    .e4_tx_en                    (e4_tx_en),          //ETH transmit enable
    .e4_txd                      (e4_txd),            //ETH transmit data
    .e4_rx_dv                    (e4_rx_dv),          //ETH receive data valid 
    .e4_rxd                      (e4_rxd),            //ETH receive data
    .e4_mdc                      (),            //mdc interface
    .e4_mdio                     (),           //mdio interface
    .speed4                      (),            //ethernet speed 00: no link, 01: 10M 02:100M 11:1000M
    .ETH_error                   (),         //={e4_rx_error,e4_tx_error,e3_rx_error,e3_tx_error}
//GTP connections
    .Q0_CLK0_GTREFCLK_PAD_N_IN   (),  //GTP clock
    .Q0_CLK0_GTREFCLK_PAD_P_IN   (e_clk),  //GTP clock
    .RXN_IN                      (),           //GTP rx pins
    .RXP_IN                      (),           //GTP rx pins  
    .TXN_OUT                     (),          //GTP tx pins
    .TXP_OUT                     (),         //GTP tx pins
    .gtp_error                   (),        //={gtp_rx_error,gtp_tx_error}
//inputs   
    .DataIn_req                  (DataIn_req),       //data to be broadcasted ready    
    .DataIn                      (DataIn),           //data to be broadcasted          
    .newData                     (newData_cp),
    .newDataReady                (newDataReady_cp),
    .EnsembleData                (EnsembleData),
    .EnsembleReady               (EnsembleReady),
    .EnsembleNeighbor            (EnsembleNeighbor),
    .EnsembleNeighborValid       (EnsembleNeighborValid),
//output results
    .Broadcast_busy             (Broadcast_busy),
    .data_valid                  (data_valid),
    .DataHome                    (DataHome), 
    .gtp0_data_recv_short        (gtp0_data_recv),
    .gtp1_data_recv_short        (gtp1_data_recv),
    .gtp2_data_recv_short        (gtp2_data_recv),
    .gtp3_data_recv_short        (gtp3_data_recv),
    .e3_data_recv_short          (e3_data_recv),
    .e4_data_recv_short          (e4_data_recv),
    .dataProteinAtom             (dataProteinAtom),                                                           //new
    .dataProteinAtom_valid       (dataProteinAtom_valid),                                                     //new
    .GatedMuxError               ()
);



MDmachine
#(
.DataByteWidth      (DataByteWidth),
.DataByteWidth_n    (DataByteWidth_n),
.EnsembleByteWidth  (EnsembleByteWidth),
.nBox               (nBox),
.vshift             (vshift),
.nSelForceLUT       (nSelForceLUT ),
.nProteinAtom       (nProteinAtom),
.metaAtomNr_len     (metaAtomNr_len),
.metaAtomTypeLJ     (metaAtomTypeLJ),
.metaAtomTypeLJ_len (metaAtomTypeLJ_len),
.metaCharge         (metaCharge),
.metaCharge_len     (metaCharge_len), 
.metaMass           (metaMass),
.metaMass_len       (metaMass_len),
.metaConstraint     (metaConstraint),
.metaRoute          (metaRoute)
) MDmachine
(
 .IOclk            (IOclk),  
 .CalcClk          (CalcClk),
 .clk200MHz        (clk200MHz),
 .MDReset          (MDReset),
//inputs from BraodcastAtom to write data into boxes
 .data_valid       (data_valid_cp),
 .DataHomeIn       (DataHome_cp),       
 .gtp0_data_recv   (gtp0_data_recv_cp), 
 .gtp1_data_recv   (gtp1_data_recv_cp), 
 .gtp2_data_recv   (gtp2_data_recv_cp), 
 .gtp3_data_recv   (gtp3_data_recv_cp), 
 .e3_data_recv     (e3_data_recv_cp),   
 .e4_data_recv     (e4_data_recv_cp),  
 .overflowError    (),
 .dataProteinAtom       (dataProteinAtom),                                                           //new
 .dataProteinAtom_valid (dataProteinAtom_valid),                                                     //new
 //input that writes into Force LUTs 
 .wrForceLUT       (wrForceLUT),    
 .dataForceLUT     (dataForceLUT[8:0]),  
 .adrForceLUT      (addrForceLUT),   
 .selForceLUT      (3'b0),    
 //input/output for MD claculation
 .nAtom0           (),               
 .nAtomResetExt    (nAtomReset),           
 .AllBusy         (AllBusy),  
 .InitCalc         (InitCalc),
 .nstep            (nstep), 
 .istepOut         (istep),
 .SyncOut          (SyncOut),              
 .CalcBusy        (),   
 .errorRxReset     (),    
 .errorRxSync      (1'b0),               
 .newData          (newData),
 .newDataReady     (newDataReady),
 .EnsembleData     (EnsembleData),
 .EnsembleReady    (EnsembleReady),
 .EnsembleNeighbor      (EnsembleNeighbor),
 .EnsembleNeighborValid (EnsembleNeighborValid),
//Control inputs for thermostat, etc. 
 .WriteDataThermostat         (WriteDataThermostat),
 .AdrDataThermostat           (3'h5),                       //is the last one, and will produce SetupMD signal when WriteDataThermostat is triggered
 .DataThermostat              (32'b0), 
//input/output to write content of boxes to MAC     
 .SendMacAdr       (1'b0),   
 .SendMacBox       (1'b0),
 .DataSendMac      ()
);




endmodule
