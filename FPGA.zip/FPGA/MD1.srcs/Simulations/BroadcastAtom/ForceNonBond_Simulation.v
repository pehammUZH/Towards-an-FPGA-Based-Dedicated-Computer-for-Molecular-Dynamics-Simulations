`timescale 1ns / 1ps
//ATTENTION: Is the version for simulating Broadcast_Atom_testbench. Has exclusively the LJ-interactions to make it simpler 
//           and hopefully faster for simulating. The inputs/outputs are the same as in the full version. Multipliers have been chnaged wizthout ful testing. 
//           Timing shoule be ok, but need to test calculated values in case they are needed

//Force calculation; starts from (dx,dy,dy) and accumulates (Fx_tot,Fy_tot_Fz_tot). 
//StoreFtot_out sets (Fx_tot,Fy_tot_Fz_tot)=0, and AddFtot is a signal that says that data are valid.
//structure of pipeline is shown in ForceNonBond_LJ.pdf 
//
//Latency currently is nPipeForce=19. Latency is the number of clock cycles from (dx,dy,dy) until (Fx_tot,Fy_tot,Fz_tot) are valid.
//Control signals AddFtot, StoreFtot and are delayed inside routine in dependence of nPipeForce. ForceNonBondHome 
//called in MDMachine is the reference for that. AddFtot appears at the input at the same time as dx,
//and StoreFtot one cycle after the last AddFtot. Timing in ForceBox_* is different, hence the routines have a proper pre-deay of
//those signals
//
//Equivalent C-code is:
//
// r2      = dx * dx + dy * dy + dz * dz;
// r2_high = (int)(r2 * 512);
// r2_low  = (r2 * 512)%1;
// r4      = r2_low * r2_low;
// ForceLJ = ForceLUT[r2_high] + r2_low * dForceLUT[r2_high] + r4 * ddForceLUT[r2_high];
// Fx      = dx * ForceLJ;
// Fy      = dy * ForceLJ;
// Fz      = dz * ForceLJ;
// if(StoreFtot_out) 
// {
//   Fx_tot = 0;
//   Fy_tot = 0;
//   Fz_tot = 0;
// }
// else if (pipe)
// {  
//   Fx_tot += Fx;
//   Fy_tot += Fy;
//   Fz_tot += Fz;
// }
//
// #operations: 9 multiplications, 7 additions

module ForceNonBond
#(
parameter  nSelForceLUT       = 3,      //width of SelForceLUT 
parameter  metaAtomNr_len     = 16      //length of atom number in meta data;                
)
(
input                                     IOclk,         
input                                     CalcClk,
input                                     MDReset,
//input that writes into Force-LUT; on IOclk
input                                     wrForceLUT,    
input              [8:0]                  dataForceLUT,   
input              [11:0]                 adrForceLUT,   
input              [nSelForceLUT-1:0]     selForceLUT,   
//stuff related to actual force calculation, on CalcClk
//input                                     ResetFtot,
input                                     AddFtot,        
input                                     StoreFtot,    
output                                    StoreFtot_out, 
input       signed [23:0]                 dx,
input       signed [23:0]                 dy,
input       signed [23:0]                 dz,
input              [metaAtomNr_len-1:0]   iAtom1,                                              
input              [metaAtomNr_len-1:0]   iAtom2,                                              
input              [4:0]                  atomTypeLJ1,     
input              [4:0]                  atomTypeLJ2,     
input       signed [17:0]                 charge1,         
input       signed [17:0]                 charge2,       
output reg  signed [31:0]                 Fx_tot=1'b0,
output reg  signed [31:0]                 Fy_tot=1'b0, 
output reg  signed [31:0]                 Fz_tot=1'b0
);

localparam nPipe_dq        = 13;  //for dx,dy,dz
localparam nPipe_r2        = 5;
localparam nPipe_Force     = 3;
//the following is new and delays signals properly depending on nPipeForce
localparam nPipeForce      = 19;                 //latency of ForceNonBond;
localparam nPipe_AddFtot   = nPipeForce-3;      //latency of reading data plus ForceNonBond;
//localparam nPipe_ResetFtot = nPipeForce-7;      //timing of ResetFtot and StoreFtot; both signals should come at the same time 
localparam nPipe_StoreFtot = nPipeForce-2;      


integer                         i;
reg  signed [23:0]              dx_pipe[nPipe_dq-1:0] ,dy_pipe[nPipe_dq-1:0] ,dz_pipe[nPipe_dq-1:0];

reg  signed [47:0]              Fx_tot_long = 1'b0;
reg  signed [47:0]              Fy_tot_long = 1'b0; 
reg  signed [47:0]              Fz_tot_long = 1'b0;
reg  signed [47:0]              dz2_d0;
reg  signed [47:0]              r2_tmp1 = 1'b0, r2_tmp2 = 1'b0;
wire signed [29:0]              r2;
reg         [16:0]              r2_d0;
reg         [16:0]              r2_d1;
reg         [nPipe_r2:0]        r2range_pipe;
wire        [16:0]              r4;
wire        [71:0]              LJ_LUT_tmp;
reg  signed [23:0]              LJ_LUT[nPipe_Force-1:0];
wire signed [23:0]              dLJ_LUT;
reg  signed [23:0]              ddLJ_LUT_d0;
//wire signed [40:0]              dLJ_tmp;
wire signed [23:0]              dLJ;
//wire signed [40:0]              ddLJ_tmp;
wire signed [23:0]              ddLJ;
reg  signed [23:0]              LJ_tmp1;
reg  signed [23:0]              LJ;
reg         [nPipe_AddFtot:0]   AddFtot_pipe    = 1'b0;
//reg         [nPipe_ResetFtot:0] ResetFtot_pipe  = 1'b0;
reg         [nPipe_StoreFtot:0] StoreFtot_pipe  = 1'b0;
assign                          StoreFtot_out = StoreFtot_pipe[nPipe_StoreFtot];
reg                             FtotReset=1'b0;




//level 1 of pipeline
  always @(posedge CalcClk) begin
    dx_pipe[0] <= dx;
    dy_pipe[0] <= dy;
    dz_pipe[0] <= dz;
  end 
  
  wire signed [49:0]   dx2, dy2, dz2;
  mult_s25xs25_lat4    mult_dx2 (.CLK(CalcClk),.A({dx,1'b0}),.B({dx,1'b0}),.P(dx2));
  mult_s25xs25_lat4    mult_dy2 (.CLK(CalcClk),.A({dy,1'b0}),.B({dy,1'b0}),.P(dy2));
  mult_s25xs25_lat4    mult_dz2 (.CLK(CalcClk),.A({dz,1'b0}),.B({dz,1'b0}),.P(dz2));
  
//level 5 of pipeline
  always @(posedge CalcClk) begin
    r2_tmp1 <= dx2[49:2] + dy2[49:2];  
    dz2_d0  <= dz2[49:2];
  end  

//level 6 of pipeline
  always @(posedge CalcClk) begin
    r2_tmp2 <= r2_tmp1 + dz2_d0;  
  end
  assign r2 = r2_tmp2[47:18];    
  
//level 7 of pipeline
  always @(posedge CalcClk) begin
    r2_d0           <= r2[16:0]; 
    r2range_pipe[0] <= (r2<31'h4000000);
  end  
  bram_9x4096_72x512 LUT_LJ (.clka(IOclk),.ena(selForceLUT==2'h0),.wea(wrForceLUT),.addra(adrForceLUT),.dina(dataForceLUT),.clkb(CalcClk),.enb(1'b1),.addrb(r2[25:17]),.doutb(LJ_LUT_tmp));
  wire   [35:0]     r4_tmp;
  mult_s18xs18_lat3 mult_r4 (.CLK(CalcClk),.A({1'b0,r2[16:0]}),.B({1'b0,r2[16:0]}),.P(r4_tmp)); //done with 1 DSP; latency 3

//level 8 of pipeline
  always @(posedge CalcClk) begin
    r2_d1 <= r2_d0; 
  end 
  
//level 9 of pipeline
  assign dLJ_LUT  = LJ_LUT_tmp[47:24];
  always @(posedge CalcClk) begin
    ddLJ_LUT_d0 <= LJ_LUT_tmp[23:0];
    LJ_LUT[0]   <= LJ_LUT_tmp[71:48]; 
  end   
  wire signed [42:0]  dLJ_tmp;
  mult_s25xs18_lat3 mult_dLJ (.CLK(CalcClk),.A({dLJ_LUT,1'b0}),.B({1'b0,r2_d1}),.P(dLJ_tmp)); //done with 1 DSP; use maximum bit resolution of DSP48, latency 3
  
//level 10 of pipeline  
  assign r4=r4_tmp[33:17];
  wire signed [42:0] ddLJ_tmp;
  mult_s25xs18_lat3 mult_ddLJ (.CLK(CalcClk),.A({ddLJ_LUT_d0,1'b0}),.B({1'b0,r4}),.P(ddLJ_tmp)); //done with 1 DSP; use maximum bit resolution of DSP48, latency 3
  
//level 12 of pipeline
  assign dLJ=dLJ_tmp[41:18]; 
  always @(posedge CalcClk) begin
    LJ_tmp1  <= LJ_LUT[nPipe_Force-1]+dLJ;
  end  
    
//level 13 of pipeline
  assign ddLJ=ddLJ_tmp[41:18];
  always @(posedge CalcClk) begin
    LJ  <= r2range_pipe[nPipe_r2] ? LJ_tmp1 + ddLJ : 24'h000000;  //ATTENTION should be 24'h000000;
  end  

//level 14 of pipeline
  wire signed [49:0]   Fx, Fy, Fz;
  mult_s25xs25_lat4    mult_Fx (.CLK(CalcClk),.A({dx_pipe[nPipe_dq-1],1'b0}),.B({LJ,1'b0}),.P(Fx));
  mult_s25xs25_lat4    mult_Fy (.CLK(CalcClk),.A({dy_pipe[nPipe_dq-1],1'b0}),.B({LJ,1'b0}),.P(Fy));
  mult_s25xs25_lat4    mult_Fz (.CLK(CalcClk),.A({dz_pipe[nPipe_dq-1],1'b0}),.B({LJ,1'b0}),.P(Fz));
  
//level 18 of pipeline
  always @(posedge CalcClk) begin
    if(FtotReset) begin           //reset for next calculation
      Fx_tot_long <= 1'b0;
      Fy_tot_long <= 1'b0;
      Fz_tot_long <= 1'b0;
    end else if (AddFtot_pipe[nPipe_AddFtot]) begin
//accumulating all forces   
      Fx_tot_long <= Fx_tot_long + Fx[49:2];
      Fy_tot_long <= Fy_tot_long + Fy[49:2];
      Fz_tot_long <= Fz_tot_long + Fz[49:2];   
//output actual force only, for debugging      
//      Fx_tot_long <=  Fx[49:2];
//      Fy_tot_long <=  Fy[49:2];
//      Fz_tot_long <=  Fz[49:2];
    end  
  end     
  
 //level 19 of pipeline,   
  always @(posedge CalcClk) begin
    if(StoreFtot_pipe[nPipe_StoreFtot-1]) begin
      Fx_tot <= Fx_tot_long[45:14];   //32 bit in range +/-1 (in Fx_tot_long, three extra bits are generated  due to signed 24*24 mult, multiplication with eLJ, and the extra bit in dx
      Fy_tot <= Fy_tot_long[45:14];   //in addition, eLJ should have room to multiply by 2
      Fz_tot <= Fz_tot_long[45:14];  
    end  
  end


//*********************************************************shift intermediate results for later usage**************************************************************
always @(posedge CalcClk) begin
   for(i=1;i<=nPipe_dq-1;i=i+1) begin   
     dx_pipe[i]<=dx_pipe[i-1];
     dy_pipe[i]<=dy_pipe[i-1];
     dz_pipe[i]<=dz_pipe[i-1];
   end 
   
   for(i=1;i<=nPipe_r2;i=i+1) begin   
       r2range_pipe[i]<=r2range_pipe[i-1];
   end  
    
   for(i=1;i<=nPipe_Force-1;i=i+1) begin   
     LJ_LUT[i]<=LJ_LUT[i-1];
   end 
   
   AddFtot_pipe   <= {AddFtot_pipe[nPipe_AddFtot-1:0],AddFtot};      
  // ResetFtot_pipe <= {ResetFtot_pipe[nPipe_ResetFtot-1:0],ResetFtot};    
   StoreFtot_pipe <= {StoreFtot_pipe[nPipe_StoreFtot-1:0],StoreFtot}; 
   
   FtotReset <= StoreFtot_pipe[nPipe_StoreFtot-2]||MDReset;
end

endmodule
