`timescale 1ns / 1ps

module CPU1_tb();

reg                 IOclk    = 1'b0;
always #5           IOclk    = ~IOclk; 

reg [15:0]          state    = 1'b0;
reg                 resetCPU = 1'b1;
reg         [7:0]   poll     = 1'b0;
wire        [7:0]   CPU_Ctrl;

always @(posedge IOclk) begin
  state <= state+1'b1;
  if(state==8'h10) begin
    resetCPU <= 1'b0; 
  end  
  if(state==8'h30) begin
    poll <= 8'b00000001;
  end  
  if(state==8'h31) begin
    poll <= 8'b00000000;
  end  
  if(state==8'h40) begin
    poll <= 8'b00000010;
  end 
  if(state==8'h41) begin
    poll<= 8'b00000000;
  end 
  if(state==8'h50) begin
    poll <= 8'b00000100;
  end 
  if(state==8'h51) begin
    poll<= 8'b00000000;
  end 
end



wire [5:0]  CPUOutAdr;
wire [31:0] CPUOutData;
reg signed [23:0] T_new,vxcm_new,vycm_new,vzcm_new;
reg signed [31:0] x_CPUin     = 32'h00000000;
reg signed [31:0] y_CPUin     = 32'h00000000;
reg signed [31:0] z_CPUin     = 32'h00000000;
reg signed [31:0] vx_CPUin    = 32'h00800000;
reg signed [31:0] vy_CPUin    = 32'h00800000;
reg signed [31:0] vz_CPUin    = 32'h00800000;
reg signed [31:0] Fx_CPUin    = 32'h00000000;
reg signed [31:0] Fy_CPUin    = 32'h00000000;
reg signed [31:0] Fz_CPUin    = 32'h00000000;
reg signed [31:0] iAtom_CPUin = 32'h00000000;           //will eventually be mass, while remaining metadata will be transmitted outside CPU
reg signed [31:0] T_CPUin     = 32'h20000000;
reg signed [31:0] T_target    = 32'h07000000;
reg signed [31:0] vxcm_CPUin  = 32'h00010000;
reg signed [31:0] vycm_CPUin  = 32'h00000000;
reg signed [31:0] vzcm_CPUin  = 32'h00000000;
reg signed [31:0] tau_CPUin   = 32'h00000606;

CPU_UpdatePosVel 
#(
.nInPort (16)
) CPU1
(
.clk       (IOclk),
.resetCPU  (resetCPU),
.InData    ({tau_CPUin,T_target,vzcm_CPUin,vycm_CPUin,vxcm_CPUin,T_CPUin,iAtom_CPUin,Fz_CPUin,Fy_CPUin,Fx_CPUin,vz_CPUin,vy_CPUin,vx_CPUin,z_CPUin,y_CPUin,x_CPUin}),
.poll      (poll),
.Ctrl      (CPU_Ctrl),
.OutValid  (CPUOutValid),
.OutData   (CPUOutData),
.OutAdr    (CPUOutAdr),
.CPUrun    (CPUrun),
.ErrorPipe (ErrorCPU)
);

 reg signed [23:0] x_CPUout, y_CPUout, z_CPUout, vx_CPUout, vy_CPUout, vz_CPUout;
 reg        [16:0] iAtom_CPUout; 
 always @(posedge IOclk) begin
   if(CPUOutValid) begin
     case (CPUOutAdr[3:0])
       0:  x_CPUout     <= CPUOutData[27:4];
       1:  y_CPUout     <= CPUOutData[27:4];
       2:  z_CPUout     <= CPUOutData[27:4];  
       3:  vx_CPUout    <= CPUOutData[27:4];
       4:  vy_CPUout    <= CPUOutData[27:4];
       5:  vz_CPUout    <= CPUOutData[27:4];
       6:  iAtom_CPUout <= CPUOutData[16:0]; 
       8:  T_new        <= CPUOutData[27:4];
       9:  vxcm_new     <= CPUOutData[27:4];
       10: vycm_new     <= CPUOutData[27:4];
       11: vzcm_new     <= CPUOutData[27:4];
     endcase
   end
 end




endmodule
