`timescale 1ns / 1ps


module testbench_ETH;

parameter nETH=28;

reg                e_clk       = 1'b0;
reg                IOclk       = 1'b0;

wire              e_tx_en;
wire [7:0]        e_txd;
reg               e_tx_en_cp;
reg [7:0]         e_txd_cp;
wire              tx_error;
wire              tx_bussy;
reg  [nETH*8-1:0] data_send = 1'b0;
reg               tx_req    = 1'b0;
wire [nETH*8-1:0] data_recv;
wire              data_valid;
wire [2:0]        rx_error;
wire              rx_bussy;
reg [15:0]        allCnt=1'b0;

ETH_tx 
 #(
   .nETH (nETH)  
 ) ETH_tx
(
 .ErrorReset                  (1'b0),
 .e_clk                       (e_clk),              //input
 .IOclk                       (IOclk),
 .e_tx_en                     (e_tx_en),            //output               transmit enable        
 .e_txd                       (e_txd),              //output [7:0]         transmit data
 .data_send                   (data_send),          //input  [nETH*8-1:0], data to be sent
 .tx_req                      (tx_req),              //input
 .tx_error                    (tx_error),
 .bussy                       (tx_bussy)
); 

//*******************ETH receiving part*******************************************  
always @(*) begin
  e_tx_en_cp <= e_tx_en;
  e_txd_cp   <= e_txd;
  e_txd_cp   <= (allCnt==16'he5) ? e_txd^8'h10 : e_txd;   //mimic 1 bit error in transmission
end  

ETH_rx 
 #(
   .nETH (nETH)  
 ) ETH_rx
(
 .ErrorReset                  (1'b0),
 .e_clk                       (e_clk),              //input
 .IOclk                       (IOclk),
 .e_rx_dv                     (e_tx_en_cp),            //input               receievd data valid       
 .e_rxd                       (e_txd_cp),              //input  [7:0]        received data
 .data_recv                   (data_recv),          //output [nETH*8-1:0] compiled received data
 .data_valid                  (data_valid),        //output              received data valid
 .error                       (rx_error),           //output              crc error in received data
 //.ecc_corr                    (ecc_corr),
 .bussy                       (rx_bussy)
); 

always #4 e_clk = ~e_clk; 
always #5 IOclk = ~IOclk; 

reg   [3:0]   cnt=1'b0;
reg   [7:0]   data=1'b0;

always @(posedge e_clk) allCnt <= allCnt +1'b1;

always @(posedge IOclk) begin
  cnt    <= cnt +1'b1;
  if (cnt==4'he) begin 
    data_send   <= {~data,data,~data,data,~data,data+3'd1,~data,data,~data,data+3'd2,~data,data,~data,data+3'd3,~data,data,~data,data+3'd4,~data,data,~data,data+3'd5,~data,data,~data,data+3'd6,~data,data};
    data <= data +1'b1;
  end  
  if (cnt==4'hf) tx_req <= 1'b1;
  else           tx_req <= 1'b0;
end

endmodule
