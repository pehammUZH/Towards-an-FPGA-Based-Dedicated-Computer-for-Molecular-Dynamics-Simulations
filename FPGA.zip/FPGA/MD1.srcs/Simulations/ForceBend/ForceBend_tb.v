`timescale 1ns / 1ps


module ForceBend_tb;

integer i,out;
//integer dat0,dat1,dat2,dat3,dat4,dat5,dat6,dat7,dat8;



parameter npipe=55;
//parameter nPipe_cosphi=12;
parameter range=  24'sh080000;


initial begin
  out= $fopen("../../../../../../forceBend.dat","w"); 
end

reg [3:0]          state=1'b0;
reg [9:0]          cnt=1'b0;
reg [2:0]          cnt2=1'b0;
reg                startForce = 1'b0;
wire               startForce2;

reg                IOclk       = 1'b0;
reg                CalcClk     = 1'b0;


always #5        IOclk = ~IOclk; 
always #1.667    CalcClk    = ~CalcClk ; 

always @(posedge IOclk) begin
  case(state)
    0: begin
      cnt <= cnt + 1'b1;
      if (cnt==10'h20) begin
        state        <= 4'd7;
      end  
    end
    7: begin
      startForce  <= 1'b1;
      state       <= 4'd8;
    end
    8: begin
      startForce <= 1'b0;
    end
  endcase
end  

ClkTransfer #(.extend (3)) ClkTransfer3
(
    .clkIn   (IOclk),
    .clkOut  (CalcClk),
    .sigIn   (startForce),
    .sigOut  (startForce2)
); 

reg         [npipe:0] pipe=1'b0;
reg         [3:0]     state2=1'b0;
reg                   AddFtot=1'b0;
reg                   StoreFtot=1'b0;
wire                  StoreFtot_out;
wire                  ready;
reg  signed [23:0]    dx1 = -range, dy1 = 24'h000000, dz1 = 24'h000000;
reg  signed [23:0]    dx2 =  range, dy2 = 24'h000000, dz2 = 24'h040000;
reg  signed [23:0]    dx_pipe[npipe:0],dy_pipe[npipe:0],dz_pipe[npipe:0];
wire signed [31:0]    Fx_tot, Fy_tot, Fz_tot; 
wire signed [25:0]    cosphi;
wire signed [26:0]    cosphi_out={1'b0,cosphi};
wire signed [23:0]    iSin;
wire signed [24:0]    phi_iSin;
wire signed [24:0]    fact1;
wire signed [24:0]    fact2;
reg                   bendType=1'b0;




reg signed [24:0]    iSin_out;


always @(posedge CalcClk) begin
//  iSin_out<={1'b0,iSin};
  pipe<={pipe[npipe-1:0],pipe[0]};
  
/*
  cosphi_pipe[0]<={1'b0,cosphi};
  for(i=1;i<nPipe_cosphi;i=i+1) begin
    cosphi_pipe[i]<=cosphi_pipe[i-1];
  end
*/
  
  dx_pipe[0] <= dx1;
  dy_pipe[0] <= dy1;
  dz_pipe[0] <= dz1;
  for(i=1;i<=npipe;i=i+1) begin
    dx_pipe[i] <= dx_pipe[i-1];
    dy_pipe[i] <= dy_pipe[i-1];
    dz_pipe[i] <= dz_pipe[i-1];
  end  
    
  case(state2)
    0: begin
      if(startForce2) begin
        state2    <= 4'd1;
        pipe[0]   <= 1'b1;
      end  
    end
    1: begin
      StoreFtot <= 1'b0;
      state2 <= 4'd2;
    end    
    2: begin
      StoreFtot <= 1'b0;
      pipe[0] <= 1'b1;
      if(ready) begin
 //       bendType      <= ~bendType;
        dx1      <= dx1 + 24'h800;  
        dy1      <= dx1<24'sh0 ? dy1 + 24'h800 : dy1 - 24'h800;
        state2 <= 4'd3;
      end 
    end  
    3: begin
      state2 <= 4'd4;
    end
    4: begin
      AddFtot <= 1'b1;
      state2 <= 4'd5;
    end
    5: begin  
      AddFtot <= 1'b0;
      StoreFtot <= 1'b1;
      if (dx1>=range - 24'sh400) begin
        state2 <= 4'd6;
        pipe[0] <= 1'b0;
      end else  state2 <= 4'd2;
    end
    6: begin
      StoreFtot <= 1'b0;
      if (pipe[npipe]==1'b0) state2 <= 4'd7;
    end
    7: begin
      $fclose(out);
    end
  endcase
  if(StoreFtot_out) begin
   // $display("%f",Fx_tot);
    $fwrite(out,"%8d %8d %8d %9d %9d %9d %9d %9d %9d %9d\n",dx_pipe[npipe-1],dy_pipe[npipe-1], dz_pipe[npipe-1], cosphi_out, phi_iSin,fact1,fact2,Fx_tot,Fy_tot,Fz_tot);
  end
end    



ForceBend ForceBend
(   
  .MDReset       (1'b0),
  .clk           (CalcClk),
  .AddFtot       (AddFtot),
  .ready         (ready),
  .StoreFtot     (StoreFtot),
  .StoreFtot_out (StoreFtot_out),
  .dx1           (dx1),
  .dy1           (dy1),
  .dz1           (dz1),
  .dx2           (dx2),
  .dy2           (dy2),
  .dz2           (dz2),
  .k             (dx1==0 ? 18'h10000 : 18'h10000),
  .phi0          (dx1==0 ? 17'h10000 : 17'h14000),  
  .bendType      (bendType),
  .Fx_tot        (Fx_tot),
  .Fy_tot        (Fy_tot), 
  .Fz_tot        (Fz_tot),
//outputs for debugging
  .cosphi        (cosphi),
  .phi_iSin      (phi_iSin),
  .fact1         (fact1),
  .fact2         (fact2)
);



endmodule
