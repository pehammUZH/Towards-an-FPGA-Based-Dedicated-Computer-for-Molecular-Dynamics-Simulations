`timescale 1ns / 1ps


module ForceDihedral_tb;

integer i,out;




parameter npipe=59;
parameter range=  24'sh080000;        //range about 24'sh013000 (0.019) to 24'sh0B0000 (0.17) 


initial begin
  out= $fopen("../../../../../../forceDihedral.dat","w"); 
end

reg [3:0]          state=1'b0;
reg [9:0]          cnt=1'b0;
reg [2:0]          cnt2=1'b0;
reg                startForce = 1'b0;
wire               startForce2;

reg                CalcClk     = 1'b0;


always #1.667    CalcClk    = ~CalcClk ; 

always @(posedge CalcClk) begin
  case(state)
    0: begin
      cnt <= cnt + 1'b1;
      if (cnt==10'h40) begin
        state        <= 4'd7;
      end  
    end
    7: begin
      startForce  <= 1'b1;
      state       <= 4'd8;
    end
    8: begin
      startForce <= 1'b0;
    end
  endcase
end  



reg         [npipe:0] pipe=1'b0;
reg         [3:0]     state2=1'b0;
reg                   AddFtot=1'b0;
reg                   StoreFtot=1'b0;
wire                  StoreFtot_out;
wire                  ready;
reg  signed [23:0]    dxij = -range, dyij = 24'h0, dzij = -range;
reg  signed [23:0]    dxkj = range, dykj = 24'h0, dzkj =24'h0;
reg  signed [23:0]    dxkl = -range, dykl = 24'h0, dzkl =-range;   //-range

reg  signed [23:0]    dxij_pipe[npipe:0],dyij_pipe[npipe:0],dzij_pipe[npipe:0];
reg  signed [23:0]    dxkj_pipe[npipe:0],dykj_pipe[npipe:0],dzkj_pipe[npipe:0];
reg  signed [23:0]    dxkl_pipe[npipe:0],dykl_pipe[npipe:0],dzkl_pipe[npipe:0];
wire signed [31:0]    Fx_tot, Fy_tot, Fz_tot; 
wire signed [24:0]    cos,sin,sincos,sincos2,dVdphi,Fi,Fl;



always @(posedge CalcClk) begin
  pipe<={pipe[npipe-1:0],pipe[0]};
  dxij_pipe[0] <= dxij;
  dyij_pipe[0] <= dyij;
  dzij_pipe[0] <= dzij;
  dxkj_pipe[0] <= dxkj;
  dykj_pipe[0] <= dykj;
  dzkj_pipe[0] <= dzkj;
  dxkl_pipe[0] <= dxkl;
  dykl_pipe[0] <= dykl;
  dzkl_pipe[0] <= dzkl;
  for(i=1;i<=npipe;i=i+1) begin
    dxij_pipe[i] <= dxij_pipe[i-1];
    dyij_pipe[i] <= dyij_pipe[i-1];
    dzij_pipe[i] <= dzij_pipe[i-1];
    
    dxkj_pipe[i] <= dxkj_pipe[i-1];
    dykj_pipe[i] <= dykj_pipe[i-1];
    dzkj_pipe[i] <= dzkj_pipe[i-1];
    
    dxkl_pipe[i] <= dxkl_pipe[i-1];
    dykl_pipe[i] <= dykl_pipe[i-1];
    dzkl_pipe[i] <= dzkl_pipe[i-1];
  end  
    
    
  case(state2)
    0: begin
      if(startForce) begin
        state2    <= 4'd1;
        pipe[0]   <= 1'b1;
      end  
    end
    1: begin
      StoreFtot <= 1'b0;
      AddFtot <= 1'b1;
      state2 <= 4'd3;
    end    
    2: begin
      StoreFtot <= 1'b0;
      pipe[0] <= 1'b1;
      AddFtot <= 1'b1;
     
      dzij      <= dzij + 24'h800; 
      dyij      <= dzij<24'sh0 ? dyij + 24'h800 : dyij - 24'h800;
      dzkl      <= dzkl + 24'h800;  
      dykl      <= dzij<24'sh0 ? dykl - 24'h800 : dykl + 24'h800;
 
/*   
      dzij      <= dzij + 24'h800;                                   //move all coordinates
      dyij      <= dzij<24'sh0 ? dyij + 24'h700 : dyij - 24'h700;
      dxij      <= dxij+24'h10;
      
      dzkl      <= dzkl + 24'h600;  
      dykl      <= dzij<24'sh0 ? dykl - 24'h500 : dykl + 24'h500;
      dxkl      <= dxkl-24'h10;
      
      dxkj      <= dxkj+24'h5;
      dykj      <= dykj+24'h20;
      dzkj      <= dzkj-24'h20;
 */     
      state2 <= 4'd3;
    end  
    3: begin
      AddFtot <= 1'b0;
      StoreFtot <= 1'b1;
      state2 <= 4'd5;
    end
    4: begin                    //wait cycle
      StoreFtot <= 1'b0;
      state2 <= 4'd5;
    end
    5: begin                    //need one wait cycle when reading final output
      StoreFtot <= 1'b0;
      state2 <= 4'd6;
    end
    6: begin  
      StoreFtot <= 1'b0;
      if (dzij>=range ) begin
        state2 <= 4'd7;
        pipe[0] <= 1'b0;
      end else  state2 <= 4'd2;
    end
    7: begin
      StoreFtot <= 1'b0;
      if (pipe[npipe]==1'b0) state2 <= 4'd8;
    end
    8: begin
      $fclose(out);
    end
  endcase
  if(StoreFtot_out) begin
 //   $display("%8d %8d %8d",dx_pipe[npipe-1],dy_pipe[npipe-1], dz_pipe[npipe-1]);
    $fwrite(out,"%8d %8d %8d %8d %8d %8d %8d %8d %8d %9d %9d %9d %9d %9d %10d %10d %10d\n",dxij_pipe[npipe-1],dyij_pipe[npipe-1], dzij_pipe[npipe-1],dxkj_pipe[npipe-1],dykj_pipe[npipe-1], dzkj_pipe[npipe-1],dxkl_pipe[npipe-1],dykl_pipe[npipe-1], dzkl_pipe[npipe-1],cos,sin,dVdphi,Fi,Fl,Fx_tot,Fy_tot,Fz_tot);
  end
end    



ForceDihedral ForceDihedral
(   
  .MDReset       (1'b0),
  .clk           (CalcClk),
  .AddFtot       (AddFtot),
  .ready         (ready),
  .StoreFtot     (StoreFtot),
  .StoreFtot_out (StoreFtot_out),
  .dxij          (dxij),
  .dyij          (dyij),
  .dzij          (dzij),
  .dxkj          (dxkj),
  .dykj          (dykj),
  .dzkj          (dzkj),
  .dxkl          (dxkl),
  .dykl          (dykl),
  .dzkl          (dzkl),
  .k1            (dzij==range/2 ? 18'h10000 : 18'h10000),          
  .k2            (dzij==range/4 ? 18'h00000 : 18'h00000), 
  .k3            (dzij==range/4 ? 18'h00000 : 18'h00000),     
  .dihedType     (dzij==range/2 ? 1'b0 : 1'b0),        
  .Fx_tot        (Fx_tot),
  .Fy_tot        (Fy_tot), 
  .Fz_tot        (Fz_tot),
//outputs for debugging
  .cos_out       (cos),
  .sin_out       (sin),
  .dVdphi_out    (dVdphi),
  .Fi_out        (Fi),
  .Fl_out        (Fl)
);



endmodule
