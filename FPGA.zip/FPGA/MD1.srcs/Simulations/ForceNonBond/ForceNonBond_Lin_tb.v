`timescale 1ns / 1ps

//Version that runs the version that uses only linear interpolation of force; using as little as possible resozrces

module ForceNonBond_tb;

integer in,i,out,data;
integer dat0,dat1,dat2,dat3,dat4;
reg [35:0] LUTforce [0:1023];

parameter npipe=17;   
  
initial begin
  $display("Open file with LUT of forces");
  in = $fopen("../../../../../../LUTforce.dat","r");
  out= $fopen("../../../../../../forceout.dat","w");

  for(i=0;i<1024;i=i+1) begin
    $fscanf(in,"%x %x %x %x %x %x %x %x %x",dat0,dat1,dat2,dat3,dat4);
 //   $display("%h",{dat0[3:0],dat1[7:0],dat2[7:0],dat3[7:0],dat4[7:0]});
    LUTforce[i] <= {dat0[7:0],dat1[7:0],dat2[7:0],dat3[7:0],dat4[7:0]};
  end   
  $fclose(in);
end

reg [3:0]          state=1'b0;
reg [9:0]          cnt=1'b0;
reg [2:0]          cnt2=1'b0;
reg [11:0]         addrForceLUT=1'b0;
reg [35:0]         dataForceLUT=1'b0;
reg                wrForceLUT=1'b0;
reg                startForce = 1'b0;
wire               startForce2;

reg                IOclk       = 1'b0;
reg                CalcClk     = 1'b0;

always #5        IOclk = ~IOclk; 
always #1.667    CalcClk    = ~CalcClk ; 

always @(posedge IOclk) begin
  case(state)
    0: begin
      cnt <= cnt + 1'b1;
      if (cnt==10'h20) begin
        state           <= 4'd1;
        cnt             <= 1'b0;
        cnt2            <= 1'b0;
        wrForceLUT      <= 1'b1;  
        addrForceLUT    <= 1'b0;
        dataForceLUT    <= LUTforce[0];
      end  
    end
    1: begin                     //write into LUT memory
      cnt2          <= cnt2 + 1'b1;
      addrForceLUT  <= addrForceLUT + 1'b1;
      dataForceLUT  <= {9'b0,dataForceLUT[35:9]};
      if(cnt2==3'h3) begin
        cnt2         <= 1'b0;
        cnt          <= cnt + 1'b1;
        dataForceLUT <= LUTforce[cnt+1'b1];
        if (cnt==10'h3ff) begin
          state <= 4'd2;
          wrForceLUT   <= 1'b0;
        end
      end    
    end
    2: begin
       startForce <= 1'b1;
       state      <= 4'd3;
    end
    3: begin
      startForce <= 1'b0;
    end
  endcase
end  

ClkTransfer #(.extend (3)) ClkTransfer3
(
    .clkIn   (IOclk),
    .clkOut  (CalcClk),
    .sigIn   (startForce),
    .sigOut  (startForce2)
); 

reg         [npipe:0] pipe=1'b0;
reg         [3:0]     state2=1'b0;
reg  signed [23:0]    dx = 1'b0, dy = 1'b0, dz = 1'b0;  //24'h3f
reg  signed [23:0]    dx_pipe[npipe:0],dy_pipe[npipe:0],dz_pipe[npipe:0];
wire signed [31:0]    Fx_tot, Fy_tot, Fz_tot; 

always @(posedge CalcClk) begin
  pipe<={pipe[npipe-1:0],pipe[0]};
  
  dx_pipe[0] <= dx;
  dy_pipe[0] <= dy;
  dz_pipe[0] <= dz;
  for(i=1;i<=npipe;i=i+1) begin
    dx_pipe[i] <= dx_pipe[i-1];
    dy_pipe[i] <= dy_pipe[i-1];
    dz_pipe[i] <= dz_pipe[i-1];
  end  
    
  case(state2)
    0: begin
      if(startForce2) begin
        state2 <= 4'd1;
        pipe[0] <= 1'b1;
        
      end  
    end
    1: begin
      pipe[0] <= 1'b1;
      dx      <= dx + 24'h200;  //24'he0080; //24'h0800;  //with 24'he0080, the first non-zero r2 has all other values non-zero, good to follow pipeline
      if (dx>=24'h410000) begin
        state2 <= 4'd2;
        pipe[0] <= 1'b0;
      end  
    end
    2: begin
      if (pipe[npipe]==1'b0) state2 <= 4'd3;
    end
    3: begin
      $fclose(out);
    end
  endcase
  if(pipe[npipe]) begin
   // $display("%f",Fx_tot);
    $fwrite(out,"%8d %9d\n",dx_pipe[npipe-1],Fx_tot);
  end
end    


ForceNonBond ForceNonBondHome
(
.IOclk         (IOclk),        
.CalcClk       (CalcClk),
.wrForceLUT    (wrForceLUT),   
.dataForceLUT  (dataForceLUT[8:0]), 
.adrForceLUT   (addrForceLUT),          
.selForceLUT   (1'b0),         
.ResetFtot     (1'b0),
.AddFtot       (1'b1), 
.StoreFtot     (1'b0),
.StoreFtot_out (StoreFtot_out), 
.dx            (dx),
.dy            (dy),
.dz            (dz),
.Fx_tot        (Fx_tot),
.Fy_tot        (Fy_tot), 
.Fz_tot        (Fz_tot)
);


endmodule