`timescale 1ns / 1ps


module ForceNonBond_tb;

integer in,i,out,data;
integer dat0,dat1,dat2,dat3,dat4,dat5,dat6,dat7,dat8;
reg [71:0] LUT_LJ   [0:511];
reg [71:0] LUT_Coul [0:511];
//reg [71:0] LUT_InvSqrtR2 [0:511];


parameter npipe=27;  
parameter  nSelForceLUT       = 3;      //width of SelForceLUT 
parameter  metaAtomNr_len     = 16;      //length of atom number in meta data;     
parameter  nProteinAtom       = 12;     //defines maximum number of protein atoms: 2^nProteinAtom                                           
parameter  nCLOSEATOM         = 21;     //maximum number of closeAtoms, which is floor(256/(nProteinAtom+1))          

initial begin
  $display("Open file with LUT of forces");
  in = $fopen("../../../../../../LUTforceLJ.dat","r");
  for(i=0;i<512;i=i+1) begin
    $fscanf(in,"%x %x %x %x %x %x %x %x %x",dat0,dat1,dat2,dat3,dat4,dat5,dat6,dat7,dat8);
    LUT_LJ[i] <= {dat0[7:0],dat1[7:0],dat2[7:0],dat3[7:0],dat4[7:0],dat5[7:0],dat6[7:0],dat7[7:0],dat8[7:0]};
  end   
  $fclose(in);
  
  in = $fopen("../../../../../../LUTforceCoul.dat","r");
  for(i=0;i<512;i=i+1) begin
    $fscanf(in,"%x %x %x %x %x %x %x %x %x",dat0,dat1,dat2,dat3,dat4,dat5,dat6,dat7,dat8);
    LUT_Coul[i] <= {dat0[7:0],dat1[7:0],dat2[7:0],dat3[7:0],dat4[7:0],dat5[7:0],dat6[7:0],dat7[7:0],dat8[7:0]};
  end   
  $fclose(in);
 
 /* 
  $display("Open file with LUT of forces");
  in = $fopen("../../../../../../LUTforce.dat","r");
  for(i=0;i<512;i=i+1) begin
    $fscanf(in,"%x %x %x %x %x %x %x %x %x",dat0,dat1,dat2,dat3,dat4,dat5,dat6,dat7,dat8);
    LUT_InvSqrtR2[i] <= {dat0[7:0],dat1[7:0],dat2[7:0],dat3[7:0],dat4[7:0],dat5[7:0],dat6[7:0],dat7[7:0],dat8[7:0]};
  end   
  $fclose(in);
 */ 
  out= $fopen("../../../../../../forceout.dat","w"); 
end

reg [3:0]          state=1'b0;
reg [9:0]          cnt=1'b0;
reg [2:0]          cnt2=1'b0;
reg [71:0]         dataForceLUT=1'b0;
reg [11:0]         addrForceLUT=1'b0;
reg                wrForceLUT=1'b0;
reg                startForce = 1'b0;
wire               startForce2;

reg                IOclk       = 1'b0;
reg                CalcClk     = 1'b0;
reg [2:0]          selForceLUT = 1'b0;

always #5        IOclk = ~IOclk; 
always #1.667    CalcClk    = ~CalcClk ; 

always @(posedge IOclk) begin
  case(state)
    0: begin
      cnt <= cnt + 1'b1;
      if (cnt==10'h20) begin
        state        <= 4'd1;
        cnt          <= 1'b0;
        cnt2         <= 1'b0;
        wrForceLUT   <= 1'b1;
        dataForceLUT <= LUT_LJ[0];
        addrForceLUT <= 1'b0;
        selForceLUT  <= 2'h0;
      end  
    end
    1: begin                     //write LJ forces into LUT memory
      cnt2          <= cnt2 + 'b1;
      addrForceLUT  <= addrForceLUT + 1'b1;
      dataForceLUT  <= {9'b0,dataForceLUT[71:9]};
      if(cnt2==3'h7) begin
        cnt          <= cnt + 1'b1;
        dataForceLUT <= LUT_LJ[cnt+1'b1];
        if (cnt==10'h1ff) begin
          state <= 4'd2;
          cnt          <= 1'b0;
          cnt2         <= 1'b0;
          dataForceLUT <= LUT_Coul[0];
          addrForceLUT <= 1'b0;
          selForceLUT  <= 2'h1;
        end
      end    
    end
    2: begin                     //write Coulomb forces into LUT memory
      cnt2          <= cnt2 + 'b1;
      addrForceLUT  <= addrForceLUT + 1'b1;
      dataForceLUT  <= {9'b0,dataForceLUT[71:9]};
      if(cnt2==3'h7) begin
        cnt          <= cnt + 1'b1;
        dataForceLUT <= LUT_Coul[cnt+1'b1];
        if (cnt==10'h1ff) begin
          state <= 4'd4;
          wrForceLUT   <= 1'b0;
        end
      end    
    end
    4: begin
      selForceLUT  <= 2'h3;
      dataForceLUT <= (36'h10000<<18)+36'h04000;    //writing 1 and 1
      wrForceLUT   <= 1'b1;
      addrForceLUT <= 1'b0;
      state        <= 4'd5; 
      cnt2         <= 1'b0;
    end
    5: begin                     //write into LUT memory
      cnt2          <= cnt2 + 'b1;
      addrForceLUT  <= addrForceLUT + 1'b1;
      dataForceLUT  <= {9'b0,dataForceLUT[71:9]};
      if(cnt2==3'h3) begin
        cnt2         <= 1'b0;
        dataForceLUT <= (36'h10000<<18)+36'h1f000;
        state        <= 4'd6;
      end    
    end
    6: begin                     //write into LUT memory
      cnt2          <= cnt2 + 'b1;
      addrForceLUT  <= addrForceLUT + 1'b1;
      dataForceLUT  <= {9'b0,dataForceLUT[71:9]};
      if(cnt2==3'h3) begin
        wrForceLUT   <= 1'b0;
        state        <= 4'd7;
      end    
    end    
    7: begin
      wrForceLUT  <= 1'b0;
      startForce  <= 1'b1;
      state       <= 4'd8;
    end
    8: begin
      startForce <= 1'b0;
    end
  endcase
end  

ClkTransfer #(.extend (3)) ClkTransfer3
(
    .clkIn   (IOclk),
    .clkOut  (CalcClk),
    .sigIn   (startForce),
    .sigOut  (startForce2)
); 

reg         [npipe:0] pipe=1'b0;
reg         [3:0]     state2=1'b0;
reg  signed [23:0]    dx = 24'h000000, dy = 24'h000000, dz = 24'h000000;
reg  signed [23:0]    dx_pipe[npipe:0],dy_pipe[npipe:0],dz_pipe[npipe:0];
wire signed [31:0]    Fx_tot, Fy_tot, Fz_tot; 

always @(posedge CalcClk) begin
  pipe<={pipe[npipe-1:0],pipe[0]};
  
  dx_pipe[0] <= dx;
  dy_pipe[0] <= dy;
  dz_pipe[0] <= dz;
  for(i=1;i<=npipe;i=i+1) begin
    dx_pipe[i] <= dx_pipe[i-1];
    dy_pipe[i] <= dy_pipe[i-1];
    dz_pipe[i] <= dz_pipe[i-1];
  end  
    
  case(state2)
    0: begin
      if(startForce2) begin
        state2 <= 4'd1;
        pipe[0] <= 1'b1;
        
      end  
    end
    1: begin
      pipe[0] <= 1'b1;
      dx      <= dx + 24'h800;  //24'he0080; //24'h0800;  //with 24'he0080, the first non-zero r2 has all other values non-zero, good to follow pipeline
      if (dx>=24'h500000) begin
        state2 <= 4'd2;
        pipe[0] <= 1'b0;
      end  
    end
    2: begin
      if (pipe[npipe]==1'b0) state2 <= 4'd3;
    end
    3: begin
      $fclose(out);
    end
  endcase
  if(pipe[npipe]) begin
   // $display("%f",Fx_tot);
    $fwrite(out,"%8d %9d\n",dx_pipe[npipe-1],Fx_tot);
  end
end    



ForceNonBond 
#(
.nSelForceLUT       (nSelForceLUT),      //width of SelForceLUT 
.metaAtomNr_len     (metaAtomNr_len),      //length of atom number in meta data;     
.nProteinAtom       (nProteinAtom),     //defines maximum number of protein atoms: 2^nProteinAtom                                         
.nCLOSEATOM         (nCLOSEATOM) 
) ForceNonBondHome
(
.IOclk        (IOclk),        
.CalcClk      (CalcClk),
.wrForceLUT   (wrForceLUT),   
.dataForceLUT (dataForceLUT[8:0]),                            
.adrForceLUT  (addrForceLUT),                                      
.selForceLUT  (selForceLUT),                               
.AddFtot      (1'b1),
.StoreFtot    (1'b0),
.iAtom1       (14'h000),                                    //is new
.iAtom2       (dx==24'h200000 ? 16'h0003  :16'h0006),         //is new
.closeAtom    ({12'h000,12'h000,12'h000,12'h000,12'h000,12'h000,12'h000,12'h000,12'h000,12'h000,12'h000,12'h000,12'h000,12'h000,12'h000,12'h000,12'h000,12'h000,12'h001,12'h002,12'h003}),
.pair14       ({18'b0,3'b001}),
.fudgeQQ      (18'd54611),     //0.8333; 0x10000 corresponds to 1
.fudgeLJ      (1'b0),
.dx           (dx),
.dy           (dy),
.dz           (dz),
.atomTypeLJ1  (5'h0),              
.atomTypeLJ2  (5'h0),    
//.atomTypeLJ2  (5'h1), //effectively switches off  LJ forces   
//.atomTypeLJ2  (dx==24'h200000 ? 5'h1 : 5'h0),                                                                      
.charge1      (18'd26869),                                  //0.41
//.charge2      (-18'd53739),                                 //-.81     
.charge2       (18'd0), 
//.charge2      (dx==24'h200000 ? 18'h0 : 18'h10000),                                  //is equivalent of +1
.Fx_tot       (Fx_tot),
.Fy_tot       (Fy_tot), 
.Fz_tot       (Fz_tot)
);


endmodule