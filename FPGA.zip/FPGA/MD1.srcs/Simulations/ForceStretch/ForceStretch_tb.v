`timescale 1ns / 1ps


module ForceStretch_tb;

integer out,i;




parameter npipe=31;   


initial begin
  out= $fopen("../../../../../../forceStretch.dat","w"); 
end

reg [3:0]          state=1'b0;
reg [9:0]          cnt=1'b0;
reg [2:0]          cnt2=1'b0;
reg [71:0]         dataForceLUT=1'b0;
reg [11:0]         addrForceLUT=1'b0;
reg                wrForceLUT=1'b0;
reg                startForce = 1'b0;
reg                AddFtot = 1'b0;
reg                ResetFtot =1'b0;
reg                StoreFtot =1'b0;
wire               StoreFtot_out;
wire               startForce2;
wire               ready;

reg                IOclk       = 1'b0;
reg                CalcClk     = 1'b0;
reg [2:0]          selForceLUT = 1'b0;
reg                MDReset     = 1'b1;

always #5        IOclk = ~IOclk; 
always #1.667    CalcClk    = ~CalcClk ; 

always @(posedge IOclk) begin
  case(state)
    0: begin
      cnt <= cnt + 1'b1;
      if (cnt==10'h20) begin
        state        <= 4'd6;
      end  
    end
    6: begin
      MDReset <= 1'b0;
      state        <= 4'd7;
    end
    7: begin
      startForce  <= 1'b1;
      state       <= 4'd8;
    end
    8: begin
      startForce <= 1'b0;
    end
  endcase
end  

ClkTransfer #(.extend (3)) ClkTransfer3
(
    .clkIn   (IOclk),
    .clkOut  (CalcClk),
    .sigIn   (startForce),
    .sigOut  (startForce2)
); 

reg         [npipe:0] pipe=1'b0;
reg         [3:0]     state2=1'b0;
reg  signed [23:0]    dx = 24'h000000, dy = 24'h000000, dz = 24'h000000;
reg  signed [23:0]    dx_pipe[npipe:0],dy_pipe[npipe:0],dz_pipe[npipe:0];
wire signed [31:0]    Fx_tot, Fy_tot, Fz_tot; 

always @(posedge CalcClk) begin
  pipe<={pipe[npipe-1:0],pipe[0]};
  
  dx_pipe[0] <= dx;
  dy_pipe[0] <= dy;
  dz_pipe[0] <= dz;
  for(i=1;i<=npipe;i=i+1) begin
    dx_pipe[i] <= dx_pipe[i-1];
    dy_pipe[i] <= dy_pipe[i-1];
    dz_pipe[i] <= dz_pipe[i-1];
  end  
    
  case(state2)
    0: begin
      if(startForce2) begin
        state2    <= 4'd1;
        pipe[0]   <= 1'b1;
        ResetFtot <= 1'b1;
      end  
    end
    1: begin
      StoreFtot <= 1'b0;
      ResetFtot <= 1'b0;  
      pipe[0] <= 1'b1;
      if(ready) begin
        dx      <= dx + 24'h800;  //24'he0080; //24'h0800;  //with 24'he0080, the first non-zero r2 has all other values non-zero, good to follow pipeline
        dy      <= dy + 24'h80;
        dz      <= dz + 24'h8; 
        AddFtot <= 1'b1;
        state2 <= 4'd2;
      end 
    end  
    2: begin  
      AddFtot <= 1'b0;
      StoreFtot <= 1'b1;
      if (dx>=24'h500000) begin
        state2 <= 4'd3;
        pipe[0] <= 1'b0;
      end else  state2 <= 4'd1;
    end
    3: begin
      StoreFtot <= 1'b0;
      if (pipe[npipe]==1'b0) state2 <= 4'd4;
    end
    4: begin
      $fclose(out);
    end
  endcase
  if(StoreFtot_out) begin
   // $display("%f",Fx_tot);
    $fwrite(out,"%8d %8d %8d %10d %10d %10d\n",dx_pipe[npipe-1],dy_pipe[npipe-1],dz_pipe[npipe-1],Fx_tot,Fy_tot,Fz_tot);
  end
end    


ForceStretch ForceStretch
(       
.clk           (CalcClk),
.MDReset       (MDReset),
//.ResetFtot     (ResetFtot),
.AddFtot       (AddFtot),
.ready         (ready),
.StoreFtot     (StoreFtot),
.StoreFtot_out (StoreFtot_out),
.dx            (dx),
.dy            (dy),
.dz            (dz),
.r0            (dx==24'h085000 ? 17'h12000 : 17'h10000),
.k             (17'h02000),  
.Fx_tot        (Fx_tot),
.Fy_tot        (Fy_tot), 
.Fz_tot        (Fz_tot)
);



endmodule