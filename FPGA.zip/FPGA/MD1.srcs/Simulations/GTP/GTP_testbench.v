`timescale 1ns / 1ps

module GTP_testbench;

parameter nGTP=7;

wire [3:0]         tx_kchar;
wire [31:0]        tx_data;

reg [3:0]         tx_kchar_cp;
reg [31:0]        tx_data_cp;

reg                tx_clk       = 1'b0;
reg                IOclk        = 1'b0;

reg  [nGTP*32-1:0] data_port0   = 1'b0;
reg  [nGTP*32-1:0] data_port1   = 1'b0;
reg  [nGTP*32-1:0] data_port2   = 1'b0;
reg  [nGTP*32-1:0] data_port3   = 1'b0;
reg                tx_req_port0 = 1'b0;
reg                tx_req_port1 = 1'b0;
reg                tx_req_port2 = 1'b0;
reg                tx_req_port3 = 1'b0;
reg [15:0]         allCnt       = 1'b0;

wire [nGTP*32-1:0] data_recv;

gtp_tx #(.nGTP (nGTP)) gtp_tx
(
    .rst          (1'b0),
    .tx_clk       (tx_clk),
    .IOclk        (IOclk),
    .tx_data      (tx_data),
    .tx_kchar     (tx_kchar),
    .data_port0   (data_port0),          
    .tx_req_port0 (tx_req_port0),    
    .data_port1   (data_port1),          
    .tx_req_port1 (tx_req_port1),   
    .data_port2   (data_port2),          
    .tx_req_port2 (tx_req_port2),
    .data_port3   (data_port3),          
    .tx_req_port3 (tx_req_port3),                  
    .tx_error     (tx0_error),
    .mux_error    (),
    .bussy        ()
);

always @(posedge tx_clk) allCnt <= allCnt +1'b1;
always @(*) begin
  tx_kchar_cp <= tx_kchar;
  //tx_data_cp  <= tx_data;
  tx_data_cp   <= (allCnt==16'h83) ? tx_data^32'h10000000 : tx_data;   //mimic error in transmission; overlays with frequency cnt
end  

gtp_rx #(.nGTP (nGTP)) gtp_rx                          
(
    .rst                      (1'b0),
    .rx_clk                   (tx_clk),
    .IOclk                    (IOclk),
    .rx_data                  (tx_data_cp),
    .rx_kchar                 (tx_kchar_cp),
    .data_recv                (data_recv),          //output [nGTP*32-1:0] compiled received data
    .data_valid               (data_valid),        //output              received data valid
    .error                    (rx_error),            //output              crc error in received data
    .bussy                    ()
);

always #4 tx_clk     = ~tx_clk; 
always #5 IOclk      = ~IOclk; 




reg   [1:0]   cnt=1'b0;
reg   [7:0]   data=1'b0;
always @(posedge IOclk) begin
  if(allCnt>16'h30&&allCnt<=16'h303) begin
    cnt <= cnt +1'b1;
    if (cnt==2'h2) begin 
      data_port0   <= {~data,data,~data,data,~data,data,~data,data,~data,data,~data,data,~data,data,~data,data,~data,data,~data,data,~data,data,~data,data,~data,data,~data,data};
      data <= data +1'b1;
    end  
    if (cnt==2'h3) tx_req_port0 <= 1'b1;
    else           tx_req_port0 <= 1'b0;
  end
end

endmodule
