`timescale 1ns / 1ps


module GatedMux_tb();

parameter nGTP=4'd1;

reg              IOclk       = 1'b0;
reg [15:0]       cnt=1'b0;
reg [3:0]        state=1'b0;             
always #5        IOclk = ~IOclk; 

wire      [nGTP*32-1:0]  data_port0;
reg                      tx_req_port0=1'b0;  
wire     [nGTP*32-1:0]   data_port1;
reg                      tx_req_port1=1'b0;  
wire     [nGTP*32-1:0]   data_port2;
reg                      tx_req_port2=1'b0;  
wire     [nGTP*32-1:0]   data_port3;
reg                      tx_req_port3=1'b0;   
wire     [nGTP*32-1:0]   dataout;
wire                     tx_req;


always @(posedge IOclk) begin
  case(state)
    0: begin
      cnt <= cnt + 1'b1;
      if (cnt==8'h10) begin
        state        <= 4'd1;
        cnt          <= 1'b0;
      end  
    end
    1: begin
      cnt <= cnt + 1'b1;
      tx_req_port0 <= (cnt==2) || (cnt==3) || (cnt==5);
      tx_req_port1 <= (cnt==2) || (cnt==7) ;
      tx_req_port2 <= (cnt==2) || (cnt==9);
      tx_req_port3 <= (cnt==1) || (cnt==8)|| (cnt==10) || (cnt==13);
    end
  endcase
end    

assign data_port0={8'b0,8'd0,cnt};
assign data_port1={8'b0,8'd1,cnt};
assign data_port2={8'b0,8'd2,cnt};
assign data_port3={8'b0,8'd3,cnt};

GatedMultplx
#(
.nPort   (4),
.nByte   (nGTP*4)                 
) GatedMultplx1
(
 .IOclk             (IOclk),
 .data_port         ({data_port3,data_port2,data_port1,data_port0}),
 .tx_req_port       ({tx_req_port3,tx_req_port2,tx_req_port1,tx_req_port0}),
 .tx_req            (tx_req),
 .dataout           (dataout),
 .error             (mux_error)
);
    
endmodule

