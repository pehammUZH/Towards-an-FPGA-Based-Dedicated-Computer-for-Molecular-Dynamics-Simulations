`timescale 1ns / 1ps

module ReadCommand_testbench();

parameter DataByteWidth=5'd27;
parameter  nProteinAtom    = 12;         //defines maximum number of protein atoms,                                          is new
//parameter  DDR3_DATA_WIDTH = 256;        //length of a line of DDR3 Ram, that stores protein force field parameter,          is new
//parameter  FF_LENGTH       = 36;          //Number of lines that defines force field.           
//reduced parameter set fro BRAM version
parameter  DDR3_DATA_WIDTH = 64;        //length of a line of DDR3 Ram, that stores protein force field parameter,          is new
parameter  FF_LENGTH       = 8;          //Number of lines that defines force field.           

reg                        IOclk  = 1'b0;
wire                       SendMem;
wire [10:0]                CommandCnt;
reg                        CommandValid = 1'b0;
reg  [7:0]                 CommandData  = 1'b0;
wire [7:0]                 PacketNr;
wire [7:0]                 PacketNrOld;
wire                       WriteDataAtom;
wire [DataByteWidth*8-1:0] DataAtom;
wire [31:0]                DataThermostat;
wire [2:0]                 AdrDataThermostat;
wire                       nAtomReset;
wire                       ErrorReset;
wire [8:0]                 dataForceLUT;
wire [11:0]                adrForceLUT;
wire                       wrForceLUT;
wire                       selForceLUT;
wire                         ForceField_rcv;   
wire [nProteinAtom-1:0]      ForceField_atom;  
wire [DDR3_DATA_WIDTH - 1:0] ForceField_data;         
      
ReadCommand
#(
.DataByteWidth   (DataByteWidth),
.nProteinAtom    (nProteinAtom),              //is new
.DDR3_DATA_WIDTH (DDR3_DATA_WIDTH),           //is new
.FF_LENGTH       (FF_LENGTH)                  //is new   
) ReadCommand
(  
 .IOclk                       (IOclk),   
 .ResetStart                  (ResetStart),
//in/output that remain within mac_top 
 .CommandCnt                  (CommandCnt),
 .CommandData                 (CommandData),
 .CommandValid                (CommandValid),
//data that are sent higher up 
 .PacketNr                    (PacketNr),                //output [7:0]                 packet number 
 .PacketNrOld                 (PacketNrOld),             //output [7:0]                 previouusly received packet number; to see if packest have been lost
//for command 0: status and reset
 .nAtomReset                  (nAtomReset),              //output                       reset nAtom counts
 .ErrorReset                  (ErrorReset),              //output                       reset Errors
 .MDReset                     (MDReset),                 //output                       reset MD machine
//for command 1: initiate MD  
 .InitCalc                    (InitCalc),
 .nstep                       (nstep),
//for command 2: write Force LUTs
 .wrForceLUT                  (wrForceLUT),    
 .dataForceLUT                (dataForceLUT),  
 .adrForceLUT                 (adrForceLUT),   
 .selForceLUT                 (selForceLUT),   
//for command 3: thermostat parameters.   
 .WriteDataThermostat         (WriteDataThermostat),
 .AdrDataThermostat           (AdrDataThermostat),
 .DataThermostat              (DataThermostat), 
//for command 4: shake parameters.      
 .WriteDataShake              (WriteDataShake),
 .AdrDataShake                (AdrDataShake),
 .DataShake                   (DataShake),             
//for command 5: protein force field data                                 //is new
 .ForceField_rcv              (ForceField_rcv),   
 .ForceField_atom             (ForceField_atom),  
 .ForceField_data             (ForceField_data),       
//for command 6:  receiving atom data                                    //command number is new
 .WriteDataAtom               (WriteDataAtom),           //output                       write data into BRAM
 .DataAtom                    (DataAtom),                //output [DataByteWidth*8-1:0] data to be written into BRAM
//for command 8: send atom data 
 .SendMacBox                  (SendMacBox),              //output [6:0]                 select box memory
 .nSend                       (nSendMem),
 .SendMem                     (SendMem)
);


//clock signals
always #5 IOclk = ~IOclk; 

reg   [10:0]   cnt=1'b0;
always @(posedge IOclk) begin
  cnt <= cnt +1'b1;
  CommandValid<=(cnt==11'd10);
/*  //sequence to write LUT
  if      (CommandCnt==1) CommandData <= 8'h1;    //packetNr
  else if (CommandCnt==2) CommandData <= 8'h2;    //command: write Force LUT
  else if (CommandCnt==3) CommandData <= 8'hc;    //start adress, MSB
  else if (CommandCnt==4) CommandData <= 8'h0;    //start adress, LSB
  else if (CommandCnt==5) CommandData <= 8'h0a;   //nLine1
  else if (CommandCnt==6) CommandData <= 4'h8;    //nLine2
  else if (CommandCnt==7) CommandData <= 8'h0;    //select
  else if (CommandCnt>7)  CommandData <= (CommandCnt[10:0]-8'd8)/9+1;
*/  
// sequence to receive atom Data from host computer
//  if      (CommandCnt==1) CommandData <= 8'h1;    //packetNr
//  else if (CommandCnt==2) CommandData <= 8'h6;    //command: received atom data from host computer
//  else if (CommandCnt==3) CommandData <= 8'h80;   //number of received atom data
//  else if (CommandCnt>3)  CommandData <= CommandCnt[7:0];
  
// sequence to receiv thermostat data from host computer and initiate calculation
 // if      (CommandCnt==1) CommandData <= 8'h1;    //packetNr
 // else if (CommandCnt==2) CommandData <= 8'h3;    //command: received thermostat data from host computer
 // else if (CommandCnt>2)  CommandData <= CommandCnt[7:0];
  
 // sequence to receive shake data from host computer and initiate calculation
//  if      (CommandCnt==1) CommandData <= 8'h1;    //packetNr
//  else if (CommandCnt==2) CommandData <= 8'h4;    //command: received thermostat data from host computer
//  else if (CommandCnt>2)  CommandData <= CommandCnt[7:0]; 
  
//sequence to receive force field data
  if      (CommandCnt==1) CommandData <= 8'h1;    //packetNr
  else if (CommandCnt==2) CommandData <= 8'h5;    //command: received force field data
  else if (CommandCnt==3) CommandData <= 8'h08;    //ForceField_data; MSB
  else if (CommandCnt==4) CommandData <= 8'hff;   //ForceField_data; LSB
  else if (CommandCnt>4)  CommandData <= CommandCnt[7:0]; 
  
//sequence to receive atom data
//  if      (CommandCnt==1) CommandData <= 8'h1;    //packetNr
//  else if (CommandCnt==2) CommandData <= 8'h6;    //command: received force field data
//  else if (CommandCnt==3) CommandData <= 8'h10;    //ForceField_data; MSB
//  else if (CommandCnt>3)  CommandData <= CommandCnt[7:0]; 
    
end

endmodule
