`timescale 1ns / 1ps


module shake_tb;

parameter  metaAtomNr_len     = 16;
parameter  DataByteWidth      = 27;
parameter  DataByteWidth_n    = 18;                   //reduced data width without velocities
parameter  vshift             = 4;                   
parameter  metaRoute          = 64;
parameter  metaMass           = 16;     //position of mass in meta data, is different position in reality
parameter  metaMass_len       = 6;      //its length; 16bit reserve
parameter  metaConstraint     = 24;      //position of contraint info in meta data, is different position in reality

integer out;
initial begin
  out= $fopen("../../../../../../shakeIteration.dat","w"); 
end

reg [3:0]                    state=1'b0;
reg [9:0]                    cnt=1'b0;
reg                          MDReset=1'b1;
reg                          atomRcv=1'b0;
reg [3:0]                    iList         = 1'b0;
reg [DataByteWidth_n*8-9+84:0] atomDataIn;                 //don't include 8bit that eventually will become route; velocities are 28bit  //new, also change in MDmachine 
reg [15:0]                   nIterTot = 1'b0;
reg                          WriteDataShake;    //write shake data
reg [2:0]                    AdrDataShake;      //adress of shake data, 0: rOHw, 1: rHHw, 2: rCH, 3: rNH, 4: rOH, 5: rSH
reg [17:0]                   DataShake;         //Shake data, inverse distance square, 17'b10000 corresponds to r=rcut/16 

reg                IOclk     = 1'b0;
wire signed [27:0] vx0_out,vx1_out,vx2_out,vy0_out,vy1_out,vy2_out,vz0_out,vz1_out,vz2_out,vx3_out,vy3_out,vz3_out;

parameter nList=3;
wire [DataByteWidth_n*8-9+84:0] atomList[nList-1:0];    //don't include 8bit that eventually will become route; velocities are 28bit

assign atomList[0] = { 28'h4000000, 28'h0000000, 28'h0000000,37'b0,3'h6,8'd16,16'h4, 24'h000000, 24'h000000, 24'h000000};   //position of mass and constraint data  is not where it will eventually be
assign atomList[1] = { 28'h0000000,-28'h4000000, 28'h4000000,37'b0,3'h6,8'd1 ,16'h5, 24'h000000, 24'h000000, 24'h040000};
assign atomList[2] = { 28'h0000000, 28'h0000000, 28'h0000000,37'b0,3'h6,8'h1 ,16'h6, 24'h000000, 24'h040000, 24'h000000};

/*
assign atomList[0] = { 25'h800000, 25'h000000, 25'h000000,37'b0,3'h1,8'd16,16'h4, 24'h000000, 24'h000000, 24'h000000};
assign atomList[1] = { 25'h000000,-25'h800000, 25'h800000,37'b0,3'h1,8'd1 ,16'h5, 24'h000000, 24'h000000, 24'd402138};      //distance r0/rcut=0.1/1.043*10^22 
*/

/*
//chnage to 28bit
assign atomList[3] = { 25'h000000, 25'h000000, 25'h000000,37'b0,3'h6,8'd16,16'h8, 24'h000000, 24'h000000, 24'h000000};
assign atomList[4] = { 25'h000000, 25'h000000, 25'h000000,37'b0,3'h6,8'd1,16'h9, 24'h000000, 24'h000000, 24'h040000};
assign atomList[5] = { 25'h000000,-25'h000000, 25'h400000,37'b0,3'h6,8'd1,16'ha, 24'h000000, 24'h040000, 24'h000000};
assign atomList[6] = {-25'h100000, 25'h000000, 25'h000000,37'b0,3'h6,8'd16,16'hc, 24'h000000, 24'h000000, 24'h000000};   
assign atomList[7] = { 25'h000000,-25'h100000, 25'h100000,37'b0,3'h6,8'h10,16'hd, 24'h000000, 24'h000000, 24'h040000};
assign atomList[8] = { 25'h000000, 25'h000000, 25'h000000,37'b0,3'h6,8'h10,16'he, 24'h000000, 24'h040000, 24'h000000};
assign atomList[9]= { 25'h100000, 25'h000000, 25'h000000,37'b0,3'h6,8'h10,16'h10, 24'h000000, 24'h000000, 24'h000000};   
assign atomList[10]= { 25'h000000,-25'h200000, 25'h200000,37'b0,3'h6,8'h10,16'h11, 24'h000000, 24'h000000, 24'h040000};
assign atomList[11]= { 25'h000000,-25'h200000, 25'h200000,37'b0,3'h6,8'h10,16'h14, 24'h000000, 24'h000000, 24'h040000};
assign atomList[12]= { 25'h000000, 25'h000000, 25'h000000,37'b0,3'h6,8'h10,16'h12, 24'h000000, 24'h040000, 24'h000000};
*/

always #5        IOclk = ~IOclk; 

always @(posedge IOclk) begin
  case(state)
    0: begin
      cnt <= cnt + 1'b1;
      if (cnt==10'h20) begin
        state        <= state+1;
      end  
    end
    1: begin
       MDReset   <= 1'b0;
       state     <= state+1;    
  //     state <= 6;                     //don't write ir2_* values, instead use defaults defined in shake
    end
    2: begin
      WriteDataShake <= 1'b1;
      AdrDataShake   <= 1;
      DataShake      <= 17'h10000;            // r_OHw               //1/16 is refernce distance, in which case r_OHw is 2^16 
      state          <= state+1;
    end
    3: begin
      AdrDataShake   <= 2;
      DataShake      <= 17'h08000;            // r_HHw
      state          <= state+1;
    end
    4: begin
      AdrDataShake   <= 3;
      DataShake      <= 17'h11000;            // r_CH
      state          <= state+1;
    end
    5: begin
      AdrDataShake   <= 5;
      DataShake      <= 17'h10000;            // r_OH
      state          <= state+1;
    end
    6: begin
      WriteDataShake <= 1'b0;
      if(readyCollectConstraint) begin
        atomDataIn <= atomList[iList];
        atomRcv    <= 1'b1;
        state      <= state+1;
      end 
    end
    7: begin
      atomRcv <= 1'b0;
      iList   <= iList+1'b1;
      if(iList>nList-2) state <= state+1;
      else              state <= 4;
    end
  endcase
end  


/*********************************************************************************************/
//eventually copy into MD machine

wire [3:0]                      DataCollectValid,DataCollectValid1,DataCollectValid2;
wire [DataByteWidth_n*8-9+84:0] atomDataCollect;                                            //new, also change in MDmachine 
wire                            readyShake,readyShake1,readyShake2;
wire                            errorCollectOvfl;
CollectContraintGroup 
#(
.metaAtomNr_len    (metaAtomNr_len),
.DataByteWidth_n   (DataByteWidth_n),
.metaConstraint    (metaConstraint)
) CollectContraintGroup 
(   
.clk              (IOclk),
.MDReset          (MDReset),                  //input, reset upon start
.inReady          (readyCollectConstraint),   //output, indicate that module is ready to accept data, can also be used as a busy signal
.atomRcv          (atomRcv),                  //input, new atom data received
.atomDataIn       (atomDataIn),               //input, new atom data, in contrast to typical data structure, velocities are 28bit
.outReady         (readyShake),               //input from downstream module when it is ready to accept data 
.DataOutBusy      (DataOutBusy),              //output, blocks a short period before and after data out
.DataOutValid     (DataCollectValid),         //output, grouped data valid, one bit for  center atom (bit0) and each of the varios H's
.atomDataCollect  (atomDataCollect),          //output, grouped atom data, velocities are 28bit 
.errorCollectOvfl (errorCollectOvfl)          //output, error on FIFO overflow
);

reg  shakeSwitch  = 1'b0; 
always @(posedge IOclk) begin
  if (DataCollectValid[0])           shakeSwitch <= ~shakeSwitch;
  else if (~DataOutBusy&&shakeDone1) shakeSwitch <= 1'b0;    //switches when one shake is ready before the other one. DataOutBusy is active one cycle before and after communication, 
  else if (~DataOutBusy&&shakeDone2) shakeSwitch <= 1'b1;    //to avoid it switches during communication. Makes maximum use of both Shake's
end
assign   DataCollectValid1 = (shakeSwitch==1'b0) ? DataCollectValid : 4'b0;
assign   DataCollectValid2 = (shakeSwitch==1'b1) ? DataCollectValid : 4'b0;
assign   readyShake        = (shakeSwitch==1'b0) ? readyShake1 : readyShake2;

wire [DataByteWidth_n*8+74:0] atomDataShake1;
wire [7:0]                    nIter1;
shake 
#(
 .DataByteWidth_n  (DataByteWidth_n),
 .DataByteWidth    (DataByteWidth),
 .vshift           (vshift),  
 .metaMass         (metaMass),
 .metaMass_len     (metaMass_len), 
 .metaConstraint   (metaConstraint),                  
 .metaRoute        (metaRoute)
) shake1
(   
 .clk              (IOclk),
 .MDReset          (MDReset),                   //input, reset upon start
 .inReady          (readyShake1),               //output, indicates that module is ready to accept data, can also be used as a busy signal
 .DataInRcv        (DataCollectValid1),         //input, new atom data received
 .atomDataIn       (atomDataCollect),           //input, new atom data, in contrast to typical data structure, velocities are 28bit
 .atomDataOutValid (atomDataShakeValid1),       //output, data valid 
 .atomDataOut      (atomDataShake1),            //output, data, velocities 28bit
 .shakeDone        (shakeDone1),                //output, shake finished
 .nIter            (nIter1),                    //output, number of iterations that were needed to reach convergence, for statistics
 .errorShake       (errorShake1),               //output, error signal either whne number of iterations has not been sufficient (bit1), or, when the initial  
                                               //velocities have been to large (in the range of the bond distance, bit0)
//receive constraint data from host computer                                                
 .WriteDataShake   (WriteDataShake),            //write shake data
 .AdrDataShake     (AdrDataShake),              //adress of shake data, 0: rOHw, 1: rHHw, 2: rCH, 3: rNH, 4: rOH, 5: rSH
 .DataShake        (DataShake),                 //Shake data, inverse distance square, 17'b10000 corresponds to r=rcut/16                                                
//the following outputs the velocities during the iteration; for debugging only
 .iterDone         (iterDone),                                              
 .vx0_out          (vx0_out),
 .vy0_out          (vy0_out),
 .vz0_out          (vz0_out),
 .vx1_out          (vx1_out),
 .vy1_out          (vy1_out),
 .vz1_out          (vz1_out),
 .vx2_out          (vx2_out),
 .vy2_out          (vy2_out),
 .vz2_out          (vz2_out),
 .vx3_out          (vx3_out),
 .vy3_out          (vy3_out),
 .vz3_out          (vz3_out)
);

wire [DataByteWidth_n*8+74:0] atomDataShake2;
wire [7:0]                    nIter2;
shake 
#(
 .DataByteWidth_n  (DataByteWidth_n),
 .DataByteWidth    (DataByteWidth),
 .vshift           (vshift),    
 .metaMass         (metaMass),
 .metaMass_len     (metaMass_len), 
 .metaConstraint   (metaConstraint),                 
 .metaRoute        (metaRoute)
) shake2
(   
 .clk              (IOclk),
 .MDReset          (MDReset),                   //input, reset upon start
 .inReady          (readyShake2),               //output, indicates that module is ready to accept data, can also be used as a busy signal
 .DataInRcv        (DataCollectValid2),         //input, new atom data received
 .atomDataIn       (atomDataCollect),           //input, new atom data, in contrast to typical data structure, velocities are 28bit
 .atomDataOutValid (atomDataShakeValid2),       //output, data valid 
 .atomDataOut      (atomDataShake2),            //output, data, velocities 28bit
 .shakeDone        (shakeDone2),                //output, shake finished
 .nIter            (nIter2),                    //output, number of iterations that were needed to reach convergence, for statistics
 .errorShake       (errorShake2),               //output, error signal either whne number of iterations has not been sufficient (bit1), or, when the initial  
                                                //velocities have been to large (in the range of the bond distance, bit0)
//receive constraint data from host computer                                                
 .WriteDataShake   (WriteDataShake),            //write shake data
 .AdrDataShake     (AdrDataShake),              //adress of shake data, 0: rOHw, 1: rHHw, 2: rCH, 3: rNH, 4: rOH, 5: rSH
 .DataShake        (DataShake)                  //Shake data, inverse distance square, 17'b10000 corresponds to r=rcut/16                                                        
);

always @(posedge IOclk) begin
  case ({shakeDone2,shakeDone1})
    2'b01: nIterTot <= nIterTot + nIter1;
    2'b10: nIterTot <= nIterTot + nIter2;
    2'b11: nIterTot <= nIterTot + nIter1 + nIter2;
  endcase
end

wire [DataByteWidth_n*8+74:0] newAtomData;
GatedMultplx
#(
.nPort   (2),
.nWidth  (DataByteWidth_n*8+75)                 
) GatedMultplx1
(
 .IOclk             (IOclk),
 .data_port         ({atomDataShake2,atomDataShake1}),               //in contrast to typical data structure, velocities are 28bit
 .data_port_valid   ({atomDataShakeValid2                    }),
 .tx_req_port       ({atomDataShakeValid2,atomDataShakeValid1}),
 .tx_req            (newAtomData_valid),
 .dataout           (newAtomData),                                   //velocities are 28bit, put 25bit into thermostat, but round lowest bit for final data
 .error             (GatedMuxError)
); 

/*******************************************************************************************/

reg shakeDone_d0=1'b0,initShake_d0=1'b0,iterDone_d0=1'b0;
always @(posedge IOclk) begin
  shakeDone_d0 <= atomDataShakeValid1;
  iterDone_d0  <= iterDone;
  if (iterDone_d0) begin
    $fwrite(out,"%9d %9d %9d %9d %9d %9d %9d %9d %9d %9d %9d %9d\n",vx0_out,vy0_out,vz0_out,vx1_out,vy1_out,vz1_out,vx2_out,vy2_out,vz2_out,vx3_out,vy3_out,vz3_out);
  end
  if (shakeDone_d0) begin
    $fclose(out);
  end
end

endmodule
