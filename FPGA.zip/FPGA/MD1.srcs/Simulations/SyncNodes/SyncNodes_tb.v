`timescale 1ns / 1ps



module SyncNodes_tb;

reg                IOclk       = 1'b0;
always #5 IOclk = ~IOclk; 

reg   [15:0]  cnt=1'b0;
reg           AllBussy_1 =1'b1;
reg           AllBussy_2 =1'b1;
reg           AllBussy_3 =1'b1;
reg           AllBussy_4 =1'b1;

reg           errorRxSync_1=1'b0;
reg           errorRxSync_2=1'b0;
reg           errorRxSync_3=1'b0;
reg           errorRxSync_4=1'b0;

always @(posedge IOclk) begin
  if(cnt<16'hffff) cnt <= cnt +1'b1;
  if (cnt==16'h40||cnt==16'h330)  AllBussy_1 <= 1'b0;
  else if ((cnt>16'h40)&&(~AllBussyIn_1))  AllBussy_1 <= 1'b1;
  if (cnt==16'h70||cnt==16'h350)  AllBussy_2 <= 1'b0;
  else if ((cnt>16'h70)&&(~AllBussyIn_2))  AllBussy_2 <= 1'b1;
  if (cnt==16'h110||cnt==16'h320) AllBussy_3 <= 1'b0;
  else if ((cnt>16'h110)&&(~AllBussyIn_3)) AllBussy_3 <= 1'b1;
  if (cnt==16'h130||cnt==16'h310) AllBussy_4 <= 1'b0;
  else if ((cnt>16'h130)&&(~AllBussyIn_4)) AllBussy_4 <= 1'b1;
  
/*  
  if (cnt==16'h300) AllBussy_1 <= 1'b0;
  if (cnt==16'h320) AllBussy_2 <= 1'b0;
  if (cnt==16'h350) AllBussy_3 <= 1'b0;
  if (cnt==16'h290) AllBussy_4 <= 1'b0;
*/ 
  
  if (cnt==16'h140) errorRxSync_1 <= 1'b1;
  if (cnt==16'h145) errorRxSync_2 <= 1'b1;
  if (cnt==16'h130) errorRxSync_3 <= 1'b1;
  if (cnt==16'h120) errorRxSync_4 <= 1'b1;

  
  if (cnt==16'h410) errorRxSync_1 <= 1'b0;
  if (cnt==16'h430) errorRxSync_2 <= 1'b0;
  if (cnt==16'h460) errorRxSync_3 <= 1'b0;
  if (cnt==16'h395) errorRxSync_4 <= 1'b0;
  
end  

wire AllBussyExt11_12;
wire errorRxSyncExt11_12;
wire AllBussyExt11_34;
wire errorRxSyncExt11_34;
wire AllBussyExt12_12;
wire errorRxSyncExt12_12;
wire AllBussyExt12_34;
wire errorRxSyncExt12_34;

wire AllBussyExt2_1;
wire errorRxSyncExt2_1;
wire AllBussyExt2_23;
wire errorRxSyncExt2_23;
wire AllBussyExt2_4;
wire errorRxSyncExt2_4;


pulldown(AllBussyExt11_12);
pulldown(errorRxSyncExt11_12);
pulldown(AllBussyExt11_34);
pulldown(errorRxSyncExt11_34);

pulldown(AllBussyExt12_12);
pulldown(errorRxSyncExt12_12);
pulldown(AllBussyExt12_34);
pulldown(errorRxSyncExt12_34);

pulldown(AllBussyExt2_1);
pulldown(errorRxSyncExt2_1);
pulldown(AllBussyExt2_23);
pulldown(errorRxSyncExt2_23);
pulldown(AllBussyExt2_4);
pulldown(errorRxSyncExt2_4);



SyncNodes SyncNodes1
(
.IOclk            (IOclk),
.AllBussyExt11    (AllBussyExt11_12),   
.errorRxSyncExt11 (errorRxSyncExt11_12), 
.AllBussyExt12    (AllBussyExt12_12),   
.errorRxSyncExt12 (errorRxSyncExt12_12), 
.AllBussyExt2     (AllBussyExt2_1),   
.errorRxSyncExt2  (errorRxSyncExt2_1), 
.AllBussy         (AllBussy_1),
.errorRxSync      (errorRxSync_1),
.AllBussyIn       (AllBussyIn_1),
.errorRxSyncIn    (errorRxSyncIn_1)
);

SyncNodes SyncNodes2
(
.IOclk            (IOclk),
.AllBussyExt11    (AllBussyExt11_12),   
.errorRxSyncExt11 (errorRxSyncExt11_12), 
.AllBussyExt12    (AllBussyExt12_12),   
.errorRxSyncExt12 (errorRxSyncExt12_12), 
.AllBussyExt2     (AllBussyExt2_23),   
.errorRxSyncExt2  (errorRxSyncExt2_23), 
.AllBussy         (AllBussy_2),
.errorRxSync      (errorRxSync_2),
.AllBussyIn       (AllBussyIn_2),
.errorRxSyncIn    (errorRxSyncIn_2)
);

SyncNodes SyncNodes3
(
.IOclk            (IOclk),
.AllBussyExt11    (AllBussyExt11_34),   
.errorRxSyncExt11 (errorRxSyncExt11_34), 
.AllBussyExt12    (AllBussyExt12_34),   
.errorRxSyncExt12 (errorRxSyncExt12_34), 
.AllBussyExt2     (AllBussyExt2_23),   
.errorRxSyncExt2  (errorRxSyncExt2_23), 
.AllBussy         (AllBussy_3),
.errorRxSync      (errorRxSync_3),
.AllBussyIn       (AllBussyIn_3),
.errorRxSyncIn    (errorRxSyncIn_3)
);

SyncNodes SyncNodes4
(
.IOclk            (IOclk),
.AllBussyExt11    (AllBussyExt11_34),   
.errorRxSyncExt11 (errorRxSyncExt11_34), 
.AllBussyExt12    (AllBussyExt12_34),   
.errorRxSyncExt12 (errorRxSyncExt12_34), 
.AllBussyExt2     (AllBussyExt2_4),   
.errorRxSyncExt2  (errorRxSyncExt2_4), 
.AllBussy         (AllBussy_4),
.errorRxSync      (errorRxSync_4),
.AllBussyIn       (AllBussyIn_4),
.errorRxSyncIn    (errorRxSyncIn_4)
);



endmodule

