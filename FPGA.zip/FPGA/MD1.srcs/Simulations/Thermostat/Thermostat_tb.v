`timescale 1ns / 1ps


module Thermostat_tb;

parameter  EnsembleByteWidth  = 5'd15;
parameter  vshift             = 4;


reg [5:0]                     mass=1'b0;
reg [3:0]                     state=1'b0;
reg [9:0]                     cnt=1'b0;
reg                           IOclk         = 1'b0;

reg                            WriteDataThermostat =1'b0;
reg [2:0]                      AdrDataThermostat   =1'b0;
reg [31:0]                     DataThermostat    =2'b0;  
reg [24:0]                     vx=1'b0,vy=1'b0,vz=1'b0;
reg                            nAtomReset =1'b0;
reg                            newDataReady = 1'b0;
wire [EnsembleByteWidth*8-1:0] EnsembleNeighbor;   
wire [EnsembleByteWidth*8-1:0] EnsembleData;


always #5        IOclk = ~IOclk; 

always @(posedge IOclk) begin
  case(state)
    0: begin
      cnt <= cnt + 1'b1;
      if (cnt==10'h20) begin
        state <= state+1;
      end  
    end
    1: begin
      WriteDataThermostat <= 1'b1;
      AdrDataThermostat   <= 0;       //write tau
      DataThermostat      <= 12'h408; 
      state <= state+1;
    end
    2: begin
      AdrDataThermostat   <= 1;       //T_target
      DataThermostat      <= 32'h20000000; 
      state <= state+1;
    end
    3: begin
      AdrDataThermostat   <= 2;       //T_all
      DataThermostat      <= 24'h800000; 
      state <= state+1;
    end
    4: begin
      AdrDataThermostat   <= 5;       //vxcm_all
      DataThermostat      <= 32'hc0000000; 
      state <= state+1;
    end
    5: begin
      WriteDataThermostat <= 1'b0;
      state <= state+1;
    end
    6,7: begin
      state <= state+1;
    end
    8: begin
      nAtomReset          <= 1'b1;
      state <= state+1;
    end
    9: begin
      nAtomReset          <= 1'b0;
      state <= state+1;
    end 
    10,11: begin
      state <= state+1;
    end
    12: begin
      newDataReady <= 1'b1;
      vx           <= 25'h0400000;
      vy           <= 25'h0200000;
      vz           <= 25'h0100000;
      mass         <= 6'h10;
      state        <= state+1;
    end
    13: begin
      mass         <= 6'h11;
      vx           <= 25'h0200000;
      vy           <= 25'h0100000;
      vz           <= 25'h0080000;
      state        <= state+1;
    end
    14: begin
      newDataReady <= 1'b0;
    end
  endcase
end  


wire signed [31:0] vxcm, vycm,vzcm;                                  
Thermostat
#(
.EnsembleByteWidth       (EnsembleByteWidth),
.vshift                  (vshift) 
) Thermostat
(
 .IOclk                  (IOclk),
 .nAtomReset             (nAtomReset),
 .newDataReady           (newDataReady),
 //ensemble data from neigboring boxes 
 .EnsembleNeighborValid  (1'b0),
 .EnsembleNeighbor       (EnsembleNeighbor),       
//Thermostat data       
 .WriteDataThermostat    (WriteDataThermostat),
 .AdrDataThermostat      (AdrDataThermostat),
 .DataThermostat         (DataThermostat),  
//velocity data 
 .mass                   (mass),
 .vx                     (vx),
 .vy                     (vy),
 .vz                     (vz),
 .vxcm                   (vxcm),
 .vycm                   (vycm),
 .vzcm                   (vzcm),
 .EnsembleData           (EnsembleData)
);     


endmodule
