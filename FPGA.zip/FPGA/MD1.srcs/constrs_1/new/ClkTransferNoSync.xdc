#set_false_path -from [get_ports sigIn] -to [get_ports sigOut]
#set_max_delay  -from [get_ports sigIn] -to [get_ports sigOut]  30.000

set_false_path -from [get_ports {sigIn[*]}]
set_max_delay  -from [get_ports {sigIn[*]}]  30.000

