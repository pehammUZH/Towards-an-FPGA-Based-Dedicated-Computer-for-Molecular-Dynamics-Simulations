set_false_path -from [get_pins iR2_OHw_reg*/C] -to [get_pins iR2_XH*/D]
set_max_delay  -from [get_pins iR2_OHw_reg*/C] -to [get_pins iR2_XH*/D]  30.000

set_false_path -from [get_pins iR2_HHw_reg*/C] -to [get_pins iR2*/D]
set_max_delay  -from [get_pins iR2_HHw_reg*/C] -to [get_pins iR2*/D]  30.000

set_false_path -from [get_pins iR2_OH_reg*/C] -to [get_pins iR2_XH*/D]
set_max_delay  -from [get_pins iR2_OH_reg*/C] -to [get_pins iR2_XH*/D]  30.000

set_false_path -from [get_pins iR2_CH_reg*/C] -to [get_pins iR2_XH*/D]
set_max_delay  -from [get_pins iR2_CH_reg*/C] -to [get_pins iR2_XH*/D]  30.000

set_false_path -from [get_pins iR2_NH_reg*/C] -to [get_pins iR2_XH*/D]
set_max_delay  -from [get_pins iR2_NH_reg*/C] -to [get_pins iR2_XH*/D]  30.000

set_false_path -from [get_pins iR2_SH_reg*/C] -to [get_pins iR2_XH*/D]
set_max_delay  -from [get_pins iR2_SH_reg*/C] -to [get_pins iR2_XH*/D]  30.000

#set_false_path -from [get_pins accur_reg*/C] -to [get_pins iIter_reg*/CE]
#set_max_delay  -from [get_pins accur_reg*/C] -to [get_pins iIter_reg*/CE]  30.000

#set_false_path -from [get_pins accur_reg*/C] -to [get_pins state_reg*/D]
#set_max_delay  -from [get_pins accur_reg*/C] -to [get_pins state_reg*/D]  30.000