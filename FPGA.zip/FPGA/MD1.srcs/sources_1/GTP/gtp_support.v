

`timescale 1ns / 1ps
`define DLY #1

(* DowngradeIPIdentifiedWarnings="yes" *)
//***********************************Entity Declaration************************
(* CORE_GENERATION_INFO = "gtp,gtwizard_v3_6_8,{protocol_file=aurora_8b10b_single_lane_4byte}" *)
module gtp_support #
(
    parameter EXAMPLE_SIM_GTRESET_SPEEDUP            = "TRUE",     // Simulation setting for GT SecureIP model
    parameter STABLE_CLOCK_PERIOD                    = 10         //Period of the stable clock driving this state-machine, unit is [ns]

)
(
input           soft_reset_tx_in,
input           soft_reset_rx_in,
input           dont_reset_on_data_error_in,
input           q0_clk0_gtrefclk_pad_n_in,
input           q0_clk0_gtrefclk_pad_p_in,
output          gt0_tx_mmcm_lock_out,
output          gt0_rx_mmcm_lock_out,
output          gt0_tx_fsm_reset_done_out,
output          gt0_rx_fsm_reset_done_out,
input           gt0_data_valid_in,
output          gt1_tx_mmcm_lock_out,
output          gt1_rx_mmcm_lock_out,
output          gt1_tx_fsm_reset_done_out,
output          gt1_rx_fsm_reset_done_out,
input           gt1_data_valid_in,
output          gt2_tx_mmcm_lock_out,
output          gt2_rx_mmcm_lock_out,
output          gt2_tx_fsm_reset_done_out,
output          gt2_rx_fsm_reset_done_out,
input           gt2_data_valid_in,
output          gt3_tx_mmcm_lock_out,
output          gt3_rx_mmcm_lock_out,
output          gt3_tx_fsm_reset_done_out,
output          gt3_rx_fsm_reset_done_out,
input           gt3_data_valid_in,
 
    output   gt0_txusrclk_out,
    output   gt0_txusrclk2_out,
    output   gt0_rxusrclk_out,
    output   gt0_rxusrclk2_out,
 
    output   gt1_txusrclk_out,
    output   gt1_txusrclk2_out,
    output   gt1_rxusrclk_out,
    output   gt1_rxusrclk2_out,
 
    output   gt2_txusrclk_out,
    output   gt2_txusrclk2_out,
    output   gt2_rxusrclk_out,
    output   gt2_rxusrclk2_out,
 
    output   gt3_txusrclk_out,
    output   gt3_txusrclk2_out,
    output   gt3_rxusrclk_out,
    output   gt3_rxusrclk2_out,
    //_________________________________________________________________________
    //GT0  (X0Y0)
    //____________________________CHANNEL PORTS________________________________
    //-------------------------- Channel - DRP Ports  --------------------------
    input   [8:0]   gt0_drpaddr_in,
    input   [15:0]  gt0_drpdi_in,
    output  [15:0]  gt0_drpdo_out,
    input           gt0_drpen_in,
    output          gt0_drprdy_out,
    input           gt0_drpwe_in,
    //----------------------------- Loopback Ports -----------------------------
    input   [2:0]   gt0_loopback_in,
    //---------------------------- Power-Down Ports ----------------------------
    input   [1:0]   gt0_rxpd_in,
    input   [1:0]   gt0_txpd_in,
    //------------------- RX Initialization and Reset Ports --------------------
    input           gt0_eyescanreset_in,
    input           gt0_rxuserrdy_in,
    //------------------------ RX Margin Analysis Ports ------------------------
    output          gt0_eyescandataerror_out,
    input           gt0_eyescantrigger_in,
    //----------------------- Receive Ports - CDR Ports ------------------------
    input           gt0_rxcdrhold_in,
    input           gt0_rxcdrovrden_in,
    //----------------- Receive Ports - Clock Correction Ports -----------------
    output  [1:0]   gt0_rxclkcorcnt_out,
    //---------------- Receive Ports - FPGA RX Interface Ports -----------------
    output  [31:0]  gt0_rxdata_out,
    //----------------- Receive Ports - Pattern Checker Ports ------------------
    output          gt0_rxprbserr_out,
    input   [2:0]   gt0_rxprbssel_in,
    //----------------- Receive Ports - Pattern Checker ports ------------------
    input           gt0_rxprbscntreset_in,
    //---------------- Receive Ports - RX 8B/10B Decoder Ports -----------------
    output  [3:0]   gt0_rxchariscomma_out,
    output  [3:0]   gt0_rxcharisk_out,
    output  [3:0]   gt0_rxdisperr_out,
    output  [3:0]   gt0_rxnotintable_out,
    //---------------------- Receive Ports - RX AFE Ports ----------------------
    input           gt0_gtprxn_in,
    input           gt0_gtprxp_in,
    //----------------- Receive Ports - RX Buffer Bypass Ports -----------------
    input           gt0_rxbufreset_in,
    output  [2:0]   gt0_rxbufstatus_out,
    //------------ Receive Ports - RX Byte and Word Alignment Ports ------------
    output          gt0_rxbyteisaligned_out,
    output          gt0_rxbyterealign_out,
    output          gt0_rxcommadet_out,
    input           gt0_rxmcommaalignen_in,
    input           gt0_rxpcommaalignen_in,
    //---------- Receive Ports - RX Decision Feedback Equalizer(DFE) -----------
    output  [14:0]  gt0_dmonitorout_out,
    //------------------ Receive Ports - RX Equailizer Ports -------------------
    input           gt0_rxlpmhfhold_in,
    input           gt0_rxlpmhfovrden_in,
    input           gt0_rxlpmlfhold_in,
    //------------- Receive Ports - RX Fabric Output Control Ports -------------
    output          gt0_rxoutclkfabric_out,
    //----------- Receive Ports - RX Initialization and Reset Ports ------------
    input           gt0_gtrxreset_in,
    input           gt0_rxlpmreset_in,
    input           gt0_rxpcsreset_in,
    input           gt0_rxpmareset_in,
    //--------------- Receive Ports - RX Polarity Control Ports ----------------
    input           gt0_rxpolarity_in,
    //------------ Receive Ports -RX Initialization and Reset Ports ------------
    output          gt0_rxresetdone_out,
    //---------------------- TX Configurable Driver Ports ----------------------
    input   [4:0]   gt0_txpostcursor_in,
    input   [4:0]   gt0_txprecursor_in,
    //------------------- TX Initialization and Reset Ports --------------------
    input           gt0_gttxreset_in,
    input           gt0_txuserrdy_in,
    //---------------- Transmit Ports - FPGA TX Interface Ports ----------------
    input   [31:0]  gt0_txdata_in,
    //---------------- Transmit Ports - Pattern Generator Ports ----------------
    input           gt0_txprbsforceerr_in,
    //---------------- Transmit Ports - TX 8B/10B Encoder Ports ----------------
    input   [3:0]   gt0_txchardispmode_in,
    input   [3:0]   gt0_txchardispval_in,
    input   [3:0]   gt0_txcharisk_in,
    //-------------------- Transmit Ports - TX Buffer Ports --------------------
    output  [1:0]   gt0_txbufstatus_out,
    //------------- Transmit Ports - TX Configurable Driver Ports --------------
    output          gt0_gtptxn_out,
    output          gt0_gtptxp_out,
    input   [3:0]   gt0_txdiffctrl_in,
    input   [6:0]   gt0_txmaincursor_in,
    //--------- Transmit Ports - TX Fabric Clock Output Control Ports ----------
    output          gt0_txoutclkfabric_out,
    output          gt0_txoutclkpcs_out,
    //----------- Transmit Ports - TX Initialization and Reset Ports -----------
    input           gt0_txpcsreset_in,
    input           gt0_txpmareset_in,
    output          gt0_txresetdone_out,
    //--------------- Transmit Ports - TX Polarity Control Ports ---------------
    input           gt0_txpolarity_in,
    //---------------- Transmit Ports - pattern Generator Ports ----------------
    input   [2:0]   gt0_txprbssel_in,

    //GT1  (X0Y1)
    //____________________________CHANNEL PORTS________________________________
    //-------------------------- Channel - DRP Ports  --------------------------
    input   [8:0]   gt1_drpaddr_in,
    input   [15:0]  gt1_drpdi_in,
    output  [15:0]  gt1_drpdo_out,
    input           gt1_drpen_in,
    output          gt1_drprdy_out,
    input           gt1_drpwe_in,
    //----------------------------- Loopback Ports -----------------------------
    input   [2:0]   gt1_loopback_in,
    //---------------------------- Power-Down Ports ----------------------------
    input   [1:0]   gt1_rxpd_in,
    input   [1:0]   gt1_txpd_in,
    //------------------- RX Initialization and Reset Ports --------------------
    input           gt1_eyescanreset_in,
    input           gt1_rxuserrdy_in,
    //------------------------ RX Margin Analysis Ports ------------------------
    output          gt1_eyescandataerror_out,
    input           gt1_eyescantrigger_in,
    //----------------------- Receive Ports - CDR Ports ------------------------
    input           gt1_rxcdrhold_in,
    input           gt1_rxcdrovrden_in,
    //----------------- Receive Ports - Clock Correction Ports -----------------
    output  [1:0]   gt1_rxclkcorcnt_out,
    //---------------- Receive Ports - FPGA RX Interface Ports -----------------
    output  [31:0]  gt1_rxdata_out,
    //----------------- Receive Ports - Pattern Checker Ports ------------------
    output          gt1_rxprbserr_out,
    input   [2:0]   gt1_rxprbssel_in,
    //----------------- Receive Ports - Pattern Checker ports ------------------
    input           gt1_rxprbscntreset_in,
    //---------------- Receive Ports - RX 8B/10B Decoder Ports -----------------
    output  [3:0]   gt1_rxchariscomma_out,
    output  [3:0]   gt1_rxcharisk_out,
    output  [3:0]   gt1_rxdisperr_out,
    output  [3:0]   gt1_rxnotintable_out,
    //---------------------- Receive Ports - RX AFE Ports ----------------------
    input           gt1_gtprxn_in,
    input           gt1_gtprxp_in,
    //----------------- Receive Ports - RX Buffer Bypass Ports -----------------
    input           gt1_rxbufreset_in,
    output  [2:0]   gt1_rxbufstatus_out,
    //------------ Receive Ports - RX Byte and Word Alignment Ports ------------
    output          gt1_rxbyteisaligned_out,
    output          gt1_rxbyterealign_out,
    output          gt1_rxcommadet_out,
    input           gt1_rxmcommaalignen_in,
    input           gt1_rxpcommaalignen_in,
    //---------- Receive Ports - RX Decision Feedback Equalizer(DFE) -----------
    output  [14:0]  gt1_dmonitorout_out,
    //------------------ Receive Ports - RX Equailizer Ports -------------------
    input           gt1_rxlpmhfhold_in,
    input           gt1_rxlpmhfovrden_in,
    input           gt1_rxlpmlfhold_in,
    //------------- Receive Ports - RX Fabric Output Control Ports -------------
    output          gt1_rxoutclkfabric_out,
    //----------- Receive Ports - RX Initialization and Reset Ports ------------
    input           gt1_gtrxreset_in,
    input           gt1_rxlpmreset_in,
    input           gt1_rxpcsreset_in,
    input           gt1_rxpmareset_in,
    //--------------- Receive Ports - RX Polarity Control Ports ----------------
    input           gt1_rxpolarity_in,
    //------------ Receive Ports -RX Initialization and Reset Ports ------------
    output          gt1_rxresetdone_out,
    //---------------------- TX Configurable Driver Ports ----------------------
    input   [4:0]   gt1_txpostcursor_in,
    input   [4:0]   gt1_txprecursor_in,
    //------------------- TX Initialization and Reset Ports --------------------
    input           gt1_gttxreset_in,
    input           gt1_txuserrdy_in,
    //---------------- Transmit Ports - FPGA TX Interface Ports ----------------
    input   [31:0]  gt1_txdata_in,
    //---------------- Transmit Ports - Pattern Generator Ports ----------------
    input           gt1_txprbsforceerr_in,
    //---------------- Transmit Ports - TX 8B/10B Encoder Ports ----------------
    input   [3:0]   gt1_txchardispmode_in,
    input   [3:0]   gt1_txchardispval_in,
    input   [3:0]   gt1_txcharisk_in,
    //-------------------- Transmit Ports - TX Buffer Ports --------------------
    output  [1:0]   gt1_txbufstatus_out,
    //------------- Transmit Ports - TX Configurable Driver Ports --------------
    output          gt1_gtptxn_out,
    output          gt1_gtptxp_out,
    input   [3:0]   gt1_txdiffctrl_in,
    input   [6:0]   gt1_txmaincursor_in,
    //--------- Transmit Ports - TX Fabric Clock Output Control Ports ----------
    output          gt1_txoutclkfabric_out,
    output          gt1_txoutclkpcs_out,
    //----------- Transmit Ports - TX Initialization and Reset Ports -----------
    input           gt1_txpcsreset_in,
    input           gt1_txpmareset_in,
    output          gt1_txresetdone_out,
    //--------------- Transmit Ports - TX Polarity Control Ports ---------------
    input           gt1_txpolarity_in,
    //---------------- Transmit Ports - pattern Generator Ports ----------------
    input   [2:0]   gt1_txprbssel_in,

    //GT2  (X0Y2)
    //____________________________CHANNEL PORTS________________________________
    //-------------------------- Channel - DRP Ports  --------------------------
    input   [8:0]   gt2_drpaddr_in,
    input   [15:0]  gt2_drpdi_in,
    output  [15:0]  gt2_drpdo_out,
    input           gt2_drpen_in,
    output          gt2_drprdy_out,
    input           gt2_drpwe_in,
    //----------------------------- Loopback Ports -----------------------------
    input   [2:0]   gt2_loopback_in,
    //---------------------------- Power-Down Ports ----------------------------
    input   [1:0]   gt2_rxpd_in,
    input   [1:0]   gt2_txpd_in,
    //------------------- RX Initialization and Reset Ports --------------------
    input           gt2_eyescanreset_in,
    input           gt2_rxuserrdy_in,
    //------------------------ RX Margin Analysis Ports ------------------------
    output          gt2_eyescandataerror_out,
    input           gt2_eyescantrigger_in,
    //----------------------- Receive Ports - CDR Ports ------------------------
    input           gt2_rxcdrhold_in,
    input           gt2_rxcdrovrden_in,
    //----------------- Receive Ports - Clock Correction Ports -----------------
    output  [1:0]   gt2_rxclkcorcnt_out,
    //---------------- Receive Ports - FPGA RX Interface Ports -----------------
    output  [31:0]  gt2_rxdata_out,
    //----------------- Receive Ports - Pattern Checker Ports ------------------
    output          gt2_rxprbserr_out,
    input   [2:0]   gt2_rxprbssel_in,
    //----------------- Receive Ports - Pattern Checker ports ------------------
    input           gt2_rxprbscntreset_in,
    //---------------- Receive Ports - RX 8B/10B Decoder Ports -----------------
    output  [3:0]   gt2_rxchariscomma_out,
    output  [3:0]   gt2_rxcharisk_out,
    output  [3:0]   gt2_rxdisperr_out,
    output  [3:0]   gt2_rxnotintable_out,
    //---------------------- Receive Ports - RX AFE Ports ----------------------
    input           gt2_gtprxn_in,
    input           gt2_gtprxp_in,
    //----------------- Receive Ports - RX Buffer Bypass Ports -----------------
    input           gt2_rxbufreset_in,
    output  [2:0]   gt2_rxbufstatus_out,
    //------------ Receive Ports - RX Byte and Word Alignment Ports ------------
    output          gt2_rxbyteisaligned_out,
    output          gt2_rxbyterealign_out,
    output          gt2_rxcommadet_out,
    input           gt2_rxmcommaalignen_in,
    input           gt2_rxpcommaalignen_in,
    //---------- Receive Ports - RX Decision Feedback Equalizer(DFE) -----------
    output  [14:0]  gt2_dmonitorout_out,
    //------------------ Receive Ports - RX Equailizer Ports -------------------
    input           gt2_rxlpmhfhold_in,
    input           gt2_rxlpmhfovrden_in,
    input           gt2_rxlpmlfhold_in,
    //------------- Receive Ports - RX Fabric Output Control Ports -------------
    output          gt2_rxoutclkfabric_out,
    //----------- Receive Ports - RX Initialization and Reset Ports ------------
    input           gt2_gtrxreset_in,
    input           gt2_rxlpmreset_in,
    input           gt2_rxpcsreset_in,
    input           gt2_rxpmareset_in,
    //--------------- Receive Ports - RX Polarity Control Ports ----------------
    input           gt2_rxpolarity_in,
    //------------ Receive Ports -RX Initialization and Reset Ports ------------
    output          gt2_rxresetdone_out,
    //---------------------- TX Configurable Driver Ports ----------------------
    input   [4:0]   gt2_txpostcursor_in,
    input   [4:0]   gt2_txprecursor_in,
    //------------------- TX Initialization and Reset Ports --------------------
    input           gt2_gttxreset_in,
    input           gt2_txuserrdy_in,
    //---------------- Transmit Ports - FPGA TX Interface Ports ----------------
    input   [31:0]  gt2_txdata_in,
    //---------------- Transmit Ports - Pattern Generator Ports ----------------
    input           gt2_txprbsforceerr_in,
    //---------------- Transmit Ports - TX 8B/10B Encoder Ports ----------------
    input   [3:0]   gt2_txchardispmode_in,
    input   [3:0]   gt2_txchardispval_in,
    input   [3:0]   gt2_txcharisk_in,
    //-------------------- Transmit Ports - TX Buffer Ports --------------------
    output  [1:0]   gt2_txbufstatus_out,
    //------------- Transmit Ports - TX Configurable Driver Ports --------------
    output          gt2_gtptxn_out,
    output          gt2_gtptxp_out,
    input   [3:0]   gt2_txdiffctrl_in,
    input   [6:0]   gt2_txmaincursor_in,
    //--------- Transmit Ports - TX Fabric Clock Output Control Ports ----------
    output          gt2_txoutclkfabric_out,
    output          gt2_txoutclkpcs_out,
    //----------- Transmit Ports - TX Initialization and Reset Ports -----------
    input           gt2_txpcsreset_in,
    input           gt2_txpmareset_in,
    output          gt2_txresetdone_out,
    //--------------- Transmit Ports - TX Polarity Control Ports ---------------
    input           gt2_txpolarity_in,
    //---------------- Transmit Ports - pattern Generator Ports ----------------
    input   [2:0]   gt2_txprbssel_in,

    //GT3  (X0Y3)
    //____________________________CHANNEL PORTS________________________________
    //-------------------------- Channel - DRP Ports  --------------------------
    input   [8:0]   gt3_drpaddr_in,
    input   [15:0]  gt3_drpdi_in,
    output  [15:0]  gt3_drpdo_out,
    input           gt3_drpen_in,
    output          gt3_drprdy_out,
    input           gt3_drpwe_in,
    //----------------------------- Loopback Ports -----------------------------
    input   [2:0]   gt3_loopback_in,
    //---------------------------- Power-Down Ports ----------------------------
    input   [1:0]   gt3_rxpd_in,
    input   [1:0]   gt3_txpd_in,
    //------------------- RX Initialization and Reset Ports --------------------
    input           gt3_eyescanreset_in,
    input           gt3_rxuserrdy_in,
    //------------------------ RX Margin Analysis Ports ------------------------
    output          gt3_eyescandataerror_out,
    input           gt3_eyescantrigger_in,
    //----------------------- Receive Ports - CDR Ports ------------------------
    input           gt3_rxcdrhold_in,
    input           gt3_rxcdrovrden_in,
    //----------------- Receive Ports - Clock Correction Ports -----------------
    output  [1:0]   gt3_rxclkcorcnt_out,
    //---------------- Receive Ports - FPGA RX Interface Ports -----------------
    output  [31:0]  gt3_rxdata_out,
    //----------------- Receive Ports - Pattern Checker Ports ------------------
    output          gt3_rxprbserr_out,
    input   [2:0]   gt3_rxprbssel_in,
    //----------------- Receive Ports - Pattern Checker ports ------------------
    input           gt3_rxprbscntreset_in,
    //---------------- Receive Ports - RX 8B/10B Decoder Ports -----------------
    output  [3:0]   gt3_rxchariscomma_out,
    output  [3:0]   gt3_rxcharisk_out,
    output  [3:0]   gt3_rxdisperr_out,
    output  [3:0]   gt3_rxnotintable_out,
    //---------------------- Receive Ports - RX AFE Ports ----------------------
    input           gt3_gtprxn_in,
    input           gt3_gtprxp_in,
    //----------------- Receive Ports - RX Buffer Bypass Ports -----------------
    input           gt3_rxbufreset_in,
    output  [2:0]   gt3_rxbufstatus_out,
    //------------ Receive Ports - RX Byte and Word Alignment Ports ------------
    output          gt3_rxbyteisaligned_out,
    output          gt3_rxbyterealign_out,
    output          gt3_rxcommadet_out,
    input           gt3_rxmcommaalignen_in,
    input           gt3_rxpcommaalignen_in,
    //---------- Receive Ports - RX Decision Feedback Equalizer(DFE) -----------
    output  [14:0]  gt3_dmonitorout_out,
    //------------------ Receive Ports - RX Equailizer Ports -------------------
    input           gt3_rxlpmhfhold_in,
    input           gt3_rxlpmhfovrden_in,
    input           gt3_rxlpmlfhold_in,
    //------------- Receive Ports - RX Fabric Output Control Ports -------------
    output          gt3_rxoutclkfabric_out,
    //----------- Receive Ports - RX Initialization and Reset Ports ------------
    input           gt3_gtrxreset_in,
    input           gt3_rxlpmreset_in,
    input           gt3_rxpcsreset_in,
    input           gt3_rxpmareset_in,
    //--------------- Receive Ports - RX Polarity Control Ports ----------------
    input           gt3_rxpolarity_in,
    //------------ Receive Ports -RX Initialization and Reset Ports ------------
    output          gt3_rxresetdone_out,
    //---------------------- TX Configurable Driver Ports ----------------------
    input   [4:0]   gt3_txpostcursor_in,
    input   [4:0]   gt3_txprecursor_in,
    //------------------- TX Initialization and Reset Ports --------------------
    input           gt3_gttxreset_in,
    input           gt3_txuserrdy_in,
    //---------------- Transmit Ports - FPGA TX Interface Ports ----------------
    input   [31:0]  gt3_txdata_in,
    //---------------- Transmit Ports - Pattern Generator Ports ----------------
    input           gt3_txprbsforceerr_in,
    //---------------- Transmit Ports - TX 8B/10B Encoder Ports ----------------
    input   [3:0]   gt3_txchardispmode_in,
    input   [3:0]   gt3_txchardispval_in,
    input   [3:0]   gt3_txcharisk_in,
    //-------------------- Transmit Ports - TX Buffer Ports --------------------
    output  [1:0]   gt3_txbufstatus_out,
    //------------- Transmit Ports - TX Configurable Driver Ports --------------
    output          gt3_gtptxn_out,
    output          gt3_gtptxp_out,
    input   [3:0]   gt3_txdiffctrl_in,
    input   [6:0]   gt3_txmaincursor_in,
    //--------- Transmit Ports - TX Fabric Clock Output Control Ports ----------
    output          gt3_txoutclkfabric_out,
    output          gt3_txoutclkpcs_out,
    //----------- Transmit Ports - TX Initialization and Reset Ports -----------
    input           gt3_txpcsreset_in,
    input           gt3_txpmareset_in,
    output          gt3_txresetdone_out,
    //--------------- Transmit Ports - TX Polarity Control Ports ---------------
    input           gt3_txpolarity_in,
    //---------------- Transmit Ports - pattern Generator Ports ----------------
    input   [2:0]   gt3_txprbssel_in,

    //____________________________COMMON PORTS________________________________
   output     gt0_pll0reset_out,
    output          gt0_pll0outclk_out,
    output          gt0_pll0outrefclk_out,
    output          gt0_pll0lock_out,
    output          gt0_pll0refclklost_out,    
    output          gt0_pll1outclk_out,
    output          gt0_pll1outrefclk_out,
    input          sysclk_in

);


//**************************** Wire Declarations ******************************//
    //------------------------ GT Wrapper Wires ------------------------------
    //________________________________________________________________________
    //________________________________________________________________________
    //GT0  (X0Y0)
    //-------------------------- Channel - DRP Ports  --------------------------
    wire    [8:0]   gt0_drpaddr_i;
    wire    [15:0]  gt0_drpdi_i;
    wire    [15:0]  gt0_drpdo_i;
    wire            gt0_drpen_i;
    wire            gt0_drprdy_i;
    wire            gt0_drpwe_i;
    //---------------------- GTPE2_CHANNEL Clocking Ports ----------------------
    wire            gt0_pll0clk_i;
    wire            gt0_pll0refclk_i;
    wire            gt0_pll1clk_i;
    wire            gt0_pll1refclk_i;
    //----------------------------- Loopback Ports -----------------------------
    wire    [2:0]   gt0_loopback_i;
    //---------------------------- Power-Down Ports ----------------------------
    wire    [1:0]   gt0_rxpd_i;
    wire    [1:0]   gt0_txpd_i;
    //------------------- RX Initialization and Reset Ports --------------------
    wire            gt0_eyescanreset_i;
    wire            gt0_rxuserrdy_i;
    //------------------------ RX Margin Analysis Ports ------------------------
    wire            gt0_eyescandataerror_i;
    wire            gt0_eyescantrigger_i;
    //----------------------- Receive Ports - CDR Ports ------------------------
    wire            gt0_rxcdrhold_i;
    wire            gt0_rxcdrovrden_i;
    //----------------- Receive Ports - Clock Correction Ports -----------------
    wire    [1:0]   gt0_rxclkcorcnt_i;
    //---------------- Receive Ports - FPGA RX Interface Ports -----------------
    wire    [31:0]  gt0_rxdata_i;
    //----------------- Receive Ports - Pattern Checker Ports ------------------
    wire            gt0_rxprbserr_i;
    wire    [2:0]   gt0_rxprbssel_i;
    //----------------- Receive Ports - Pattern Checker ports ------------------
    wire            gt0_rxprbscntreset_i;
    //---------------- Receive Ports - RX 8B/10B Decoder Ports -----------------
    wire    [3:0]   gt0_rxchariscomma_i;
    wire    [3:0]   gt0_rxcharisk_i;
    wire    [3:0]   gt0_rxdisperr_i;
    wire    [3:0]   gt0_rxnotintable_i;
    //---------------------- Receive Ports - RX AFE Ports ----------------------
    wire            gt0_gtprxn_i;
    wire            gt0_gtprxp_i;
    //----------------- Receive Ports - RX Buffer Bypass Ports -----------------
    wire            gt0_rxbufreset_i;
    wire    [2:0]   gt0_rxbufstatus_i;
    //------------ Receive Ports - RX Byte and Word Alignment Ports ------------
    wire            gt0_rxbyteisaligned_i;
    wire            gt0_rxbyterealign_i;
    wire            gt0_rxcommadet_i;
    wire            gt0_rxmcommaalignen_i;
    wire            gt0_rxpcommaalignen_i;
    //---------- Receive Ports - RX Decision Feedback Equalizer(DFE) -----------
    wire    [14:0]  gt0_dmonitorout_i;
    //------------------ Receive Ports - RX Equailizer Ports -------------------
    wire            gt0_rxlpmhfhold_i;
    wire            gt0_rxlpmhfovrden_i;
    wire            gt0_rxlpmlfhold_i;
    //------------- Receive Ports - RX Fabric Output Control Ports -------------
    wire            gt0_rxoutclk_i;
    wire            gt0_rxoutclkfabric_i;
    //----------- Receive Ports - RX Initialization and Reset Ports ------------
    wire            gt0_gtrxreset_i;
    wire            gt0_rxlpmreset_i;
    wire            gt0_rxpcsreset_i;
    wire            gt0_rxpmareset_i;
    //--------------- Receive Ports - RX Polarity Control Ports ----------------
    wire            gt0_rxpolarity_i;
    //------------ Receive Ports -RX Initialization and Reset Ports ------------
    wire            gt0_rxresetdone_i;
    //---------------------- TX Configurable Driver Ports ----------------------
    wire    [4:0]   gt0_txpostcursor_i;
    wire    [4:0]   gt0_txprecursor_i;
    //------------------- TX Initialization and Reset Ports --------------------
    wire            gt0_gttxreset_i;
    wire            gt0_txuserrdy_i;
    //---------------- Transmit Ports - FPGA TX Interface Ports ----------------
    wire    [31:0]  gt0_txdata_i;
    //---------------- Transmit Ports - Pattern Generator Ports ----------------
    wire            gt0_txprbsforceerr_i;
    //---------------- Transmit Ports - TX 8B/10B Encoder Ports ----------------
    wire    [3:0]   gt0_txchardispmode_i;
    wire    [3:0]   gt0_txchardispval_i;
    wire    [3:0]   gt0_txcharisk_i;
    //-------------------- Transmit Ports - TX Buffer Ports --------------------
    wire    [1:0]   gt0_txbufstatus_i;
    //------------- Transmit Ports - TX Configurable Driver Ports --------------
    wire            gt0_gtptxn_i;
    wire            gt0_gtptxp_i;
    wire    [3:0]   gt0_txdiffctrl_i;
    wire    [6:0]   gt0_txmaincursor_i;
    //--------- Transmit Ports - TX Fabric Clock Output Control Ports ----------
    wire            gt0_txoutclk_i;
    wire            gt0_txoutclkfabric_i;
    wire            gt0_txoutclkpcs_i;
    //----------- Transmit Ports - TX Initialization and Reset Ports -----------
    wire            gt0_txpcsreset_i;
    wire            gt0_txresetdone_i;
    //--------------- Transmit Ports - TX Polarity Control Ports ---------------
    wire            gt0_txpolarity_i;
    //---------------- Transmit Ports - pattern Generator Ports ----------------
    wire    [2:0]   gt0_txprbssel_i;

    //________________________________________________________________________
    //________________________________________________________________________
    //GT1  (X0Y1)
    //-------------------------- Channel - DRP Ports  --------------------------
    wire    [8:0]   gt1_drpaddr_i;
    wire    [15:0]  gt1_drpdi_i;
    wire    [15:0]  gt1_drpdo_i;
    wire            gt1_drpen_i;
    wire            gt1_drprdy_i;
    wire            gt1_drpwe_i;
    //---------------------- GTPE2_CHANNEL Clocking Ports ----------------------
    wire            gt1_pll0clk_i;
    wire            gt1_pll0refclk_i;
    wire            gt1_pll1clk_i;
    wire            gt1_pll1refclk_i;
    //----------------------------- Loopback Ports -----------------------------
    wire    [2:0]   gt1_loopback_i;
    //---------------------------- Power-Down Ports ----------------------------
    wire    [1:0]   gt1_rxpd_i;
    wire    [1:0]   gt1_txpd_i;
    //------------------- RX Initialization and Reset Ports --------------------
    wire            gt1_eyescanreset_i;
    wire            gt1_rxuserrdy_i;
    //------------------------ RX Margin Analysis Ports ------------------------
    wire            gt1_eyescandataerror_i;
    wire            gt1_eyescantrigger_i;
    //----------------------- Receive Ports - CDR Ports ------------------------
    wire            gt1_rxcdrhold_i;
    wire            gt1_rxcdrovrden_i;
    //----------------- Receive Ports - Clock Correction Ports -----------------
    wire    [1:0]   gt1_rxclkcorcnt_i;
    //---------------- Receive Ports - FPGA RX Interface Ports -----------------
    wire    [31:0]  gt1_rxdata_i;
    //----------------- Receive Ports - Pattern Checker Ports ------------------
    wire            gt1_rxprbserr_i;
    wire    [2:0]   gt1_rxprbssel_i;
    //----------------- Receive Ports - Pattern Checker ports ------------------
    wire            gt1_rxprbscntreset_i;
    //---------------- Receive Ports - RX 8B/10B Decoder Ports -----------------
    wire    [3:0]   gt1_rxchariscomma_i;
    wire    [3:0]   gt1_rxcharisk_i;
    wire    [3:0]   gt1_rxdisperr_i;
    wire    [3:0]   gt1_rxnotintable_i;
    //---------------------- Receive Ports - RX AFE Ports ----------------------
    wire            gt1_gtprxn_i;
    wire            gt1_gtprxp_i;
    //----------------- Receive Ports - RX Buffer Bypass Ports -----------------
    wire            gt1_rxbufreset_i;
    wire    [2:0]   gt1_rxbufstatus_i;
    //------------ Receive Ports - RX Byte and Word Alignment Ports ------------
    wire            gt1_rxbyteisaligned_i;
    wire            gt1_rxbyterealign_i;
    wire            gt1_rxcommadet_i;
    wire            gt1_rxmcommaalignen_i;
    wire            gt1_rxpcommaalignen_i;
    //---------- Receive Ports - RX Decision Feedback Equalizer(DFE) -----------
    wire    [14:0]  gt1_dmonitorout_i;
    //------------------ Receive Ports - RX Equailizer Ports -------------------
    wire            gt1_rxlpmhfhold_i;
    wire            gt1_rxlpmhfovrden_i;
    wire            gt1_rxlpmlfhold_i;
    //------------- Receive Ports - RX Fabric Output Control Ports -------------
    wire            gt1_rxoutclk_i;
    wire            gt1_rxoutclkfabric_i;
    //----------- Receive Ports - RX Initialization and Reset Ports ------------
    wire            gt1_gtrxreset_i;
    wire            gt1_rxlpmreset_i;
    wire            gt1_rxpcsreset_i;
    wire            gt1_rxpmareset_i;
    //--------------- Receive Ports - RX Polarity Control Ports ----------------
    wire            gt1_rxpolarity_i;
    //------------ Receive Ports -RX Initialization and Reset Ports ------------
    wire            gt1_rxresetdone_i;
    //---------------------- TX Configurable Driver Ports ----------------------
    wire    [4:0]   gt1_txpostcursor_i;
    wire    [4:0]   gt1_txprecursor_i;
    //------------------- TX Initialization and Reset Ports --------------------
    wire            gt1_gttxreset_i;
    wire            gt1_txuserrdy_i;
    //---------------- Transmit Ports - FPGA TX Interface Ports ----------------
    wire    [31:0]  gt1_txdata_i;
    //---------------- Transmit Ports - Pattern Generator Ports ----------------
    wire            gt1_txprbsforceerr_i;
    //---------------- Transmit Ports - TX 8B/10B Encoder Ports ----------------
    wire    [3:0]   gt1_txchardispmode_i;
    wire    [3:0]   gt1_txchardispval_i;
    wire    [3:0]   gt1_txcharisk_i;
    //-------------------- Transmit Ports - TX Buffer Ports --------------------
    wire    [1:0]   gt1_txbufstatus_i;
    //------------- Transmit Ports - TX Configurable Driver Ports --------------
    wire            gt1_gtptxn_i;
    wire            gt1_gtptxp_i;
    wire    [3:0]   gt1_txdiffctrl_i;
    wire    [6:0]   gt1_txmaincursor_i;
    //--------- Transmit Ports - TX Fabric Clock Output Control Ports ----------
    wire            gt1_txoutclk_i;
    wire            gt1_txoutclkfabric_i;
    wire            gt1_txoutclkpcs_i;
    //----------- Transmit Ports - TX Initialization and Reset Ports -----------
    wire            gt1_txpcsreset_i;
    wire            gt1_txresetdone_i;
    //--------------- Transmit Ports - TX Polarity Control Ports ---------------
    wire            gt1_txpolarity_i;
    //---------------- Transmit Ports - pattern Generator Ports ----------------
    wire    [2:0]   gt1_txprbssel_i;

    //________________________________________________________________________
    //________________________________________________________________________
    //GT2  (X0Y2)
    //-------------------------- Channel - DRP Ports  --------------------------
    wire    [8:0]   gt2_drpaddr_i;
    wire    [15:0]  gt2_drpdi_i;
    wire    [15:0]  gt2_drpdo_i;
    wire            gt2_drpen_i;
    wire            gt2_drprdy_i;
    wire            gt2_drpwe_i;
    //---------------------- GTPE2_CHANNEL Clocking Ports ----------------------
    wire            gt2_pll0clk_i;
    wire            gt2_pll0refclk_i;
    wire            gt2_pll1clk_i;
    wire            gt2_pll1refclk_i;
    //----------------------------- Loopback Ports -----------------------------
    wire    [2:0]   gt2_loopback_i;
    //---------------------------- Power-Down Ports ----------------------------
    wire    [1:0]   gt2_rxpd_i;
    wire    [1:0]   gt2_txpd_i;
    //------------------- RX Initialization and Reset Ports --------------------
    wire            gt2_eyescanreset_i;
    wire            gt2_rxuserrdy_i;
    //------------------------ RX Margin Analysis Ports ------------------------
    wire            gt2_eyescandataerror_i;
    wire            gt2_eyescantrigger_i;
    //----------------------- Receive Ports - CDR Ports ------------------------
    wire            gt2_rxcdrhold_i;
    wire            gt2_rxcdrovrden_i;
    //----------------- Receive Ports - Clock Correction Ports -----------------
    wire    [1:0]   gt2_rxclkcorcnt_i;
    //---------------- Receive Ports - FPGA RX Interface Ports -----------------
    wire    [31:0]  gt2_rxdata_i;
    //----------------- Receive Ports - Pattern Checker Ports ------------------
    wire            gt2_rxprbserr_i;
    wire    [2:0]   gt2_rxprbssel_i;
    //----------------- Receive Ports - Pattern Checker ports ------------------
    wire            gt2_rxprbscntreset_i;
    //---------------- Receive Ports - RX 8B/10B Decoder Ports -----------------
    wire    [3:0]   gt2_rxchariscomma_i;
    wire    [3:0]   gt2_rxcharisk_i;
    wire    [3:0]   gt2_rxdisperr_i;
    wire    [3:0]   gt2_rxnotintable_i;
    //---------------------- Receive Ports - RX AFE Ports ----------------------
    wire            gt2_gtprxn_i;
    wire            gt2_gtprxp_i;
    //----------------- Receive Ports - RX Buffer Bypass Ports -----------------
    wire            gt2_rxbufreset_i;
    wire    [2:0]   gt2_rxbufstatus_i;
    //------------ Receive Ports - RX Byte and Word Alignment Ports ------------
    wire            gt2_rxbyteisaligned_i;
    wire            gt2_rxbyterealign_i;
    wire            gt2_rxcommadet_i;
    wire            gt2_rxmcommaalignen_i;
    wire            gt2_rxpcommaalignen_i;
    //---------- Receive Ports - RX Decision Feedback Equalizer(DFE) -----------
    wire    [14:0]  gt2_dmonitorout_i;
    //------------------ Receive Ports - RX Equailizer Ports -------------------
    wire            gt2_rxlpmhfhold_i;
    wire            gt2_rxlpmhfovrden_i;
    wire            gt2_rxlpmlfhold_i;
    //------------- Receive Ports - RX Fabric Output Control Ports -------------
    wire            gt2_rxoutclk_i;
    wire            gt2_rxoutclkfabric_i;
    //----------- Receive Ports - RX Initialization and Reset Ports ------------
    wire            gt2_gtrxreset_i;
    wire            gt2_rxlpmreset_i;
    wire            gt2_rxpcsreset_i;
    wire            gt2_rxpmareset_i;
    //--------------- Receive Ports - RX Polarity Control Ports ----------------
    wire            gt2_rxpolarity_i;
    //------------ Receive Ports -RX Initialization and Reset Ports ------------
    wire            gt2_rxresetdone_i;
    //---------------------- TX Configurable Driver Ports ----------------------
    wire    [4:0]   gt2_txpostcursor_i;
    wire    [4:0]   gt2_txprecursor_i;
    //------------------- TX Initialization and Reset Ports --------------------
    wire            gt2_gttxreset_i;
    wire            gt2_txuserrdy_i;
    //---------------- Transmit Ports - FPGA TX Interface Ports ----------------
    wire    [31:0]  gt2_txdata_i;
    //---------------- Transmit Ports - Pattern Generator Ports ----------------
    wire            gt2_txprbsforceerr_i;
    //---------------- Transmit Ports - TX 8B/10B Encoder Ports ----------------
    wire    [3:0]   gt2_txchardispmode_i;
    wire    [3:0]   gt2_txchardispval_i;
    wire    [3:0]   gt2_txcharisk_i;
    //-------------------- Transmit Ports - TX Buffer Ports --------------------
    wire    [1:0]   gt2_txbufstatus_i;
    //------------- Transmit Ports - TX Configurable Driver Ports --------------
    wire            gt2_gtptxn_i;
    wire            gt2_gtptxp_i;
    wire    [3:0]   gt2_txdiffctrl_i;
    wire    [6:0]   gt2_txmaincursor_i;
    //--------- Transmit Ports - TX Fabric Clock Output Control Ports ----------
    wire            gt2_txoutclk_i;
    wire            gt2_txoutclkfabric_i;
    wire            gt2_txoutclkpcs_i;
    //----------- Transmit Ports - TX Initialization and Reset Ports -----------
    wire            gt2_txpcsreset_i;
    wire            gt2_txresetdone_i;
    //--------------- Transmit Ports - TX Polarity Control Ports ---------------
    wire            gt2_txpolarity_i;
    //---------------- Transmit Ports - pattern Generator Ports ----------------
    wire    [2:0]   gt2_txprbssel_i;

    //________________________________________________________________________
    //________________________________________________________________________
    //GT3  (X0Y3)
    //-------------------------- Channel - DRP Ports  --------------------------
    wire    [8:0]   gt3_drpaddr_i;
    wire    [15:0]  gt3_drpdi_i;
    wire    [15:0]  gt3_drpdo_i;
    wire            gt3_drpen_i;
    wire            gt3_drprdy_i;
    wire            gt3_drpwe_i;
    //---------------------- GTPE2_CHANNEL Clocking Ports ----------------------
    wire            gt3_pll0clk_i;
    wire            gt3_pll0refclk_i;
    wire            gt3_pll1clk_i;
    wire            gt3_pll1refclk_i;
    //----------------------------- Loopback Ports -----------------------------
    wire    [2:0]   gt3_loopback_i;
    //---------------------------- Power-Down Ports ----------------------------
    wire    [1:0]   gt3_rxpd_i;
    wire    [1:0]   gt3_txpd_i;
    //------------------- RX Initialization and Reset Ports --------------------
    wire            gt3_eyescanreset_i;
    wire            gt3_rxuserrdy_i;
    //------------------------ RX Margin Analysis Ports ------------------------
    wire            gt3_eyescandataerror_i;
    wire            gt3_eyescantrigger_i;
    //----------------------- Receive Ports - CDR Ports ------------------------
    wire            gt3_rxcdrhold_i;
    wire            gt3_rxcdrovrden_i;
    //----------------- Receive Ports - Clock Correction Ports -----------------
    wire    [1:0]   gt3_rxclkcorcnt_i;
    //---------------- Receive Ports - FPGA RX Interface Ports -----------------
    wire    [31:0]  gt3_rxdata_i;
    //----------------- Receive Ports - Pattern Checker Ports ------------------
    wire            gt3_rxprbserr_i;
    wire    [2:0]   gt3_rxprbssel_i;
    //----------------- Receive Ports - Pattern Checker ports ------------------
    wire            gt3_rxprbscntreset_i;
    //---------------- Receive Ports - RX 8B/10B Decoder Ports -----------------
    wire    [3:0]   gt3_rxchariscomma_i;
    wire    [3:0]   gt3_rxcharisk_i;
    wire    [3:0]   gt3_rxdisperr_i;
    wire    [3:0]   gt3_rxnotintable_i;
    //---------------------- Receive Ports - RX AFE Ports ----------------------
    wire            gt3_gtprxn_i;
    wire            gt3_gtprxp_i;
    //----------------- Receive Ports - RX Buffer Bypass Ports -----------------
    wire            gt3_rxbufreset_i;
    wire    [2:0]   gt3_rxbufstatus_i;
    //------------ Receive Ports - RX Byte and Word Alignment Ports ------------
    wire            gt3_rxbyteisaligned_i;
    wire            gt3_rxbyterealign_i;
    wire            gt3_rxcommadet_i;
    wire            gt3_rxmcommaalignen_i;
    wire            gt3_rxpcommaalignen_i;
    //---------- Receive Ports - RX Decision Feedback Equalizer(DFE) -----------
    wire    [14:0]  gt3_dmonitorout_i;
    //------------------ Receive Ports - RX Equailizer Ports -------------------
    wire            gt3_rxlpmhfhold_i;
    wire            gt3_rxlpmhfovrden_i;
    wire            gt3_rxlpmlfhold_i;
    //------------- Receive Ports - RX Fabric Output Control Ports -------------
    wire            gt3_rxoutclk_i;
    wire            gt3_rxoutclkfabric_i;
    //----------- Receive Ports - RX Initialization and Reset Ports ------------
    wire            gt3_gtrxreset_i;
    wire            gt3_rxlpmreset_i;
    wire            gt3_rxpcsreset_i;
    wire            gt3_rxpmareset_i;
    //--------------- Receive Ports - RX Polarity Control Ports ----------------
    wire            gt3_rxpolarity_i;
    //------------ Receive Ports -RX Initialization and Reset Ports ------------
    wire            gt3_rxresetdone_i;
    //---------------------- TX Configurable Driver Ports ----------------------
    wire    [4:0]   gt3_txpostcursor_i;
    wire    [4:0]   gt3_txprecursor_i;
    //------------------- TX Initialization and Reset Ports --------------------
    wire            gt3_gttxreset_i;
    wire            gt3_txuserrdy_i;
    //---------------- Transmit Ports - FPGA TX Interface Ports ----------------
    wire    [31:0]  gt3_txdata_i;
    //---------------- Transmit Ports - Pattern Generator Ports ----------------
    wire            gt3_txprbsforceerr_i;
    //---------------- Transmit Ports - TX 8B/10B Encoder Ports ----------------
    wire    [3:0]   gt3_txchardispmode_i;
    wire    [3:0]   gt3_txchardispval_i;
    wire    [3:0]   gt3_txcharisk_i;
    //-------------------- Transmit Ports - TX Buffer Ports --------------------
    wire    [1:0]   gt3_txbufstatus_i;
    //------------- Transmit Ports - TX Configurable Driver Ports --------------
    wire            gt3_gtptxn_i;
    wire            gt3_gtptxp_i;
    wire    [3:0]   gt3_txdiffctrl_i;
    wire    [6:0]   gt3_txmaincursor_i;
    //--------- Transmit Ports - TX Fabric Clock Output Control Ports ----------
    wire            gt3_txoutclk_i;
    wire            gt3_txoutclkfabric_i;
    wire            gt3_txoutclkpcs_i;
    //----------- Transmit Ports - TX Initialization and Reset Ports -----------
    wire            gt3_txpcsreset_i;
    wire            gt3_txresetdone_i;
    //--------------- Transmit Ports - TX Polarity Control Ports ---------------
    wire            gt3_txpolarity_i;
    //---------------- Transmit Ports - pattern Generator Ports ----------------
    wire    [2:0]   gt3_txprbssel_i;

    wire gt0_pll0reset_i  ;
    wire gt0_pll1reset_i  ;
    wire gt0_pll0reset_t  ;
    wire gt0_pll0pd_t  ;
    wire gt0_pll1pd_t  ;
    wire gt0_pll1reset_t  ;
    wire gt0_pll0outclk_i  ;
    wire gt0_pll0outrefclk_i  ;
    wire gt0_pll0lock_i  ;
    wire gt0_pll0refclklost_i  ;    
    wire gt0_pll1lock_i  ;
    wire gt0_pll1refclklost_i  ;    
    wire gt0_pll1outclk_i  ;
    wire gt0_pll1outrefclk_i  ;


    //----------------------------- Global Signals -----------------------------

    wire            sysclk_in_i;
    wire            gt0_tx_system_reset_c;
    wire            gt0_rx_system_reset_c;
    wire            gt1_tx_system_reset_c;
    wire            gt1_rx_system_reset_c;
    wire            gt2_tx_system_reset_c;
    wire            gt2_rx_system_reset_c;
    wire            gt3_tx_system_reset_c;
    wire            gt3_rx_system_reset_c;
    wire            tied_to_ground_i;
    wire    [63:0]  tied_to_ground_vec_i;
    wire            tied_to_vcc_i;
    wire    [7:0]   tied_to_vcc_vec_i;
    wire            GTTXRESET_IN;
    wire            GTRXRESET_IN;
    wire            CPLLRESET_IN;
    wire            QPLLRESET_IN;

     //--------------------------- User Clocks ---------------------------------
     wire            gt0_txusrclk_i; 
     wire            gt0_txusrclk2_i; 
     wire            gt0_rxusrclk_i; 
     wire            gt0_rxusrclk2_i; 
     wire            gt1_txusrclk_i; 
     wire            gt1_txusrclk2_i; 
     wire            gt1_rxusrclk_i; 
     wire            gt1_rxusrclk2_i; 
     wire            gt2_txusrclk_i; 
     wire            gt2_txusrclk2_i; 
     wire            gt2_rxusrclk_i; 
     wire            gt2_rxusrclk2_i; 
     wire            gt3_txusrclk_i; 
     wire            gt3_txusrclk2_i; 
     wire            gt3_rxusrclk_i; 
     wire            gt3_rxusrclk2_i; 
    wire            gt0_txmmcm_lock_i;
    wire            gt0_txmmcm_reset_i;
    wire            gt0_rxmmcm_lock_i; 
    wire            gt0_rxmmcm_reset_i;
    wire            gt1_txmmcm_lock_i;
    wire            gt1_txmmcm_reset_i;
    wire            gt1_rxmmcm_lock_i; 
    wire            gt1_rxmmcm_reset_i;
    wire            gt2_txmmcm_lock_i;
    wire            gt2_txmmcm_reset_i;
    wire            gt2_rxmmcm_lock_i; 
    wire            gt2_rxmmcm_reset_i;
    wire            gt3_txmmcm_lock_i;
    wire            gt3_txmmcm_reset_i;
    wire            gt3_rxmmcm_lock_i; 
    wire            gt3_rxmmcm_reset_i;
 
    //--------------------------- Reference Clocks ----------------------------
    
    wire            q0_clk0_refclk_i;

    wire commonreset_i;
    wire commonreset_t;

wire cpll_reset_pll0_q0_clk0_refclk_i;
wire cpll_pd_pll0_q0_clk0_refclk_i;


//**************************** Main Body of Code *******************************

    //  Static signal Assigments    
    assign tied_to_ground_i             = 1'b0;
    assign tied_to_ground_vec_i         = 64'h0000000000000000;
    assign tied_to_vcc_i                = 1'b1;
    assign tied_to_vcc_vec_i            = 8'hff;

    assign  gt0_tx_mmcm_lock_out = gt0_txmmcm_lock_i;
    assign  gt0_rx_mmcm_lock_out = gt0_rxmmcm_lock_i;
    assign  gt1_tx_mmcm_lock_out = gt1_txmmcm_lock_i;
    assign  gt1_rx_mmcm_lock_out = gt1_rxmmcm_lock_i;
    assign  gt2_tx_mmcm_lock_out = gt2_txmmcm_lock_i;
    assign  gt2_rx_mmcm_lock_out = gt2_rxmmcm_lock_i;
    assign  gt3_tx_mmcm_lock_out = gt3_txmmcm_lock_i;
    assign  gt3_rx_mmcm_lock_out = gt3_rxmmcm_lock_i;
 

 
     assign gt0_pll0reset_t = commonreset_i | gt0_pll0reset_i | cpll_reset_pll0_q0_clk0_refclk_i;
 
     assign gt0_pll0pd_t = cpll_pd_pll0_q0_clk0_refclk_i;
   assign gt0_pll0reset_out = commonreset_i | gt0_pll0reset_i;
    assign gt0_pll0outclk_out = gt0_pll0outclk_i;
    assign gt0_pll0outrefclk_out = gt0_pll0outrefclk_i;
    assign gt0_pll0lock_out = gt0_pll0lock_i;
    assign gt0_pll0refclklost_out = gt0_pll0refclklost_i;    
    assign gt0_pll1outclk_out = gt0_pll1outclk_i;
    assign gt0_pll1outrefclk_out = gt0_pll1outrefclk_i;


 
    assign  gt0_txusrclk_out = gt0_txusrclk_i; 
    assign  gt0_txusrclk2_out = gt0_txusrclk2_i;
    assign  gt0_rxusrclk_out = gt0_rxusrclk_i;
    assign  gt0_rxusrclk2_out = gt0_rxusrclk2_i;
 
    assign  gt1_txusrclk_out = gt1_txusrclk_i; 
    assign  gt1_txusrclk2_out = gt1_txusrclk2_i;
    assign  gt1_rxusrclk_out = gt1_rxusrclk_i;
    assign  gt1_rxusrclk2_out = gt1_rxusrclk2_i;
 
    assign  gt2_txusrclk_out = gt2_txusrclk_i; 
    assign  gt2_txusrclk2_out = gt2_txusrclk2_i;
    assign  gt2_rxusrclk_out = gt2_rxusrclk_i;
    assign  gt2_rxusrclk2_out = gt2_rxusrclk2_i;
 
    assign  gt3_txusrclk_out = gt3_txusrclk_i; 
    assign  gt3_txusrclk2_out = gt3_txusrclk2_i;
    assign  gt3_rxusrclk_out = gt3_rxusrclk_i;
    assign  gt3_rxusrclk2_out = gt3_rxusrclk2_i;


    gtp_GT_USRCLK_SOURCE gt_usrclk_source
   (
 
    .GT0_TXUSRCLK_OUT    (gt0_txusrclk_i),
    .GT0_TXUSRCLK2_OUT   (gt0_txusrclk2_i),
    .GT0_TXOUTCLK_IN     (gt0_txoutclk_i),
    .GT0_TXCLK_LOCK_OUT    (gt0_txmmcm_lock_i),
    .GT0_TX_MMCM_RESET_IN  (gt0_txmmcm_reset_i),
    .GT0_RXUSRCLK_OUT    (gt0_rxusrclk_i),
    .GT0_RXUSRCLK2_OUT   (gt0_rxusrclk2_i),
    .GT0_RXCLK_LOCK_OUT  (gt0_rxmmcm_lock_i),
 //   .GT0_RX_MMCM_RESET_IN  (gt0_rxmmcm_reset_i),
 
    .GT1_TXUSRCLK_OUT    (gt1_txusrclk_i),
    .GT1_TXUSRCLK2_OUT   (gt1_txusrclk2_i),
 //   .GT1_TXOUTCLK_IN     (gt1_txoutclk_i),
    .GT1_TXCLK_LOCK_OUT    (gt1_txmmcm_lock_i),
 //   .GT1_TX_MMCM_RESET_IN  (gt1_txmmcm_reset_i),
    .GT1_RXUSRCLK_OUT    (gt1_rxusrclk_i),
    .GT1_RXUSRCLK2_OUT   (gt1_rxusrclk2_i),
    .GT1_RXCLK_LOCK_OUT  (gt1_rxmmcm_lock_i),
 //   .GT1_RX_MMCM_RESET_IN  (gt1_rxmmcm_reset_i),
 
    .GT2_TXUSRCLK_OUT    (gt2_txusrclk_i),
    .GT2_TXUSRCLK2_OUT   (gt2_txusrclk2_i),
 //   .GT2_TXOUTCLK_IN     (gt2_txoutclk_i),
    .GT2_TXCLK_LOCK_OUT    (gt2_txmmcm_lock_i),
 //   .GT2_TX_MMCM_RESET_IN  (gt2_txmmcm_reset_i),
    .GT2_RXUSRCLK_OUT    (gt2_rxusrclk_i),
    .GT2_RXUSRCLK2_OUT   (gt2_rxusrclk2_i),
    .GT2_RXCLK_LOCK_OUT  (gt2_rxmmcm_lock_i),
//    .GT2_RX_MMCM_RESET_IN  (gt2_rxmmcm_reset_i),
 
    .GT3_TXUSRCLK_OUT    (gt3_txusrclk_i),
    .GT3_TXUSRCLK2_OUT   (gt3_txusrclk2_i),
//    .GT3_TXOUTCLK_IN     (gt3_txoutclk_i),
    .GT3_TXCLK_LOCK_OUT    (gt3_txmmcm_lock_i),
//    .GT3_TX_MMCM_RESET_IN  (gt3_txmmcm_reset_i),
    .GT3_RXUSRCLK_OUT    (gt3_rxusrclk_i),
    .GT3_RXUSRCLK2_OUT   (gt3_rxusrclk2_i), 
    .GT3_RXCLK_LOCK_OUT  (gt3_rxmmcm_lock_i),
//    .GT3_RX_MMCM_RESET_IN  (gt3_rxmmcm_reset_i),

    .Q0_CLK0_GTREFCLK_PAD_N_IN  (q0_clk0_gtrefclk_pad_n_in),
    .Q0_CLK0_GTREFCLK_PAD_P_IN  (q0_clk0_gtrefclk_pad_p_in),
    .Q0_CLK0_GTREFCLK_OUT       (q0_clk0_refclk_i)
);
assign  sysclk_in_i = sysclk_in;
 
 gtp_cpll_railing #
   (
        .USE_BUFG(0)
   )
  cpll_railing_pll0_q0_clk0_refclk_i
   (
        .cpll_reset_out(cpll_reset_pll0_q0_clk0_refclk_i),
        .cpll_pd_out(cpll_pd_pll0_q0_clk0_refclk_i),
        .refclk_out(),
        .refclk_in(q0_clk0_refclk_i)
);

    gtp_common #
  (
   .WRAPPER_SIM_GTRESET_SPEEDUP(EXAMPLE_SIM_GTRESET_SPEEDUP),
   .SIM_PLL0REFCLK_SEL(3'b001),
   .SIM_PLL1REFCLK_SEL(3'b001)
  )
 common0_i
   (
    .PLL0OUTCLK_OUT(gt0_pll0outclk_i),
    .PLL0OUTREFCLK_OUT(gt0_pll0outrefclk_i),
    .PLL0LOCK_OUT(gt0_pll0lock_i),
    .PLL0LOCKDETCLK_IN(sysclk_in_i),
    .PLL0REFCLKLOST_OUT(gt0_pll0refclklost_i), 
    .PLL0RESET_IN(gt0_pll0reset_t ),
    .PLL0PD_IN(gt0_pll0pd_t ),
    .PLL0REFCLKSEL_IN(3'b001),
    .PLL1OUTCLK_OUT(gt0_pll1outclk_i),
    .PLL1OUTREFCLK_OUT(gt0_pll1outrefclk_i),
    .GTREFCLK0_IN(q0_clk0_refclk_i),

    .GTREFCLK1_IN(tied_to_ground_i)

);

    gtp_common_reset # 
   (
      .STABLE_CLOCK_PERIOD (STABLE_CLOCK_PERIOD)        // Period of the stable clock driving this state-machine, unit is [ns]
   )
   common_reset_i
   (    
      .STABLE_CLOCK(sysclk_in_i),             //Stable Clock, either a stable clock from the PCB
      .SOFT_RESET(soft_reset_tx_in),               //User Reset, can be pulled any time
      .COMMON_RESET(commonreset_i)              //Reset QPLL
   );


    
    gtp gtp_init_i
    (
        .sysclk_in                      (sysclk_in_i),
        .soft_reset_tx_in               (soft_reset_tx_in),
        .soft_reset_rx_in               (soft_reset_rx_in),
        .dont_reset_on_data_error_in    (dont_reset_on_data_error_in),
        .gt0_tx_mmcm_lock_in            (gt0_txmmcm_lock_i),
        .gt0_tx_mmcm_reset_out          (gt0_txmmcm_reset_i),
        .gt0_rx_mmcm_lock_in            (gt0_rxmmcm_lock_i),
        .gt0_rx_mmcm_reset_out          (gt0_rxmmcm_reset_i),
        .gt0_drp_busy_out               (),
        .gt0_tx_fsm_reset_done_out      (gt0_tx_fsm_reset_done_out),
        .gt0_rx_fsm_reset_done_out      (gt0_rx_fsm_reset_done_out),
        .gt0_data_valid_in              (gt0_data_valid_in),
        .gt1_tx_mmcm_lock_in            (gt1_txmmcm_lock_i),
        .gt1_tx_mmcm_reset_out          (gt1_txmmcm_reset_i),
        .gt1_rx_mmcm_lock_in            (gt1_rxmmcm_lock_i),
        .gt1_rx_mmcm_reset_out          (gt1_rxmmcm_reset_i),
        .gt1_drp_busy_out               (),
        .gt1_tx_fsm_reset_done_out      (gt1_tx_fsm_reset_done_out),
        .gt1_rx_fsm_reset_done_out      (gt1_rx_fsm_reset_done_out),
        .gt1_data_valid_in              (gt1_data_valid_in),
        .gt2_tx_mmcm_lock_in            (gt2_txmmcm_lock_i),
        .gt2_tx_mmcm_reset_out          (gt2_txmmcm_reset_i),
        .gt2_rx_mmcm_lock_in            (gt2_rxmmcm_lock_i),
        .gt2_rx_mmcm_reset_out          (gt2_rxmmcm_reset_i),
        .gt2_drp_busy_out               (),
        .gt2_tx_fsm_reset_done_out      (gt2_tx_fsm_reset_done_out),
        .gt2_rx_fsm_reset_done_out      (gt2_rx_fsm_reset_done_out),
        .gt2_data_valid_in              (gt2_data_valid_in),
        .gt3_tx_mmcm_lock_in            (gt3_txmmcm_lock_i),
        .gt3_tx_mmcm_reset_out          (gt3_txmmcm_reset_i),
        .gt3_rx_mmcm_lock_in            (gt3_rxmmcm_lock_i),
        .gt3_rx_mmcm_reset_out          (gt3_rxmmcm_reset_i),
        .gt3_drp_busy_out               (),
        .gt3_tx_fsm_reset_done_out      (gt3_tx_fsm_reset_done_out),
        .gt3_rx_fsm_reset_done_out      (gt3_rx_fsm_reset_done_out),
        .gt3_data_valid_in              (gt3_data_valid_in),

        //_____________________________________________________________________
        //_____________________________________________________________________
        //GT0  (X0Y0)

        //-------------------------- Channel - DRP Ports  --------------------------
        .gt0_drpaddr_in                 (gt0_drpaddr_in), // input wire [8:0] gt0_drpaddr_in
        .gt0_drpclk_in                  (sysclk_in_i), // input wire sysclk_in_i
        .gt0_drpdi_in                   (gt0_drpdi_in), // input wire [15:0] gt0_drpdi_in
        .gt0_drpdo_out                  (gt0_drpdo_out), // output wire [15:0] gt0_drpdo_out
        .gt0_drpen_in                   (gt0_drpen_in), // input wire gt0_drpen_in
        .gt0_drprdy_out                 (gt0_drprdy_out), // output wire gt0_drprdy_out
        .gt0_drpwe_in                   (gt0_drpwe_in), // input wire gt0_drpwe_in
        //----------------------------- Loopback Ports -----------------------------
        .gt0_loopback_in                (gt0_loopback_in), // input wire [2:0] gt0_loopback_in
        //---------------------------- Power-Down Ports ----------------------------
        .gt0_rxpd_in                    (gt0_rxpd_in), // input wire [1:0] gt0_rxpd_in
        .gt0_txpd_in                    (gt0_txpd_in), // input wire [1:0] gt0_txpd_in
        //------------------- RX Initialization and Reset Ports --------------------
        .gt0_eyescanreset_in            (gt0_eyescanreset_in), // input wire gt0_eyescanreset_in
        .gt0_rxuserrdy_in               (gt0_rxuserrdy_in), // input wire gt0_rxuserrdy_in
        //------------------------ RX Margin Analysis Ports ------------------------
        .gt0_eyescandataerror_out       (gt0_eyescandataerror_out), // output wire gt0_eyescandataerror_out
        .gt0_eyescantrigger_in          (gt0_eyescantrigger_in), // input wire gt0_eyescantrigger_in
        //----------------------- Receive Ports - CDR Ports ------------------------
        .gt0_rxcdrhold_in               (gt0_rxcdrhold_in), // input wire gt0_rxcdrhold_in
        .gt0_rxcdrovrden_in             (gt0_rxcdrovrden_in), // input wire gt0_rxcdrovrden_in
        //----------------- Receive Ports - Clock Correction Ports -----------------
        .gt0_rxclkcorcnt_out            (gt0_rxclkcorcnt_out), // output wire [1:0] gt0_rxclkcorcnt_out
        //---------------- Receive Ports - FPGA RX Interface Ports -----------------
        .gt0_rxdata_out                 (gt0_rxdata_out), // output wire [31:0] gt0_rxdata_out
        .gt0_rxusrclk_in                (gt0_rxusrclk_i), // input wire gt0_rxusrclk_i
        .gt0_rxusrclk2_in               (gt0_rxusrclk2_i), // input wire gt0_rxusrclk2_i
        //----------------- Receive Ports - Pattern Checker Ports ------------------
        .gt0_rxprbserr_out              (gt0_rxprbserr_out), // output wire gt0_rxprbserr_out
        .gt0_rxprbssel_in               (gt0_rxprbssel_in), // input wire [2:0] gt0_rxprbssel_in
        //----------------- Receive Ports - Pattern Checker ports ------------------
        .gt0_rxprbscntreset_in          (gt0_rxprbscntreset_in), // input wire gt0_rxprbscntreset_in
        //---------------- Receive Ports - RX 8B/10B Decoder Ports -----------------
        .gt0_rxchariscomma_out          (gt0_rxchariscomma_out), // output wire [3:0] gt0_rxchariscomma_out
        .gt0_rxcharisk_out              (gt0_rxcharisk_out), // output wire [3:0] gt0_rxcharisk_out
        .gt0_rxdisperr_out              (gt0_rxdisperr_out), // output wire [3:0] gt0_rxdisperr_out
        .gt0_rxnotintable_out           (gt0_rxnotintable_out), // output wire [3:0] gt0_rxnotintable_out
        //---------------------- Receive Ports - RX AFE Ports ----------------------
        .gt0_gtprxn_in                  (gt0_gtprxn_in), // input wire gt0_gtprxn_in
        .gt0_gtprxp_in                  (gt0_gtprxp_in), // input wire gt0_gtprxp_in
        //----------------- Receive Ports - RX Buffer Bypass Ports -----------------
        .gt0_rxbufreset_in              (gt0_rxbufreset_in), // input wire gt0_rxbufreset_in
        .gt0_rxbufstatus_out            (gt0_rxbufstatus_out), // output wire [2:0] gt0_rxbufstatus_out
        //------------ Receive Ports - RX Byte and Word Alignment Ports ------------
        .gt0_rxbyteisaligned_out        (gt0_rxbyteisaligned_out), // output wire gt0_rxbyteisaligned_out
        .gt0_rxbyterealign_out          (gt0_rxbyterealign_out), // output wire gt0_rxbyterealign_out
        .gt0_rxcommadet_out             (gt0_rxcommadet_out), // output wire gt0_rxcommadet_out
        .gt0_rxmcommaalignen_in         (gt0_rxmcommaalignen_in), // input wire gt0_rxmcommaalignen_in
        .gt0_rxpcommaalignen_in         (gt0_rxpcommaalignen_in), // input wire gt0_rxpcommaalignen_in
        //---------- Receive Ports - RX Decision Feedback Equalizer(DFE) -----------
        .gt0_dmonitorout_out            (gt0_dmonitorout_out), // output wire [14:0] gt0_dmonitorout_out
        //------------------ Receive Ports - RX Equailizer Ports -------------------
        .gt0_rxlpmhfhold_in             (gt0_rxlpmhfhold_in), // input wire gt0_rxlpmhfhold_in
        .gt0_rxlpmhfovrden_in           (gt0_rxlpmhfovrden_in), // input wire gt0_rxlpmhfovrden_in
        .gt0_rxlpmlfhold_in             (gt0_rxlpmlfhold_in), // input wire gt0_rxlpmlfhold_in
        //------------- Receive Ports - RX Fabric Output Control Ports -------------
        .gt0_rxoutclkfabric_out         (gt0_rxoutclkfabric_out), // output wire gt0_rxoutclkfabric_out
        //----------- Receive Ports - RX Initialization and Reset Ports ------------
        .gt0_gtrxreset_in               (gt0_gtrxreset_in), // input wire gt0_gtrxreset_in
        .gt0_rxlpmreset_in              (gt0_rxlpmreset_in), // input wire gt0_rxlpmreset_in
        .gt0_rxpcsreset_in              (gt0_rxpcsreset_in), // input wire gt0_rxpcsreset_in
        .gt0_rxpmareset_in              (gt0_rxpmareset_in), // input wire gt0_rxpmareset_in
        //--------------- Receive Ports - RX Polarity Control Ports ----------------
        .gt0_rxpolarity_in              (gt0_rxpolarity_in), // input wire gt0_rxpolarity_in
        //------------ Receive Ports -RX Initialization and Reset Ports ------------
        .gt0_rxresetdone_out            (gt0_rxresetdone_out), // output wire gt0_rxresetdone_out
        //---------------------- TX Configurable Driver Ports ----------------------
        .gt0_txpostcursor_in            (gt0_txpostcursor_in), // input wire [4:0] gt0_txpostcursor_in
        .gt0_txprecursor_in             (gt0_txprecursor_in), // input wire [4:0] gt0_txprecursor_in
        //------------------- TX Initialization and Reset Ports --------------------
        .gt0_gttxreset_in               (gt0_gttxreset_in), // input wire gt0_gttxreset_in
        .gt0_txuserrdy_in               (gt0_txuserrdy_in), // input wire gt0_txuserrdy_in
        //---------------- Transmit Ports - FPGA TX Interface Ports ----------------
        .gt0_txdata_in                  (gt0_txdata_in), // input wire [31:0] gt0_txdata_in
        .gt0_txusrclk_in                (gt0_txusrclk_i), // input wire gt0_txusrclk_i
        .gt0_txusrclk2_in               (gt0_txusrclk2_i), // input wire gt0_txusrclk2_i
        //---------------- Transmit Ports - Pattern Generator Ports ----------------
        .gt0_txprbsforceerr_in          (gt0_txprbsforceerr_in), // input wire gt0_txprbsforceerr_in
        //---------------- Transmit Ports - TX 8B/10B Encoder Ports ----------------
        .gt0_txchardispmode_in          (gt0_txchardispmode_in), // input wire [3:0] gt0_txchardispmode_in
        .gt0_txchardispval_in           (gt0_txchardispval_in), // input wire [3:0] gt0_txchardispval_in
        .gt0_txcharisk_in               (gt0_txcharisk_in), // input wire [3:0] gt0_txcharisk_in
        //-------------------- Transmit Ports - TX Buffer Ports --------------------
        .gt0_txbufstatus_out            (gt0_txbufstatus_out), // output wire [1:0] gt0_txbufstatus_out
        //------------- Transmit Ports - TX Configurable Driver Ports --------------
        .gt0_gtptxn_out                 (gt0_gtptxn_out), // output wire gt0_gtptxn_out
        .gt0_gtptxp_out                 (gt0_gtptxp_out), // output wire gt0_gtptxp_out
        .gt0_txdiffctrl_in              (gt0_txdiffctrl_in), // input wire [3:0] gt0_txdiffctrl_in
        .gt0_txmaincursor_in            (gt0_txmaincursor_in), // input wire [6:0] gt0_txmaincursor_in
        //--------- Transmit Ports - TX Fabric Clock Output Control Ports ----------
        .gt0_txoutclk_out               (gt0_txoutclk_i), // output wire gt0_txoutclk_i
        .gt0_txoutclkfabric_out         (gt0_txoutclkfabric_out), // output wire gt0_txoutclkfabric_out
        .gt0_txoutclkpcs_out            (gt0_txoutclkpcs_out), // output wire gt0_txoutclkpcs_out
        //----------- Transmit Ports - TX Initialization and Reset Ports -----------
        .gt0_txpcsreset_in              (gt0_txpcsreset_in), // input wire gt0_txpcsreset_in
        .gt0_txpmareset_in              (gt0_txpmareset_in), // input wire gt0_txpmareset_i
        .gt0_txresetdone_out            (gt0_txresetdone_out), // output wire gt0_txresetdone_out
        //--------------- Transmit Ports - TX Polarity Control Ports ---------------
        .gt0_txpolarity_in              (gt0_txpolarity_in), // input wire gt0_txpolarity_in
        //---------------- Transmit Ports - pattern Generator Ports ----------------
        .gt0_txprbssel_in               (gt0_txprbssel_in), // input wire [2:0] gt0_txprbssel_in



        //_____________________________________________________________________
        //_____________________________________________________________________
        //GT1  (X0Y1)

        //-------------------------- Channel - DRP Ports  --------------------------
        .gt1_drpaddr_in                 (gt1_drpaddr_in), // input wire [8:0] gt1_drpaddr_in
        .gt1_drpclk_in                  (sysclk_in_i), // input wire sysclk_in_i
        .gt1_drpdi_in                   (gt1_drpdi_in), // input wire [15:0] gt1_drpdi_in
        .gt1_drpdo_out                  (gt1_drpdo_out), // output wire [15:0] gt1_drpdo_out
        .gt1_drpen_in                   (gt1_drpen_in), // input wire gt1_drpen_in
        .gt1_drprdy_out                 (gt1_drprdy_out), // output wire gt1_drprdy_out
        .gt1_drpwe_in                   (gt1_drpwe_in), // input wire gt1_drpwe_in
        //----------------------------- Loopback Ports -----------------------------
        .gt1_loopback_in                (gt1_loopback_in), // input wire [2:0] gt1_loopback_in
        //---------------------------- Power-Down Ports ----------------------------
        .gt1_rxpd_in                    (gt1_rxpd_in), // input wire [1:0] gt1_rxpd_in
        .gt1_txpd_in                    (gt1_txpd_in), // input wire [1:0] gt1_txpd_in
        //------------------- RX Initialization and Reset Ports --------------------
        .gt1_eyescanreset_in            (gt1_eyescanreset_in), // input wire gt1_eyescanreset_in
        .gt1_rxuserrdy_in               (gt1_rxuserrdy_in), // input wire gt1_rxuserrdy_in
        //------------------------ RX Margin Analysis Ports ------------------------
        .gt1_eyescandataerror_out       (gt1_eyescandataerror_out), // output wire gt1_eyescandataerror_out
        .gt1_eyescantrigger_in          (gt1_eyescantrigger_in), // input wire gt1_eyescantrigger_in
        //----------------------- Receive Ports - CDR Ports ------------------------
        .gt1_rxcdrhold_in               (gt1_rxcdrhold_in), // input wire gt1_rxcdrhold_in
        .gt1_rxcdrovrden_in             (gt1_rxcdrovrden_in), // input wire gt1_rxcdrovrden_in
        //----------------- Receive Ports - Clock Correction Ports -----------------
        .gt1_rxclkcorcnt_out            (gt1_rxclkcorcnt_out), // output wire [1:0] gt1_rxclkcorcnt_out
        //---------------- Receive Ports - FPGA RX Interface Ports -----------------
        .gt1_rxdata_out                 (gt1_rxdata_out), // output wire [31:0] gt1_rxdata_out
        .gt1_rxusrclk_in                (gt1_rxusrclk_i), // input wire gt1_rxusrclk_i
        .gt1_rxusrclk2_in               (gt1_rxusrclk2_i), // input wire gt1_rxusrclk2_i
        //----------------- Receive Ports - Pattern Checker Ports ------------------
        .gt1_rxprbserr_out              (gt1_rxprbserr_out), // output wire gt1_rxprbserr_out
        .gt1_rxprbssel_in               (gt1_rxprbssel_in), // input wire [2:0] gt1_rxprbssel_in
        //----------------- Receive Ports - Pattern Checker ports ------------------
        .gt1_rxprbscntreset_in          (gt1_rxprbscntreset_in), // input wire gt1_rxprbscntreset_in
        //---------------- Receive Ports - RX 8B/10B Decoder Ports -----------------
        .gt1_rxchariscomma_out          (gt1_rxchariscomma_out), // output wire [3:0] gt1_rxchariscomma_out
        .gt1_rxcharisk_out              (gt1_rxcharisk_out), // output wire [3:0] gt1_rxcharisk_out
        .gt1_rxdisperr_out              (gt1_rxdisperr_out), // output wire [3:0] gt1_rxdisperr_out
        .gt1_rxnotintable_out           (gt1_rxnotintable_out), // output wire [3:0] gt1_rxnotintable_out
        //---------------------- Receive Ports - RX AFE Ports ----------------------
        .gt1_gtprxn_in                  (gt1_gtprxn_in), // input wire gt1_gtprxn_in
        .gt1_gtprxp_in                  (gt1_gtprxp_in), // input wire gt1_gtprxp_in
        //----------------- Receive Ports - RX Buffer Bypass Ports -----------------
        .gt1_rxbufreset_in              (gt1_rxbufreset_in), // input wire gt1_rxbufreset_in
        .gt1_rxbufstatus_out            (gt1_rxbufstatus_out), // output wire [2:0] gt1_rxbufstatus_out
        //------------ Receive Ports - RX Byte and Word Alignment Ports ------------
        .gt1_rxbyteisaligned_out        (gt1_rxbyteisaligned_out), // output wire gt1_rxbyteisaligned_out
        .gt1_rxbyterealign_out          (gt1_rxbyterealign_out), // output wire gt1_rxbyterealign_out
        .gt1_rxcommadet_out             (gt1_rxcommadet_out), // output wire gt1_rxcommadet_out
        .gt1_rxmcommaalignen_in         (gt1_rxmcommaalignen_in), // input wire gt1_rxmcommaalignen_in
        .gt1_rxpcommaalignen_in         (gt1_rxpcommaalignen_in), // input wire gt1_rxpcommaalignen_in
        //---------- Receive Ports - RX Decision Feedback Equalizer(DFE) -----------
        .gt1_dmonitorout_out            (gt1_dmonitorout_out), // output wire [14:0] gt1_dmonitorout_out
        //------------------ Receive Ports - RX Equailizer Ports -------------------
        .gt1_rxlpmhfhold_in             (gt1_rxlpmhfhold_in), // input wire gt1_rxlpmhfhold_in
        .gt1_rxlpmhfovrden_in           (gt1_rxlpmhfovrden_in), // input wire gt1_rxlpmhfovrden_in
        .gt1_rxlpmlfhold_in             (gt1_rxlpmlfhold_in), // input wire gt1_rxlpmlfhold_in
        //------------- Receive Ports - RX Fabric Output Control Ports -------------
        .gt1_rxoutclkfabric_out         (gt1_rxoutclkfabric_out), // output wire gt1_rxoutclkfabric_out
        //----------- Receive Ports - RX Initialization and Reset Ports ------------
        .gt1_gtrxreset_in               (gt1_gtrxreset_in), // input wire gt1_gtrxreset_in
        .gt1_rxlpmreset_in              (gt1_rxlpmreset_in), // input wire gt1_rxlpmreset_in
        .gt1_rxpcsreset_in              (gt1_rxpcsreset_in), // input wire gt1_rxpcsreset_in
        .gt1_rxpmareset_in              (gt1_rxpmareset_in), // input wire gt1_rxpmareset_in
        //--------------- Receive Ports - RX Polarity Control Ports ----------------
        .gt1_rxpolarity_in              (gt1_rxpolarity_in), // input wire gt1_rxpolarity_in
        //------------ Receive Ports -RX Initialization and Reset Ports ------------
        .gt1_rxresetdone_out            (gt1_rxresetdone_out), // output wire gt1_rxresetdone_out
        //---------------------- TX Configurable Driver Ports ----------------------
        .gt1_txpostcursor_in            (gt1_txpostcursor_in), // input wire [4:0] gt1_txpostcursor_in
        .gt1_txprecursor_in             (gt1_txprecursor_in), // input wire [4:0] gt1_txprecursor_in
        //------------------- TX Initialization and Reset Ports --------------------
        .gt1_gttxreset_in               (gt1_gttxreset_in), // input wire gt1_gttxreset_in
        .gt1_txuserrdy_in               (gt1_txuserrdy_in), // input wire gt1_txuserrdy_in
        //---------------- Transmit Ports - FPGA TX Interface Ports ----------------
        .gt1_txdata_in                  (gt1_txdata_in), // input wire [31:0] gt1_txdata_in
        .gt1_txusrclk_in                (gt1_txusrclk_i), // input wire gt1_txusrclk_i
        .gt1_txusrclk2_in               (gt1_txusrclk2_i), // input wire gt1_txusrclk2_i
        //---------------- Transmit Ports - Pattern Generator Ports ----------------
        .gt1_txprbsforceerr_in          (gt1_txprbsforceerr_in), // input wire gt1_txprbsforceerr_in
        //---------------- Transmit Ports - TX 8B/10B Encoder Ports ----------------
        .gt1_txchardispmode_in          (gt1_txchardispmode_in), // input wire [3:0] gt1_txchardispmode_in
        .gt1_txchardispval_in           (gt1_txchardispval_in), // input wire [3:0] gt1_txchardispval_in
        .gt1_txcharisk_in               (gt1_txcharisk_in), // input wire [3:0] gt1_txcharisk_in
        //-------------------- Transmit Ports - TX Buffer Ports --------------------
        .gt1_txbufstatus_out            (gt1_txbufstatus_out), // output wire [1:0] gt1_txbufstatus_out
        //------------- Transmit Ports - TX Configurable Driver Ports --------------
        .gt1_gtptxn_out                 (gt1_gtptxn_out), // output wire gt1_gtptxn_out
        .gt1_gtptxp_out                 (gt1_gtptxp_out), // output wire gt1_gtptxp_out
        .gt1_txdiffctrl_in              (gt1_txdiffctrl_in), // input wire [3:0] gt1_txdiffctrl_in
        .gt1_txmaincursor_in            (gt1_txmaincursor_in), // input wire [6:0] gt1_txmaincursor_in
        //--------- Transmit Ports - TX Fabric Clock Output Control Ports ----------
        .gt1_txoutclk_out               (gt1_txoutclk_i), // output wire gt1_txoutclk_i
        .gt1_txoutclkfabric_out         (gt1_txoutclkfabric_out), // output wire gt1_txoutclkfabric_out
        .gt1_txoutclkpcs_out            (gt1_txoutclkpcs_out), // output wire gt1_txoutclkpcs_out
        //----------- Transmit Ports - TX Initialization and Reset Ports -----------
        .gt1_txpcsreset_in              (gt1_txpcsreset_in), // input wire gt1_txpcsreset_in
        .gt1_txpmareset_in              (gt1_txpmareset_in), // input wire gt1_txpmareset_i
        .gt1_txresetdone_out            (gt1_txresetdone_out), // output wire gt1_txresetdone_out
        //--------------- Transmit Ports - TX Polarity Control Ports ---------------
        .gt1_txpolarity_in              (gt1_txpolarity_in), // input wire gt1_txpolarity_in
        //---------------- Transmit Ports - pattern Generator Ports ----------------
        .gt1_txprbssel_in               (gt1_txprbssel_in), // input wire [2:0] gt1_txprbssel_in



        //_____________________________________________________________________
        //_____________________________________________________________________
        //GT2  (X0Y2)

        //-------------------------- Channel - DRP Ports  --------------------------
        .gt2_drpaddr_in                 (gt2_drpaddr_in), // input wire [8:0] gt2_drpaddr_in
        .gt2_drpclk_in                  (sysclk_in_i), // input wire sysclk_in_i
        .gt2_drpdi_in                   (gt2_drpdi_in), // input wire [15:0] gt2_drpdi_in
        .gt2_drpdo_out                  (gt2_drpdo_out), // output wire [15:0] gt2_drpdo_out
        .gt2_drpen_in                   (gt2_drpen_in), // input wire gt2_drpen_in
        .gt2_drprdy_out                 (gt2_drprdy_out), // output wire gt2_drprdy_out
        .gt2_drpwe_in                   (gt2_drpwe_in), // input wire gt2_drpwe_in
        //----------------------------- Loopback Ports -----------------------------
        .gt2_loopback_in                (gt2_loopback_in), // input wire [2:0] gt2_loopback_in
        //---------------------------- Power-Down Ports ----------------------------
        .gt2_rxpd_in                    (gt2_rxpd_in), // input wire [1:0] gt2_rxpd_in
        .gt2_txpd_in                    (gt2_txpd_in), // input wire [1:0] gt2_txpd_in
        //------------------- RX Initialization and Reset Ports --------------------
        .gt2_eyescanreset_in            (gt2_eyescanreset_in), // input wire gt2_eyescanreset_in
        .gt2_rxuserrdy_in               (gt2_rxuserrdy_in), // input wire gt2_rxuserrdy_in
        //------------------------ RX Margin Analysis Ports ------------------------
        .gt2_eyescandataerror_out       (gt2_eyescandataerror_out), // output wire gt2_eyescandataerror_out
        .gt2_eyescantrigger_in          (gt2_eyescantrigger_in), // input wire gt2_eyescantrigger_in
        //----------------------- Receive Ports - CDR Ports ------------------------
        .gt2_rxcdrhold_in               (gt2_rxcdrhold_in), // input wire gt2_rxcdrhold_in
        .gt2_rxcdrovrden_in             (gt2_rxcdrovrden_in), // input wire gt2_rxcdrovrden_in
        //----------------- Receive Ports - Clock Correction Ports -----------------
        .gt2_rxclkcorcnt_out            (gt2_rxclkcorcnt_out), // output wire [1:0] gt2_rxclkcorcnt_out
        //---------------- Receive Ports - FPGA RX Interface Ports -----------------
        .gt2_rxdata_out                 (gt2_rxdata_out), // output wire [31:0] gt2_rxdata_out
        .gt2_rxusrclk_in                (gt2_rxusrclk_i), // input wire gt2_rxusrclk_i
        .gt2_rxusrclk2_in               (gt2_rxusrclk2_i), // input wire gt2_rxusrclk2_i
        //----------------- Receive Ports - Pattern Checker Ports ------------------
        .gt2_rxprbserr_out              (gt2_rxprbserr_out), // output wire gt2_rxprbserr_out
        .gt2_rxprbssel_in               (gt2_rxprbssel_in), // input wire [2:0] gt2_rxprbssel_in
        //----------------- Receive Ports - Pattern Checker ports ------------------
        .gt2_rxprbscntreset_in          (gt2_rxprbscntreset_in), // input wire gt2_rxprbscntreset_in
        //---------------- Receive Ports - RX 8B/10B Decoder Ports -----------------
        .gt2_rxchariscomma_out          (gt2_rxchariscomma_out), // output wire [3:0] gt2_rxchariscomma_out
        .gt2_rxcharisk_out              (gt2_rxcharisk_out), // output wire [3:0] gt2_rxcharisk_out
        .gt2_rxdisperr_out              (gt2_rxdisperr_out), // output wire [3:0] gt2_rxdisperr_out
        .gt2_rxnotintable_out           (gt2_rxnotintable_out), // output wire [3:0] gt2_rxnotintable_out
        //---------------------- Receive Ports - RX AFE Ports ----------------------
        .gt2_gtprxn_in                  (gt2_gtprxn_in), // input wire gt2_gtprxn_in
        .gt2_gtprxp_in                  (gt2_gtprxp_in), // input wire gt2_gtprxp_in
        //----------------- Receive Ports - RX Buffer Bypass Ports -----------------
        .gt2_rxbufreset_in              (gt2_rxbufreset_in), // input wire gt2_rxbufreset_in
        .gt2_rxbufstatus_out            (gt2_rxbufstatus_out), // output wire [2:0] gt2_rxbufstatus_out
        //------------ Receive Ports - RX Byte and Word Alignment Ports ------------
        .gt2_rxbyteisaligned_out        (gt2_rxbyteisaligned_out), // output wire gt2_rxbyteisaligned_out
        .gt2_rxbyterealign_out          (gt2_rxbyterealign_out), // output wire gt2_rxbyterealign_out
        .gt2_rxcommadet_out             (gt2_rxcommadet_out), // output wire gt2_rxcommadet_out
        .gt2_rxmcommaalignen_in         (gt2_rxmcommaalignen_in), // input wire gt2_rxmcommaalignen_in
        .gt2_rxpcommaalignen_in         (gt2_rxpcommaalignen_in), // input wire gt2_rxpcommaalignen_in
        //---------- Receive Ports - RX Decision Feedback Equalizer(DFE) -----------
        .gt2_dmonitorout_out            (gt2_dmonitorout_out), // output wire [14:0] gt2_dmonitorout_out
        //------------------ Receive Ports - RX Equailizer Ports -------------------
        .gt2_rxlpmhfhold_in             (gt2_rxlpmhfhold_in), // input wire gt2_rxlpmhfhold_in
        .gt2_rxlpmhfovrden_in           (gt2_rxlpmhfovrden_in), // input wire gt2_rxlpmhfovrden_in
        .gt2_rxlpmlfhold_in             (gt2_rxlpmlfhold_in), // input wire gt2_rxlpmlfhold_in
        //------------- Receive Ports - RX Fabric Output Control Ports -------------
        .gt2_rxoutclkfabric_out         (gt2_rxoutclkfabric_out), // output wire gt2_rxoutclkfabric_out
        //----------- Receive Ports - RX Initialization and Reset Ports ------------
        .gt2_gtrxreset_in               (gt2_gtrxreset_in), // input wire gt2_gtrxreset_in
        .gt2_rxlpmreset_in              (gt2_rxlpmreset_in), // input wire gt2_rxlpmreset_in
        .gt2_rxpcsreset_in              (gt2_rxpcsreset_in), // input wire gt2_rxpcsreset_in
        .gt2_rxpmareset_in              (gt2_rxpmareset_in), // input wire gt2_rxpmareset_in
        //--------------- Receive Ports - RX Polarity Control Ports ----------------
        .gt2_rxpolarity_in              (gt2_rxpolarity_in), // input wire gt2_rxpolarity_in
        //------------ Receive Ports -RX Initialization and Reset Ports ------------
        .gt2_rxresetdone_out            (gt2_rxresetdone_out), // output wire gt2_rxresetdone_out
        //---------------------- TX Configurable Driver Ports ----------------------
        .gt2_txpostcursor_in            (gt2_txpostcursor_in), // input wire [4:0] gt2_txpostcursor_in
        .gt2_txprecursor_in             (gt2_txprecursor_in), // input wire [4:0] gt2_txprecursor_in
        //------------------- TX Initialization and Reset Ports --------------------
        .gt2_gttxreset_in               (gt2_gttxreset_in), // input wire gt2_gttxreset_in
        .gt2_txuserrdy_in               (gt2_txuserrdy_in), // input wire gt2_txuserrdy_in
        //---------------- Transmit Ports - FPGA TX Interface Ports ----------------
        .gt2_txdata_in                  (gt2_txdata_in), // input wire [31:0] gt2_txdata_in
        .gt2_txusrclk_in                (gt2_txusrclk_i), // input wire gt2_txusrclk_i
        .gt2_txusrclk2_in               (gt2_txusrclk2_i), // input wire gt2_txusrclk2_i
        //---------------- Transmit Ports - Pattern Generator Ports ----------------
        .gt2_txprbsforceerr_in          (gt2_txprbsforceerr_in), // input wire gt2_txprbsforceerr_in
        //---------------- Transmit Ports - TX 8B/10B Encoder Ports ----------------
        .gt2_txchardispmode_in          (gt2_txchardispmode_in), // input wire [3:0] gt2_txchardispmode_in
        .gt2_txchardispval_in           (gt2_txchardispval_in), // input wire [3:0] gt2_txchardispval_in
        .gt2_txcharisk_in               (gt2_txcharisk_in), // input wire [3:0] gt2_txcharisk_in
        //-------------------- Transmit Ports - TX Buffer Ports --------------------
        .gt2_txbufstatus_out            (gt2_txbufstatus_out), // output wire [1:0] gt2_txbufstatus_out
        //------------- Transmit Ports - TX Configurable Driver Ports --------------
        .gt2_gtptxn_out                 (gt2_gtptxn_out), // output wire gt2_gtptxn_out
        .gt2_gtptxp_out                 (gt2_gtptxp_out), // output wire gt2_gtptxp_out
        .gt2_txdiffctrl_in              (gt2_txdiffctrl_in), // input wire [3:0] gt2_txdiffctrl_in
        .gt2_txmaincursor_in            (gt2_txmaincursor_in), // input wire [6:0] gt2_txmaincursor_in
        //--------- Transmit Ports - TX Fabric Clock Output Control Ports ----------
        .gt2_txoutclk_out               (gt2_txoutclk_i), // output wire gt2_txoutclk_i
        .gt2_txoutclkfabric_out         (gt2_txoutclkfabric_out), // output wire gt2_txoutclkfabric_out
        .gt2_txoutclkpcs_out            (gt2_txoutclkpcs_out), // output wire gt2_txoutclkpcs_out
        //----------- Transmit Ports - TX Initialization and Reset Ports -----------
        .gt2_txpcsreset_in              (gt2_txpcsreset_in), // input wire gt2_txpcsreset_in
        .gt2_txpmareset_in              (gt2_txpmareset_in), // input wire gt2_txpmareset_i
        .gt2_txresetdone_out            (gt2_txresetdone_out), // output wire gt2_txresetdone_out
        //--------------- Transmit Ports - TX Polarity Control Ports ---------------
        .gt2_txpolarity_in              (gt2_txpolarity_in), // input wire gt2_txpolarity_in
        //---------------- Transmit Ports - pattern Generator Ports ----------------
        .gt2_txprbssel_in               (gt2_txprbssel_in), // input wire [2:0] gt2_txprbssel_in



        //_____________________________________________________________________
        //_____________________________________________________________________
        //GT3  (X0Y3)

        //-------------------------- Channel - DRP Ports  --------------------------
        .gt3_drpaddr_in                 (gt3_drpaddr_in), // input wire [8:0] gt3_drpaddr_in
        .gt3_drpclk_in                  (sysclk_in_i), // input wire sysclk_in_i
        .gt3_drpdi_in                   (gt3_drpdi_in), // input wire [15:0] gt3_drpdi_in
        .gt3_drpdo_out                  (gt3_drpdo_out), // output wire [15:0] gt3_drpdo_out
        .gt3_drpen_in                   (gt3_drpen_in), // input wire gt3_drpen_in
        .gt3_drprdy_out                 (gt3_drprdy_out), // output wire gt3_drprdy_out
        .gt3_drpwe_in                   (gt3_drpwe_in), // input wire gt3_drpwe_in
        //----------------------------- Loopback Ports -----------------------------
        .gt3_loopback_in                (gt3_loopback_in), // input wire [2:0] gt3_loopback_in
        //---------------------------- Power-Down Ports ----------------------------
        .gt3_rxpd_in                    (gt3_rxpd_in), // input wire [1:0] gt3_rxpd_in
        .gt3_txpd_in                    (gt3_txpd_in), // input wire [1:0] gt3_txpd_in
        //------------------- RX Initialization and Reset Ports --------------------
        .gt3_eyescanreset_in            (gt3_eyescanreset_in), // input wire gt3_eyescanreset_in
        .gt3_rxuserrdy_in               (gt3_rxuserrdy_in), // input wire gt3_rxuserrdy_in
        //------------------------ RX Margin Analysis Ports ------------------------
        .gt3_eyescandataerror_out       (gt3_eyescandataerror_out), // output wire gt3_eyescandataerror_out
        .gt3_eyescantrigger_in          (gt3_eyescantrigger_in), // input wire gt3_eyescantrigger_in
        //----------------------- Receive Ports - CDR Ports ------------------------
        .gt3_rxcdrhold_in               (gt3_rxcdrhold_in), // input wire gt3_rxcdrhold_in
        .gt3_rxcdrovrden_in             (gt3_rxcdrovrden_in), // input wire gt3_rxcdrovrden_in
        //----------------- Receive Ports - Clock Correction Ports -----------------
        .gt3_rxclkcorcnt_out            (gt3_rxclkcorcnt_out), // output wire [1:0] gt3_rxclkcorcnt_out
        //---------------- Receive Ports - FPGA RX Interface Ports -----------------
        .gt3_rxdata_out                 (gt3_rxdata_out), // output wire [31:0] gt3_rxdata_out
        .gt3_rxusrclk_in                (gt3_rxusrclk_i), // input wire gt3_rxusrclk_i
        .gt3_rxusrclk2_in               (gt3_rxusrclk2_i), // input wire gt3_rxusrclk2_i
        //----------------- Receive Ports - Pattern Checker Ports ------------------
        .gt3_rxprbserr_out              (gt3_rxprbserr_out), // output wire gt3_rxprbserr_out
        .gt3_rxprbssel_in               (gt3_rxprbssel_in), // input wire [2:0] gt3_rxprbssel_in
        //----------------- Receive Ports - Pattern Checker ports ------------------
        .gt3_rxprbscntreset_in          (gt3_rxprbscntreset_in), // input wire gt3_rxprbscntreset_in
        //---------------- Receive Ports - RX 8B/10B Decoder Ports -----------------
        .gt3_rxchariscomma_out          (gt3_rxchariscomma_out), // output wire [3:0] gt3_rxchariscomma_out
        .gt3_rxcharisk_out              (gt3_rxcharisk_out), // output wire [3:0] gt3_rxcharisk_out
        .gt3_rxdisperr_out              (gt3_rxdisperr_out), // output wire [3:0] gt3_rxdisperr_out
        .gt3_rxnotintable_out           (gt3_rxnotintable_out), // output wire [3:0] gt3_rxnotintable_out
        //---------------------- Receive Ports - RX AFE Ports ----------------------
        .gt3_gtprxn_in                  (gt3_gtprxn_in), // input wire gt3_gtprxn_in
        .gt3_gtprxp_in                  (gt3_gtprxp_in), // input wire gt3_gtprxp_in
        //----------------- Receive Ports - RX Buffer Bypass Ports -----------------
        .gt3_rxbufreset_in              (gt3_rxbufreset_in), // input wire gt3_rxbufreset_in
        .gt3_rxbufstatus_out            (gt3_rxbufstatus_out), // output wire [2:0] gt3_rxbufstatus_out
        //------------ Receive Ports - RX Byte and Word Alignment Ports ------------
        .gt3_rxbyteisaligned_out        (gt3_rxbyteisaligned_out), // output wire gt3_rxbyteisaligned_out
        .gt3_rxbyterealign_out          (gt3_rxbyterealign_out), // output wire gt3_rxbyterealign_out
        .gt3_rxcommadet_out             (gt3_rxcommadet_out), // output wire gt3_rxcommadet_out
        .gt3_rxmcommaalignen_in         (gt3_rxmcommaalignen_in), // input wire gt3_rxmcommaalignen_in
        .gt3_rxpcommaalignen_in         (gt3_rxpcommaalignen_in), // input wire gt3_rxpcommaalignen_in
        //---------- Receive Ports - RX Decision Feedback Equalizer(DFE) -----------
        .gt3_dmonitorout_out            (gt3_dmonitorout_out), // output wire [14:0] gt3_dmonitorout_out
        //------------------ Receive Ports - RX Equailizer Ports -------------------
        .gt3_rxlpmhfhold_in             (gt3_rxlpmhfhold_in), // input wire gt3_rxlpmhfhold_in
        .gt3_rxlpmhfovrden_in           (gt3_rxlpmhfovrden_in), // input wire gt3_rxlpmhfovrden_in
        .gt3_rxlpmlfhold_in             (gt3_rxlpmlfhold_in), // input wire gt3_rxlpmlfhold_in
        //------------- Receive Ports - RX Fabric Output Control Ports -------------
        .gt3_rxoutclkfabric_out         (gt3_rxoutclkfabric_out), // output wire gt3_rxoutclkfabric_out
        //----------- Receive Ports - RX Initialization and Reset Ports ------------
        .gt3_gtrxreset_in               (gt3_gtrxreset_in), // input wire gt3_gtrxreset_in
        .gt3_rxlpmreset_in              (gt3_rxlpmreset_in), // input wire gt3_rxlpmreset_in
        .gt3_rxpcsreset_in              (gt3_rxpcsreset_in), // input wire gt3_rxpcsreset_in
        .gt3_rxpmareset_in              (gt3_rxpmareset_in), // input wire gt3_rxpmareset_in
        //--------------- Receive Ports - RX Polarity Control Ports ----------------
        .gt3_rxpolarity_in              (gt3_rxpolarity_in), // input wire gt3_rxpolarity_in
        //------------ Receive Ports -RX Initialization and Reset Ports ------------
        .gt3_rxresetdone_out            (gt3_rxresetdone_out), // output wire gt3_rxresetdone_out
        //---------------------- TX Configurable Driver Ports ----------------------
        .gt3_txpostcursor_in            (gt3_txpostcursor_in), // input wire [4:0] gt3_txpostcursor_in
        .gt3_txprecursor_in             (gt3_txprecursor_in), // input wire [4:0] gt3_txprecursor_in
        //------------------- TX Initialization and Reset Ports --------------------
        .gt3_gttxreset_in               (gt3_gttxreset_in), // input wire gt3_gttxreset_in
        .gt3_txuserrdy_in               (gt3_txuserrdy_in), // input wire gt3_txuserrdy_in
        //---------------- Transmit Ports - FPGA TX Interface Ports ----------------
        .gt3_txdata_in                  (gt3_txdata_in), // input wire [31:0] gt3_txdata_in
        .gt3_txusrclk_in                (gt3_txusrclk_i), // input wire gt3_txusrclk_i
        .gt3_txusrclk2_in               (gt3_txusrclk2_i), // input wire gt3_txusrclk2_i
        //---------------- Transmit Ports - Pattern Generator Ports ----------------
        .gt3_txprbsforceerr_in          (gt3_txprbsforceerr_in), // input wire gt3_txprbsforceerr_in
        //---------------- Transmit Ports - TX 8B/10B Encoder Ports ----------------
        .gt3_txchardispmode_in          (gt3_txchardispmode_in), // input wire [3:0] gt3_txchardispmode_in
        .gt3_txchardispval_in           (gt3_txchardispval_in), // input wire [3:0] gt3_txchardispval_in
        .gt3_txcharisk_in               (gt3_txcharisk_in), // input wire [3:0] gt3_txcharisk_in
        //-------------------- Transmit Ports - TX Buffer Ports --------------------
        .gt3_txbufstatus_out            (gt3_txbufstatus_out), // output wire [1:0] gt3_txbufstatus_out
        //------------- Transmit Ports - TX Configurable Driver Ports --------------
        .gt3_gtptxn_out                 (gt3_gtptxn_out), // output wire gt3_gtptxn_out
        .gt3_gtptxp_out                 (gt3_gtptxp_out), // output wire gt3_gtptxp_out
        .gt3_txdiffctrl_in              (gt3_txdiffctrl_in), // input wire [3:0] gt3_txdiffctrl_in
        .gt3_txmaincursor_in            (gt3_txmaincursor_in), // input wire [6:0] gt3_txmaincursor_in
        //--------- Transmit Ports - TX Fabric Clock Output Control Ports ----------
        .gt3_txoutclk_out               (gt3_txoutclk_i), // output wire gt3_txoutclk_i
        .gt3_txoutclkfabric_out         (gt3_txoutclkfabric_out), // output wire gt3_txoutclkfabric_out
        .gt3_txoutclkpcs_out            (gt3_txoutclkpcs_out), // output wire gt3_txoutclkpcs_out
        //----------- Transmit Ports - TX Initialization and Reset Ports -----------
        .gt3_txpcsreset_in              (gt3_txpcsreset_in), // input wire gt3_txpcsreset_in
        .gt3_txpmareset_in              (gt3_txpmareset_in), // input wire gt3_txpmareset_i
        .gt3_txresetdone_out            (gt3_txresetdone_out), // output wire gt3_txresetdone_out
        //--------------- Transmit Ports - TX Polarity Control Ports ---------------
        .gt3_txpolarity_in              (gt3_txpolarity_in), // input wire gt3_txpolarity_in
        //---------------- Transmit Ports - pattern Generator Ports ----------------
        .gt3_txprbssel_in               (gt3_txprbssel_in), // input wire [2:0] gt3_txprbssel_in



   .gt0_pll0reset_out(gt0_pll0reset_i),
    .gt0_pll0outclk_in(gt0_pll0outclk_i),
    .gt0_pll0outrefclk_in(gt0_pll0outrefclk_i),
    .gt0_pll0lock_in(gt0_pll0lock_i),
    .gt0_pll0refclklost_in(gt0_pll0refclklost_i),    
    .gt0_pll1outclk_in(gt0_pll1outclk_i),
    .gt0_pll1outrefclk_in(gt0_pll1outrefclk_i)
    );




 
endmodule
    

