`timescale 1ns / 1ps

//ToDo:
//- add checksum to DDR3 Ram to generate an error signal
//- ther is space for 3 error signals, not used for now
//- currently, when dataHome>=nProteinAtom,  atomNr1 is set to a hypothetical atom 0, which doesn't exist, and whose force field parameters are all set to 0 in MDcontrol.cpp. However, the 
//  complete sequence of  state machines runs, including the DDR3 Ram which might require quite some current. Might want to avoid that, and circumvent all state machines. Need to fire 
//  StoreBendFtot_out and StoreBendFtot_out though, since that is the signal that force calculation is done. Maybe, only circumvent reading DDR3-RAM

//Comments:
//- currently designed for Villin Headpiece, and optimize resources for that. In particular, nCLOSEATOM = 24 (21 are needed for villin). 
//- slowDown mechanism thoroughly tested. Will probably never happen for stretch, and probabyly also not for bend, but for dihedral might be relevant
//  FIFO fifoDihedral needs to be the largest; i.e., depth 512 using a BRAM  to achieve a match with the depth of dataDihedral, since number of dihedrals can be as large as 33.  Use the same for bend and stretch, 
//  even though that is an overkill (maximum number of bends is around 16, so a depth of 256 would be sufficient)  
//- atomNr=0 must not be used, since that is used as stop-criterion for various state machines, and also as the number of a fake-atom when no force calculation is supposed to be done. The
//  corresponding block in the DDR3 Ram must be set to all 0 n MDcontrol.cpp.  


//Structure force field data: 
//---------------------------
//For each protein atom1, the force field data consist of FF_LENGTH=36 lines, each with width DDR3_DATA_WIDTH=256 
//
//line 1: 
//  |atom16|atom15|...|atom2|atom1|                        Atoms within 3 chemical bonds around atomNr1, called closeAtoms in the following. An atom number 0 indicates a stop,  
//  |  16  |  16  |...|  16 |  16 |                        i.e., subsequnt entries are discarded. The information is used (i) to exclude nonbonded interaction and (ii) to transfer
//                                                         their coordinates from the main BRAM (bram_72x8192_simple_dual ProteinAtom) into smaller BRAMS for each force field type
//                                                         (e.g. bram_72x512_simple_dual dataStretch). In each of the 16 16'h-numbers, the lowest nProteinAtom-bits are the atom number
//                                                         while the highest bit indicate whether it is an atom that is listed as [ pair ]. Consequently, 
//                                                         the largest possible nProteinAtom will be 15 (currently set to 12 to save resources).
//line 2: 
//  |checksum|atom31|...|atom17|atom16|                    2nd line of closeAtoms, as above. A maximum of 31 closeAtoms is possible, however, it is restricted to nCLOSEATOM = 21 to 
//  |  16    | 16   |...|  16  |  16  |                    reduce resources in nonbonded pipelines. The last entry is reserved for a checksum (not implemented yet). Later on
//                                                         atoms are indexed by their position in closeAtoms, starting at 1 (since 0 is used as a stop criterion), i.e., also from 
//                                                         that persepctive, 31 is the maximum possible. 
//
//line 3 to  FF_LENGTH:   
//  ||          dihedral (88)                 ||          bend (48)        || stretch (40)  ||
//  || k3  | k2  | k1  |type|atom4|atom3|atom2||type | k  |phi0|atom3|atom2|| k  | r0 |atom2||                 
//  ||6r+18|6r+18|6r+18| 1  |  5  |  5  |  5  ||1+1r | 17 | 17 |1r+5 |1r+5 || 17 | 17 |1r+5 ||  
//                 
//                                                         Force field lines consist of 3 columns for stretch, bend ane dihedral interactions.  atom* no longer is the overall atom number, 
//                                                         but the position in the list of closeAtoms from line1 and 2, starting with 1 (!!!), while atom2=0 indicates a stop. Requires 5bit per atom 
//                                                         STRETCH:
//                                                         r0:    17'h10000 corresponds to 1, positive only, defined relative to r_ref=rcut/8                
//                                                         k:     17'h04000 corresponds to 1, postive only when k is given in kJ/mol, needs to be multiplied with vshift*(10^-6)*dt^2/m_ref 
//                                                         BEND
//                                                         phi0:  range: 0....1 mapping onto 0...180°
//                                                         k:     17'h10000 corresponds to 1/128, positive only, when k is given in kJ/mol/rad^2, needs to be multiplied with vshift*(10^-6)*dt^2/m_ref/rcut^2 
//                                                         type:  1: middle atom, 0: outer atom
//                                                         DIHEDRAL:
//                                                         type:  1: inner atom, 0: outer atom
//                                                         k1-k3: 18'h10000 corresponds to 1/1024, pos/neg, when k is given in kJ/mol, needs to be multiplied with vshift*(10^-6)*dt^2/m_ref/rcut^2
//                                                                (for now, done wastefully, since it will be easier to write it)
//                                                         
//     
//Last line must be zero-line, as that serves as a stop criterion 
                                             
module BondedInteractions
#(
parameter  metaAtomNr_len     = 16,      //length of atom number in meta data; starts at 1. 2bit reserve
parameter  nProteinAtom       = 12,      //defines maximum number of protein atoms: 2^nProteinAtom
parameter  DDR3_DATA_WIDTH    = 256,     //length of a line from  the DDR3 Ram
parameter  FF_LENGTH          = 36,      //Number of lines that defines force field. First 2 lines are for closeAtoms, and then the actually orce field. For the Villin headpiece, 
                                         //largest number of dihedral interactions is 33. Last line needs to be 0, since it is used as a stop criterion. 
parameter  FF_WIDTH           = 6,       //FF_WIDTH = Floor(Log2(FF_LENGTH))+1                                         
parameter  nCLOSEATOM         = 24,      //maximum number of closeAtoms 21 is sufficient for villin headpiece; can be increased to maximum 31 (keep one position free for checksum)    
                                         //ATTENTION: nCLOSEATOM must be <FF_LENGTH, otherwise statemachine state3 would be slower than state2 (there is some reserve)                                      
parameter  CLOSEATOM_WIDTH    = 5        //CLOSEATOM_WIDTH=Floor(Log2(nCLOSEATOM))+1                                                                     
) 
(
 input                                    IOclk,                                                            
 input                                    clk200MHz, //medium claculation speed; can be adaped in clkGeneration
 input                                    sys_clk,   //Needed for DDR3 Ram controller. Is also 200MHz, but use the clk before MMCM;     
 output                                   DDR3clk,
 input                                    MDReset,                   //on IOclk    
 input                                    ResetStart, 
 output [2:0]                             BondInteraction_error,                                     
//input from ReadCommand to write force field data into DDR3 RAM; 
 input                                    ForceField_rcv,
 input [DDR3_DATA_WIDTH - 1:0]            ForceField_data,
 input [nProteinAtom-1:0]                 ForceField_atom,       
//input from BroadcastAtom to write into in BRAM that contains all protein atoms indexed by atom number
 //input                                    nAtomReset,
 input                                    iHalf,                      //iHalf on IOclk
 input      [71+nProteinAtom:0]           dataProteinAtom,            //Protein data to be written in BRAM; on IOclk                                                
 input                                    dataProteinAtom_valid,      //request to write protein data into BRAM; on IOclk                            
//initiate calculation pipeline
 input                                    start_i2,                   //atom1-data ready to write into input FIFO; on IOclk
 input      [metaAtomNr_len-1:0]          dataHome,                   //only atomNr of atom1; coordinates are taken from  bram_72x8192_simple_dual ProteinAtom
 output                                   slowDown,                   //input FIFO almost full, tell master pipeline to slow down, on IOclk
//output of closeAtom, for exclusion in ForceNonBond
 output reg [nCLOSEATOM*nProteinAtom-1:0] closeAtom=1'b0,            //closeAtom data, on DDR3clk 
 output reg [nCLOSEATOM-1:0]              pair14=1'b0,               //close atoms that are in pair list, used to calculated fudged nonbonded forces
 output reg                               closeAtom_rcv=1'b0,        //closeAtom valid, on DDR3clk  
//output of stretch calculation
 input                                    fifoAllForcesOut,          //trigger output FIFO to send data, used for all forces (stretch, bend and dihedral forces)
 output                                   forceStretchReady,         //force stretch calculation done,
 output     [95:0]                        forceStretchFifo,           //calculated forces,  read out with fifoAllForcesOut,  
//output of bend calculation
 output                                   forceBendReady,             //force bend calculation done,
 output     [95:0]                        forceBendFifo,              //calculated forces, , read out with fifoAllForcesOut,  
//output of dihedral calculation
 output                                   forceDihedReady,            //force dihedral calculation done, 
 output     [95:0]                        forceDihedFifo,             //calculated forces,  read out with fifoAllForcesOut,  
//DDR3-pins; comment out when using reduced BRAM version of mem_burst
 inout  [31:0]                            ddr3_dq,                    //ddr3 data
 inout  [3:0]                             ddr3_dqs_n,                 //ddr3 dqs negative
 inout  [3:0]                             ddr3_dqs_p,                 //ddr3 dqs positive
 output [14:0]                            ddr3_addr,                  //ddr3 address
 output [2:0]                             ddr3_ba,                    //ddr3 bank
 output                                   ddr3_ras_n,                 //ddr3 ras_n
 output                                   ddr3_cas_n,                 //ddr3 cas_n
 output                                   ddr3_we_n,                  //ddr3 write enable 
 output                                   ddr3_reset_n,               //ddr3 reset,
 output [0:0]                             ddr3_ck_p,                  //ddr3 clock negative
 output [0:0]                             ddr3_ck_n,                  //ddr3 clock positive
 output [0:0]                             ddr3_cke,                   //ddr3_cke,
 output [0:0]                             ddr3_cs_n,                  //ddr3 chip select,
 output [3:0]                             ddr3_dm,                    //ddr3_dm
 output [0:0]                             ddr3_odt                    //ddr3_odt
);


localparam DDR3_ADDR_WIDTH  = 29;    //address width of DDR3 Ram

//position of force field paramater in force field line
localparam pos_atom2Stretch = 0;         
localparam pos_r0Stretch    = 6;                     
localparam pos_kStretch     = 23;    
localparam pos_atom2Bend    = 40;
localparam pos_atom3Bend    = 46;
localparam pos_phi0Bend     = 52;
localparam pos_kBend        = 69;
localparam pos_BendType     = 87;      
localparam pos_atom2Dihed   = 88;
localparam pos_atom3Dihed   = 93; 
localparam pos_atom4Dihed   = 98; 
localparam pos_DihedType    = 103;  
localparam pos_k1Dihed      = 104;  
localparam pos_k2Dihed      = 128;  
localparam pos_k3Dihed      = 152;  


integer                   i; 
    

//*****************************************************************************************************************************
  wire                          ForceField_ready;
  reg [1:0]                     stateDDR3=1'b0;
  reg                           DDR3_wr_burst_req=1'b0;
  wire                          DDR3_wr_burst_data_req;
  wire                          DDR3_wr_burst_finish;
  wire [DDR3_DATA_WIDTH - 1:0]  DDR3_wr_burst_data;
  wire [DDR3_DATA_WIDTH - 1:0]  DDR3_rd_burst_data;
  reg                           DDR3_rd_burst_req=1'b0;
  wire                          DDR3_rd_burst_finish;
  reg  [nProteinAtom-1:0]       atomNr1 = 1'b0, atomNr1_d0 = 1'b0; 
  reg                           error2=1'b0;
  reg                           error3=1'b0;
  reg                           error1=1'b0;
  wire                          ForceField_empty;
  reg  [3:0]                    waitcnt=1'b0;
  
//FIFO that receives force field data from ReadCommand, and will be sent as burst to DDR3 Ram. 
//ForceField_ready is a signal that says one full block of FF_LENGTH lines is received. 
//Width needs to match DDR3_DATA_WIDTH  

  
  FIFO_async 
  #(
   .WIDTH(256),
   .DEPTH(64),
   .PROG_FULL_THRESH(FF_LENGTH)
  ) ForceField 
 (
    .rst(1'b0),
    .wr_clk(IOclk),                             
    .din(ForceField_data),      
    .wr_en(ForceField_rcv),  
    .rd_clk(DDR3clk),
    .rd_en(DDR3_wr_burst_data_req),         
    .dout(DDR3_wr_burst_data),          
    .full(),                                    
    .empty(ForceField_empty),    
    .prog_full(ForceField_ready)
  );


wire [nProteinAtom-1:0] ForceField_atom_d0;
reg  [nProteinAtom-1:0] ForceField_atom_d1=1'b0;
ClkTransferStat #(.Width (nProteinAtom))  ClkTransferStat2  
(
    .clkIn   (IOclk),
    .clkOut  (DDR3clk),
    .sigIn   (ForceField_atom),
    .sigOut  (ForceField_atom_d0)
); 

wire ForceField_ready_d0;
ClkTransferStat #(.Width (1))  ClkTransferStat3  
(
    .clkIn   (IOclk),
    .clkOut  (DDR3clk),
    .sigIn   (ForceField_ready),
    .sigOut  (ForceField_ready_d0)
);

//state machine that starts when ForceField_ready=1'b1 and initiates writing into DDR3 Ram as a bunch
  always @(posedge DDR3clk) begin
    case(stateDDR3)
      0: begin
        if(ForceField_ready_d0) begin
          ForceField_atom_d1 <= ForceField_atom_d0;
          DDR3_wr_burst_req  <= 1'b1;
          stateDDR3          <= stateDDR3+1'b1;
        end  
      end
      1: begin
        if(DDR3_wr_burst_finish) begin
          DDR3_wr_burst_req <= 1'b0;
          waitcnt           <= 1'b0;
          stateDDR3         <= stateDDR3 + 1'b1;
        end
      end
      2: begin
       waitcnt <= waitcnt + 1'b1;
       if(waitcnt==4'hf) begin
         stateDDR3 <= 1'b0;
       end  
      end
    endcase
  end  
  
//********************************************************************************************
//DDR3 Ram interface; DDR* Ram stores all force field data 
wire ResetStart_d0;
ClkTransferStat #(.Width (1))  ClkTransferStat6  
(
    .clkIn   (IOclk),
    .clkOut  (sys_clk),
    .sigIn   (ResetStart),
    .sigOut  (ResetStart_d0)
);


  mem_burst
  #(
   .MEM_DATA_WIDTH  (DDR3_DATA_WIDTH),
   .MEM_ADDR_WIDTH  (DDR3_ADDR_WIDTH),
   .BURST_LENGTH    (FF_LENGTH),                                    //number of lines written and read in a burst
   .BURST_WIDTH     (FF_WIDTH)                                     //BURST_WIDTH = Floor(Log2(BURST_LENGTH))+1 
   ) mem_burst
   (
   .sys_rst               (~ResetStart_d0),                          //system reset, is active-low!
   .sys_clk               (sys_clk),                                 //system clock; is 200MHz, but use clock before MMCM
   .mem_clk               (DDR3clk),                                 //mem clock, generated by DDR3 logic
   .mem_rst               (mem_rst),                                 //output, not used, probably says that there has been a reset
//Memory write/read signals
   .rd_burst_req          (DDR3_rd_burst_req),                       //read burst request, must be 1 until rd_burst_finish
   .wr_burst_req          (DDR3_wr_burst_req),                       //write burst request, must be 1 until wr_burst_finish
   .rd_burst_addr         ({{DDR3_ADDR_WIDTH-3-nProteinAtom-FF_WIDTH{1'b0}},atomNr1,           {FF_WIDTH{1'b0}}}),   //read burst address; 
   .wr_burst_addr         ({{DDR3_ADDR_WIDTH-3-nProteinAtom-FF_WIDTH{1'b0}},ForceField_atom_d1,{FF_WIDTH{1'b0}}}),   //write burst address
   .rd_burst_data_valid   (DDR3_rd_burst_data_valid),                //read burst data valid
   .wr_burst_data_req     (DDR3_wr_burst_data_req),                  //write burst data request, wr_burst_data  must be valid at the next cycle
   .rd_burst_data         (DDR3_rd_burst_data),                      //read burst data, valid at the same time as rd_burst_data_valid
   .wr_burst_data         (DDR3_wr_burst_data),                      //write burst data
   .rd_burst_finish       (DDR3_rd_burst_finish),                    //read burst finish flag
   .wr_burst_finish       (DDR3_wr_burst_finish),                    //write burst finish flag
//DDR3-pins; need to be carried up to MD.v; comment out when using reduced BRAM version
   .ddr3_dq               (ddr3_dq),                                 //ddr3 data
   .ddr3_dqs_n            (ddr3_dqs_n),                              //ddr3 dqs negative
   .ddr3_dqs_p            (ddr3_dqs_p),                              //ddr3 dqs positive
   .ddr3_addr             (ddr3_addr),                               //ddr3 address
   .ddr3_ba               (ddr3_ba),                                 //ddr3 bank
   .ddr3_ras_n            (ddr3_ras_n),                              //ddr3 ras_n
   .ddr3_cas_n            (ddr3_cas_n),                              //ddr3 cas_n
   .ddr3_we_n             (ddr3_we_n),                               //ddr3 write enable 
   .ddr3_reset_n          (ddr3_reset_n),                            //ddr3 reset,
   .ddr3_ck_p             (ddr3_ck_p),                               //ddr3 clock negative            
   .ddr3_ck_n             (ddr3_ck_n),                               //ddr3 clock positive
   .ddr3_cke              (ddr3_cke),                                //ddr3_cke,
   .ddr3_cs_n             (ddr3_cs_n),                               //ddr3 chip select,
   .ddr3_dm               (ddr3_dm),                                 //ddr3_dm
   .ddr3_odt              (ddr3_odt)                                 //ddr3_odt
   ); 
  
//************************************************************************************************************************  
//memory containing all protein atoms in home box as well as in all neigboring boxes, indexed by atom number. Address range of BRAM needs to be nProteinAtom+1;   
   
  wire [nProteinAtom-1:0] proteinAtomNr    = dataProteinAtom[71+nProteinAtom:72];
  wire [71:0]             proteinAtomCoord = dataProteinAtom[71:0];
  wire [71:0]             atomData2;
  wire                    iHalf_DDR3clk;
 
//for reduced BRAM version 
//  bram_72x1024_simple_dual ProteinAtom (.clka(IOclk),.ena(1'b1),.wea(dataProteinAtom_valid) ,.addra({iHalf,proteinAtomNr}),.dina(proteinAtomCoord),.clkb(DDR3clk),.enb(1'b1),.addrb({~iHalf_DDR3clk,closeAtom_d0[nProteinAtom-1:0]}),.doutb(atomData2));
  reg [(nCLOSEATOM+1)*nProteinAtom-1:0] closeAtom_d0=1'b0;
  bram_72x8192_simple_dual ProteinAtom (.clka(IOclk),.ena(1'b1),.wea(dataProteinAtom_valid) ,.addra({iHalf,proteinAtomNr}),.dina(proteinAtomCoord),.clkb(DDR3clk),.enb(1'b1),.addrb({~iHalf_DDR3clk,closeAtom_d0[nProteinAtom-1:0]}),.doutb(atomData2));
 

//************************************************************************************************************************  
//input FIFO with atom1 from MD machine; atom1Ready says data are received, which initiates claculation. Also has an almost-full option, that will tell the master-pipeline in MDmachine to slow down. 
  wire  [metaAtomNr_len-1:0] dataHomeFifo;
  wire                       atom1Ready;
  reg                        fifoDataOut=1'b0; 

    
  FIFO_async 
  #(
   .WIDTH(metaAtomNr_len),
   .DEPTH(64),
   .PROG_FULL_THRESH(55)
  ) atomData 
  ( 
    .rst(1'b0),
    .wr_clk(IOclk),                             
    .din(dataHome),           //only atomNr of atom1; coordinates are taken from  bram_72x8192_simple_dual ProteinAtom
    .wr_en(start_i2),  
    .rd_clk(DDR3clk),
    .rd_en(fifoDataOut),         
    .dout(dataHomeFifo),          
    .full(),    
    .empty(atom1Ready),       
    .prog_full(slowDown)      //sent upwards to slow down master-pipeline in MDmachine
    );  

//******************************************************************************************************************
//state machines state1 and state2, which initiate reading force field for atom1 from DDR3 ram. They are staggered to account for the large read latency of the DDR3 Ram. 
//State2 also initiates state machine state3, which stores coordinates of all neigboring atoms in dataStretch, databend and dataDihedral, while state2
//stores atomNr's and force field parameters into fifoStretch, fifoBend and fifoDihedral. Here, AtomNr now longer is the real one, but the address of dataStretch, databend and dataDihedral
  reg   [2:0]   state1=1'b0;
  reg           state1_busy=1'b0; 
  reg           fifoStretchIn=1'b0;
  reg           fifoBendIn   =1'b0;
  reg           fifoDihedIn   =1'b0;
  wire          MDReset_DDR3clk;
  reg           state2_busy=1'b0; 
  reg           state2_busy2=1'b0; 
  
  
  wire                      slowDownS1,slowDownS2_d0;
  wire                      slowDownB1,slowDownB2_d0;
  wire                      slowDownD1,slowDownD2_d0;
  always @(posedge DDR3clk) begin
    if(MDReset_DDR3clk) begin
      state1      <= 1'b0;
      state1_busy <= 1'b0;
    end else begin
      case (state1)
        0: begin
          if((~atom1Ready)&&(~(slowDownS1||slowDownS2_d0||slowDownB1||slowDownB2_d0||slowDownD1||slowDownD2_d0))) begin
            state1_busy  <= 1'b1;
            fifoDataOut  <= 1'b1;
            state1       <= state1 + 1'b1;
          end
        end  
        1: begin                     //wait for latency of FIFO
          fifoDataOut    <= 1'b0;
          state1         <= state1 + 1'b1;
        end    
        2: begin                     //atom 1 data ready
          atomNr1            <= (dataHomeFifo[metaAtomNr_len-1:nProteinAtom]==1'b0) ? dataHomeFifo[nProteinAtom-1:0] : 1'b0;   //if dataHomeFifo<nProteinAtom continue with it, otherwise set 
          DDR3_rd_burst_req  <= 1'b1;                                                                                          //to hypothetical atomNr1=0, which doesn't interact with any other atom
          state1             <= state1 + 1'b1;
        end  
 //initiate reading DDR3 ram
        3: begin
          DDR3_rd_burst_req  <= 1'b1;
          state1             <= state1 + 1'b1;
        end
        4: begin
          if(DDR3_rd_burst_finish) begin
            DDR3_rd_burst_req      <= 1'b0;
            state1_busy            <= 1'b0;
            if(state2_busy) state1 <= 1'b0;               //state2 started already
            else            state1 <= state1 + 1'b1;
          end
        end
        5: begin
          if(state2_busy) state1 <= 1'b0;               //wait until state2 starts
        end
      endcase  
    end
  end  
 
  
  reg [CLOSEATOM_WIDTH-1:0]         atom2Stretch  = 1'b0;               
  reg [16:0]                        r0Stretch     = 1'b0;                     
  reg [16:0]                        kStretch      = 1'b0;   
  reg [CLOSEATOM_WIDTH-1:0]         atom2Bend     = 1'b0;  
  reg [CLOSEATOM_WIDTH-1:0]         atom3Bend     = 1'b0;               
  reg [16:0]                        phi0Bend      = 1'b0;                     
  reg [16:0]                        kBend         = 1'b0;   
  reg                               BendType      = 1'b0;    
  reg [CLOSEATOM_WIDTH-1:0]         atom2Dihed    = 1'b0;  
  reg [CLOSEATOM_WIDTH-1:0]         atom3Dihed    = 1'b0;               
  reg [CLOSEATOM_WIDTH-1:0]         atom4Dihed    = 1'b0;             
  reg [17:0]                        k1Dihed       = 1'b0; 
  reg [17:0]                        k2Dihed       = 1'b0; 
  reg [17:0]                        k3Dihed       = 1'b0;   
  reg                               DihedType     = 1'b0;                 
  reg [FF_WIDTH-1:0]                state2=1'b0; 
  reg                               stretch_done =1'b0;
  reg                               bend_done    =1'b0;
  reg                               dihed_done   =1'b0;
  
  always @(posedge DDR3clk) begin                 //state machine 2 
    if(MDReset_DDR3clk) begin
      state2       <= 1'b0;
      state2_busy  <= 1'b0;    //for handshake with state1
      state2_busy2 <= 1'b0;    //to determine when to start force claculations
    end else begin
      closeAtom_rcv  <= 1'b0;
      fifoStretchIn  <= 1'b0;
      fifoBendIn     <= 1'b0;
      fifoDihedIn     <= 1'b0;
      if(DDR3_rd_burst_data_valid) begin
        case (state2)
          0: begin                                                                    //first line of closeAtoms
            stretch_done <= 1'b0;
            bend_done    <= 1'b0;
            dihed_done   <= 1'b0;
            for(i=0;i<DDR3_DATA_WIDTH/16;i=i+1) begin           
              closeAtom[i*nProteinAtom+:nProteinAtom] <= DDR3_rd_burst_data[i*16+:nProteinAtom];         //closeAtom data are stored as 16bit numbers in  DDR3_rd_burst_data, and compresssed to nProteinAtom in closeAtom  
              pair14[i]                               <= DDR3_rd_burst_data[i*16+15];                    //close atoms that are in pair list, used to calculated fudged nonbonded forces                                                                                  
            end 
            atomNr1_d0   <= atomNr1;
            if(state1_busy) begin
              state2  <= state2 + 1'b1;                                       //start only when DDR3_rd_burst_data_valid is initiated from state1. Introduced to supress events in initialisation of DDR3 Ram which fires 
              state2_busy  <= 1'b1;                                           //DDR3_rd_burst_data_valid (at some point, thought that is is happening but probably not correct)
              state2_busy2 <= 1'b1; 
            end  
          end 
          1: begin                                                            //read 2nd line of close atoms
            for(i=DDR3_DATA_WIDTH/16;i<nCLOSEATOM;i=i+1) begin
              closeAtom[i*nProteinAtom+:nProteinAtom] <= DDR3_rd_burst_data[(i-DDR3_DATA_WIDTH/16)*16+:nProteinAtom];    //closeAtom data are stored as 16bit numbers in  DDR3_rd_burst_data, and compresssed to nProteinAtom in closeAtom                                                                                                      
              pair14[i]                               <= DDR3_rd_burst_data[(i-DDR3_DATA_WIDTH/16)*16+15];               //close atoms that are in pair list, used to calculated fudged nonbonded forces    
            end
            closeAtom_rcv <= 1'b1;
            state2 <= state2 + 1'b1;
          end
          default: begin                                                                      //beyond DDR3_rd_cnt>=2'h2, DDR3_rd_burst_data is split into pieces and written into written FIFO_40x64 fifoStretch, fifoBend, etc.
//part the contains force field parameter for stretch 
            if((DDR3_rd_burst_data[pos_atom2Stretch+:CLOSEATOM_WIDTH]==1'b0)||(state2==FF_LENGTH-1)) begin 
              stretch_done <= 1'b1; 
            end                                                        
            fifoStretchIn <= ~stretch_done;       
            atom2Stretch  <= DDR3_rd_burst_data[pos_atom2Stretch+:CLOSEATOM_WIDTH];        //one reserve bit discarded here              
            r0Stretch     <= DDR3_rd_burst_data[pos_r0Stretch+:17];                     
            kStretch      <= DDR3_rd_burst_data[pos_kStretch+:17];   
//part the contains force field parameter for bend            
            if((DDR3_rd_burst_data[pos_atom2Bend+:CLOSEATOM_WIDTH]==1'b0)||(state2==FF_LENGTH-1)) begin 
              bend_done   <= 1'b1; 
            end   
            fifoBendIn    <= ~bend_done;  
            atom2Bend     <= DDR3_rd_burst_data[pos_atom2Bend+:CLOSEATOM_WIDTH];        //one reserve bit discarded here          
            atom3Bend     <= DDR3_rd_burst_data[pos_atom3Bend+:CLOSEATOM_WIDTH];        //one reserve bit discarded here                
            phi0Bend      <= DDR3_rd_burst_data[pos_phi0Bend+:17];                     
            kBend         <= DDR3_rd_burst_data[pos_kBend+:17];        
            BendType      <= DDR3_rd_burst_data[pos_BendType];        
//part the contains force field parameter for dihedrals           
            if((DDR3_rd_burst_data[pos_atom2Dihed+:CLOSEATOM_WIDTH]==1'b0)||(state2==FF_LENGTH-1)) begin 
//            if((state2==FF_LENGTH-3)) begin 
              dihed_done   <= 1'b1; 
            end   
            fifoDihedIn    <= ~dihed_done;   
            atom2Dihed     <= DDR3_rd_burst_data[pos_atom2Dihed+:CLOSEATOM_WIDTH];        //one reserve bit discarded here
            atom3Dihed     <= DDR3_rd_burst_data[pos_atom3Dihed+:CLOSEATOM_WIDTH];        //one reserve bit discarded here
            atom4Dihed     <= DDR3_rd_burst_data[pos_atom4Dihed+:CLOSEATOM_WIDTH];        //one reserve bit discarded here  
            k1Dihed        <= DDR3_rd_burst_data[pos_k1Dihed+:18];   
            k2Dihed        <= DDR3_rd_burst_data[pos_k2Dihed+:18];   
            k3Dihed        <= DDR3_rd_burst_data[pos_k3Dihed+:18];   
            DihedType      <= DDR3_rd_burst_data[pos_DihedType];           
//done reading force field data                                                                 
            if (state2==FF_LENGTH-1) begin
              state2         <= 1'b0;
              state2_busy    <= 1'b0;                                  //busy signal for handshake with state1
              state2_busy2   <= 1'b0;
            end else begin
              state2 <= state2 + 1'b1;    
              if(bend_done&&stretch_done&&dihed_done) state2_busy2 <= 1'b0;       //all force field data received and ready to initiate force calculation       
            end  
          end 
        endcase
      end
    end
  end
  
 //statemachine state3, that writes atom data of all closeAtom into ram_72x64 dataStretch, databend and dataDihedral. These memories are identical, but copies from each other so that they can be read in parallel 
 //by the different force pipelines. Atoms are then no longer indexed by atomNr, but by their appearance in closeAtom. Smallest address is 1, while address0 in ram_72x64 dataStretch contains (x1,y1,z1)
 //ATTENTION: state machine state3 must be faster than state1 and state2, which is equivalent to nCLOSEATOM<FF_LENGTH
 
  reg [1:0]                 state3   = 1'b0;
  reg [CLOSEATOM_WIDTH-1:0] adrData2_d0 = 1'b0,adrData2_d1 = 1'b0,adrData2 = 1'b0;
  reg                       wrData2_d0=1'b0,wrData2_d1=1'b0,wrData2=1'b0;        
  reg [4:0]                 cntData2_in=1'b0;
  reg                       state3_busy=1'b0,state23_busy=1'b0,state23_busy_d0=1'b0,state23_busy_d1=1'b0,state23_busy_d2=1'b0; 
       
  always @(posedge DDR3clk) begin
    wrData2        <= wrData2_d0;      //delay to account for the latency of bram ProteinAtom
    wrData2_d0     <= wrData2_d1;
    adrData2       <= adrData2_d0;
    adrData2_d0    <= adrData2_d1;
 //   error3         <= 1'b0;
    
    state23_busy <= state2_busy2|state3_busy;                        
    state23_busy_d0 <= state23_busy;
    state23_busy_d1 <= state23_busy_d0;
    state23_busy_d2 <= state23_busy_d1;                              
    if((~state23_busy_d1)&&state23_busy_d2) begin
      cntData2_in  <= cntData2_in + 1'b1;
    end
    
    case (state3)
      0: begin
        adrData2_d1    <= 1'b0;
        if(closeAtom_rcv) begin
          state3_busy  <= 1'b1;
          closeAtom_d0 <= atomNr1_d0;       //first entry is home atom
          state3       <= state3 + 1'b1;
          wrData2_d1   <= 1'b1;
        end
      end 
      1: begin
        adrData2_d1    <= adrData2_d1 + 1'b1;
        closeAtom_d0 <= {{nProteinAtom{1'b0}},closeAtom};                                 //from here on, is close atoms; closeAtom_d0 is one larger than closeAtom with a leading 0, thagt acts as a stop criterion
  //      if(atomNr1_d0!={closeAtom[nProteinAtom-1:1],~closeAtom[0]}) error3 <= 1'b1;     //that is specific for dimer; will disappear
        state3       <= state3 + 1'b1;
      end
      2: begin
        adrData2_d1    <= adrData2_d1 + 1'b1;
        closeAtom_d0   <= closeAtom_d0>>nProteinAtom;
        if ((adrData2_d1==nCLOSEATOM)||(closeAtom_d0[nProteinAtom+:nProteinAtom]==1'b0)) begin      //written all close atom; nProteinAtom-1:0]==1'b0 
          wrData2_d1   <= 1'b0;
          state3       <= 1'b0;
          state3_busy  <= 1'b0;
        end  
      end 
    endcase
  end      

wire [4:0]  cntData2_in_d0;
reg  [4:0]  cntData2_in_d1;
reg  [4:0]  cntData2_in_d2;
ClkTransferStat #(.Width (5))  ClkTransferStat4  
(
    .clkIn   (DDR3clk),
    .clkOut  (clk200MHz),
    .sigIn   (cntData2_in),
    .sigOut  (cntData2_in_d0)
); 

always @(posedge clk200MHz) begin
  cntData2_in_d1 <= cntData2_in_d0;
  cntData2_in_d2 <= cntData2_in_d1;
end

  
//************************************************************************************************************************************** 
//                                                 Stretch Interactions                                                                *
//**************************************************************************************************************************************
//memory that contains the coordinates of all neigboring atoms with which bonded interactions may occur, i.e. up to 3 bonds away.  Position 0 contains (x1,y1,z1)
//CLOSEATOM_WIDTH+4 must equal size of Ram (i.e., Log2(512))
 wire [71:0]                atomStretchData2; 
 reg  [CLOSEATOM_WIDTH-1:0] adrStretchData2_out=1'b0;
 reg  [4:0]                 cntStretchData2_out=1'b0;
 
 reg                        rdStretchEn1=1'b0, rdStretchEn2=1'b0;   //all the subseqtent is new
 wire                       rdStretchEn_d0=rdStretchEn1||rdStretchEn2;
 reg                        rdStretchEn_d1,rdStretchEn_d2; 
 wire                       rdStretchEn=rdStretchEn_d0||rdStretchEn_d1||rdStretchEn_d2;    //extend by two cycles, probably extend by 1 cycle would be correct
 always @(posedge clk200MHz) begin
   rdStretchEn_d1 <= rdStretchEn_d0;
   rdStretchEn_d2 <= rdStretchEn_d1;
 end
 
 bram_72x512_simple_dual dataStretch 
  (
    .clka(DDR3clk),
    .ena(1'b1),
    .wea(wrData2) ,
    .addra({cntData2_in[3:0],adrData2}),              //upper 4 bits make it a circular buffer (de fact a FIFO) with 16 sites
    .dina(atomData2),
    .clkb(clk200MHz),
    .enb(rdStretchEn),                                  //is new
    .addrb({cntStretchData2_out[3:0],adrStretchData2_out}),
    .doutb(atomStretchData2)
  );


//FIFO that contains force field paramaters, as well as atom with which intercations occurs. Lowest allowed atomNr is 1, while 0 indicates to stop the calculation.
//Generates an slowDown signal for state1 when more that 450 entries are in FIFO, which probably wil never happen for stretch. Limiting aspect is bram_72x512_simple_dual dataStretch
//which generates a second slow down when 14 atoms are in it.    Done that way to be consistent with Bend and dihedrals
wire [38:0]                 paramStretchFifo;
wire [CLOSEATOM_WIDTH-1:0]  atomNrStretchFifo = paramStretchFifo[0+:CLOSEATOM_WIDTH];                    
reg  [16:0]                 r0StretchFifo     = 1'b0;     
reg  [16:0]                 kStretchFifo      = 1'b0; 
wire                        fifoStretch_empty;
reg                         fifoStretchOut=1'b0;


 FIFO_async 
  #(
   .WIDTH(39),
   .DEPTH(512),                       
   .PROG_FULL_THRESH(450)
  ) fifoStretch 
 (
  .rst(1'b0),
  .wr_clk(DDR3clk),                            
  .din({kStretch,r0Stretch,atom2Stretch}),       //first 40 bits of DDR3_rd_burst_data contian stretch parameters: {kstretch,r0stretch,atom2Stretch}; one reserve bit is discarded
  .wr_en(fifoStretchIn),  
  .rd_clk(clk200MHz),
  .rd_en(fifoStretchOut),         
  .dout(paramStretchFifo),       
  .full(),    
  .empty(fifoStretch_empty),   
  .prog_full(slowDownS1)                          
 );
 
 
//state machine stateStretch that initiates stretch force calculation 
  wire                           MDReset_clk200MHz;
  reg  signed [23:0]             x1stretch = 1'b0, y1stretch=1'b0, z1stretch=1'b0;
  wire signed [23:0]             x2stretch = atomStretchData2[24*0 +:24];  //when used in simulator, with 1 node only, use "atomStretchData2[24*0 +:24]&24'h3fffff", otherwise, information in BRAM will be that of some neigboring box 
  wire signed [23:0]             y2stretch = atomStretchData2[24*1 +:24];
  wire signed [23:0]             z2stretch = atomStretchData2[24*2 +:24];
  reg         [3:0]              stateStretch=1'b0;
  reg  signed [23:0]             dxstretch = 1'b0, dystretch=1'b0, dzstretch=1'b0;
  reg                            AddStretchFtot=1'b0,StoreStretchFtot=1'b0;
  reg         [4:0]              pipeStretch;
  reg                            stateStretch_done=1'b0;
  wire signed [4:0]              cntStretchData2_diff =   cntData2_in_d2-cntStretchData2_out;
  reg                            slowDownS2 = 1'b0;
  reg         [FF_WIDTH-1:0]     stateStretchCnt=0;                   

  always @(posedge clk200MHz) begin
    pipeStretch <= {pipeStretch[3:0], fifoStretchOut};
    if(MDReset_clk200MHz) begin
      stateStretch          <= 1'b0;
      slowDownS2            <= 1'b0;
    end else begin
      case (stateStretch)      
        0: begin
          stateStretch_done  <= 1'b0;
          StoreStretchFtot   <= 1'b0; 
          stateStretchCnt    <= 1'b0;
          if(cntStretchData2_out!=cntData2_in_d2) begin 
            stateStretch     <= stateStretch + 1'b1;
            rdStretchEn1     <= 1'b1;                       //is new
          end  
        end
        1: begin 
          rdStretchEn1          <= 1'b0;                       //is new
          fifoStretchOut        <= 1'b1;
          stateStretch          <= stateStretch + 1'b1;
        end
        2: begin
          fifoStretchOut     <= 1'b0;
          stateStretch       <= stateStretch + 1'b1;                     //wait for latency FIFO and BRAM; 
        end  
        3: begin
          x1stretch            <= atomStretchData2[24*0 +:24];  
          y1stretch            <= atomStretchData2[24*1 +:24];  
          z1stretch            <= atomStretchData2[24*2 +:24]; 
          if(atomNrStretchFifo==0) begin                                 //stop
            stateStretch       <= 10;
          end else begin 
            stateStretch       <= stateStretch + 1'b1;                                   
          end  
        end  
        4: begin 
          stateStretchCnt       <= stateStretchCnt +1'b1;
          fifoStretchOut        <= 1'b1;
          stateStretch          <= stateStretch + 1'b1;
        end
        5: begin
          fifoStretchOut     <= 1'b0;
          stateStretch       <= stateStretch + 1'b1;                     //wait for latency FIFO; 
        end  
        6: begin
          if((atomNrStretchFifo==0)||(stateStretchCnt>=FF_LENGTH-3)) begin   //stop criterion; either atom2=0 found, or maximum length exceeded 
            stateStretch       <= 10;                                     //loop until stop criterion
          end else begin 
            stateStretch       <= 4;                                     
          end  
        end  
        10: begin                                                   //done
          stateStretch           <= stateStretch + 1'b1; 
          stateStretch_done      <= 1'b1;
        end
        11: begin                     
          cntStretchData2_out    <= cntStretchData2_out + 1'b1;
          if(cntStretchData2_diff>=5'sd13)       slowDownS2 <= 1'b1;        //slow down state1 when close to full, i.e. only two spots left in  bram_72x512_simple_dual dataStretch 
          else if (cntStretchData2_diff<=5'sd12) slowDownS2 <= 1'b0;        //ractivate with hysteresiss                              
          StoreStretchFtot   <= 1'b1; 
          stateStretch       <= 0;  
        end
      endcase
    end
  end         
 
 //pipeline initiated by  stateStretch that reads bram_72x512_simple_dual dataStretch  and iniziates force calculation
  always @(posedge clk200MHz) begin
    if(pipeStretch[1]) begin  
        if(atomNrStretchFifo!=1'b0) begin                    //is new; suppress read for the last line, where atomNrStretchFifo==1'b0, which is the stop criterion
          adrStretchData2_out  <= atomNrStretchFifo;
          rdStretchEn2         <= 1'b1;                     
        end else begin
          adrStretchData2_out  <= 1'b0;
          rdStretchEn2         <= 1'b0; 
        end  
    end else begin
      adrStretchData2_out  <= 1'b0;
      rdStretchEn2         <= 1'b0; 
    end    
    if(pipeStretch[2]) begin
       r0StretchFifo      <= paramStretchFifo[CLOSEATOM_WIDTH+:17];     
       kStretchFifo       <= paramStretchFifo[(CLOSEATOM_WIDTH+17)+:17]; 
    end
    if(pipeStretch[4]) begin
       dxstretch          <= x2stretch-x1stretch;  //enters into ForceStretch
       dystretch          <= y2stretch-y1stretch;  
       dzstretch          <= z2stretch-z1stretch;
       AddStretchFtot     <= ~stateStretch_done;   //to supress last atom2, which is 0 and as such a stop criterion  
    end else begin
       AddStretchFtot     <= 1'b0;
    end
  end
  
ClkTransferStat #(.Width (1))  ClkTransferStat5  
(
    .clkIn   (clk200MHz),
    .clkOut  (DDR3clk),
    .sigIn   (slowDownS2),
    .sigOut  (slowDownS2_d0)
); 


//******************************************************************************************************  
//actual stretch Force calculation                                                    
wire signed [31:0]    FxStretch_tot, FyStretch_tot, FzStretch_tot;  
ForceStretch  ForceStretch
(     
.clk           (clk200MHz),   
.MDReset       (MDReset_clk200MHz),              
.AddFtot       (AddStretchFtot), 
.ready         (),                        //not used. accepts data only every 3rd clock cycle, but stateStretch has that build in
.StoreFtot     (StoreStretchFtot),
.StoreFtot_out (StoreStretchFtot_out), 
.dx            (dxstretch),
.dy            (dystretch),
.dz            (dzstretch),
.r0            (r0StretchFifo),  
.k             (kStretchFifo),    
.Fx_tot        (FxStretch_tot),
.Fy_tot        (FyStretch_tot), 
.Fz_tot        (FzStretch_tot)
);  



FIFO_sync   
  #(
   .WIDTH(96),
   .DEPTH(64)
  ) FIFOForceStretch 
 (
  .rst(1'b0),
  .clk(clk200MHz),                
  .din({FzStretch_tot,FyStretch_tot,FxStretch_tot}),      
  .wr_en(StoreStretchFtot_out),     
  .rd_en(fifoAllForcesOut),  
  .dout(forceStretchFifo),    
  .full(),            //should never become full due to slowDown logic
  .prog_full(),
  .empty(forceStretchReady)  
);
  

//************************************************************************************************************************************** 
//                                                 Bend Interactions                                                                   *
//**************************************************************************************************************************************
//memory that contains the coordinates of all neigboring atoms with which bonded interactions may occur, i.e. up to 3 bonds away.  Position 0 contains (x1,y1,z1)
//CLOSEATOM_WIDTH+4 must equal size of Ram (i.e., Log2(512))
 wire [71:0]                atomBendData2; 
 reg  [CLOSEATOM_WIDTH-1:0] adrBendData2_out=1'b0;
 reg  [4:0]                 cntBendData2_out=1'b0;
 
 reg                        rdBendEn1=1'b0, rdBendEn2=1'b0;   //all the subseqtent is new
 wire                       rdBendEn_d0=rdBendEn1||rdBendEn2;
 reg                        rdBendEn_d1,rdBendEn_d2; 
 wire                       rdBendEn=rdBendEn_d0||rdBendEn_d1||rdBendEn_d2;    //extend by two cycles, probably extend by 1 cycle would be correct
 always @(posedge clk200MHz) begin
   rdBendEn_d1 <= rdBendEn_d0;
   rdBendEn_d2 <= rdBendEn_d1;
 end
 
 bram_72x512_simple_dual dataBend 
  (
    .clka(DDR3clk),
    .ena(1'b1),
    .wea(wrData2) ,
    .addra({cntData2_in[3:0],adrData2}),              //upper 4 bits make it a circular buffer (de fact a FIFO) with 16 sites
    .dina(atomData2),
    .clkb(clk200MHz),
    .enb(rdBendEn),                                      //is new
    .addrb({cntBendData2_out[3:0],adrBendData2_out}),
    .doutb(atomBendData2)
  );


//FIFO that contains force field paramaters, as well as atoms with which bend intercations occurs. Lowest allowed atomNr is 1, while 0 indicates to stop the calculation.
//Generates an slowDown signal for state1 when more that 450 entries are in FIFO. Uses BRAM for FIFO. Each atom has maximum around 16 bond interactions, so depth of FIFO  
//is a overkill, since bram_72x512_simple_dual dataBend  will run full earlier. bram_72x512_simple_dual dataBend triggers slowDownB2 after 14 entries
wire [44:0]                 paramBendFifo;
wire [CLOSEATOM_WIDTH-1:0]  atom2BendFifo   = paramBendFifo[0+:CLOSEATOM_WIDTH];     
wire [CLOSEATOM_WIDTH-1:0]  atom3BendFifo   = paramBendFifo[CLOSEATOM_WIDTH+:CLOSEATOM_WIDTH];  
wire                        BendTypeFIFO    = paramBendFifo[44];             
reg  [16:0]                 phi0BendFifo    = 1'b0;     
reg  [16:0]                 kBendFifo       = 1'b0; 
reg                         BendTypeFifo_d0 = 1'b0;
wire                        fifoBend_empty;
reg                         fifoBendOut=1'b0;



 FIFO_async 
  #(
   .WIDTH(45),
   .DEPTH(512),
   .PROG_FULL_THRESH(450)
  ) fifoBend
 (
  .rst(1'b0),
  .wr_clk(DDR3clk),                            
  .din({BendType,kBend,phi0Bend,atom3Bend,atom2Bend}),       
  .wr_en(fifoBendIn),  
  .rd_clk(clk200MHz),
  .rd_en(fifoBendOut),         
  .dout(paramBendFifo),       
  .full(),    
  .empty(fifoBend_empty),   
  .prog_full(slowDownB1)                          
 );
 
 
//state machine stateBend that initiates bend force calculation 
  reg  signed [23:0]             x1Bend = 1'b0, y1Bend=1'b0, z1Bend=1'b0;
  wire signed [23:0]             x23Bend = atomBendData2[24*0 +:24];  //when used in simulator, with 1 node only, use "atomBendData2[24*0 +:24]&24'h3fffff", otherwise, information in BRAM will be that of some neigboring box 
  wire signed [23:0]             y23Bend = atomBendData2[24*1 +:24];
  wire signed [23:0]             z23Bend = atomBendData2[24*2 +:24];
  reg         [3:0]              stateBend=1'b0;
  reg  signed [23:0]             dx1Bend = 1'b0, dy1Bend=1'b0, dz1Bend=1'b0;
  reg  signed [23:0]             dx2Bend = 1'b0, dy2Bend=1'b0, dz2Bend=1'b0;
  reg                            AddBendFtot=1'b0,StoreBendFtot=1'b0;
  reg         [4:0]              pipeBend;
  reg                            stateBend_done=1'b0;
  wire signed [4:0]              cntBendData2_diff =   cntData2_in_d2-cntBendData2_out;
  reg                            slowDownB2 = 1'b0;
  reg         [FF_WIDTH-1:0]     stateBendCnt=0;        
  reg         [1:0]              bendWaitCnt;

  always @(posedge clk200MHz) begin
    pipeBend <= {pipeBend[3:0], fifoBendOut};
    if(MDReset_clk200MHz) begin
      stateBend          <= 1'b0;
      slowDownB2            <= 1'b0;
    end else begin
      case (stateBend)      
        0: begin
          stateBend_done  <= 1'b0;
          StoreBendFtot   <= 1'b0; 
          stateBendCnt    <= 1'b0;
          if(cntBendData2_out!=cntData2_in_d2) begin 
            stateBend     <= stateBend + 1'b1;
            rdBendEn1     <= 1'b1;
          end  
        end
        1: begin 
          rdBendEn1         <= 1'b0;
          fifoBendOut       <= 1'b1;
          bendWaitCnt       <= 2'h3;
          stateBend         <= stateBend + 1'b1;
        end
        2: begin                                                   
          fifoBendOut       <= 1'b0;
          stateBend         <= stateBend + 1'b1;                     //wait for latency FIFO and BRAM; 
        end  
        3: begin
          bendWaitCnt       <= bendWaitCnt - 1'b1;
          if(bendWaitCnt==2'h3) begin
            x1Bend          <= atomBendData2[24*0 +:24];  
            y1Bend          <= atomBendData2[24*1 +:24];  
            z1Bend          <= atomBendData2[24*2 +:24];
          end 
          if(atom2BendFifo==0) begin                                 //stop     
            stateBend       <= 10;
          end else if (bendWaitCnt==1'b0||~BendTypeFIFO) begin 
            stateBend       <= stateBend + 1'b1;                                   
          end  
        end  
        4: begin 
          stateBendCnt       <= stateBendCnt +1'b1;
          fifoBendOut        <= 1'b1;
          bendWaitCnt        <= 2'h3;                            
          stateBend          <= stateBend + 1'b1;
        end
        5: begin
          fifoBendOut     <= 1'b0;
          stateBend       <= stateBend + 1'b1;                     //wait for latency FIFO; 
        end  
        6: begin
          bendWaitCnt       <= bendWaitCnt - 1'b1;               
          if((atom2BendFifo==0)||(stateBendCnt>=FF_LENGTH-3)) begin   //stop criterion; either atom2=0 found, or maximum length exceeded 
            stateBend       <= 10;                                     //loop until stop criterion
          end else if (bendWaitCnt==1'b0||~BendTypeFIFO) begin       
            stateBend       <= 4;                                     
          end  
        end  
        10: begin                                                   //done
          stateBend_done      <= 1'b1;
          stateBend           <= stateBend + 1'b1; 
        end
        11: begin 
          cntBendData2_out    <= cntBendData2_out + 1'b1;
          if(cntBendData2_diff>=5'sd13)       slowDownB2 <= 1'b1;        //slow down state1 when close to full, i.e. only two spots left in  bram_72x512_simple_dual dataBend 
          else if (cntBendData2_diff<=5'sd12) slowDownB2 <= 1'b0;        //ractivate with hysteresiss                                                  
          StoreBendFtot   <= 1'b1; 
          stateBend       <= 0;  
        end
      endcase
    end
  end         
 
 //pipeline initiated by  stateBend that reads bram_72x512_simple_dual dataBend  and iniziates force calculation
  always @(posedge clk200MHz) begin
    case (pipeBend[1:0])
      2'b01: begin
        if(atom2BendFifo!=1'b0) begin
          adrBendData2_out  <= atom2BendFifo;
          rdBendEn2         <= 1'b1;
        end else begin
          adrBendData2_out  <= 1'b0;
          rdBendEn2         <= 1'b0;
        end  
      end    
      2'b10: begin
        if(atom2BendFifo!=1'b0) begin
          adrBendData2_out  <= atom3BendFifo;
          rdBendEn2         <= 1'b1;
       end else begin
          adrBendData2_out  <= 1'b0;
          rdBendEn2         <= 1'b0;
        end            
      end
      default: begin
        adrBendData2_out  <= 1'b0;
        rdBendEn2         <= 1'b0;
      end
    endcase
    if(pipeBend[2]) begin
      phi0BendFifo     <= paramBendFifo[(2*CLOSEATOM_WIDTH)+:17];     
      kBendFifo        <= paramBendFifo[(2*CLOSEATOM_WIDTH+17)+:17];
      BendTypeFifo_d0  <= BendTypeFIFO; 
    end
    if(pipeBend[3]) begin
      if(BendTypeFifo_d0) begin             //middle atom
        dx1Bend         <= x23Bend-x1Bend;  //enters into ForceBend
        dy1Bend         <= y23Bend-y1Bend; 
        dz1Bend         <= z23Bend-z1Bend;      
      end else begin                        //outer atom
        dx1Bend         <= x1Bend-x23Bend;  //enters into ForceBend
        dy1Bend         <= y1Bend-y23Bend; 
        dz1Bend         <= z1Bend-z23Bend;
        dx2Bend         <= x23Bend;         //store for next step; middle atom
        dy2Bend         <= y23Bend;  
        dz2Bend         <= z23Bend;
      end 
    end 
    if(pipeBend[4]) begin
      if(BendTypeFifo_d0) begin              //middle atom
        dx2Bend         <= x23Bend-x1Bend;  //enters into ForceBend
        dy2Bend         <= y23Bend-y1Bend; 
        dz2Bend         <= z23Bend-z1Bend;  
      end else begin                         //outer atom
        dx2Bend         <= x23Bend-dx2Bend;  //enters into ForceBend
        dy2Bend         <= y23Bend-dy2Bend;  
        dz2Bend         <= z23Bend-dz2Bend;
      end  
      AddBendFtot     <= ~stateBend_done;   //to supress last atom2, which is 0 and as such a stop criterion  
    end else begin
      AddBendFtot     <= 1'b0;
    end
  end
  
ClkTransferStat #(.Width (1))  ClkTransferStat7  
(
    .clkIn   (clk200MHz),
    .clkOut  (DDR3clk),
    .sigIn   (slowDownB2),
    .sigOut  (slowDownB2_d0)
); 


//******************************************************************************************************  
//actual bend Force calculation  

wire signed [31:0]    FxBend_tot, FyBend_tot, FzBend_tot;  
ForceBend ForceBend
(   
  .MDReset       (MDReset_clk200MHz),
  .clk           (clk200MHz),
  .AddFtot       (AddBendFtot),
  .ready         (),
  .StoreFtot     (StoreBendFtot),
  .StoreFtot_out (StoreBendFtot_out),
  .dx1           (dx1Bend),
  .dy1           (dy1Bend),
  .dz1           (dz1Bend),
  .dx2           (dx2Bend),
  .dy2           (dy2Bend),
  .dz2           (dz2Bend),
  .k             ({1'b0,kBendFifo}),
  .phi0          (phi0BendFifo),  
  .bendType      (BendTypeFifo_d0),
  .Fx_tot        (FxBend_tot),
  .Fy_tot        (FyBend_tot), 
  .Fz_tot        (FzBend_tot),
//outputs for debugging; intermediates results
  .cosphi        (),
  .phi_iSin      (),
  .fact1         (),
  .fact2         ()
);



FIFO_sync 
  #(
   .WIDTH(96),
   .DEPTH(64)
  ) FIFOForceBend 
 (
  .rst(1'b0),
  .clk(clk200MHz),                 
  .din({FzBend_tot,FyBend_tot,FxBend_tot}),      
  .wr_en(StoreBendFtot_out),     
  .rd_en(fifoAllForcesOut),  
  .dout(forceBendFifo),    
  .full(),            //should never become full due to slowDown logic
  .prog_full(),
  .empty(forceBendReady)  
);

//************************************************************************************************************************************** 
//                                                 Dihedrals Interactions                                                                *
//**************************************************************************************************************************************
//memory that contains the coordinates of all neigboring atoms with which bonded interactions may occur, i.e. up to 3 bonds away.  Position 0 contains (x1,y1,z1)
//CLOSEATOM_WIDTH+4 must equal size of Ram (i.e., Log2(512))
 wire [71:0]                atomDihedData2; 
 reg  [CLOSEATOM_WIDTH-1:0] adrDihedData2_out=1'b0;
 reg  [4:0]                 cntDihedData2_out=1'b0;
 
 reg                        rdDihedEn1=1'b0, rdDihedEn2=1'b0;   //all the subseqtent is new
 wire                       rdDihedEn_d0=rdDihedEn1||rdDihedEn2;
 reg                        rdDihedEn_d1,rdDihedEn_d2; 
 wire                       rdDihedEn=rdDihedEn_d0||rdDihedEn_d1||rdDihedEn_d2;    //extend by two cycles, probably extend by 1 cycle would be correct
 always @(posedge clk200MHz) begin
   rdDihedEn_d1 <= rdDihedEn_d0;
   rdDihedEn_d2 <= rdDihedEn_d1;
 end
 
 bram_72x512_simple_dual dataDihed 
  (
    .clka(DDR3clk),
    .ena(1'b1),
    .wea(wrData2) ,
    .addra({cntData2_in[3:0],adrData2}),              //upper 4 bits make it a circular buffer (de fact a FIFO) with 16 sites
    .dina(atomData2),
    .clkb(clk200MHz),
    .enb(rdDihedEn),                                 //is new
    .addrb({cntDihedData2_out[3:0],adrDihedData2_out}),
    .doutb(atomDihedData2)
  );


//FIFO that contains force field paramaters, as well as atoms with which dihedral intercations occurs. Lowest allowed atomNr is 1, while 0 indicates to stop the calculation.
//Generates an slowDown signal for state1 when more that 450 entries are in FIFO. bram_72x512_simple_dual dataDihed triggers slowDownD2 after 14 entries
wire [69:0]                 paramDihedFifo;
wire [CLOSEATOM_WIDTH-1:0]  atom2DihedFifo    = paramDihedFifo[0+:CLOSEATOM_WIDTH];  
wire [CLOSEATOM_WIDTH-1:0]  atom3DihedFifo    = paramDihedFifo[CLOSEATOM_WIDTH+:CLOSEATOM_WIDTH];               
wire [CLOSEATOM_WIDTH-1:0]  atom4DihedFifo    = paramDihedFifo[2*CLOSEATOM_WIDTH+:CLOSEATOM_WIDTH];  
reg  [17:0]                 k1DihedFifo       = 1'b0; 
reg  [17:0]                 k2DihedFifo       = 1'b0; 
reg  [17:0]                 k3DihedFifo       = 1'b0;   
reg                         DihedTypeFifo     = 1'b0;       
reg  [17:0]                 k1DihedFifo_d0    = 1'b0; 
reg  [17:0]                 k2DihedFifo_d0    = 1'b0; 
reg  [17:0]                 k3DihedFifo_d0    = 1'b0;   
reg                         DihedTypeFifo_d0  = 1'b0;       
wire                        fifoDihed_empty;
reg                         fifoDihedOut=1'b0;


FIFO_async 
  #(
   .WIDTH(70),
   .DEPTH(512),
   .PROG_FULL_THRESH(450)
  ) fifoDihed
 (
  .rst(1'b0),
  .wr_clk(DDR3clk),                            
  .din({DihedType,k3Dihed,k2Dihed,k1Dihed,atom4Dihed,atom3Dihed,atom2Dihed}),       
  .wr_en(fifoDihedIn),  
  .rd_clk(clk200MHz),
  .rd_en(fifoDihedOut),         
  .dout(paramDihedFifo),       
  .full(),    
  .empty(fifoDihed_empty),   
  .prog_full(slowDownD1)                          
 );

  reg  signed [23:0]             x1dihed = 1'b0, y1dihed=1'b0, z1dihed=1'b0;
  wire signed [23:0]             x24dihed = atomDihedData2[24*0 +:24];  
  wire signed [23:0]             y24dihed = atomDihedData2[24*1 +:24];
  wire signed [23:0]             z24dihed = atomDihedData2[24*2 +:24];
  reg         [3:0]              stateDihed=1'b0;
  reg  signed [23:0]             dxijdihed = 1'b0, dyijdihed=1'b0, dzijdihed=1'b0;
  reg  signed [23:0]             dxkjdihed = 1'b0, dykjdihed=1'b0, dzkjdihed=1'b0;
  reg  signed [23:0]             dxkldihed = 1'b0, dykldihed=1'b0, dzkldihed=1'b0;
  reg                            AddDihedFtot=1'b0,StoreDihedFtot=1'b0;
  reg         [5:0]              pipeDihed;
  reg                            stateDihed_done=1'b0,stateDihed_done_d0=1'b0;
  wire signed [4:0]              cntDihedData2_diff =   cntData2_in_d2-cntDihedData2_out;
  reg                            slowDownD2 = 1'b0;
  reg         [FF_WIDTH-1:0]     stateDihedCnt=0;     
              

  always @(posedge clk200MHz) begin
    pipeDihed <= {pipeDihed[4:0], fifoDihedOut};
    if(MDReset_clk200MHz) begin
      stateDihed            <= 1'b0;
      slowDownD2            <= 1'b0;
    end else begin
      case (stateDihed)      
        0: begin
          stateDihed_done   <= 1'b0;
          StoreDihedFtot    <= 1'b0; 
          stateDihedCnt     <= 1'b0;
          if(cntDihedData2_out!=cntData2_in_d2) begin 
            stateDihed      <= stateDihed + 1'b1;
            rdDihedEn1      <= 1'b1;                          //read x1,y1,z1; the address, which is always 0, is set by subsequent pipeline   //is new
          end  
        end
        1: begin 
          rdDihedEn1        <= 1'b0;                           //is new
          fifoDihedOut      <= 1'b1;
          stateDihed        <= stateDihed + 1'b1;
        end
        2: begin
          fifoDihedOut      <= 1'b0;
          stateDihed        <= stateDihed + 1'b1;                     //wait for latency FIFO and BRAM; 
        end  
        3: begin
          x1dihed           <= atomDihedData2[24*0 +:24];  
          y1dihed           <= atomDihedData2[24*1 +:24];  
          z1dihed           <= atomDihedData2[24*2 +:24]; 
          if(atom2DihedFifo==0) begin                                 //stop
            stateDihed      <= 10;
          end else begin 
            stateDihed      <= stateDihed + 1'b1;                                   
          end  
        end  
        4: begin 
          stateDihedCnt     <= stateDihedCnt +1'b1;
          fifoDihedOut      <= 1'b1;
          stateDihed        <= stateDihed + 1'b1;
        end
        5: begin
          fifoDihedOut      <= 1'b0;
          stateDihed        <= stateDihed + 1'b1;                     //wait for latency FIFO; 
        end  
        6: begin
          if((atom2DihedFifo==0)||(stateDihedCnt>=FF_LENGTH-3)) begin   //stop criterion; either atom2=0 found, or maximum length exceeded 
            stateDihed      <= 10;                                     //loop until stop criterion
          end else begin 
            stateDihed      <= 4;                                     
          end  
        end  
        10: begin
          stateDihed_done   <= 1'b1;
          stateDihed        <= stateDihed + 1'b1;         //need to wait cycles to finalize read process in subsequent pipeline before increasing cntDihedData2_out
        end
        11: begin 
          stateDihed        <= stateDihed + 1'b1;
        end
        12: begin   
          StoreDihedFtot    <= 1'b1;                                               
          cntDihedData2_out <= cntDihedData2_out + 1'b1;                  //is new; wait two cycles before increasing cntDihedData2_out
          if(cntDihedData2_diff>=5'sd13)       slowDownD2 <= 1'b1;        //slow down state1 when close to full, i.e. only two spots left in  bram_72x512_simple_dual dataDihed 
          else if (cntDihedData2_diff<=5'sd12) slowDownD2 <= 1'b0;        //ractivate with hysteresiss
          stateDihed        <= 1'b0;
        end
      endcase
    end
  end         
 
 //pipeline initiated by  stateDihed that reads bram_72x512_simple_dual dataDihed  and iniziates force calculation
  reg signed [23:0] x2dihed=1'b0,y2dihed=1'b0,z2dihed=1'b0;
  reg signed [23:0] x3dihed=1'b0,y3dihed=1'b0,z3dihed=1'b0;
  always @(posedge clk200MHz) begin
    stateDihed_done_d0 <= stateDihed_done;
    case (pipeDihed[2:0])
      3'b001: begin
        if(atom2DihedFifo!=1'b0) begin                    //is new; suppress read for the last line, where atom2DihedFifo==1'b0, which is the stop criterion
          adrDihedData2_out  <= atom2DihedFifo;
          rdDihedEn2         <= 1'b1;                     
        end else begin
          adrDihedData2_out  <= 1'b0;
          rdDihedEn2         <= 1'b0; 
        end  
      end 
      3'b010: begin
        if(atom2DihedFifo!=1'b0) begin                    //is new
          adrDihedData2_out  <= atom3DihedFifo;
          rdDihedEn2         <= 1'b1;                      
        end else begin
          adrDihedData2_out  <= 1'b0;
          rdDihedEn2         <= 1'b0; 
        end    
      end
      3'b100: begin
        if(atom2DihedFifo!=1'b0) begin                      //is new
          adrDihedData2_out  <= atom4DihedFifo;
          rdDihedEn2         <= 1'b1;                      
        end else begin
          adrDihedData2_out  <= 1'b0;
          rdDihedEn2         <= 1'b0; 
        end              
        k1DihedFifo        <= paramDihedFifo[(3*CLOSEATOM_WIDTH)+:18]; 
        k2DihedFifo        <= paramDihedFifo[(3*CLOSEATOM_WIDTH+1*18)+:18]; 
        k3DihedFifo        <= paramDihedFifo[(3*CLOSEATOM_WIDTH+2*18)+:18]; 
        DihedTypeFifo      <= paramDihedFifo[69];
      end
      default: begin 
        adrDihedData2_out  <= 1'b0;                   //set adress for reading x1,y1,z1
        rdDihedEn2         <= 1'b0;                   //is new
      end   
    endcase
    
    case (pipeDihed[5:3])
      3'b001: begin
        x2dihed      <= x24dihed;
        y2dihed      <= y24dihed;
        z2dihed      <= z24dihed;
        AddDihedFtot <= 1'b0; 
      end 
      3'b010: begin
        x3dihed      <= x24dihed;
        y3dihed      <= y24dihed;
        z3dihed      <= z24dihed;
        AddDihedFtot <= 1'b0; 
      end
      3'b100: begin
        if(DihedTypeFifo) begin
          dxijdihed        <= x2dihed-x1dihed;   //role of atom1 and atom2 are swapped if it is an inner atom
          dyijdihed        <= y2dihed-y1dihed;
          dzijdihed        <= z2dihed-z1dihed;
          dxkjdihed        <= x3dihed-x1dihed;
          dykjdihed        <= y3dihed-y1dihed;
          dzkjdihed        <= z3dihed-z1dihed;
        end else begin
          dxijdihed        <= x1dihed-x2dihed;
          dyijdihed        <= y1dihed-y2dihed;
          dzijdihed        <= z1dihed-z2dihed;       
          dxkjdihed        <= x3dihed-x2dihed;
          dykjdihed        <= y3dihed-y2dihed;
          dzkjdihed        <= z3dihed-z2dihed;
        end
        dxkldihed        <= x3dihed-x24dihed;
        dykldihed        <= y3dihed-y24dihed;
        dzkldihed        <= z3dihed-z24dihed;
        k1DihedFifo_d0   <= k1DihedFifo; 
        k2DihedFifo_d0   <= k2DihedFifo; 
        k3DihedFifo_d0   <= k3DihedFifo; 
        DihedTypeFifo_d0 <= DihedTypeFifo;
        AddDihedFtot <= ~stateDihed_done_d0; 
      end
      default: AddDihedFtot <= 1'b0; 
    endcase
  end



ClkTransferStat #(.Width (1))  ClkTransferStat8  
(
    .clkIn   (clk200MHz),
    .clkOut  (DDR3clk),
    .sigIn   (slowDownD2),
    .sigOut  (slowDownD2_d0)
); 

//******************************************************************************************************  
//actual dihedral force calculation  

wire signed [31:0]    FxDihed_tot, FyDihed_tot, FzDihed_tot;  
ForceDihedral ForceDihedral
(   
  .MDReset       (MDReset_clk200MHz),
  .clk           (clk200MHz),
  .AddFtot       (AddDihedFtot),             
  .ready         (),               
  .StoreFtot     (StoreDihedFtot),           
  .StoreFtot_out (StoreDihedFtot_out),       
  .dxij          (dxijdihed),                 
  .dyij          (dyijdihed),                 
  .dzij          (dzijdihed),                 
  .dxkj          (dxkjdihed),                  
  .dykj          (dykjdihed),               
  .dzkj          (dzkjdihed),               
  .dxkl          (dxkldihed),               
  .dykl          (dykldihed),             
  .dzkl          (dzkldihed),                
  .k1            (k1DihedFifo_d0),        
  .k2            (k2DihedFifo_d0),        
  .k3            (k3DihedFifo_d0),         
  .dihedType     (DihedTypeFifo_d0),       
  .Fx_tot        (FxDihed_tot),
  .Fy_tot        (FyDihed_tot), 
  .Fz_tot        (FzDihed_tot),
//outputs for debugging; intermediates results
  .cos_out       (),
  .sin_out       (),
  .dVdphi_out    (),
  .Fi_out        (),
  .Fl_out        ()
);




FIFO_sync 
  #(
   .WIDTH(96),
   .DEPTH(64)
  ) FIFOForceDihed 
  (
  .rst(1'b0),
  .clk(clk200MHz),                
  .din({FzDihed_tot,FyDihed_tot,FxDihed_tot}),           
  .wr_en(StoreDihedFtot_out),                               
  .rd_en(fifoAllForcesOut),  
  .dout(forceDihedFifo),    
  .full(),            //should never become full due to slowDown logic
  .prog_full(),
  .empty(forceDihedReady)  
);

//*****************************************************************************************************
//clock transfers

  ClkTransferStat #(.Width (1)) ClkTransferStat1
  (
    .clkIn   (IOclk),
    .clkOut  (DDR3clk),
    .sigIn   (iHalf),
    .sigOut  (iHalf_DDR3clk)
  ); 

  ClkTransfer #(.extend (2)) ClkTransfer2
  ( 
    .clkIn   (IOclk),
    .clkOut  (DDR3clk),
    .sigIn   (MDReset),
    .sigOut  (MDReset_DDR3clk)
  );

  ClkTransfer #(.extend (2)) ClkTransfer3
  ( 
    .clkIn   (IOclk),
    .clkOut  (clk200MHz),
    .sigIn   (MDReset),
    .sigOut  (MDReset_clk200MHz)
  );
  
  
  ClkTransfer #(.extend (2)) ClkTransfer4
  ( 
    .clkIn   (clk200MHz),
    .clkOut  (IOclk),
    .sigIn   (error1),
    .sigOut  (error1_d0)
  );

 ClkTransfer #(.extend (2)) ClkTransfer5
  ( 
    .clkIn   (DDR3clk),
    .clkOut  (IOclk),
    .sigIn   (error2),
    .sigOut  (error2_d0)
  );
  
 ClkTransfer #(.extend (2)) ClkTransfer6
  ( 
    .clkIn   (DDR3clk),
    .clkOut  (IOclk),
    .sigIn   (error3),
    .sigOut  (error3_d0)
  );

assign BondInteraction_error = {error3_d0,error2_d0,error1_d0};

endmodule
