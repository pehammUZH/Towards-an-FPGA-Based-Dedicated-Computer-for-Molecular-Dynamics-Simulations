`timescale 1ns / 1ps

//- inteligent "FIFO" that collects group of atoms that are constrained, and outputs them as a block once all atoms 
//  of a group are received.
//- can be up to 4 atoms as for a CH3 group, where nH (which is in the meta data) labels the number of H's (e.g. nH=2
//  for H2O) 
//- current FIFO dephth 4, could be extended to 16 without significant additional resources, since atom data are 
//  stored in LUT Ram. Some of the code would have to be adapted by hand 
//- data in the upper line of the LUT Ram are not zero'ed upon shifting down, only FIFOatomNr, FIFOnH and FIFOocc is.  
//  Should not matter since they will be overwritten before used.  
//- produces error signel (errorCollectOvfl) if FIFO runs full.   
//- the lower two bits of atomNr of atoms in contrained group label the atoms, where 2'h0 is the 
//  center atom (O in H2O or C in -CH3) and 2'h1...2'h3 for H1...H3. If nH<3, some of the atomNr remain unused.
//- ATTENTION: atomNr=0 must not be used, as that is used as an indicator of no atom. Lowest allowed atomNr  
//  is atomnr=1, if it is not in a constrained group, or 4 if it is in a constrained group.
//- the 4 atoms of a constrained group are output one after the other, with DataOutValid indicating which one it is. 
//  The center atom, and hence DataOutValid[0] is output last, initiating the start of the downstream shake module.      
//- bit size velocities 28 


module CollectContraintGroup
#(
parameter  DataByteWidth_n    = 18,
parameter  metaAtomNr_len     = 16,     //length of atom number
parameter  metaConstraint     = 48     //position of contraint info in meta data
)
(
input                                    IOclk,
input                                    clk,
input                                    MDReset,         //reset upon start
output reg                               inReady,         //ready to accept input; can also be used as busy signal
input                                    atomRcv,         //new atom data received
input        [DataByteWidth_n*8-9+84:0]  atomDataIn,      //new atom data. 8bit, which eventually will become route, are not included; velocities are 28bit each
input                                    outReady,        //downstream module is ready to accept data 
output reg                               DataOutBusy,     //blocks a short period before and after data out
output reg   [3:0]                       DataOutValid,    //grouped data valid, one bit for each center atom (bit0) and the varios H's
output       [DataByteWidth_n*8-9+84:0]  atomDataCollect, //output grouped atom data 
output                                   errorCollectOvfl //error on FIFO overflow
);


localparam nFIFO    = 4;        //FIFO dephth 

wire [metaAtomNr_len-1:0] atomNr = atomDataIn[72 +:metaAtomNr_len]; 
wire [1:0]                nH     = atomDataIn[72+metaConstraint +:2]; 
reg  [metaAtomNr_len-3:0] FIFOatomNr[nFIFO-1:0]; 
reg  [3:0]                FIFOocc[nFIFO-1:0]; 
reg  [1:0]                FIFOnH[nFIFO-1:0]; 
reg  [2:0]                state=0;
reg  [1:0]                writePos;        //works for nFIFO of 4
reg  [2:0]                FIFOpos;         //works for nFIFO of 4; need an extra bit to detect overflows
reg  [3:0]                readAdr;         //works for nFIFO of 4
reg                       storeData;
reg                       errorCollectOvfl_d0;

wire MDReset_clk;
ClkTransfer #(.extend (2)) ClkTransfer0  
(
    .clkIn      (IOclk),
    .clkOut     (clk),
    .sigIn      (MDReset),
    .sigOut     (MDReset_clk)
); 


wire [3:0]                      writeAdr      = (state<=2) ? {writePos,~(atomNr[1:0])} : (readAdr-4'h4);  //upon atomRcv, write atoms in opposite order so that center atom is sent out last. Upon sending data out, shift down data by one position
wire                            we            = (state<=2) ? storeData                 : (readAdr >= 4);                   
wire [DataByteWidth_n*8-9+84:0] atomDataIn_d0 = (state<=2) ? atomDataIn                : atomDataCollect;  //Upon sending data out, shift down the subsequent ones
ram_220x16_lat1 dataStorage
(
  .clk(clk),        
  .a(writeAdr),     
  .d(atomDataIn_d0),       
  .we(we),      
  .dpra(readAdr),                
  .dpo(atomDataCollect)      
);



integer i;

 always @(posedge clk) begin
   if(MDReset_clk) begin
     state             <= 1'b0;
     inReady           <= 1'b1;
     FIFOpos <= 1'b0;
     for(i=0;i<=nFIFO-1;i=i+1) begin   
       FIFOatomNr[i]   <= 1'b0;
       FIFOnH[i]       <= 1'b0;
       FIFOocc[i]      <= 1'b0; 
     end
   end else begin
     case(state)
       0: begin
         errorCollectOvfl_d0 <= 1'b0;
         storeData           <= 1'b0; 
         DataOutValid        <= 4'b0000;
         readAdr             <= 1'b0;
         writePos            <= 1'b0;
         DataOutBusy         <= 1'b0;
         if(atomRcv) begin
           state <= 1;
           inReady <= 1'b0;
         end
       end
       1: begin
         if          (atomNr[metaAtomNr_len-3:2]==FIFOatomNr[0]) begin    //would have to be exended if FIFO depth>4 is needed
           writePos                <= 2'h0;
           FIFOocc[0][atomNr[1:0]] <= 1'b1;
         end else if (atomNr[metaAtomNr_len-3:2]==FIFOatomNr[1]) begin 
           writePos                <= 2'h1; 
           FIFOocc[1][atomNr[1:0]] <= 1'b1;
         end else if (atomNr[metaAtomNr_len-3:2]==FIFOatomNr[2]) begin 
           writePos                <= 2'h2; 
           FIFOocc[2][atomNr[1:0]] <= 1'b1;
         end else if (atomNr[metaAtomNr_len-3:2]==FIFOatomNr[3]) begin
           writePos                <= 2'h3; 
           FIFOocc[3][atomNr[1:0]] <= 1'b1;
         end else begin                                               
           writePos                      <= FIFOpos[1:0];                 //works for nFIFO of 4
           FIFOatomNr[FIFOpos[1:0]]      <= atomNr[metaAtomNr_len-3:2];   //works for nFIFO of 4
           FIFOnH[FIFOpos[1:0]]          <= nH;                           //works for nFIFO of 4
           FIFOpos                       <= FIFOpos + 1'b1;
           if(FIFOpos == nFIFO) errorCollectOvfl_d0 <= 1'b1;      //FIFO overflow
           FIFOocc[FIFOpos][atomNr[1:0]] <= 1'b1;      
         end
         storeData <= 1'b1;  
         state     <= state + 1'b1;
       end
       2: begin  
         storeData <= 1'b0;                                             
         if ((FIFOnH[0]==2'h1&&FIFOocc[0]==4'h3)||(FIFOnH[0]==2'h2&&FIFOocc[0]==4'h7)||(FIFOnH[0]==2'h3&&FIFOocc[0]==4'hf)) begin    //test if lowest entry is full, in which case it is sent out and all other entries are shifted down, 
           if(outReady) begin                              //wait until the down stream shake is ready to accept data              
             state        <= state + 1'b1;
             DataOutBusy  <= 1'b1; 
           end
         end else begin
           inReady <= 1'b1;
           state <= 1'b0;                                  //wait for next atom
         end
       end
       3:begin
         state        <= state + 1'b1;
         DataOutValid <= 4'b1000; 
       end
       4:begin
         if(readAdr==4'h0) begin                          //shift down FIFOatomNr, FIFOnH and FIFOocc
           FIFOpos             <= FIFOpos - 1'b1;
           for(i=1;i<=nFIFO-1;i=i+1) begin 
             FIFOatomNr[i-1]   <= FIFOatomNr[i];
             FIFOnH[i-1]    <= FIFOnH[i];
             FIFOocc[i-1]      <= FIFOocc[i];
           end          
           FIFOatomNr[3]       <= 1'b0;
           FIFOnH[3]        <= 1'b0;
           FIFOocc[3]          <= 1'b0;                 
         end 
         readAdr <= readAdr + 1'b1;                          //shift down data in memory 
         DataOutValid <= {1'b0, DataOutValid[3:1]};
         if(readAdr==4'h4) DataOutBusy <= 1'b0;
         if(readAdr==4'hf) state       <= 2;                       //done, test whether next entry is already full
       end
     endcase
   end    
 end
 
 
 ClkTransfer #(.extend (2)) ClkTransfer1  
(
    .clkIn      (clk),
    .clkOut     (IOclk),
    .sigIn      (errorCollectOvfl_d0),
    .sigOut     (errorCollectOvfl)
); 
 
endmodule