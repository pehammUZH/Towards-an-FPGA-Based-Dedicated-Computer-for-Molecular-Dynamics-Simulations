`timescale 1ns / 1ps

//        BENDING FORCES
//
//Definition of atom labels:
//        dq1
//    q2------q1
//    |
// dq2|
//    |
//    q3
//
//required input:
//  dq1=q1-q2
//  dq2=q3-q2
//
//with that, it calculates 
//   F1=k(phi-phi0)/sin(phi)[1/(r1*r2)*dq2-p/(r1^(3/2)*r2)*dq1]
//with
//   p=dq1.dq2
//and
//   phi=arccos[p/(r1*r2)]


//Remarks:
//-  Not fully pipelied, can accept new data only upon "ready". Depending on bendType, that is either after 3 clock cycles (bendType=0, outer atom q1), or 6 clock cycles
//  (bendType=1, middle atom q2). In the latter case, the force calculation is run twice with inverted force and one for each outer atom, i.e. force of middle atom q2 equals minus the sum 
//  of forces on the two outer atoms q1 and q3.
//- Only one AddFtot is expected per atom, even if it is the middle atom. In that case, AddFtot is dublicated within ForceBend.v
//- StoreFtot must be one cycle after the last AddFtot in case it is outer atom, or 4 cycles if it is middle atom (it used to be that this distinction was done within ForceBend.v, 
//  but with new calling routine, it is easier to do it externally)
//- designed for bond distances about 0.03...0.25
//- If cosphi exactly +/-1, or larger beyond +/-1 due to round-off, force will be 0, but that is a situation that will essentially never occur, and if 
//  it does, the 1/sinphi term is also wrong
//- range of k: largest bend potentials in Amber is 1200 kJ/mol/rad^2 when P is involved, when allowing for dt=3.5fs, input range should be -1/64...1/64.
//  Need  negative k for the middle atom. When k is given in kJ/mol/rad^2, needs to be multiplied with vshift*(10^-6)*dt^2/m_ref/rcut^2 to obtain the correct 
//  unit-less force.
//- Frequency in 1/ps is f=1/2Pi sqrt(k/mu/rbond^2), where mu is reduced mass in atomic units, k the force constnat in kJ/mol, and rbond the bond distance   
//  in nm.

module ForceBend
(    
input                                     MDReset, 
input                                     clk,
//input                                     ResetFtot,     
input                                     AddFtot,       
output      reg                           ready=1'b1,  
input                                     StoreFtot,       
output                                    StoreFtot_out,   
input       signed [23:0]                 dx1,
input       signed [23:0]                 dy1,
input       signed [23:0]                 dz1,
input       signed [23:0]                 dx2,
input       signed [23:0]                 dy2,
input       signed [23:0]                 dz2,
input              [16:0]                 phi0,              //range: 0....1 mapping onto 0...180°
input       signed [17:0]                 k,                 //range: -1/64....1/64; 18'h10000 corresponds to 1/128           
input                                     bendType,          //bendType=1: middle atom, in which case calculation is launched twice, bendType=0: outer atom
output reg  signed [31:0]                 Fx_tot=1'b0,
output reg  signed [31:0]                 Fy_tot=1'b0, 
output reg  signed [31:0]                 Fz_tot=1'b0,
//output intermediate results for debugging
output reg signed  [25:0]                 cosphi,
output     signed  [24:0]                 phi_iSin,
output     signed  [24:0]                 fact1,
output     signed  [24:0]                 fact2
);


localparam r2_shift          = 4;                             
localparam invSqrtR2_shift   = 6;
localparam invR2SqrtR2_shift = 16;                          

              

localparam nPipeTot        = 54;              //latency up to fact1,fact2
localparam nPipe_AddFtot   = nPipeTot-3;      //latency of reading data plus ForceNonBond;
localparam nPipe_StoreFtot = nPipeTot-2;      

integer                         i;
reg  signed [48:0]              Fx_tot_long=1'b0;
reg  signed [48:0]              Fy_tot_long=1'b0; 
reg  signed [48:0]              Fz_tot_long=1'b0;
reg  signed [23:0]              dy1_d0,dy2_d0,dz1_d0,dz2_d0,dx1_d0,dx2_d0;
reg         [16:0]              phi0_d0;
reg  signed [17:0]              k_d0,k_d1;   
reg  signed [47:0]              r2_tmp1=1'b0,r2_tmp2=1'b0,p_tmp=1'b0,r2_tmp1_d0=1'b0;
reg  signed [25:0]              r2=1'b0; 
reg  signed [24:0]              iR2=1'b0;
reg  signed [24:0]              iR2_d0;
wire signed [49:0]              p_iR2,p_iR2_iR1;
wire signed [49:0]              p_iR2_iR1_32_tmp;
wire signed [49:0]              iR2_iR1_tmp;
reg  signed [23:0]              phi_tmp2;
reg  signed [24:0]              phi;
reg  signed [23:0]              iSin_tmp2;
wire signed [42:0]              k_phi_iSin;
reg  signed [23:0]              iSin;
reg  signed [48:0]              Fq;
reg                             FtotReset=1'b0;




localparam nPipe_dq        = 44;  
localparam nPipe_phi0      = 32;                           
localparam nPipe_k         = 36;                           
localparam nPipe_iR1       = 4;  
localparam nPipe_p         = 8;  
localparam nPipe_sign      = 8;  
localparam nPipe_piR2iR132 = 16; 
localparam nPipe_iR2iR1    = 19;    

//all shift register
reg  signed [24:0]              iR1[nPipe_iR1-1 :0];
reg  signed [24:0]              iR1_32[nPipe_iR1-1 :0];
reg  signed [23:0]              dq1_pipe[nPipe_dq-1:0] ,dq2_pipe[nPipe_dq-1:0]; 
reg  signed [24:0]              p[nPipe_p-1:0];
reg         [nPipe_sign-1:0]    sign_cosphi;
reg         [17:0]              k_pipe[nPipe_k-1:0];
reg         [16:0]              phi0_pipe[nPipe_phi0-1:0];
reg         [24:0]              p_iR2_iR1_32[nPipe_piR2iR132-1:0];
reg         [23:0]              iR2_iR1[nPipe_iR2iR1-1:0];

reg         [nPipe_AddFtot:0]   AddFtot_pipe    = 1'b0;
reg         [nPipe_StoreFtot:0] StoreFtot_pipe  = 1'b0;
assign                          StoreFtot_out = StoreFtot_pipe[nPipe_StoreFtot];
reg         [2:0]               state=1'b0;
reg         [2:0]               StoreFtot_d1=1'b0;
reg                             StoreFtot_d2=1'b0;

//statemachine that decides whether it is a middle atom or outer atom
  always @(posedge clk) begin
    if(MDReset) begin
      ready <= 1'b1;  
      state <= 1'b0;
    end else begin
      case (state) 
        3'h0: begin
 //         StoreFtot_d2      <= 1'b0;
          if(AddFtot) begin
//level 0 of pipeline      
            AddFtot_pipe[0] <= 1'b1;    
            dx1_d0          <= dx1;
            dy1_d0          <= dy1;
            dz1_d0          <= dz1;
            dx2_d0          <= dx2;
            dy2_d0          <= dy2;
            dz2_d0          <= dz2;
            k_d0            <= k;
            phi0_d0         <= phi0;
            state           <= bendType ? 3'h2: 3'h1;
            ready           <= 1'b0;
          end  
        end     
        3'h1: begin                               //run only once for outer atom
          k_d1             <= k_d0;
          AddFtot_pipe[0]  <= 1'b0; 
          ready            <= 1'b1;
          state            <= 3'h0;
        end
        3'h2,3'h3 : begin                            //run twice for middle atom with inverted force; include 1 wait cycle
          k_d1             <= -k_d0;
          AddFtot_pipe[0]  <= 1'b0;
          state            <= state + 'b1;
        end  
        3'h4: begin
          AddFtot_pipe[0]  <= 1'b1; 
          dx1_d0           <= dx2_d0;
          dy1_d0           <= dy2_d0;
          dz1_d0           <= dz2_d0;
          dx2_d0           <= dx1_d0;
          dy2_d0           <= dy1_d0;
          dz2_d0           <= dz1_d0;
          state            <= state + 'b1;
        end
        3'h5: begin
          AddFtot_pipe[0]  <= 1'b0; 
          ready            <= 1'b1;
          state            <= 3'h0;
        end
      endcase
    end  
  end
//****************************Calculation pipeline******************* 
 
  always @(posedge clk) begin       //send to multiplier
    case(AddFtot_pipe[2:0])
//level 1 of pipeline    
      3'b001: begin
        dq1_pipe[0]  <= dx1_d0;
        dq2_pipe[0]  <= dx2_d0;
        phi0_pipe[0] <= phi0_d0;
      end
//level 2 of pipeline          
      3'b010: begin
        k_pipe[0]    <= k_d1;
        dq1_pipe[0] <= dy1_d0;
        dq2_pipe[0] <= dy2_d0;
      end
//level 3 of pipeline
      3'b100: begin
        dq1_pipe[0] <= dz1_d0;
        dq2_pipe[0] <= dz2_d0;
      end      
    endcase    
  end 
 
  wire signed [49:0]    dq1_2, dq2_2, pq;
  mult_s25xs25_lat4     mult_dx1_2    (.CLK(clk),.A({dq1_pipe[0],1'b0}),.B({dq1_pipe[0],1'b0}),.P(dq1_2));   //used 3 times      
  mult_s25xs25_lat4     mult_dy1_2    (.CLK(clk),.A({dq2_pipe[0],1'b0}),.B({dq2_pipe[0],1'b0}),.P(dq2_2));   //used 3 times
  mult_s25xs25_lat4     mult_dz1_2    (.CLK(clk),.A({dq1_pipe[0],1'b0}),.B({dq2_pipe[0],1'b0}),.P(pq));      //used 3 times

  always @(posedge clk) begin  //collect results from multipier
    case(AddFtot_pipe[7:5])
//level 6 of pipeline   
      3'b001: begin
        r2_tmp1 <= dq1_2[49:2]; 
        r2_tmp2 <= dq2_2[49:2];  
        p_tmp   <= pq[49:2];
      end
//level 7 of pipeline   
      3'b010: begin
        r2_tmp1 <= r2_tmp1 + dq1_2[49:2]; 
        r2_tmp2 <= r2_tmp2 + dq2_2[49:2];  
        p_tmp   <= p_tmp+pq[49:2];
      end
//level 8 of pipeline   
      3'b100: begin
        r2_tmp1 <= r2_tmp1 + dq1_2[49:2]; 
        r2_tmp2 <= r2_tmp2 + dq2_2[49:2];  
        p_tmp   <= p_tmp+pq[49:2];             
      end      
    endcase  
  end  
  
  always @(posedge clk) begin        //send r1^2 and r2^2 to InvSqrtR2 and mult_r4, as well as all the subsequent until iR2 and iR1 are calculated
    case(AddFtot_pipe[9:8])
      2'b01: begin                       //level 9 of pipeline 
        r2         <= (r2_tmp2[47:18]<(31'h4000000>>r2_shift)) ? r2_tmp2[43-r2_shift:18-r2_shift] : 26'h3ffffff;  //treat overflow when r>0.25, as in ForceStretch.v    
        p[0]       <= p_tmp[48-r2_shift:24-r2_shift];
        r2_tmp1_d0 <= r2_tmp1;
      end  
      2'b10:  begin                     //level 10 of pipeline  
        r2         <= (r2_tmp1_d0[47:18]<(31'h4000000>>r2_shift)) ? r2_tmp1_d0[43-r2_shift:18-r2_shift] : 26'h3ffffff; //treat overflow when r>0.25, as in ForceStretch.v     
      end          
    endcase
  end

//*******************************************************************************************************
//Done:  r1^2, r2^2 and p=dx1.dx2                                                                       *
//*******************************************************************************************************
//level 10 of pipeline
//InvSqrt is used twice, also level 11. InvR2SqrtR2 is used only once at level 11
  wire [25:0] iR_tmp, iR32_tmp;
  LUTfunction2 #(.FUNCTIONTYPE1(0),.FUNCTIONTYPE2(2)) InvSqrtR2_InvR2SqrtR2 (.clk(clk),.in(r2),.out1(iR_tmp),.out2(iR32_tmp));
  
//level 16 of pipeline
  always @(posedge clk) begin
    if(AddFtot_pipe[15]) begin              
      iR2 <= iR_tmp[25:1];            
    end  
  end  
  
//level 17 of pipeline  
 //********************************************************************************************************
//Done:  1/r2                                                                                            *
//********************************************************************************************************        
  mult_s25xs25_lat4 mult_p1   (.CLK(clk),.A(p[nPipe_p-1]),.B(iR2),.P(p_iR2));  //used only once
  always @(posedge clk) begin
    iR2_d0 <= iR2;
    if(AddFtot_pipe[16]) begin              
      iR1[0]  <= iR_tmp[25:1];
      iR1_32[0]  <= iR32_tmp[25:1];
    end  
  end  
  

//level 18 of pipline
//********************************************************************************************************
//Done:  1/r1, 1/r1^(3/2)                                                                                *
//********************************************************************************************************    
  mult_s25xs25_lat4 mult_iR2_iR1 (.CLK(clk),.A(iR1[0]),.B(iR2_d0),.P(iR2_iR1_tmp));

//level 21 of pipeline
//********************************************************************************************************
//Done:  p/r2                                                                                            *
//********************************************************************************************************  
  mult_s25xs25_lat4 mult_p2    (.CLK(clk),.A(iR1[nPipe_iR1-1])   ,.B(p_iR2[40:16]),.P(p_iR2_iR1));                        
  mult_s25xs25_lat4 mult_p232  (.CLK(clk),.A(iR1_32[nPipe_iR1-1]),.B(p_iR2[40:16]),.P(p_iR2_iR1_32_tmp)); 
  
 //level 22 of pipline
  always @(posedge clk) begin
    iR2_iR1[0] <= iR2_iR1_tmp[48:25];                 
  end
  
 //level 25 of pipeline 
  always @(posedge clk) begin                           
    cosphi <= p_iR2_iR1[47-2*(invSqrtR2_shift-5)]  ? -p_iR2_iR1[45-2*(invSqrtR2_shift-5):20-2*(invSqrtR2_shift-5)] : 
                                                      p_iR2_iR1[45-2*(invSqrtR2_shift-5):20-2*(invSqrtR2_shift-5)];  
    sign_cosphi[0]  <= p_iR2_iR1[47-2*(invSqrtR2_shift-5)];
    p_iR2_iR1_32[0] <= p_iR2_iR1_32_tmp[48:24];                         
  end  
  
 //level 26 of pipeline 
 //*******************************************************************************************************
//Done:  cos(phi)=p/(r1*r2) and p/r2/r1^(3/2)                                                            *
//********************************************************************************************************    
  wire [25:0] phi_tmp1, iSin_tmp1;
  LUTfunction2 #(.FUNCTIONTYPE1(3),.FUNCTIONTYPE2(4)) Arccos_InvSin (.clk(clk),.in(cosphi),.out1(phi_tmp1),.out2(iSin_tmp1));    

//level 32 of pipeline
  always @(posedge clk) begin
    phi_tmp2   <=  phi_tmp1[25:2];
    iSin_tmp2  <= iSin_tmp1[25:2];
  end
  wire signed [24:0] phi_tmp3={1'b0,phi_tmp2};

//level 33 of pipeline
  always @(posedge clk) begin
    phi   <= sign_cosphi [nPipe_sign-1] ? 25'h1000000-phi_tmp3-{1'b0,phi0_pipe[nPipe_phi0-1],7'b0} : phi_tmp3-{1'b0,phi0_pipe[nPipe_phi0-1],7'b0};
    iSin  <= iSin_tmp2;
  end     
   
 //level 34 of pipeline 
//********************************************************************************************************
//Done:  (phi-ph0) and 1/sin(phi)                                                                        *
//********************************************************************************************************   
  wire signed [49:0] phi_iSin_tmp;
  mult_s25xs25_lat4 mult_phi_iSin (.CLK(clk),.A(phi),.B({1'b0,iSin}) ,.P(phi_iSin_tmp));
  assign phi_iSin= phi_iSin_tmp[48:24];
    
//level 38 of pipeline   
//********************************************************************************************************
//Done:  (phi-phi0)/sin(phi)                                                                             *
//********************************************************************************************************         
 mult_s25xs18_lat3 mult_k_phi_iSin (.CLK(clk),.A(phi_iSin),.B(k_pipe[nPipe_k-1]) ,.P(k_phi_iSin));

//level 41 of pipline
//********************************************************************************************************
//Done:  k*(phi-phi0)/sin(phi), p/r1^3/r2 and 1/r1/r2 delayed properly                                                                           *
//********************************************************************************************************
 wire signed [49:0]              fact1_tmp;
 wire signed [49:0]              fact2_tmp;
 mult_s25xs25_lat4 mult_fact1 (.CLK(clk),.A(k_phi_iSin[41:17]),.B(p_iR2_iR1_32[nPipe_piR2iR132-1]),.P(fact1_tmp));   
 mult_s25xs25_lat4 mult_fact2 (.CLK(clk),.A(k_phi_iSin[41:17]),.B({1'b0,iR2_iR1[nPipe_iR2iR1-1]}),.P(fact2_tmp)); 
 assign fact1=fact1_tmp[41-(invR2SqrtR2_shift-16)-(invSqrtR2_shift-6):17-(invR2SqrtR2_shift-16)-(invSqrtR2_shift-6)];   //with that choice, both fact1 and fact2 are on the same scale, and the distance 
 assign fact2=fact2_tmp[42-2*(invSqrtR2_shift-6):18-2*(invSqrtR2_shift-6)];                                             //range is sort of the same as those of InvR2SqrtR2 and InvSqrtR2 (i.e., 0.03...0.25) 

//level 45 of pipeline
//********************************************************************************************************
//Done:  fact1 and fact2                                                                                 *
//********************************************************************************************************
  wire signed [49:0]              Fq1,Fq2;
  mult_s25xs25_lat4     mult_Fq1 (.CLK(clk),.A(fact1),.B({dq1_pipe[nPipe_dq-1],1'b0}),.P(Fq1));  //is used three times for dx,dy,dz
  mult_s25xs25_lat4     mult_Fq2 (.CLK(clk),.A(fact2),.B({dq2_pipe[nPipe_dq-1],1'b0}),.P(Fq2));

//level 49 of pipeline
  always @(posedge clk) begin
    Fq <= Fq2[49:1]-Fq1[49:1];
  end
  
//level 50,51,52 of pipeline
  always @(posedge clk) begin
    if(FtotReset) begin
      Fx_tot_long <= 1'b0;
      Fy_tot_long <= 1'b0;
      Fz_tot_long <= 1'b0;
    end else begin
//accumulating all forces   
      case(AddFtot_pipe[nPipe_AddFtot:nPipe_AddFtot-2])
        3'b001: Fx_tot_long <= Fx_tot_long + Fq;      //level 50 of pipeline
        3'b010: Fy_tot_long <= Fy_tot_long + Fq;      //level 51 of pipeline
        3'b100: Fz_tot_long <= Fz_tot_long + Fq;      //level 52 of pipeline
      endcase
    end  
  end     
  
//level 53 of pipeline,   
  always @(posedge clk) begin
    if (StoreFtot_pipe[nPipe_StoreFtot-1]) begin
      Fx_tot <= Fx_tot_long[40:9] + {31'b0,Fx_tot_long[8]};   
      Fy_tot <= Fy_tot_long[40:9] + {31'b0,Fy_tot_long[8]};   
      Fz_tot <= Fz_tot_long[40:9] + {31'b0,Fz_tot_long[8]};
    end    
  end
  
  

//*********************************************************shift intermediate results for later usage**************************************************************
always @(posedge clk) begin
   for(i=1;i<=nPipe_dq-1;i=i+1) begin   
     dq1_pipe[i]<=dq1_pipe[i-1];
     dq2_pipe[i]<=dq2_pipe[i-1];
   end 
   
   for(i=1;i<=nPipe_p-1;i=i+1) begin   
     p[i]<=p[i-1];
   end 
   
   for(i=1;i<=nPipe_sign-1;i=i+1) begin   
     sign_cosphi[i]<=sign_cosphi[i-1];
   end 
    
    for(i=1;i<=nPipe_phi0-1;i=i+1) begin   
       phi0_pipe[i]<=phi0_pipe[i-1];
    end 
    
   for(i=1;i<=nPipe_k-1;i=i+1) begin   
       k_pipe[i]<=k_pipe[i-1];
   end 
   
    for(i=1;i<=nPipe_piR2iR132-1;i=i+1) begin   
       p_iR2_iR1_32[i]<=p_iR2_iR1_32[i-1];
    end 
    
    for(i=1;i<=nPipe_iR2iR1-1;i=i+1) begin   
      iR2_iR1[i]<=iR2_iR1[i-1];
    end 
   
   for(i=1;i<=nPipe_iR1-1;i=i+1) begin   
     iR1[i]      <= iR1[i-1];
     iR1_32[i]   <= iR1_32[i-1];
   end 
    
   for(i=1;i<=nPipe_AddFtot;i=i+1) begin   
     AddFtot_pipe[i] <= AddFtot_pipe[i-1];
   end  
      
   StoreFtot_pipe <= {StoreFtot_pipe[nPipe_StoreFtot-1:0],StoreFtot};   
   FtotReset <= StoreFtot_pipe[nPipe_StoreFtot-2]||MDReset;
 end   
    
endmodule
