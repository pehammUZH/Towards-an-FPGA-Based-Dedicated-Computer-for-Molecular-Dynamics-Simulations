`timescale 1ns / 1ps

//-pipeline for calculation of the non-bonded forces with atoms in neigboring boxes in the (xy)-corners. 
//-With the parameters (q0,q1,q2), it can be re-programmed to also do y- and z-directions. 
//-overall structure and timing of ForceBox1, ForceBox12 and ForceBox123 the same
//-FIFO-buffered at the input (i.e., coordinates and metadata of atom in the homebox) as well as the output (i.e, forces on that atom)
// to adjust for time-mismatch of the various pipelines. Is initiated with start_i2, and forceReady indicates that force data are ready 
// in the output FIFO.
//-Does nearest neighbor estimate not with an explicit nearest neighbor list (whose calculation would take the same effort as the force 
// calculation, but by dividing the neigboring boxes into 4*4*4 subboxes. The relevant nearest-neigbor subboxes for a given home-box 
// atom are taken from a pre-programmed LUT_Box_x. Could in principle also be a writeable BRAM, in which case it could be programmed
// at runtime (would probably not add any significant resources)
//-Format of LUT_Box_xy: Contains 10 address bits; the 7 LSBs is a counter that can (in principle) adress 128 subboxes, the 3 MSBs is 
// the position in the home box. In principle, 3*2 bits would be needed for that, but positions {3,2} are complimentary to {0,1}, hence 
// only 3*1 bits are needed. Each data element contains 8 bits. The 6 LSBs label (x,y,z) in the neigboring box (this time really two bits 
// each), and the 2 MSBs label one of the 4 neigboring boxes in +/-(x,y)-directions. File is generated with ProduceNearestNeighborLUTs.nb.
//-Actual force calculation is done in an universal submodule ForceNonBond.  

//DATE FLOW:
//
//Data in atomData initiate CalcState1
//                                               lat2                            lat6
// +--------+   +----------+  (i1r,cntSubBox)  +-------+ (iBox,ix2,iy2,iz2)   +------------+  (nAtomSubBox,iBox,ix2,iy2,iz2)  +----------+
// |atomData|-->|CalcState1|------------------>|Lut_Box|--------------------->|  pipeline  |--------------------------------->|SubBoxFIFO|
// +--------+   +----------+                   +-------+                      +----------^-+                                  +-----^----+
//      |            |                                                          | npipe2 |                                          |
//      |            |               npipe1                                     +--------+                                          |
//      |            +--------------------------------------------------------------------------------------------------------------+
//      |
//      |         +-----------+        (nSubBox,metadata,x1,y1,z1)
//      +-------->|miniFIFO1,2|-------------------------------------------------------+
//                +-----------+                                                       |
//                                                                                    |
//  (closeAtom,pair14)   +-------------+                                              |
//---------------------->|closeAtomFIFO|----------------------------------------------+                                                                                    |
//                       +-------------+                                              |
//                                                                                    |
//Data in SubBoxFIFO initiate CalcState2:                                             |
//                                                             lat5                   | lat2
// +----------+   +----------+  (ix2,iy2,iz2,iAtomSubBox)  +-----------+ (x2,y2,z2) +----------+  (dx,dy,dz,iAtom2,closeAtom,pair14) +------------+    +-----+
// |SubBoxFIFO|-->|CalcState2|---------------------------->|NeighborBox|----------->| pipeline |------------------------------------>|ForceNonBond|--->|Force|
// +----------+   +----------+                             +-----------+            +-^--------+                                     +^-----------+    +-----+
//                     |                     npipe3                                   |                                               |                 
//                     +--------------------------------------------------------------+                                               |            
//                     |                          nPipe_AddFtot, nPipe_StoreFtot                                                      |          
//                     +--------------------------------------------------------------------------------------------------------------+                    
//
//

`include "MDSwitches.h"

module ForceBox12
#(   
parameter DataByteWidth_n    = 5'd18,  //width of the memories containing neigboring box data, i.e., coordinates and meta-data
parameter nSelForceLUT       = 3,      //width of SelForceLUT
parameter q0                 = 0,      //ordering of the data, so that subroutine can be used for x-, y- or z-directions.
parameter q1                 = 1,      //Swap at most two numbers and keep one constant, e.g, (2,1,3) but not (2,3,1),
parameter q2                 = 2,       //otherwise, cannot be inverted easily
parameter metaAtomNr_len     = 16,     //length of atom number in meta data;
parameter metaAtomTypeLJ     = 18,    //atomType for LJ
parameter metaAtomTypeLJ_len = 5,     
parameter metaCharge         = 24,    //charge
parameter metaCharge_len     = 18,
parameter nProteinAtom       = 12,     //defines maximum number of protein atoms: 2^nProteinAtom                                            
parameter nCLOSEATOM         = 21      //maximum number of closeAtoms  
)
(
input                                 IOclk,
input                                 CalcClk,   
input                                 clk200MHz,
input                                 DDR3clk,           
input                                 MDReset,
//input that writes into Force-LUT
 input                                wrForceLUT,    
 input      [8:0]                     dataForceLUT,  
 input      [11:0]                    adrForceLUT,   
 input      [nSelForceLUT-1:0]        selForceLUT,     
//write into Neigboring Box BRAM
input                                 data_valid_pp,       //data valid for the right-upper box
input                                 data_valid_pn,       //data valid for the left-upper box
input                                 data_valid_np,       //data valid for the right-lower box
input                                 data_valid_nn,       //data valid for the left-lower box
input                                 iHalf,              //iHalf on IOclk
input         [7:0]                   nAtom_pp,            //total number of data in right-upper box, is a running index during writing
input         [7:0]                   nAtom_pn,            //total number of data in left-upper box, is a running index during writing
input         [7:0]                   nAtom_np,            //total number of data in right-lower box, is a running index during writing
input         [7:0]                   nAtom_nn,            //total number of data in left-lower box, is a running index during writing
input         [DataByteWidth_n*8-1:0] data_pp,             //data for the right-upper box
input         [DataByteWidth_n*8-1:0] data_pn,             //data for the left-upper box
input         [DataByteWidth_n*8-1:0] data_np,             //data for the right-lower box
input         [DataByteWidth_n*8-1:0] data_nn,             //data for the left-lower box
input                                 nAtomReset,          //reset nAtomSubBox_*, number of data in the various sub-boxes
output                                overflowSubbox,      //error upon overflow in one of the subboxes
//Calculation pipeline
input                                 iHalf_CalcClk,       //iHalf on CalcClk for reading
input                                 start_i2,            //(x1,y1,z1)-data ready to write into input FIFO, on IOclk
input         [DataByteWidth_n*8-1:0] dataHome,            //(x1,y1,z1)-data, contains coordinates and metadata, on IOclk
//closeAtom, for exclusion in ForceNonBond
input                                 closeAtom_rcv,       //closeAtom valid, on DDR3clk,   
input   [nCLOSEATOM*nProteinAtom-1:0] closeAtom,           //closeAtom data, on DDR3clk, 
input   [nCLOSEATOM-1:0]              pair14,              //close atoms that are in pair list, used to calculated fudged nonbonded forces  
input   [16:0]                        fudgeQQ,             //fudging factor for Coulomb; 0x10000 corresponds to 1                           
input                                 fudgeLJ,             //fudging factor for LJ; is 1.0 when fudgeLJ=1, or 0.5 when fudgeLJ=0           
//output data
output                                forceReady,          //force calculation done
input                                 fifoOut,             //trigger output FIFO to send data
output        [95:0]                  forceFifo,           //calculated forces
output                                slowDown            //input FIFO almost full, tell master pipeline to slow down
);

localparam   nSubBoxTot      = 64;
localparam   width_iBox      = 2;                   //will chnage for different versions of subroutine
localparam   width_LUTBox    = width_iBox+6;
localparam   widthFIFOBox    = width_iBox+12;       //NEW
 
localparam   nPipe1          = 8;                   //length of pipeline from cntSubBox to SubBoxFIFO in 
localparam   nPipe2          = 3;                   //length of pipeline from LUT_Box out to FIFO_Box_in
localparam   nPipe3          = 4;                   //length of pipeline from SubBoxFIFO out to dataBox_* out
localparam   nPipe_AddFtot   = 6;                   //latency of reading data ;
localparam   nPipe_StoreFtot = 7;                   //one after the last AddFtot.  



reg         [1:0]                   CalcState1 = 1'b0,CalcState2 = 1'b0;
reg         [6:0]                   cntSubBox  = 1'b0, cntSubBox2 = 1'b0;  
reg         [2:0]                   i1 = 1'b0; 
reg         [1:0]                   ix2[nPipe2:0];
reg         [1:0]                   iy2[nPipe2:0];
reg         [1:0]                   iz2[nPipe2:0];
reg         [nPipe_StoreFtot:0]     StoreFtot   = 1'b0;        
reg         [nPipe_AddFtot:0]       AddFtot   =1'b0;     
reg         [width_iBox-1:0]        iBox[nPipe2:0];    
reg         [width_iBox-1:0]        iBox2[nPipe3:0];                     
wire                                FIFO2DataReady;
wire                                FIFO2AlmostFull;  
reg         [nPipe1:0]              FIFO2Write    = 1'b0; 
//reg                                 FIFO2Read     = 1'b0;
reg                                 miniFIFOWrite = 1'b0;
reg         [nPipe3+2:0]            miniFIFORead  = 1'b0;
reg         [nPipe3:0]              ReadCloseAtomFIFO=1'b0;                 
wire        [nSubBoxTot*4-1:0]      nAtomSubBox_pp;
wire        [nSubBoxTot*4-1:0]      nAtomSubBox_pn;
wire        [nSubBoxTot*4-1:0]      nAtomSubBox_np;
wire        [nSubBoxTot*4-1:0]      nAtomSubBox_nn;
reg         [31:0]                  nAtomSubBox_nn_d0;
reg         [31:0]                  nAtomSubBox_np_d0;
reg         [31:0]                  nAtomSubBox_pn_d0;
reg         [31:0]                  nAtomSubBox_pp_d0;
reg         [3:0]                   nAtomSubBox_nn_d1;
reg         [3:0]                   nAtomSubBox_np_d1;
reg         [3:0]                   nAtomSubBox_pn_d1;
reg         [3:0]                   nAtomSubBox_pp_d1;
reg         [3:0]                   nAtomSubBox = 1'b0;
reg                                 fifoDataOut = 1'b0;          
reg         [6:0]                   writeFIFO   = 1'b0, writeFIFO_d0 = 1'b0;        
reg         [6:0]                   readFIFO    = 1'b0;
wire                                overflowSubbox_pn, overflowSubbox_pp,overflowSubbox_nn, overflowSubbox_np;

  wire     [DataByteWidth_n*8-1:0]  dataBox_nn;
  wire     [DataByteWidth_n*8-1:0]  dataBox_np;
  wire     [DataByteWidth_n*8-1:0]  dataBox_pn;
  wire     [DataByteWidth_n*8-1:0]  dataBox_pp;


wire [6:0] nSubBox [0:7];
assign nSubBox[0]=7'd79;     //Number of SubBoxes -1
assign nSubBox[1]=7'd77;
assign nSubBox[2]=7'd77;
assign nSubBox[3]=7'd75;
assign nSubBox[4]=7'd83;
assign nSubBox[5]=7'd83;
assign nSubBox[6]=7'd83;
assign nSubBox[7]=7'd83;

ClkTransfer #(.extend (2)) ClkTransfer1
(
    .clkIn   (IOclk),
    .clkOut  (CalcClk),
    .sigIn   (MDReset),
    .sigOut  (MDReset_CalcClk)
); 


//******************************input data FIFO************************
//resuffle data so that subroutine can be used for x,y,z directions; add one buffer stage for better routing
reg [DataByteWidth_n*8-1:0] dataHomeReshuffle;
reg                         start_i2_d0;
always @(posedge IOclk) begin
  dataHomeReshuffle <= {dataHome[DataByteWidth_n*8-1:72],dataHome[24*q2 +:24],dataHome[24*q1 +:24],dataHome[24*q0 +:24]};
  start_i2_d0       <= start_i2;
end

//has an almost-full option, that will tell the master-pipeline in MDmachine to slow down. 
wire        [DataByteWidth_n*8-1:0] dataBoxFifo;
FIFO_async 
  #(
   .WIDTH(DataByteWidth_n*8),
   .DEPTH(64),
   .PROG_FULL_THRESH(55)
   ) atomData
  (
  .rst(1'b0),
   .wr_clk(IOclk),      
  .din(dataHomeReshuffle),      
  .wr_en(start_i2_d0), 
  .rd_clk(CalcClk), 
  .rd_en(fifoDataOut),  
  .dout(dataBoxFifo),    
  .full(),    
  .empty(atomDataReady),  
  .prog_full(slowDown)
);

//buffers closeAtom data; width must be nCLOSEATOM*(nProteinAtom+1). 
wire [nCLOSEATOM*(nProteinAtom+1)-1:0] closeAtomFIFO_Out;         
FIFO_async 
  #(
   .WIDTH(nCLOSEATOM*(nProteinAtom+1)),
   .DEPTH(64) 
   ) closeAtomFIFO
  (                                               
  .rst(1'b0),
  .wr_clk(DDR3clk),      
  .din({pair14,closeAtom}),      
  .wr_en(closeAtom_rcv),  
  .rd_clk(CalcClk),
  .rd_en(ReadCloseAtomFIFO[nPipe3]),  
  .dout(closeAtomFIFO_Out),    
  .full(),    
  .empty(closeAtomReady),  
  .prog_full()                   //doesn't need extra slow-down, since that should go in parallel with atom1FIFO
);
wire [nCLOSEATOM*nProteinAtom-1:0] closeAtom_d0 = closeAtomFIFO_Out[nCLOSEATOM*nProteinAtom-1:0];             
wire [nCLOSEATOM-1:0]              pair14_d0    = closeAtomFIFO_Out[nCLOSEATOM*nProteinAtom +:nCLOSEATOM]; 

//*****************************************************************state machine 1*********************************************************
//generates a stream of (nAtomSubBox,iBox,iz2,iy2,ix2) that is fed into a FIFO and ultimately processed by state machine 2.
//The stream is output with CalcClk without waiting cycles. nAtomSubBox has a significant latency relative to iz2,iy2,ix2, hence the latter
//need to be delayed accordingly to be synchronized. Due to that latency, one cannot process data directly in one statemachine without 
//significant number of wait cycles. State machine 2 reads that stream, and can process data with in essence no wait cycles. Whenever some 
//nAtomSubBox>1, it will be slower than state machine 1, and there is a slow-down mechanism for state machine 1. 

//subbox in homebox. data can be just outside box, which occurs for H's whose distance is constrained to a heavy atom, in which case it is forced to be in the 
//same box as the heavy atom. It will be very close to box, though, maximal the bond distance. If it is outside, assign it to closest subbox
//                           is negative (<range)                     is > range                      is in range
wire        [1:0]     ix1  = dataBoxFifo[24*0+23] ? 2'b00 : (dataBoxFifo[24*0+22] ? 2'b11 : dataBoxFifo[24*0+20 +:2]);               
wire        [1:0]     iy1  = dataBoxFifo[24*1+23] ? 2'b00 : (dataBoxFifo[24*1+22] ? 2'b11 : dataBoxFifo[24*1+20 +:2]);               
wire        [1:0]     iz1  = dataBoxFifo[24*2+23] ? 2'b00 : (dataBoxFifo[24*2+22] ? 2'b11 : dataBoxFifo[24*2+20 +:2]);               

wire        [2:0]     i1r  = {iz1[0]^ iz1[1],iy1[0]^ iy1[1],ix1[0]^ ix1[1]}; //reduce subboxnumber 0...3 to only 0...1, since it is symmetric, i.e., 3eq0 and 2eq1.
integer i;
always @(posedge CalcClk) begin
    for(i=1;i<=nPipe1;i=i+1) begin 
      FIFO2Write[i]<=FIFO2Write[i-1];
    end  
//state machine 1   
    case (CalcState1)
      0: begin
        if(~(atomDataReady||closeAtomReady)) begin
          fifoDataOut  <= 1'b1;
          CalcState1   <= 3'd1;
        end
      end  
      1: begin                     //wait for latency of FIFO
        fifoDataOut    <= 1'b0;
        CalcState1     <= 3'd2;
      end    
      2: begin                     //atom 1 data ready
        cntSubBox      <= 1'b0; 
        i1             <= {iz1[1],iy1[1],ix1[1]};  
        FIFO2Write[0]  <= 1'b1;
        miniFIFOWrite  <= 1'b1;
        CalcState1     <= 3'd3;
      end    
      3: begin
        miniFIFOWrite  <= 1'b0;
        if(cntSubBox==nSubBox[i1r]) begin        
          CalcState1       <= 3'd0;
          FIFO2Write[0]    <= 1'b0;
        end else begin 
          if(FIFO2AlmostFull) begin
            FIFO2Write[0]  <= 1'b0;
          end else begin
            FIFO2Write[0]  <= 1'b1;  
            cntSubBox      <= cntSubBox + 1'b1;
          end   
        end  
      end  
    endcase 
end          

//*******************miniFIFOs to store number of boxes, coordinates and meta data
//has space for two entries only
wire [6:0] nSubBox_FIFO;
miniFIFO #(.width (7)) miniFIFO1
(
  .clk   (CalcClk),      
  .din   (nSubBox[i1r]),      
  .wr_en (miniFIFOWrite),  
  .rd_en (miniFIFORead[0]),  
  .dout  (nSubBox_FIFO)  
);

wire [71+metaCharge+metaCharge_len:0] atom1_FIFO;            //meta data only up to charge are needed for force calculation
miniFIFO #(.width (72+metaCharge+metaCharge_len)) miniFIFO2
(
  .clk   (CalcClk),      
  .din   (dataBoxFifo[71+metaCharge+metaCharge_len:0]),      
  .wr_en (miniFIFOWrite),  
  .rd_en (miniFIFORead[nPipe3+2]),  
  .dout  (atom1_FIFO)  
);


//*********************LUT that contains all sub-boxes that need to be considered within cut-off****************************
//starts from cntSubBox and reveals iBox, ix2, iy2 and iz2. Latency 2
wire        [width_LUTBox-1:0]      LUT_Box_out;   
LUT_Box_xy LUT_Box_xy (
  .clka(CalcClk),    
  .addra({i1r,cntSubBox}),  
  .douta(LUT_Box_out) 
);

//subsequent pipeline starts from LUT_Box_out, determines iBox, ix2, iy2iz2, and nAtomSubbox and writes that into SubBoxFIFO 
wire   [2:0]                 adr0_nAtomSubbox={iz2[0],iy2[0][1]};
wire   [2:0]                 adr1_nAtomSubbox={iy2[1][0],ix2[1]};
reg    [widthFIFOBox-1:0]    FIFO_Box_in, FIFO_Box_in_d0; 
always @(posedge CalcClk) begin
    for(i=1;i<=nPipe2;i=i+1) begin 
      iBox[i]<=iBox[i-1];
      ix2[i] <= ix2[i-1];
      iy2[i] <= iy2[i-1];
      iz2[i] <= iz2[i-1];
    end  
//level 1 of pipeline
    iBox[0] <= i1[width_iBox-1:0]^LUT_Box_out[width_iBox+5:6];
    ix2[0]  <= i1[0] ? 2'd3-LUT_Box_out[1:0] : LUT_Box_out[1:0];
    iy2[0]  <= i1[1] ? 2'd3-LUT_Box_out[3:2] : LUT_Box_out[3:2];
    iz2[0]  <= i1[2] ? 2'd3-LUT_Box_out[5:4] : LUT_Box_out[5:4];
//level 2 of pipeline
//separate multiplexer into 3 stages
    nAtomSubBox_nn_d0 <= nAtomSubBox_nn[adr0_nAtomSubbox*32+:32];   
    nAtomSubBox_np_d0 <= nAtomSubBox_np[adr0_nAtomSubbox*32+:32];  
    nAtomSubBox_pn_d0 <= nAtomSubBox_pn[adr0_nAtomSubbox*32+:32];  
    nAtomSubBox_pp_d0 <= nAtomSubBox_pp[adr0_nAtomSubbox*32+:32];  
//level 3 of pipeline
    nAtomSubBox_nn_d1 <= nAtomSubBox_nn_d0[adr1_nAtomSubbox*4+:4];    
    nAtomSubBox_np_d1 <= nAtomSubBox_np_d0[adr1_nAtomSubbox*4+:4];  
    nAtomSubBox_pn_d1 <= nAtomSubBox_pn_d0[adr1_nAtomSubbox*4+:4];
    nAtomSubBox_pp_d1 <= nAtomSubBox_pp_d0[adr1_nAtomSubbox*4+:4];  
//level 4 of pipeline 
    case (iBox[nPipe2-1])
      0: nAtomSubBox <=  nAtomSubBox_nn_d1;
      1: nAtomSubBox <=  nAtomSubBox_np_d1;
      2: nAtomSubBox <=  nAtomSubBox_pn_d1;
      3: nAtomSubBox <=  nAtomSubBox_pp_d1;
    endcase  
//level 5 of pipeline  
    FIFO_Box_in     <= {(nAtomSubBox<=1'b1),(nAtomSubBox!=0),((nAtomSubBox==0)? 3'b0: nAtomSubBox-1'b1),iBox[nPipe2],iz2[nPipe2],iy2[nPipe2],ix2[nPipe2]};  //precalculate some things, see below 
//level 6 of pipeline  
    FIFO_Box_in_d0   <= FIFO_Box_in;   //for easier routing
end 


//*********************************************state machine 2****************************************
//process synchronized (nAtomSubBox,iBox,iz2,iy2,ix2) stream
//the fiollowing until the end of CalcState2 is in part NEW 
wire  [widthFIFOBox-1:0] FIFO_Box_out;
wire  [1:0]              ix2_FIFO         = FIFO_Box_out[1:0];
wire  [1:0]              iy2_FIFO         = FIFO_Box_out[3:2];
wire  [1:0]              iz2_FIFO         = FIFO_Box_out[5:4];
wire  [width_iBox-1:0]   iBox_FIFO        = FIFO_Box_out[width_iBox+5:6];
wire  [3:0]              nAtomSubBox_FIFO = FIFO_Box_out[width_iBox+9:width_iBox+6];  //precalculated NAtomSubBox-1, but not smaller than 0
wire                     noAtom           = FIFO_Box_out[width_iBox+10];              //precalculated when it is >0 atoms
wire                     FIFO2Read_2      = FIFO_Box_out[width_iBox+11];              //precalculated when it is 0 or 1 atoms (in which case nAtomSubBox_FIFO=0)
reg   [3:0]              iAtomSubBox      = 1'b0;
reg                      FIFO2Read_0      = 1'b0;
reg                      FIFO2Read_1      = 1'b0;
wire                     FIFO2Read        = FIFO2Read_0&&(FIFO2Read_2||FIFO2Read_1);   
FIFO_Box_xy SubBoxFIFO
(
  .clk(CalcClk),      
  .din(FIFO_Box_in_d0),      
  .wr_en(FIFO2Write[nPipe1]),  
  .rd_en(FIFO2Read),  
  .dout(FIFO_Box_out),    
  .full(),    
  .empty(FIFO2DataReady),
  .prog_full(FIFO2AlmostFull)  
);

//reg [15:0]            readCnt   = 1'b0;    //for debugging  only   
reg                   next_cnt2 =1'b0;                  
always @(posedge CalcClk) begin
  StoreFtot[nPipe_StoreFtot:1] <= StoreFtot[nPipe_StoreFtot-1:0]; 
  AddFtot[nPipe_AddFtot:1]     <= AddFtot[nPipe_AddFtot-1:0];
  miniFIFORead[nPipe3+2:1]     <= miniFIFORead[nPipe3+1:0];
  ReadCloseAtomFIFO[nPipe3:1]  <= ReadCloseAtomFIFO[nPipe3-1:0];           
  iBox2[0]     <= iBox_FIFO;
  for(i=1;i<=nPipe3;i=i+1) begin 
    iBox2[i]        <=iBox2[i-1];
  end  
  case (CalcState2)
    0: begin
      AddFtot[0]             <= 1'b0;
      cntSubBox2             <= 1'b0;
      if(~FIFO2DataReady) begin
        CalcState2           <= 3'd1;
        FIFO2Read_0          <= 1'b1;
        ReadCloseAtomFIFO[0] <= 1'b1;
      end  
    end
    1: begin
      ReadCloseAtomFIFO[0] <= 1'b0;
      AddFtot[0]           <= noAtom;
      FIFO2Read_1          <= (iAtomSubBox==(nAtomSubBox_FIFO-1'b1));
      if(iAtomSubBox<nAtomSubBox_FIFO) begin
        iAtomSubBox        <= iAtomSubBox +1'b1;
      end else begin
        iAtomSubBox        <= 1'b0;
        cntSubBox2         <= cntSubBox2 + 1'b1;
        next_cnt2          <= (cntSubBox2 == nSubBox_FIFO -1'b1);       //precalculate
        if(next_cnt2) begin
          miniFIFORead[0] <= 1'b1;
          FIFO2Read_0     <= 1'b0;
          StoreFtot[0]    <= 1'b1;
          CalcState2      <= 3'd2;
        end 
      end      
    end
    2: begin
      StoreFtot[0]     <= 1'b0;
      AddFtot[0]      <= 1'b0;
      miniFIFORead[0]  <= 1'b0;
      CalcState2       <= 3'd0;
    end
  endcase  
end

//************************************Memories for neighboring boxes*******************************************
//Reads atom data based on (iz2,iy2,ix2,nAtomWork) input, latency 4.
//The data that are written into memory are reshuffled in a way that subroutine can be used for x,y,z directions, 
//depending on parameters q0,q1,and q2.
wire [DataByteWidth_n*8-1:0] data_nnReshuffle = {data_nn[DataByteWidth_n*8-1:72],data_nn[24*q2 +:24],data_nn[24*q1 +:24],data_nn[24*q0 +:24]};
NeighborBox
#(  
.DataByteWidth_n (DataByteWidth_n),
.nSubBoxTot      (nSubBoxTot)
) NeighborBox_nn  
(
.IOclk          (IOclk),
.CalcClk        (CalcClk),
//write into BRAM and sub-box LUT
.data_valid     (data_valid_nn),                             //input data valid
.iHalf          (iHalf),                                     //iHalf on IOclk for writing
.dataIn         (data_nnReshuffle),                          //input data, contains positions and meta data
.nAtomReset     (nAtomReset),                                //reset nAtomSubBox
.nAtom          (nAtom_nn),                                  //input, number of data in whole box, is a running index during writing
.shift_x        (-24'h400000),                              
.shift_y        (-24'h400000),
.shift_z        (24'h000000),
.overflowSubbox (overflowSubbox_nn),                         //indicates that one of the subboxes contains >16 entries (in average should be <4)
//read Data
.iHalf_CalcClk  (iHalf_CalcClk),                             //iHalf on CalcClk for reading
.nAtomSubBox    (nAtomSubBox_nn),                            //output, number of data in the various sub-boxes
.readEn         (1'b1),                                      //used to be iBox_FIFO==2'b00, to save power if not used                         
.iAtomSub       ({iz2_FIFO,iy2_FIFO,ix2_FIFO,iAtomSubBox}),  //input, read data for (iz2,iy2,ix2) ate level nAtomWork
.dataBox        (dataBox_nn)                                 //outout data, contains positions and meta-data
);

wire [DataByteWidth_n*8-1:0] data_npReshuffle = {data_np[DataByteWidth_n*8-1:72],data_np[24*q2 +:24],data_np[24*q1 +:24],data_np[24*q0 +:24]};
NeighborBox
#(  
.DataByteWidth_n (DataByteWidth_n),
.nSubBoxTot      (nSubBoxTot)
) NeighborBox_np 
(
.IOclk          (IOclk),
.CalcClk        (CalcClk),
//write into BRAM and sub-box LUT
.data_valid     (data_valid_np),                             //input data valid
.iHalf          (iHalf),                                     //iHalf on IOclk for writing
.dataIn         (data_npReshuffle),                          //input data, contains positions and meta data
.nAtomReset     (nAtomReset),                                //reset nAtomSubBox
.nAtom          (nAtom_np),                                  //input, number of data in whole box, is a running index during writing
.shift_x        (+24'h400000),                              
.shift_y        (-24'h400000),
.shift_z        (24'h000000),
.overflowSubbox (overflowSubbox_np),                         //indicates that one of the subboxes contains >16 entries (in average should be <4)
//read Data
.iHalf_CalcClk  (iHalf_CalcClk),                             //iHalf on CalcClk for reading
.nAtomSubBox    (nAtomSubBox_np),                            //output, number of data in the various sub-boxes
.readEn         (1'b1),                                      //used to be iBox_FIFO==2'b01, to save power if not used 
.iAtomSub       ({iz2_FIFO,iy2_FIFO,ix2_FIFO,iAtomSubBox}),  //input, read data for (iz2,iy2,ix2) ate level nAtomWork
.dataBox        (dataBox_np)                                 //outout data, contains positions and meta-data
);

wire [DataByteWidth_n*8-1:0] data_pnReshuffle = {data_pn[DataByteWidth_n*8-1:72],data_pn[24*q2 +:24],data_pn[24*q1 +:24],data_pn[24*q0 +:24]};
NeighborBox
#(  
.DataByteWidth_n (DataByteWidth_n),
.nSubBoxTot      (nSubBoxTot)
) NeighborBox_pn  
(
.IOclk          (IOclk),
.CalcClk        (CalcClk),
//write into BRAM and sub-box LUT
.data_valid     (data_valid_pn),                             //input data valid
.iHalf          (iHalf),                                     //iHalf on IOclk for writing
.dataIn         (data_pnReshuffle),                          //input data, contains positions and meta data
.nAtomReset     (nAtomReset),                                //reset nAtomSubBox
.nAtom          (nAtom_pn),                                  //input, number of data in whole box, is a running index during writing
.shift_x        (-24'h400000),                              
.shift_y        (+24'h400000),
.shift_z        (24'h000000),
.overflowSubbox (overflowSubbox_pn),                         //indicates that one of the subboxes contains >16 entries (in average should be <4)
//read Data
.iHalf_CalcClk  (iHalf_CalcClk),                             //iHalf on CalcClk for reading
.nAtomSubBox    (nAtomSubBox_pn),                            //output, number of data in the various sub-boxes
.readEn         (1'b1),                                      //used to be iBox_FIFO==2'b10, to save power if not used      
.iAtomSub       ({iz2_FIFO,iy2_FIFO,ix2_FIFO,iAtomSubBox}),  //input, read data for (iz2,iy2,ix2) ate level nAtomWork
.dataBox        (dataBox_pn)                                 //outout data, contains positions and meta-data
);

wire [DataByteWidth_n*8-1:0] data_ppReshuffle = {data_pp[DataByteWidth_n*8-1:72],data_pp[24*q2 +:24],data_pp[24*q1 +:24],data_pp[24*q0 +:24]};
NeighborBox  //right box
#(  
.DataByteWidth_n (DataByteWidth_n),
.nSubBoxTot      (nSubBoxTot)
) NeighborBox_pp
(
.IOclk          (IOclk),
.CalcClk        (CalcClk),
//write into BRAM and to sub-box LUT
.data_valid     (data_valid_pp),                               //input data valid
.iHalf          (iHalf),                                       //iHalf on IOclk for writing
.dataIn         (data_ppReshuffle),                            //input data, contains positions and meta data
.nAtomReset     (nAtomReset),                                  //reset nAtomSubBox
.nAtom          (nAtom_pp),                                    //input, number of data in whole box, is a running index during writing
.shift_x        (24'h400000),                              
.shift_y        (24'h400000),
.shift_z        (24'h000000),
.overflowSubbox (overflowSubbox_pp),                           //indicates that one of the subboxes contains >16 entries (in average should be <4)
//read Data
.iHalf_CalcClk  (iHalf_CalcClk),                               //iHalf on CalcClk for reading
.nAtomSubBox    (nAtomSubBox_pp),                              //output, number of data in the various sub-boxes
.readEn         (1'b1),                                        //used to be iBox_FIFO==2'b11, to save power if not used 
.iAtomSub       ({iz2_FIFO,iy2_FIFO,ix2_FIFO,iAtomSubBox}),    //input, read data for (iz2,iy2,ix2) ate level nAtomWork
.dataBox        (dataBox_pp)                                   //outout data, contains positions and meta-data
);
assign overflowSubbox = overflowSubbox_pp||overflowSubbox_np||overflowSubbox_pn||overflowSubbox_nn;  //will produce an errorsignal




//subsequent pipeline starts from dataBox_* from NeighborBox_*
wire signed [23:0]                   x1          = atom1_FIFO[24*0 +:24];
wire signed [23:0]                   y1          = atom1_FIFO[24*1 +:24];
wire signed [23:0]                   z1          = atom1_FIFO[24*2 +:24];
wire        [metaAtomTypeLJ_len-1:0] atomTypeLJ1 = atom1_FIFO[24*3+metaAtomTypeLJ +:metaAtomTypeLJ_len];
wire signed [metaCharge_len-1:0]     charge1     = atom1_FIFO[24*3+metaCharge +: metaCharge_len];
reg         [metaAtomTypeLJ_len-1:0] atomTypeLJ2,atomTypeLJ2_d0;
reg  signed [metaCharge_len-1:0]     charge2,charge2_d0;
wire        [metaAtomNr_len-1:0]     iAtom1      = atom1_FIFO[24*3 +:metaAtomNr_len];
reg         [metaAtomNr_len-1:0]     iAtom2, iAtom2_d0;
reg  signed [23:0]                   dx = 1'b0, dy = 1'b0, dz = 1'b0;
reg  signed [23:0]                   x2 = 1'b0, y2 = 1'b0, z2 = 1'b0;
always @(posedge CalcClk) begin
    case (iBox2[nPipe3])
      0: begin
        x2              <= dataBox_nn[24*0 +:24];
        y2              <= dataBox_nn[24*1 +:24];
        z2              <= dataBox_nn[24*2 +:24];
        atomTypeLJ2     <= dataBox_nn[24*3+metaAtomTypeLJ +:metaAtomTypeLJ_len];
        charge2         <= dataBox_nn[24*3+metaCharge +: metaCharge_len];
        iAtom2          <= dataBox_nn[24*3 +:metaAtomNr_len];
      end
      1: begin
        x2              <= dataBox_np[24*0 +:24];
        y2              <= dataBox_np[24*1 +:24];
        z2              <= dataBox_np[24*2 +:24];
        atomTypeLJ2     <= dataBox_np[24*3+metaAtomTypeLJ +:metaAtomTypeLJ_len];
        charge2         <= dataBox_np[24*3+metaCharge +: metaCharge_len];   
        iAtom2          <= dataBox_np[24*3 +:metaAtomNr_len];     
      end
      2: begin
        x2              <= dataBox_pn[24*0 +:24];
        y2              <= dataBox_pn[24*1 +:24];
        z2              <= dataBox_pn[24*2 +:24];
        atomTypeLJ2     <= dataBox_pn[24*3+metaAtomTypeLJ +:metaAtomTypeLJ_len];
        charge2         <= dataBox_pn[24*3+metaCharge +: metaCharge_len];     
        iAtom2          <= dataBox_pn[24*3 +:metaAtomNr_len];   
      end
      3: begin
        x2              <= dataBox_pp[24*0 +:24];
        y2              <= dataBox_pp[24*1 +:24];
        z2              <= dataBox_pp[24*2 +:24];
        atomTypeLJ2     <= dataBox_pp[24*3+metaAtomTypeLJ +:metaAtomTypeLJ_len];
        charge2         <= dataBox_pp[24*3+metaCharge +: metaCharge_len]; 
        iAtom2          <= dataBox_pp[24*3 +:metaAtomNr_len];       
      end
    endcase
//level 1 of pipeline    
    dx              <= x2-x1;  
    dy              <= y2-y1;
    dz              <= z2-z1;  
    atomTypeLJ2_d0  <= atomTypeLJ2;
    charge2_d0      <= charge2;
    iAtom2_d0       <= iAtom2;
//force calculation in ForceNonBond starts from here    
end

wire signed [31:0]   Fx_tot,Fy_tot,Fz_tot;
ForceNonBond 
#(
.nSelForceLUT       (nSelForceLUT),
.metaAtomNr_len     (metaAtomNr_len),
.nProteinAtom       (nProteinAtom),                                                 
.nCLOSEATOM         (nCLOSEATOM)                      
) ForceNonBond
(
.IOclk         (IOclk),
.CalcClk       (CalcClk),
.MDReset       (MDReset_CalcClk),
.wrForceLUT    (wrForceLUT),    
.dataForceLUT  (dataForceLUT),  
.adrForceLUT   (adrForceLUT),   
.selForceLUT   (selForceLUT),    
//.ResetFtot     (ResetFtot[nPipe_ResetFtot]),
.AddFtot       (AddFtot[nPipe_AddFtot]),
.StoreFtot     (StoreFtot[nPipe_StoreFtot]),
.StoreFtot_out (StoreFtot_out),                
.closeAtom     (closeAtom_d0),
.pair14        (pair14_d0),        
.fudgeQQ       (fudgeQQ),          
.fudgeLJ       (fudgeLJ),                                     
.dx            (dx),
.dy            (dy),
.dz            (dz),
.iAtom1        (iAtom1[metaAtomNr_len-1:2]),       //lowest two bits not needed for exclude evaluation, 
.iAtom2        (iAtom2_d0),
.atomTypeLJ1   (atomTypeLJ1),
.atomTypeLJ2   (atomTypeLJ2_d0),
.charge1       (charge1),
.charge2       (charge2_d0),
.Fx_tot        (Fx_tot),
.Fy_tot        (Fy_tot), 
.Fz_tot        (Fz_tot)
);

//re-reshufle calculated forces so that that subroutine can be used for x,y,z directions
wire  [95:0] F_totReshuffle;
assign F_totReshuffle[32*q0 +:32] = Fx_tot;
assign F_totReshuffle[32*q1 +:32] = Fy_tot;
assign F_totReshuffle[32*q2 +:32] = Fz_tot;

//store results in output FIFO, for later usage
FIFO_async 
  #(
   .WIDTH(96),
   .DEPTH(64) 
   ) Force
  (                                               
  .rst(1'b0),
  .wr_clk(CalcClk),    
  .rd_clk(clk200MHz),        
  .din(F_totReshuffle),      
  .wr_en(StoreFtot_out),     
  .rd_en(fifoOut),  
  .dout(forceFifo),    
  .full(),            //should never become full due to slowDown logic
  .empty(forceReady),
  .prog_full()  
);



endmodule
