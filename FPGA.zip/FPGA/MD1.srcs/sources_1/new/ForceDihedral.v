`timescale 1ns / 1ps
//Calculates dihedral forces (sort of done for now)
//
//Definition of atom labels:
//
//                     l
//                    /
//                   / dx_kl
//          dx_kj  |/_
//       j<--------k
//      /
//     / dx_ij 
//   |/_ 
//   i   
//    
//calculates:
//  n_ijk = dx_ij \cross dx_kj
//  n_jkl = dx_kj \cross dx_kl

//  cos\phi  = (n_ijk.n_jkl)/(|n_ijk||n_ijk|)
//  sin\phi  = |dx_kj|*(dx_kl.n_ijk)/(|n_ijk||n_ijk|)
//  dV/d\phi = k1*sin\phi + k2*sin\phi*cos\phi + k3*sin\phi*cos^2\phi
//  
//  then, for inner atom (i.e., when dihedType=1):
//
//  Fj = dV/d\phi * [(|dx_kj|-(dx_ij.dx_kj)/|dx_kj|)/|n_ijk|*(n_ijk/|n_ijk|) - (dx_kl.dx_kj)/|dx_kj|/|n_jkl|*(n_jkl/|n_jkl|)]     (1)
//
//  or, if it is outer atom (i.e., when dihedType=0):
//
//  Fi = -dV/d\phi * |dx_kj|/|n_ijk|*(n_ijk/|n_ijk|)                                                                              (2)

//Remarks:
//- phi=0 corresponds to cis-configuration 
//- verified sign of sin-function and the resulting force
//- valid and tested distance range from about 24'sh013000 (r=0.019) to 24'sh0B0000 (r=0.17). Limiting aspect is  the claculation of 1/|n_ijk|,
//  which scales with 1/r^4, where r is a measure of overall size. Had to implement a range-shift for the corresponding submodule that calculates 1/sqrt |n_ijk|^2, 
//  otherwise range would have been too small 
//- in Eqs. 1 and 2, direct division by 1/|n_ijk|^2 would be problematic in terms of range. Divide prefactor by 1/|n_ijk| instead, and then multiply with normalized 
//  n_ijk/|n_ijk| in a separate step. Costs one extra multiplier  
//- tuned bit-ranges of all multiplications so that it is compatible with distance range.
//- Thoroughly tested. That is, tested effect of cycle time (5 vs 3 clock cycles per calculation), overflows in dependence of range and that for all intermediate steps, 
//  changing all input coordinates, changing all ki's, timing of ki's and dihedType -> deemed ok!
//- When k is given in kJ/mol/rad^2, needs to be multiplied with vshift*(10^-6)*dt^2/m_ref/rcut^2 to obtain the correct unit-less force.
//- range of k: largest dihedral potentials in Amber is about 44 kJ/mol for improper dihedrals, which has periodicity 2, so 88 kJ/mol. When allowing for dt=4fs, input 
//  range should be -1/512...1/512 (force constants can be negative). 
//- in case two parallel pipelines are needed for dihedrals, separate them as inner and outer atoms. The outer-atom version can delete some stuff related to Fl,
//  which saves some resources (not too many). Search for outer atom 


module ForceDihedral
(    
input                                     MDReset, 
input                                     clk,
input                                     AddFtot,       
output      reg                           ready=1'b1,  
input                                     StoreFtot,       
output                                    StoreFtot_out,   
input       signed [23:0]                 dxij,
input       signed [23:0]                 dyij,
input       signed [23:0]                 dzij,
input       signed [23:0]                 dxkj,
input       signed [23:0]                 dykj,
input       signed [23:0]                 dzkj,
input       signed [23:0]                 dxkl,
input       signed [23:0]                 dykl,
input       signed [23:0]                 dzkl,
input       signed [17:0]                 k1,            //range: -1/512....1/512; 18'h10000 corresponds to 1/1024  
input       signed [17:0]                 k2,            //range: -1/512....1/512; 18'h10000 corresponds to 1/1024 
input       signed [17:0]                 k3,            //range: -1/512....1/512; 18'h10000 corresponds to 1/1024 
input                                     dihedType,     //0: outer atom, 1: inner atom
output reg  signed [31:0]                 Fx_tot=1'b0,
output reg  signed [31:0]                 Fy_tot=1'b0, 
output reg  signed [31:0]                 Fz_tot=1'b0,
//output intermediate results for debugging
output wire signed  [24:0]                cos_out,
output wire signed  [24:0]                sin_out,
output wire signed  [24:0]                dVdphi_out,
output wire signed  [24:0]                Fi_out,
output wire signed  [24:0]                Fl_out
);


localparam r2_shift2         = 5;             //r2 shift for qunatities that depend on r^2 (e.g. |dx_kj|^2). Upper limit of range is 0.25; 
localparam r2_shift4         = 12;            //r2 shift for qunatities that depend on r^4 (e.g. |n_ijk|^2). Upper limit of range is 0.25/sqrt[2]=0.18;               
localparam cosphi_shift      = 14;
localparam sinphi_shift      = 14;              

localparam nPipeTot        = 59;              //total latency of force calculation, will change               
localparam nPipe_AddFtot   = nPipeTot-3;      //latency of reading data plus ForceNonBond;
localparam nPipe_StoreFtot = nPipeTot-2;        
localparam nPipe_dqkl      = 5; 
localparam nPipe_sin2      = 3; 
localparam nPipe_cos2      = 9;              
localparam nPipe_r2range   = 5; 
localparam nPipe_cos       = 5;
localparam nPipe_sin       = 8;
localparam nPipe_sincos    = 3;
localparam nPipe_k         = 38;
localparam nPipe_invR1ijk  = 6;
localparam nPipe_pijkj     = 6;
localparam nPipe_pklkj     = 7;
localparam nPipe_type      = 18;
localparam nPipe_r1kj      = 5; 
localparam nPipe_Fil       = 20;  
localparam nPipe1_nijk     = 16;   
localparam nPipe2_nijk     = 25;  


reg         [nPipe_AddFtot:0]   AddFtot_pipe    = 1'b0;
reg         [nPipe_StoreFtot:0] StoreFtot_pipe  = 1'b0;
reg         [nPipe_r2range:0]   r2range_pipe;
reg         [nPipe_type:0]      type_pipe;

reg  signed [24:0]              nijk_pipe1[nPipe1_nijk-1 :0];
reg  signed [24:0]              njkl_pipe1[nPipe1_nijk-1 :0];
reg  signed [24:0]              nijk_pipe2[nPipe2_nijk-1 :0];
reg  signed [24:0]              njkl_pipe2[nPipe2_nijk-1 :0];
reg  signed [24:0]              cos2[nPipe_cos2-1:0];
reg  signed [24:0]              sin2[nPipe_sin2-1:0];
reg  signed [24:0]              dq_kl[nPipe_dqkl-1:0];
reg  signed [24:0]              dq_ij[nPipe_dqkl-1:0];
reg  signed [24:0]              sin[nPipe_sin-1:0];
reg  signed [24:0]              cos[nPipe_cos-1:0];
reg  signed [24:0]              sincos[nPipe_sincos-1:0];
reg  signed [17:0]              k_pipe[nPipe_k-1:0];
reg         [23:0]              invR1_ijk[nPipe_invR1ijk-1:0];
reg  signed [24:0]              pijkj[nPipe_pijkj-1:0];
reg  signed [24:0]              pklkj[nPipe_pklkj-1:0];
reg  signed [24:0]              Fil_2[nPipe_Fil-1:0];
reg         [23:0]              r1_kj[nPipe_r1kj-1:0];  

integer                         i;
reg  signed [48:0]              Fx_tot_long=1'b0;
reg  signed [48:0]              Fy_tot_long=1'b0; 
reg  signed [48:0]              Fz_tot_long=1'b0;
reg  signed [48:0]              Fq;
reg                             FtotReset=1'b0;
reg  signed [24:0]              dVdphi;


assign                          StoreFtot_out = StoreFtot_pipe[nPipe_StoreFtot];
reg         [2:0]               StoreFtot_d1=1'b0;
reg                             StoreFtot_d2=1'b0;


reg  signed [47:0]              r2_ijk,r2_jkl,r2_jkl_d0,cos1,sin1;
reg         [25:0]              r2_tmp1,r2_kj; 
reg  signed [23:0]              f1_ij,f1_kj,f2_ij,f2_kj,f1_kl,f2_kl;
reg         [23:0]              invR1_jkl; 
reg         [23:0]              invR1;
reg  signed [24:0]              sin2_r1kj;
reg  signed [24:0]              Fil_1;
reg  signed [24:0]              Fi,Fi_d0,Fl;

reg signed  [17:0]              k2_d0,k3_d0,k3_d1;
reg signed  [23:0]              dxij_d0,dyij_d0,dzij_d0,dxkj_d0,dykj_d0,dzkj_d0,dxkl_d0,dykl_d0,dzkl_d0;
reg signed  [23:0]              dxij_d1,dyij_d1,dzij_d1,dxkj_d1,dykj_d1,dzkj_d1,dxkl_d1,dykl_d1,dzkl_d1;

//****************************Calculation pipeline*******************
  always @(posedge clk) begin       
    if (MDReset) ready <= 1'b1;
    else begin   
      case({AddFtot_pipe[1:0],AddFtot})         //send to mult1-7; all dq* need to be valid when AddFtot is asserted, and for the subsequent 2 cycles 
//level 1 of pipeline    
        3'b001: begin
          f1_ij        <= dyij;           //for nijk = dx_ij \times dx_kj; x-component
          f2_ij        <= dzij;
          f1_kj        <= dzkj;    
          f2_kj        <= dykj;    
          f1_kl        <= dzkl;           //for njkl = dx_kj \times dq_kl; x-component
          f2_kl        <= dykl;
          dq_ij[0]     <= dxij;
          dq_kl[0]     <= dxkl;
          dxij_d0      <= dxij;           //delay for later usage           
          dyij_d0      <= dyij; 
          dzij_d0      <= dzij;
          dxkj_d0      <= dxkj;  
          dykj_d0      <= dykj;    
          dzkj_d0      <= dzkj;  
          dxkl_d0      <= dxkl;  
          dykl_d0      <= dykl;           
          dzkl_d0      <= dzkl;       
          type_pipe[0] <= dihedType;  
          k_pipe[0]    <= k1;
          k2_d0        <= k2;
          k3_d0        <= k3;
          ready        <= 1'b0;
        end
//level 2 of pipeline          
        3'b010: begin
          f1_ij      <= dzij_d0;           //for nijk = dq_ij \times dq_kj; y-component
          f2_ij      <= dxij_d0;
          f1_kj      <= dxkj_d0;    
          f2_kj      <= dzkj_d0;    
          f1_kl      <= dxkl_d0;           //for njkl = dx_kj \times dx_kl; y-component
          f2_kl      <= dzkl_d0;
          dq_ij[0]   <= dyij_d0;    
          dq_kl[0]   <= dykl_d0;       
          dxij_d1    <= dxij_d0;           
          dyij_d1    <= dyij_d0; 
          dzij_d1    <= dzij_d0; 
          dxkj_d1    <= dxkj_d0;  
          dykj_d1    <= dykj_d0;    
          dxkl_d1    <= dxkl_d0;
          dykl_d1    <= dykl_d0;           
          dzkl_d1    <= dzkl_d0; 
          k_pipe[0]  <= k2_d0;
          k3_d1      <= k3_d0;
          ready      <= 1'b1;
        end
//level 3 of pipeline
        3'b100: begin
          f1_ij      <= dxij_d1;           //for nijk = dx_ij \times dx_kj; y-component
          f2_ij      <= dyij_d1;
          f1_kj      <= dykj_d1;    
          f2_kj      <= dxkj_d1;    
          f1_kl      <= dykl_d1;           //for njkl = dx_kj \times dx_kl; y-component
          f2_kl      <= dxkl_d1;
          dq_ij[0]   <= dzij_d1;
          dq_kl[0]   <= dzkl_d1;
          k_pipe[0]  <= k3_d1;       
        end      
      endcase
    end      
  end
 
  wire signed [49:0]    p1_1,p1_2,p2_1,p2_2,p3,p4,p5;
  mult_s25xs25_lat4     mult1    (.CLK(clk),.A({f1_ij,1'b0}),.B({f1_kj,1'b0}),.P(p1_1));   //for nijk = dx_ij \times dx_kj, used 3 times      
  mult_s25xs25_lat4     mult2    (.CLK(clk),.A({f2_ij,1'b0}),.B({f2_kj,1'b0}),.P(p1_2));       
  mult_s25xs25_lat4     mult3    (.CLK(clk),.A({f2_kj,1'b0}),.B({f1_kl,1'b0}),.P(p2_1));   //for njkl = dx_kj \times dx_kl, used 3 times      
  mult_s25xs25_lat4     mult4    (.CLK(clk),.A({f1_kj,1'b0}),.B({f2_kl,1'b0}),.P(p2_2));  
  mult_s25xs25_lat4     mult5    (.CLK(clk),.A({f1_kj,1'b0}),.B({f1_kj,1'b0}),.P(p3));    //for |dxjk|^2, used 3 times
  mult_s25xs25_lat4     mult6    (.CLK(clk),.A({f1_kj,1'b0}),.B({f2_ij,1'b0}),.P(p4));    //for dx_ij.dx_kj, used 3 times. not needed for outer atom
  mult_s25xs25_lat4     mult7    (.CLK(clk),.A({f2_kj,1'b0}),.B({f2_kl,1'b0}),.P(p5));    //for dx_kl.dx_kj, used 3 times. not needed for outer atom

  
//******************************************************************************************************
//do:      sqrt r2_kj^2,  dx_ij.dx_kj/|dx_kj|^2,  dx_kl.dx_kj/|dx_kj|^2                                                                             * 
//******************************************************************************************************
  reg  signed [47:0]  r2_kj_tmp,pijkj_tmp,pklkj_tmp;
  always @(posedge clk) begin  //collect results from multipier
    case(AddFtot_pipe[6:4])
//level 6 of pipeline   
      3'b001: begin
        r2_kj_tmp <= p3[48:1]; 
        pijkj_tmp <= p4[48:1];                           // not needed for outer atom
        pklkj_tmp <= p5[48:1];                           // not needed for outer atom
      end
//level 7 of pipeline   
      3'b010: begin
        r2_kj_tmp <= r2_kj_tmp + p3[48:1];  
        pijkj_tmp <= pijkj_tmp + p4[48:1];              // not needed for outer atom
        pklkj_tmp <= pklkj_tmp + p5[48:1];              // not needed for outer atom
      end
//level 8 of pipeline   
      3'b100: begin
        r2_kj_tmp <= r2_kj_tmp + p3[48:1];
        pijkj_tmp <= pijkj_tmp + p4[48:1];             // not needed for outer atom
        pklkj_tmp <= pklkj_tmp + p5[48:1];             // not needed for outer atom
      end      
    endcase  
  end  
  
 //level 9 of pipeline   
  always @(posedge clk) begin
    if(AddFtot_pipe[7]) begin
      r2_kj     <= (r2_kj_tmp[47:24]<(24'h0400000>>r2_shift2)) ? r2_kj_tmp[45-r2_shift2:20-r2_shift2] : 26'h3ffffff;  //treat overflow (cleaned up in comparison to forceStretch.v), valid range 0.01 to 0.25,
      pijkj[0]  <= pijkj_tmp[45-r2_shift2:21-r2_shift2];                                                              // not needed for outer atom
      pklkj[0]  <= pklkj_tmp[45-r2_shift2:21-r2_shift2];                                                              // not needed for outer atom                                                
    end  
  end
 
 //level 10 of pipeline   
  wire [25:0] r1_kj_tmp;
  wire [25:0] invR1_kj_tmp;
  LUTfunction2 #(.FUNCTIONTYPE1(1),.FUNCTIONTYPE2(0)) Sqrt_Inv (.clk(clk),.in(r2_kj),.out1(r1_kj_tmp),.out2(invR1_kj_tmp));   //latency is 6, only first function needed if it is outer atom
  wire [23:0] invR1_kj = invR1_kj_tmp[25:2];  
  
//most of the following is not needed if it is outer atom
reg signed [24:0] mult_tmp4;
  always @(posedge clk) begin       
     r1_kj[0] = r1_kj_tmp[25:2];       
     case(AddFtot_pipe[14:13])  
//level 15 of pipeline
      2'b01: begin   
        mult_tmp4 <= pijkj[nPipe_pijkj-1];
      end
//level 16 of pipeline      
      2'b10:begin
        mult_tmp4 <= pklkj[nPipe_pklkj-1];
      end
    endcase
  end     

//level 17 and 18 of pipline
  wire [49:0] mult_tmp5;
  mult_s25xs25_lat4 mult8 (.CLK(clk),.A({1'b0,invR1_kj}),.B(mult_tmp4),.P(mult_tmp5));  //used twice, calculates dx_ij.dx_kj/|dx_kj| and dx_kl.dx_kj/|dx_kj|. invR1_kj must be valid for both cycles
                                                                                        //in contrast to paper, divide by |dx_kj|, not |dx_kj|^2, since it is multiplied by |dx_kj| later on
  
  always @(posedge clk) begin    //funnel sin, sincos and sincos into mult19 to multiply with the 3 force constants                      
    case(AddFtot_pipe[19:18])  
//level 16 of pipeline
      2'b01: begin   
        Fil_1 <= type_pipe[nPipe_type] ? r1_kj[nPipe_r1kj-1]-mult_tmp5[45:21] : -r1_kj[nPipe_r1kj-1];   //pipeline Fi for later usage, from here on, everything related to Fl is not needed for outer atom
      end                                                                                               //(but doesn't save much, since most multiplier are double-usage
//level 17 of pipeline      
      2'b10:begin
        Fil_1 <= type_pipe[nPipe_type] ? mult_tmp5[45:21] : 1'b0;   //pipeline Fl for later usage     
      end
    endcase
  end       
  
  
  
//******************************************************************************************************
//done with:      sqrt r2_kj^2, pipeline for future usage                                              * 
//continue with:  r2_ijk^2, r2_jkl^2 and n_ijk.n_jkl                                                   *      
//******************************************************************************************************
  
//level 5-7 of pipeline 
  wire signed [28:0]    n_ijk = p1_1[48:20]-p1_2[48:20];
  wire signed [28:0]    n_jkl = p2_1[48:20]-p2_2[48:20];

  wire signed [49:0]    p_ijk,p_jkl,p_cos,p1_sin,p2_sin;
  mult_s25xs25_lat4     mult9    (.CLK(clk),.A(n_ijk[28:4]),.B(n_ijk[28:4]),.P(p_ijk));                 //for nijk.nijk, used 3 times      
  mult_s25xs25_lat4     mult10    (.CLK(clk),.A(n_jkl[28:4]),.B(n_jkl[28:4]),.P(p_jkl));                 //for njkl.njkl, used 3 times          
  mult_s25xs25_lat4     mult11    (.CLK(clk),.A(n_ijk[28:4]),.B(n_jkl[28:4]),.P(p_cos));                 //for nijk.njkl, used 3 times  
  mult_s25xs25_lat4     mult12    (.CLK(clk),.A(dq_kl[nPipe_dqkl-1]),.B(n_ijk[28:4]),.P(p1_sin));        //for dx_kl.njkl, used 3 times         
  mult_s25xs25_lat4     mult13    (.CLK(clk),.A(dq_ij[nPipe_dqkl-1]),.B(n_jkl[28:4]),.P(p2_sin));        //for dx_kl.njkl, used 3 times           
 
//level 6-8 of pipeline 
  always @(posedge clk) begin  //collect results from 1st set of multipier, and pipeline nijk and njkl for later usage, stream contains x,y,and z-coordinates 
    nijk_pipe1[0] <= n_ijk[24:0];  
    njkl_pipe1[0] <= n_jkl[24:0]; 
  end  
 
  always @(posedge clk) begin  //collect results from mult9-mult12
    case(AddFtot_pipe[10:8])
//level 10 of pipeline   
      3'b001: begin
        r2_ijk  <= p_ijk[48:1];
        r2_jkl  <= p_jkl[48:1]; 
        cos1    <= p_cos[48:1];  
        sin1    <= p1_sin[49:2] + p2_sin[49:2];  
      end
//level 11 of pipeline   
      3'b010: begin
        r2_ijk  <= r2_ijk + p_ijk[48:1];
        r2_jkl  <= r2_jkl + p_jkl[48:1]; 
        cos1    <= cos1 + p_cos[48:1];    
        sin1    <= sin1 + p1_sin[49:2] + p2_sin[49:2];  
      end
//level 12 of pipeline   
      3'b100: begin
        r2_ijk  <= r2_ijk + p_ijk[48:1];
        r2_jkl  <= r2_jkl + p_jkl[48:1]; 
        cos1    <= cos1 + p_cos[48:1];  
        sin1    <= sin1 + p1_sin[49:2] + p2_sin[49:2]; 
      end      
    endcase  
  end  

  always @(posedge clk) begin        //send r2_ijk^2 and r2_jkl^2 to LUTfunction2, in order to use it twice
    case(AddFtot_pipe[12:11])
      2'b01: begin                       //level 13 of pipeline 
        r2_tmp1     <= (r2_ijk[47:24]<(24'h200000>>r2_shift4)) ? r2_ijk[44-r2_shift4:19-r2_shift4] : 26'h3ffffff;  //treat overflow, cleaned up in comparison to forceStretch.v    
        cos2[0]     <= cos1[46-r2_shift4:22-r2_shift4];  //pipeline for later usage  //with that range, no overflows for current scaling of InvSqrtR2, but that might change
        sin2[0]     <= sin1[46-(r2_shift4-1):22-(r2_shift4-1)];
        r2_jkl_d0   <= r2_jkl;                              //is valid for one clock cycle only, so needs to be delayed
      end  
      2'b10:  begin                     //level 14 of pipeline  
        r2_tmp1     <= (r2_jkl_d0[47:24]<(24'h200000>>r2_shift4)) ? r2_jkl_d0[44-r2_shift4:19-r2_shift4] : 26'h3ffffff; 
      end          
    endcase
  end
  wire r2range=(r2_tmp1<26'h100000);                                         //upper part 9bits of r2_tmp1, which will be address of LUT in force calculation, is smaller than 8, which is when
                                                                             //LUT entries become unreliable. In that case, shift r2 up by 6bit (in which case it remains smaller than 9bit)

 //********************************************************************************************************
//Done:  r2_ijk^2, r2_jkl^2, n_ijk.n_jkl and dx_kl.n_ijk                                                   *
//********************************************************************************************************  

 //level 16 of pipeline                                                                                                                                               
  wire [49:0] sin2_r1kj_tmp;  
  mult_s25xs25_lat4 mult14 (.CLK(clk),.A(sin2[nPipe_sin2-1]),.B({1'b0,r1_kj_tmp[25:2]}),.P(sin2_r1kj_tmp));    //calculate |dx_kj|*sin2     

//level 20 of pipeline
  always @(posedge clk) begin
    sin2_r1kj <= sin2_r1kj_tmp[48:24];
  end
  
  
//************* calculate invR1_ijk and invR1_jkl ***************      
//level 14 + 15 of pipeline   
  wire [25:0] invR1_tmp;
  LUTfunction #(.FUNCTIONTYPE(0)) InvSqrt (.clk(clk),.in(r2range ? r2_tmp1<<6:r2_tmp1),.out(invR1_tmp)); //used 2 times for r*_ijk and r*_jkl, latency is 6
                                                                                                                                                                                                                                                                                                                           
//level 20 of pipeline
  always @(posedge clk) begin
    invR1     <= r2range_pipe[nPipe_r2range] ? invR1_tmp[25:2]<<1: invR1_tmp[25:2]>>2;          //compenstate for the r2 shift, but in order to avoid the numbers overflow, also downshift the result when when r2 has been above threshold 
    if(AddFtot_pipe[18]) begin                                                                  //collect result for r2_ijk 
      invR1_ijk[0] <= r2range_pipe[nPipe_r2range] ? invR1_tmp[25:2]<<1: invR1_tmp[25:2]>>2;     //compenstate for the r2 shift, but in order to avoid the numbers overflow, also downshift the result when when r2 has been above threshold                                                      
    end  
  end  

//level 21 of pipeline  
  always @(posedge clk) begin       
    if(AddFtot_pipe[19]) begin                                                          //collect result for r2_jkl
      invR1_jkl <= r2range_pipe[nPipe_r2range] ? invR1_tmp[25:2]<<1: invR1_tmp[25:2]>>2;
    end  
  end  
 
 //************* calculate Fil_2 from invR1_ijk and invR1_jkl ***************      
//level 21 and 22 of pipeline   
  wire [49:0] Fil_tmp2;
  mult_s25xs25_lat4 mult15 (.CLK(clk),.A({1'b0,invR1}),.B(Fil_1),.P(Fil_tmp2));   //calculate Fi_1/|n_ijk| and Fl_1/|n_jkl|, respectively 

//level 25 and 26 of pipeline
  always @(posedge clk) begin 
    Fil_2[0] <= Fil_tmp2[45:21];               //pipeline for later usage, adjusted bit range so it works at the lower disance range limit                                                                                
  end
 
  reg signed [24:0] mult_tmp1;
  always @(posedge clk) begin    //funnel sin, sincos and sincos into mult19 to multiply with the 3 force constants                      
     case(AddFtot_pipe[20:19])  
//level 21 of pipeline
      2'b01: begin   
        mult_tmp1 <= sin2_r1kj;
      end
//level 22 of pipeline      
      2'b10:begin
        mult_tmp1 <= cos2[nPipe_cos2-1];
      end
    endcase
  end     

//************* normalize n_ijk and n_jkl with invR1_ijk and invR1_jkl ***********  
  wire [49:0] nijk_tmp1,njkl_tmp1;
  mult_s25xs25_lat4 mult16 (.CLK(clk),.A({1'b0,invR1_ijk[1]}),.B(nijk_pipe1[nPipe1_nijk-1]),.P(nijk_tmp1));  //used 3 times for x,y, and z-coordinates
  mult_s25xs25_lat4 mult17 (.CLK(clk),.A({1'b0,invR1_jkl}),.B(njkl_pipe1[nPipe1_nijk-1]),.P(njkl_tmp1));     //used 3 times for x,y, and z-coordinates
  
  always @(posedge clk) begin 
    nijk_pipe2[0] <= nijk_tmp1[39:15];      
    njkl_pipe2[0] <= njkl_tmp1[39:15];                                                                                         
  end
  

//************* calculate sin and cos from invR1_ijk and invR1_jkl ***************  
//level 22 and 23 of pipline
  wire [49:0] mult_tmp2;
  mult_s25xs25_lat4 mult18 (.CLK(clk),.A({1'b0,invR1_jkl}),.B( mult_tmp1),.P(mult_tmp2));  //used twice, calculates |dx_kj|*sin2/|n_ijk| and cos2/|n_ijk|. invR1_jkl must be valid for both cycles
  
//level 26 of 27 pipline
  wire [49:0] mult_tmp3;
  mult_s25xs25_lat4 mult19 (.CLK(clk),.A({1'b0,invR1_ijk[nPipe_invR1ijk-1]}),.B( mult_tmp2[48:24]),.P(mult_tmp3));  //used twice, calculates |dx_kj|*sin2/|n_ijk|/|n_jkl| and cos2/|n_ijk||n_jkl|. invR1_ijk must be valid for both cycles
  
  always @(posedge clk) begin    //funnel sin, sincos and sincos into mult19 to multiply with the 3 force constants                      
    case(AddFtot_pipe[29:28])  
//level 30 of pipeline
      2'b01: begin   
        sin[0] <= mult_tmp3[48-sinphi_shift:24-sinphi_shift];   //range +/-2; 
      end
//level 31 of pipeline      
      2'b10:begin
        cos[0] <= mult_tmp3[48-cosphi_shift:24-cosphi_shift];        //range +/-2;    
      end
    endcase
  end     
  assign sin_out=sin[1];
  assign cos_out=cos[0];
 
//********************************************************************************************************
//Done with:  sin\phi and cos\phi                                                                        *
//********************************************************************************************************  

//level 32 of pipeline
  wire [49:0] sincos_tmp;
  mult_s25xs25_lat4 mult20 (.CLK(clk),.A(cos[0]),.B(sin[1]),.P(sincos_tmp));   //calculates sinphi*cosphi
 
//level 36 of pipeline  
  always @(posedge clk) begin                          
    sincos[0] <= sincos_tmp[47:23];        //range +/-2;       
  end  
  
  wire [49:0] sincos2;
  mult_s25xs25_lat4 mult21 (.CLK(clk),.A(cos[nPipe_cos-1]),.B(sincos_tmp[47:23]),.P(sincos2)); //calculates sin\phi*cos^2\phi

  reg signed [24:0] dVdphi_in;
  always @(posedge clk) begin    //funnel sin, sincos and sincos into mult21 to multiply with the 3 force constants                      
     case(AddFtot_pipe[38:36])
//level 38 of pipeline
       3'b001: begin       
         dVdphi_in <= sin[nPipe_sin-1];
       end
//level 39 of pipeline
       3'b010: begin       
         dVdphi_in <= sincos[nPipe_sincos-1];
       end
//level 40 of pipeline
       3'b100: begin       
         dVdphi_in <= sincos2[47:23];
       end
    endcase   
  end  
 
  wire [42:0] dVdphi_tmp1;
  mult_s25xs18_lat3 mult22 (.CLK(clk),.A(dVdphi_in),.B(k_pipe[nPipe_k-1]),.P(dVdphi_tmp1));  //used 3 times, calculates k_i with sin, sincos and sincos2
  
  reg [24:0] dVdphi_tmp2;
  always @(posedge clk) begin                       
     case(AddFtot_pipe[42:40])
//level 42 of pipeline
       3'b001: begin       
         dVdphi_tmp2 <= dVdphi_tmp1[41:17];
       end
//level 43 of pipeline
       3'b010: begin       
         dVdphi_tmp2 <= dVdphi_tmp2 + dVdphi_tmp1[41:17];
       end
//level 44 of pipeline
       3'b100: begin       
         dVdphi <= dVdphi_tmp2 + dVdphi_tmp1[41:17];                      //range +/-4
       end
    endcase   
  end  
  assign dVdphi_out = dVdphi;
  
//********************************************************************************************************
//Done with:  A1 sin\phi +  A2 sin\phi cos\phi + A3 sin\phi cos^2\phi                                    *
//********************************************************************************************************   
  
 //level 45 of pipeline 
  wire [49:0] Fil_tmp3;
  mult_s25xs25_lat4 mult23 (.CLK(clk),.A(dVdphi),.B(Fil_2[nPipe_Fil-1]),.P(Fil_tmp3)); //calculates dV/d\phi*Fi_2 and dV/d\phi*Fi_2, respectively
  
  always @(posedge clk) begin    //funnel sin, sincos and sincos into mult19 to multiply with the 3 force constants                      
     case(AddFtot_pipe[48:47])
//level 49 of pipeline
       2'b01: begin       
         Fi_d0 <= Fil_tmp3[47:23];   //bit range adjusted so it works for the lower disance range limit and the largest possible dVdphi
       end
//level 50 of pipeline
       2'b10: begin
         Fi <= Fi_d0;       
         Fl <= Fil_tmp3[47:23];
       end
    endcase   
  end  
  assign Fi_out=Fi;
  assign Fl_out=Fl;
   
//level 51 of pipeline
  wire [49:0] Fi_tmp1,Fl_tmp1;
  mult_s25xs25_lat4 mult24 (.CLK(clk),.A(Fi),.B(nijk_pipe2[nPipe2_nijk-1]),.P(Fi_tmp1)); 
  mult_s25xs25_lat4 mult25 (.CLK(clk),.A(Fl),.B(njkl_pipe2[nPipe2_nijk-1]),.P(Fl_tmp1));
   
//level 55 of pipeline
  always @(posedge clk) begin
    Fq <= Fi_tmp1[48:0] - Fl_tmp1[48:0];
  end
  
//level 56,57,58 of pipeline
  always @(posedge clk) begin
    if(FtotReset) begin
      Fx_tot_long <= 1'b0;
      Fy_tot_long <= 1'b0;
      Fz_tot_long <= 1'b0;
    end else begin
//accumulating all forces   
      case(AddFtot_pipe[nPipe_AddFtot:nPipe_AddFtot-2])
        3'b001: Fx_tot_long <= Fx_tot_long + Fq;      //level 56 of pipeline
        3'b010: Fy_tot_long <= Fy_tot_long + Fq;      //level 57 of pipeline
        3'b100: Fz_tot_long <= Fz_tot_long + Fq;      //level 58 of pipeline
      endcase
    end  
  end     
  
//level 59 of pipeline,   
  always @(posedge clk) begin
    if (StoreFtot_pipe[nPipe_StoreFtot-1]) begin
      Fx_tot <= Fx_tot_long[47:16] + {31'b0,Fx_tot_long[15]};   
      Fy_tot <= Fy_tot_long[47:16] + {31'b0,Fy_tot_long[15]};   
      Fz_tot <= Fz_tot_long[47:16] + {31'b0,Fz_tot_long[15]};
    end    
  end
  


//*********************************************************shift intermediate results for later usage**************************************************************
always @(posedge clk) begin 

   for(i=1;i<=nPipe1_nijk-1;i=i+1) begin   
     nijk_pipe1[i]      <= nijk_pipe1[i-1];
     njkl_pipe1[i]      <= njkl_pipe1[i-1];
   end 
      
   for(i=1;i<=nPipe2_nijk-1;i=i+1) begin       
     nijk_pipe2[i]      <= nijk_pipe2[i-1];
     njkl_pipe2[i]      <= njkl_pipe2[i-1];
   end 

   for(i=1;i<=nPipe_invR1ijk-1;i=i+1) begin   
     invR1_ijk[i]<=invR1_ijk[i-1];
   end 

   for(i=1;i<=nPipe_cos2-1;i=i+1) begin   
     cos2[i]<=cos2[i-1];
   end 
   
   for(i=1;i<=nPipe_sin2-1;i=i+1) begin   
     sin2[i]<=sin2[i-1];
   end 
   
   for(i=1;i<=nPipe_cos-1;i=i+1) begin   
     cos[i]<=cos[i-1];
   end 
   
   for(i=1;i<=nPipe_sin-1;i=i+1) begin   
     sin[i]<=sin[i-1];
   end 
   
   for(i=1;i<=nPipe_sincos-1;i=i+1) begin   
     sincos[i]<=sincos[i-1];
   end 
   
   for(i=1;i<=nPipe_dqkl-1;i=i+1) begin   
     dq_kl[i]<=dq_kl[i-1];
     dq_ij[i]<=dq_ij[i-1];
   end 
   
   for(i=1;i<=nPipe_k-1;i=i+1) begin   
     k_pipe[i]<=k_pipe[i-1];
   end 
   
   for(i=1;i<=nPipe_pijkj-1;i=i+1) begin   
     pijkj[i]<=pijkj[i-1];
   end 
   
   for(i=1;i<=nPipe_pklkj-1;i=i+1) begin   
     pklkj[i]<=pklkj[i-1];
   end 
 
   for(i=1;i<=nPipe_Fil-1;i=i+1) begin   
     Fil_2[i]<=Fil_2[i-1];
   end 
   
   for(i=1;i<=nPipe_r1kj-1;i=i+1) begin   
     r1_kj[i]<=r1_kj[i-1];
   end 
 
   type_pipe[nPipe_type:1] <= type_pipe[nPipe_type-1:0]; 
    
   AddFtot_pipe   <= {AddFtot_pipe[nPipe_AddFtot-1:0],AddFtot};         
   StoreFtot_pipe <= {StoreFtot_pipe[nPipe_StoreFtot-1:0],StoreFtot}; 
   r2range_pipe   <= {r2range_pipe[nPipe_r2range-1:0],r2range}; 
   FtotReset <= StoreFtot_pipe[nPipe_StoreFtot-2]||MDReset;
 end   
    
endmodule
