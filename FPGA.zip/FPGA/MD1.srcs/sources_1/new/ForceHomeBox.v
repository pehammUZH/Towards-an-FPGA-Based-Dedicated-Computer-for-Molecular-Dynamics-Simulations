`timescale 1ns / 1ps

//-pipeline for calculation of the non-bonded forces with atoms in home box. 
//-FIFO-buffered at the input (i.e., coordinates and metadata of atom in the homebox) as well as the output (i.e, forces on that atom)
// to adjust for time-mismatch of the various pipelines. Is initiated with start_i2, and forceReady indicates that force data are ready 
// in the output FIFO.
//-Overall similar structure as neigboring boxes
//-Actual force calculation is done in an universal submodule ForceNonBond. 
//


module ForceHomeBox
#(   
  parameter DataByteWidth_n    = 5'd18,  //width of the memories containing neigboring box data, i.e., coordinates and meta-data
  parameter nSelForceLUT       = 3,      //width of SelForceLUT 
  parameter metaAtomNr_len     = 16,     //length of atom number in meta data;
  parameter metaAtomTypeLJ     = 18,     //atomType for LJ
  parameter metaAtomTypeLJ_len = 5,     
  parameter metaCharge         = 24,     //charge
  parameter metaCharge_len     = 18,    
  parameter nProteinAtom       = 12,     //defines maximum number of protein atoms: 2^nProteinAtom                                           
  parameter nCLOSEATOM         = 21      //maximum number of closeAtoms
)
(
  input                                 IOclk,
  input                                 CalcClk, 
  input                                 clk200MHz,
  input                                 DDR3clk,           
  input                                 MDReset,
//input that writes into Force-LUT
  input                                 wrForceLUT,    
  input   [8:0]                         dataForceLUT,  
  input   [11:0]                        adrForceLUT,   
  input   [nSelForceLUT-1:0]            selForceLUT,      
//write atom2 data into BRAM; on IOclk
  input                                 data_valid,          //data valid
  input                                 iHalf,               //iHalf on IOclk
  input   [7:0]                         nAtom,               //total number of data, is a running index during writing, upper nAtom if iHalf=1, and lower nAtom if iHalf=0 
  input   [DataByteWidth_n*8-1:0]       dataIn,              //data
//write atom1 data into FIFO; on IOclk
  input                                 start_i2,            //(x1,y1,z1)-data ready to write into input FIFO, on IOclk
  input   [DataByteWidth_n*8-1:0]       dataHome,            //(x1,y1,z1)-data, contains coordinates and metadata, on IOclk
//closeAtom, for exclusion in ForceNonBond
  input                                 closeAtom_rcv,        //closeAtom valid, on DDR3clk,   
  input   [nCLOSEATOM*nProteinAtom-1:0] closeAtom,            //closeAtom data, on DDR3clk, 
  input   [nCLOSEATOM-1:0]              pair14,               //close atoms that are in pair list, used to calculated fudged nonbonded forces  
  input   [16:0]                        fudgeQQ,              //fudging factor for Coulomb; 0x10000 corresponds to 1                           
  input                                 fudgeLJ,              //fudging factor for LJ; is 1.0 when fudgeLJ=1, or 0.5 when fudgeLJ=0             
//Calculation pipeline; on CalcClk
  input                                 iHalf_CalcClk,       //iHalf on CalcClk for reading
  input   [7:0]                         nAtom_CalcClk,       //nAtom corresponding to ~iHalf_CalcClk, upper nAtom if iHalf=0, and lower nAtom if iHalf=1 
  output                                forceReady,          //force calculation done
  input                                 fifoOut,             //trigger output FIFO to send data
  output  [95:0]                        forceFifo,           //calculated forces
  output                                slowDown             //input FIFO almost full, tell master pipeline to slow down
);


reg         [7:0]                    MDadr_000    = 1'b0; 
reg         [8:0]                    adr_000      = 1'b0;
reg         [7:0]                    nAtomCalc_m1 = 1'b0;
reg         [7:0]                    nAtomCalc_m2 = 1'b0;
reg         [2:0]                    HomeState    = 1'b0;
reg                                  fifoDataOut  = 1'b0;

reg         [metaAtomTypeLJ_len-1:0] atomTypeLJ2,atomTypeLJ2_d0;
reg  signed [metaCharge_len-1:0]     charge2,charge2_d0;
reg  signed [23:0]                   dx = 1'b0, dy = 1'b0, dz = 1'b0;
reg  signed [23:0]                   x2 = 1'b0, y2 = 1'b0, z2 = 1'b0;
reg         [metaAtomNr_len-1:0]     iAtom2, iAtom2_d0;

reg                                  AddFtot =1'b0;
reg                                  StoreFtot  = 1'b0;
reg                                  i2Done     = 1'b0;
reg         [7:0]                    i2 = 1'b0;



ClkTransfer #(.extend (2)) ClkTransfer1
(
    .clkIn   (IOclk),
    .clkOut  (CalcClk),
    .sigIn   (MDReset),
    .sigOut  (MDReset_CalcClk)
); 


//******************************input data FIFO************************
//contains atom1 data; has an almost-full option, that will tell the master-pipeline in MDmachine to slow down. 
wire        [DataByteWidth_n*8-1:0] dataHome1;
FIFO_async 
  #(
   .WIDTH(DataByteWidth_n*8),
   .DEPTH(64),
   .PROG_FULL_THRESH(55)
   ) atom1FIFO
(
  .rst(1'b0),
  .wr_clk(IOclk),      
  .din(dataHome),      
  .wr_en(start_i2),  
  .rd_clk(CalcClk),
  .rd_en(fifoDataOut),  
  .dout(dataHome1),    
  .full(),    
  .empty(atomDataReady),  
  .prog_full(slowDown)
);
   
   

wire signed [23:0]                   x1          = dataHome1[24*0 +:24];
wire signed [23:0]                   y1          = dataHome1[24*1 +:24];
wire signed [23:0]                   z1          = dataHome1[24*2 +:24];
wire        [metaAtomTypeLJ_len-1:0] atomTypeLJ1 = dataHome1[24*3+metaAtomTypeLJ +:metaAtomTypeLJ_len];
wire signed [metaCharge_len-1:0]     charge1     = dataHome1[24*3+metaCharge +: metaCharge_len];
wire        [metaAtomNr_len-1:0]     iAtom1      = dataHome1[24*3 +:metaAtomNr_len];



//buffers closeAtom and pair14 data.                                     
wire [nCLOSEATOM*(nProteinAtom+1)-1:0] closeAtomFIFO_Out;               
FIFO_async 
  #(
   .WIDTH(nCLOSEATOM*(nProteinAtom+1)),
   .DEPTH(64) 
   ) closeAtomFIFO
  (                                              
  .rst(1'b0),
  .wr_clk(DDR3clk),      
  .din({pair14,closeAtom}),      
  .wr_en(closeAtom_rcv),  
  .rd_clk(CalcClk),
  .rd_en(fifoDataOut),  
  .dout(closeAtomFIFO_Out),    
  .full(),    
  .empty(closeAtomReady),  
  .prog_full()                   //doesn't need extra slow-down, since that should go in parallel with atom1FIFO   
  ); 


wire [nCLOSEATOM*nProteinAtom-1:0] closeAtom_d0 = closeAtomFIFO_Out[nCLOSEATOM*nProteinAtom-1:0];            
wire [nCLOSEATOM-1:0]              pair14_d0    = closeAtomFIFO_Out[nCLOSEATOM*nProteinAtom +:nCLOSEATOM]; 

//***********************************Bram for atom2 data*************************************
wire        [DataByteWidth_n*8-1:0] dataHome2;
bram_144x512_simple_dual homeMemory (.clka(IOclk),.ena(1'b1),.wea(data_valid) ,.addra({iHalf,nAtom}),.dina(dataIn),.clkb(CalcClk),.enb(1'b1),.addrb({~iHalf_CalcClk,MDadr_000}),.doutb(dataHome2));


always @(posedge CalcClk) begin
   case (HomeState)
      0: begin                         //idle
        MDadr_000      <= 1'b0;
        StoreFtot      <= 1'b0;
        i2             <= 1'b0;
        if(~(atomDataReady||closeAtomReady)) begin   //start when both FIFOs with atom data and corresponding closeAtom have received data
          fifoDataOut  <= 1'b1;
          HomeState    <= HomeState + 1'b1;
          nAtomCalc_m1 <= nAtom_CalcClk-1'b1;
          nAtomCalc_m2 <= nAtom_CalcClk-8'h2;
        end    
      end         
      1,2: begin     //wait cycles to account for latency of memory 
        fifoDataOut  <= 1'b0;
        MDadr_000    <= MDadr_000 + 1'b1; 
        HomeState    <= HomeState + 1'b1;
      end   
      3: begin                            
        MDadr_000    <= MDadr_000 + 1'b1;
        x2           <= dataHome2[24*0 +:24];
        y2           <= dataHome2[24*1 +:24];
        z2           <= dataHome2[24*2 +:24];
        atomTypeLJ2  <= dataHome2[24*3+metaAtomTypeLJ +:metaAtomTypeLJ_len];
        charge2      <= dataHome2[24*3+metaCharge     +: metaCharge_len];
        iAtom2       <= dataHome2[24*3                +: metaAtomNr_len];
        HomeState    <= HomeState + 1'b1;
        i2Done       <= (nAtomCalc_m1==1'b0);  
      end
      4: begin                     //do homebox calculation
        dx              <= x2-x1;  //enters into ForceNonBond
        dy              <= y2-y1;
        dz              <= z2-z1;
        atomTypeLJ2_d0  <= atomTypeLJ2;
        charge2_d0      <= charge2;
        iAtom2_d0       <= iAtom2;
        MDadr_000       <= MDadr_000 + 1'b1;
        x2              <= dataHome2[24*0 +:24];
        y2              <= dataHome2[24*1 +:24];
        z2              <= dataHome2[24*2 +:24];
        atomTypeLJ2     <= dataHome2[24*3+metaAtomTypeLJ +:metaAtomTypeLJ_len];
        charge2         <= dataHome2[24*3+metaCharge     +: metaCharge_len];
        iAtom2          <= dataHome2[24*3                +: metaAtomNr_len];
        i2              <= i2 + 1'b1;
        i2Done          <= (i2==nAtomCalc_m2);
        AddFtot         <= 1'b1;
        if(i2Done) begin      
          HomeState    <= HomeState + 1'b1;
        end     
      end
      5: begin
        StoreFtot     <= 1'b1;    
        AddFtot       <= 1'b0;    
        HomeState     <= 1'b0; 
      end  
    endcase
end





//******************************actual force calculation************************
wire signed [31:0]    Fx_tot, Fy_tot, Fz_tot; 
ForceNonBond 
#(
.nSelForceLUT   (nSelForceLUT),
.metaAtomNr_len (metaAtomNr_len),
.nProteinAtom   (nProteinAtom),                                                
.nCLOSEATOM     (nCLOSEATOM)                     
) ForceNonBond
(
.IOclk         (IOclk),
.CalcClk       (CalcClk),
.MDReset       (MDReset_CalcClk),
.wrForceLUT    (wrForceLUT),    
.dataForceLUT  (dataForceLUT),  
.adrForceLUT   (adrForceLUT),   
.selForceLUT   (selForceLUT),    
.AddFtot       (AddFtot), 
.StoreFtot     (StoreFtot),
.StoreFtot_out (StoreFtot_out), 
.closeAtom     (closeAtom_d0),     
.pair14        (pair14_d0),        
.fudgeQQ       (fudgeQQ),          
.fudgeLJ       (fudgeLJ),                 
.dx            (dx),
.dy            (dy),
.dz            (dz),
.iAtom1        (iAtom1[metaAtomNr_len-1:2]),       //lowest two bits not needed for exclude evaluation,                 
.iAtom2        (iAtom2_d0),
.atomTypeLJ1   (atomTypeLJ1),
.atomTypeLJ2   (atomTypeLJ2_d0),
.charge1       (charge1),
.charge2       (charge2_d0),
.Fx_tot        (Fx_tot),
.Fy_tot        (Fy_tot), 
.Fz_tot        (Fz_tot)
);


FIFO_async 
  #(
   .WIDTH(96),
   .DEPTH(64) 
   ) ForceHome
  (                                               
  .rst(1'b0),
  .wr_clk(CalcClk),    
  .rd_clk(clk200MHz),  
  .din({Fz_tot,Fy_tot,Fx_tot}),      
  .wr_en(StoreFtot_out),     
  .rd_en(fifoOut),  
  .dout(forceFifo),    
  .full(),    
  .empty(forceReady),  
  .prog_full()
);
  
endmodule
