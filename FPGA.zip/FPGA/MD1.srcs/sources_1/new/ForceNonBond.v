`timescale 1ns / 1ps

//Force calculation; starts from (dx,dy,dy) and accumulates (Fx_tot,Fy_tot_Fz_tot). 
//StoreFtot_out sets (Fx_tot,Fy_tot_Fz_tot)=0, and AddFtot is a signal that says that data are valid.
//structure of pipeline is shown in ForceNonBond_LJCoul.pdf 
//
//Latency  is nPipeTot=27. Latency is the number of clock cycles from (dx,dy,dy) until (Fx_tot,Fy_tot,Fz_tot) are valid.
//Control signals AddFtot and StoreFtot  are delayed inside routine in dependence of nPipeTot. ForceNonBondHome 
//called in MDMachine is the reference for that. AddFtot appears at the input at the same time as dx, and StoreFtot one cycle after the last AddFtot. 
//Timing in ForceBox_* is different, hence the routines have a proper pre-delay of those signals
//
//excludes are evaluation in two ways: Either, both iAtom2 and iAtom1 both <2^nProteinAtom and iAtom2 is in the closeAtom list, or iAtom2 and iAtom1 both 
//>=2^nProteinAtom and for all except of the lowest two bits iAtom2 == iAtom1. In that case, they are in the same constraint group, and the space >=2^nProteinAtom 
//is reserved for water only. For that evaluation, the lowest two bits of iAtom1 are in fact not needed, and hence is not transmitted.
//Furthermore, if both atoms are protein atoms with iAtom2 is in the closeAtom list, and the corresponding pair-bit is set, that overwrites exclude and the forces 
//are only reduced by fudging factor, not set to zero. 
//
//Fixed-point representation:
//q1,q2: 18'h10000 corresponds to 1, range +/-2
//invr2: 17'h04000 corresponds to 1, range 0...8
//eLJ:   17'h10000 corresponds to 1, range 0...2

//adresses selForceLUT:
//3'h0:  Lennard Jones Force
//3'h1:  Coulomb Force
//3'h3:  LJtype LUT containing LennradJones distance and binding energy in dependence of atomType[1] and atmoType[2] 

//Equivalent C-type code (sort of):
//
//void ForceNonBond (int24 dx, int24 dy, int24 dz, uint iAtom1, uint iAtom2, uint5 atomType1, uint5 atomType2, int18 q1, int18 q2,
//                   bool AddFtot, bool StoreFtot_in, bool *StoreFtot_out, int32 *Fx_tot, int32 *Fy_tot, int32 *Fz_tot)                                                                                      
//{                                                                                               
//  dx2        = dx * dx 
//  dy2        = dy * dy                                                      
//  dz2        = dz * dz                                           
//  1/r2LJ     = LUT_LJatom[atomType2,atomType1][17:0]
//  eLJ        = LUT_LJatom[atomType2,atomType1][34:18]                                
//  q12        = charge1 * charge2 
//  if(isPair(iAtom1,iAtom2))
//  {
//       eLJ = eLJ * fudgeLJ
//       q12 = q12 * fudgeQQ
//  }                                                   
//  r2         = dx2 + dy2 + dz2   
//  r2s        = r2*(1/r2LJ)  
//  if(r2s<1) 
//       LJ    = funcLJ(r2s);
//  else      
//       LJ    = 0;
//  if(r2<1)  
//       Coul  = funcCoul(r2s);
//  else      
//       Coul  = 0;
//  LJ_scale   = eLJ * LJ;
//  Coul_scale = q12 * Coul
//  if(exclude==0)
//     Force    = LJ_scale + Coul_scale;
//  else
//     Force   = 0;                                                           
//  Fx         = dx * Force;  
//  Fy         = dy * Force;                                             
//  Fz         = dz * Force; 
//  if(StoreFtot_out) 
//  {                                                                          
//    Fx_tot   = 0;                                                             
//    Fy_tot   = 0;                                                             
//    Fz_tot   = 0;                                                             
//  }                                                                          
//  else if (AddFtot)                                                             
//  {                                                                         
//    Fx_tot  += Fx;                                                           
//    Fy_tot  += Fy;                                                           
//    Fz_tot  += Fz;                                                           
//  }               
//}


module ForceNonBond
#(
parameter  nSelForceLUT       = 3,      //width of SelForceLUT 
parameter  metaAtomNr_len     = 16,      //length of atom number in meta data;     
parameter  nProteinAtom       = 12,     //defines maximum number of protein atoms: 2^nProteinAtom                                           
parameter  nCLOSEATOM         = 21      //maximum number of closeAtoms, which is floor(256/(nProteinAtom+1))            
)
(
input                                            IOclk,         
input                                            CalcClk,
input                                            MDReset,
//input that writes into Force-LUT; on IOclk
input                                            wrForceLUT,    
input              [8:0]                         dataForceLUT, 
input              [11:0]                        adrForceLUT,     
input              [nSelForceLUT-1:0]            selForceLUT,     
//signals controlling force calculation, on CalcClk
input                                            AddFtot,         
input                                            StoreFtot,       
output                                           StoreFtot_out,   
//stuff related to handling atoms within 3 chemical bonds
input              [metaAtomNr_len-3:0]          iAtom1,      //lowest two bits not needed for exclude evaluation
input              [metaAtomNr_len-1:0]          iAtom2,                                              
input              [nCLOSEATOM*nProteinAtom-1:0] closeAtom,   //list of all close atoms within 3 bonds    
input              [nCLOSEATOM-1:0]              pair14,      //if it is in pair list, forces are reduced by fudging factor           //is new
input              [16:0]                        fudgeQQ,     //fudging factor for Coulomb; 0x10000 corresponds to 1                  //is new
input                                            fudgeLJ,     //fudging factor for LJ; is 1.0 when fudgeLJ=1, or 0.5 when fudgeLJ=0   //is new       
//input atom data    
input       signed [23:0]                        dx,
input       signed [23:0]                        dy,
input       signed [23:0]                        dz,
input              [4:0]                         atomTypeLJ1,     
input              [4:0]                         atomTypeLJ2,     
input       signed [17:0]                        charge1,         
input       signed [17:0]                        charge2,                      
output reg  signed [31:0]                        Fx_tot=1'b0,
output reg  signed [31:0]                        Fy_tot=1'b0, 
output reg  signed [31:0]                        Fz_tot=1'b0
);


localparam nPipe_dq        = 21;  //for dx,dy,dz; 
localparam nPipe_range     = 5;
localparam nPipe_eLJ       = 15; 
localparam nPipe_q12       = 11;  //is new, used to be 14
localparam nPipe_r2        = 4; 
//localparam nPipe_Force     = 3;
localparam nPipe_invr2     = 4;

localparam nPipeTot        = 27;              //total latency of force calculation
localparam nPipe_AddFtot   = nPipeTot-3;      //latency of reading data plus ForceNonBond;
localparam nPipe_StoreFtot = nPipeTot-2;   

integer                         i;
reg  signed [48:0]              Fx_tot_long = 1'b0;
reg  signed [48:0]              Fy_tot_long = 1'b0; 
reg  signed [48:0]              Fz_tot_long = 1'b0;
reg  signed [47:0]              dz2_d0;
reg  signed [47:0]              r2_tmp1 = 1'b0, r2_tmp2 = 1'b0;
wire signed [29:0]              r2;  
wire        [46:0]              r2s_tmp;
wire        [30:0]              r2s;
reg         [16:0]              r2s_d0;
reg         [16:0]              r2s_d1;
reg         [16:0]              r2_d0;
reg         [16:0]              r2_d1;
reg         [nPipe_range:0]     r2srange_pipe;
reg         [nPipe_range:0]     r2range_pipe;
reg  signed [23:0]              dx_pipe[nPipe_dq-1:0] ,dy_pipe[nPipe_dq-1:0] ,dz_pipe[nPipe_dq-1:0];               
reg         [16:0]              eLJ_pipe[nPipe_eLJ-1:0];
wire signed [35:0]              q12;  
wire signed [35:0]              q12_fudge;  
reg  signed [17:0]              q12_pipe[nPipe_q12-1:0];
reg  signed [29:0]              r2_pipe[nPipe_r2-1:0];
reg  signed [23:0]              LJ;
reg  signed [23:0]              Coul;
wire signed [42:0]              LJ_scale;
wire signed [42:0]              Coul_scale;      
reg  signed [24:0]              LJpCoul;
wire        [35:0]              LUT_LJatom_all; 
reg         [16:0]              invr2_pipe[nPipe_invr2-1:0];   
reg         [nPipe_AddFtot:0]   AddFtot_pipe    = 1'b0;
reg         [nPipe_StoreFtot:0] StoreFtot_pipe  = 1'b0;
assign                          StoreFtot_out = StoreFtot_pipe[nPipe_StoreFtot];
reg                             FtotReset=1'b0;
reg                             exclude=1'b0;
reg                             fudge=1'b0;
reg                             exclude_d0=1'b0;
reg                             fudge_d0=1'b0;
reg         [nCLOSEATOM-1:0]    near14=1'b0;
reg                             excludeWater=1'b0;   
reg                             isProtein=1'b0;
reg         [nCLOSEATOM-1:0]    pair14_d0;  


wire [16:0] fudgeQQ_d0;
ClkTransferStat #(.Width (17))  ClkTransferStat1  //is new
(
    .clkIn   (IOclk),
    .clkOut  (CalcClk),
    .sigIn   (fudgeQQ),
    .sigOut  (fudgeQQ_d0)
); 

wire fudgeLJ_d0;
ClkTransferStat #(.Width (1))  ClkTransferStat2  //is new
(
    .clkIn   (IOclk),
    .clkOut  (CalcClk),
    .sigIn   (fudgeLJ),
    .sigOut  (fudgeLJ_d0)
); 

//****************************Calculation pipeline******************* 
  
//level 1 of pipeline 
  always @(posedge CalcClk) begin
    isProtein     <= (iAtom2[metaAtomNr_len-1:nProteinAtom]==1'b0)&&(iAtom1[metaAtomNr_len-3:nProteinAtom-2]==1'b0);    //both are protein atoms
    excludeWater  <= (iAtom1 == iAtom2[metaAtomNr_len-1:2]);                                                            //waters are within a 4bit constraint group; 
    pair14_d0     <= pair14;                                                                                            //is new
    for(i=0;i<nCLOSEATOM;i=i+1) begin
      near14[i] <= (iAtom2[nProteinAtom-1:0]==closeAtom[i*nProteinAtom+:nProteinAtom]);  
    end
    dx_pipe[0]    <= dx;
    dy_pipe[0]    <= dy;
    dz_pipe[0]    <= dz;
  end
  bram_9x4096_36x1024 LUT_LJatom  (.clka(IOclk),.ena(selForceLUT==2'h3),.wea(wrForceLUT),.addra(adrForceLUT),.dina(dataForceLUT),.clkb(CalcClk),.enb(1'b1),.addrb({atomTypeLJ2,atomTypeLJ1}),.doutb(LUT_LJatom_all));
 
  wire signed [49:0]              dx2, dy2, dz2;
  mult_s25xs25_lat4   mult_dx2    (.CLK(CalcClk),.A({dx,1'b0}),.B({dx,1'b0}),.P(dx2));         
  mult_s25xs25_lat4   mult_dy2    (.CLK(CalcClk),.A({dy,1'b0}),.B({dy,1'b0}),.P(dy2));
  mult_s25xs25_lat4   mult_dz2    (.CLK(CalcClk),.A({dz,1'b0}),.B({dz,1'b0}),.P(dz2));
  mult_s18xs18_lat3   mult_q12    (.CLK(CalcClk),.A(charge1),.B(charge2),.P(q12));     

//level 2 of pipeline 
  always @(posedge CalcClk) begin
    exclude  <=  (isProtein&&(|(near14&(~pair14_d0))))||(~isProtein&&excludeWater);    //Coulomb and LJ forces are set to 0                     //is new
    fudge    <=  (isProtein&&(|(near14&( pair14_d0))));                                //Coulomb and LJ forces are reduced by fudging factor    //is new
  end
  
//level 3 of pipeline  
  always @(posedge CalcClk) begin  
    exclude_d0     <= exclude;                                                                                                                 //is new
    fudge_d0       <= fudge;                                                                                                                   //is new
    invr2_pipe[0]  <= LUT_LJatom_all[16:0];
    eLJ_pipe[0]    <= exclude ? 17'b0 : ((fudge &&(~fudgeLJ_d0)) ? {1'b0,LUT_LJatom_all[34:19]} : LUT_LJatom_all[34:18]); //if exclude==1, is set to 0, otherwise if fudge&&(fudgeLJ==0) is diveded by 2.   //is new
                                                                                                                          //possible fudgeLJ is only 1 or 0.5, hence doen't need multiplication
  end  

//level 4 of pipeline    
  wire [17:0] fudgeFact = exclude_d0 ? 18'b0 : (fudge_d0 ? {1'b0,fudgeQQ_d0} : 18'h10000);                  //if exclude==1, mulify 0, otherwise if fudge==1 multiply with fudgeQQ, otherwise multiply with 1. 
  mult_s18xs18_lat3   mult_fudgeQQ    (.CLK(CalcClk),.A(q12[34:17]),.B(fudgeFact),.P(q12_fudge));    //multiply coulomb force with fudging factor when is in pair listm or set to zero when excluded     //is new
  
   
//level 5 of pipeline
  always @(posedge CalcClk) begin
    r2_tmp1 <= dx2[49:2] + dy2[49:2];  
    dz2_d0  <= dz2[49:2];
  end  

//level 6 of pipeline
  always @(posedge CalcClk) begin
    r2_tmp2 <= r2_tmp1 + dz2_d0;  
  end
  assign r2 = r2_tmp2[47:18];   
   
//level 7 of pipeline      
  always @(posedge CalcClk) begin  
    q12_pipe[0]  <= q12_fudge[33:16]; //range: +/-4                                                      //is new
    r2_pipe[0]   <= r2;
  end  
  mult_u30xu17 mult_rLJ (.CLK(CalcClk),.A(r2),.B(invr2_pipe[nPipe_invr2-1]),.P(r2s_tmp)); 
  assign r2s = r2s_tmp[44:14];
  

//level 11 of pipeline
  always @(posedge CalcClk) begin
    r2srange_pipe[0] <= (r2s<31'h4000000);
    r2range_pipe[0]  <= (r2_pipe[nPipe_r2-1]<30'h4000000);
  end
  
  wire [25:0] LJ_tmp1, Coul_tmp1;
  LUTfunctionProg LUT_LJ  (.IOclk(IOclk),.selForceLUT(selForceLUT==2'h0),.wrForceLUT(wrForceLUT),.adrForceLUT(adrForceLUT),.dataForceLUT(dataForceLUT),.clk(CalcClk),.in(r2s[25:0]),.out(LJ_tmp1));
  LUTfunctionProg Coul_LJ (.IOclk(IOclk),.selForceLUT(selForceLUT==2'h1),.wrForceLUT(wrForceLUT),.adrForceLUT(adrForceLUT),.dataForceLUT(dataForceLUT),.clk(CalcClk),.in(r2_pipe[nPipe_r2-1][25:0]),.out(Coul_tmp1));

//level 17 of pipeline
  always @(posedge CalcClk) begin
    LJ   <= r2srange_pipe[nPipe_range] ? LJ_tmp1[25:2]     : 24'h000000;
    Coul <= r2range_pipe[nPipe_range]  ? Coul_tmp1[25:2]   : 24'h000000;
  end  

//level 18 of pipeline
  mult_s25xs18_lat3 mult_LJs   (.CLK(CalcClk),.A({LJ[23],LJ})    ,.B({1'b0,eLJ_pipe[nPipe_eLJ-1]}),.P(LJ_scale));       //LJ_scale[41:17] gives the proper scale
  mult_s25xs18_lat3 mult_Couls (.CLK(CalcClk),.A({Coul[23],Coul}),.B(q12_pipe[nPipe_q12-1])       ,.P(Coul_scale));     //Coul_scale[40:16] gives the proper scale
  
//level 21 of pipeline
  always @(posedge CalcClk) begin
    LJpCoul <= LJ_scale[41:17] + Coul_scale[40:16];                                                      //is new
  end  

//level 22 of pipeline  
  wire signed [49:0]   Fx, Fy, Fz;
  mult_s25xs25_lat4    mult_Fx (.CLK(CalcClk),.A(LJpCoul),.B({dx_pipe[nPipe_dq-1],1'b0}),.P(Fx));  
  mult_s25xs25_lat4    mult_Fy (.CLK(CalcClk),.A(LJpCoul),.B({dy_pipe[nPipe_dq-1],1'b0}),.P(Fy));  
  mult_s25xs25_lat4    mult_Fz (.CLK(CalcClk),.A(LJpCoul),.B({dz_pipe[nPipe_dq-1],1'b0}),.P(Fz));  
  
  
//level 26 of pipeline
  always @(posedge CalcClk) begin
    if(FtotReset) begin
      Fx_tot_long <= 1'b0;
      Fy_tot_long <= 1'b0;
      Fz_tot_long <= 1'b0;
    end else if (AddFtot_pipe[nPipe_AddFtot]) begin
//accumulating all forces   
      Fx_tot_long <= Fx_tot_long + Fx[49:1];
      Fy_tot_long <= Fy_tot_long + Fy[49:1];
      Fz_tot_long <= Fz_tot_long + Fz[49:1];   
//output actual force only, for debugging. In next block, if(StoreFtot_pipe[nPipe_StoreFtot-1]) needs to be coemmented out when used
 //     Fx_tot_long <=  Fx[49:1];
 //     Fy_tot_long <=  Fy[49:1];
 //     Fz_tot_long <=  Fz[49:1];
    end  
  end     
  
 //level 27 of pipeline,   
  always @(posedge CalcClk) begin
    if(StoreFtot_pipe[nPipe_StoreFtot-1]) begin              //needs to be commented out for debugging as well
      Fx_tot <= Fx_tot_long[44:13] + {31'b0,Fx_tot_long[12]};   //32 bit in range +/-1 (in Fx_tot_long, three extra bits are generated  due to signed 24*24 mult, multiplication with eLJ, and the extra bit in dx
      Fy_tot <= Fy_tot_long[44:13] + {31'b0,Fy_tot_long[12]};   
      Fz_tot <= Fz_tot_long[44:13] + {31'b0,Fz_tot_long[12]};
    end  
  end

//*********************************************************shift intermediate results for later usage**************************************************************
always @(posedge CalcClk) begin
   for(i=1;i<=nPipe_dq-1;i=i+1) begin   
       dx_pipe[i]<=dx_pipe[i-1];
       dy_pipe[i]<=dy_pipe[i-1];
       dz_pipe[i]<=dz_pipe[i-1];
    end 
  
 
    for(i=1;i<=nPipe_range;i=i+1) begin   
       r2srange_pipe[i]<= r2srange_pipe[i-1];
       r2range_pipe[i] <= r2range_pipe[i-1];
    end  
    
    for(i=1;i<=nPipe_eLJ-1;i=i+1) begin   
       eLJ_pipe[i]<=eLJ_pipe[i-1];
    end
    
    for(i=1;i<=nPipe_q12-1;i=i+1) begin   
       q12_pipe[i]<=q12_pipe[i-1];
    end
    
    for(i=1;i<=nPipe_r2-1;i=i+1) begin   
       r2_pipe[i]<=r2_pipe[i-1];
    end
      
    for(i=1;i<=nPipe_invr2-1;i=i+1) begin   
       invr2_pipe[i]<=invr2_pipe[i-1];
    end
 
    
   AddFtot_pipe   <= {AddFtot_pipe[nPipe_AddFtot-1:0],AddFtot};      
   StoreFtot_pipe <= {StoreFtot_pipe[nPipe_StoreFtot-1:0],StoreFtot};   
   FtotReset <= StoreFtot_pipe[nPipe_StoreFtot-2]||MDReset;
 end   
    
endmodule
