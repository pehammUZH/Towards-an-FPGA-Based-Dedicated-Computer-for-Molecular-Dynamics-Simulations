`timescale 1ns / 1ps

//Calculates harmonic stretch force:
//  Fx=k(1-r0/sqrt(r^2))dx 
//starts from (dx,dy,dy) and accumulates (Fx_tot,Fy_tot_Fz_tot). 
//AddFtot is a signal that says that data are valid and should be added.
//Calculation is not fully pipelined to save resources. That is, mult_dq2 and mult_fq do claculation for dx, dy, and dz  
//separated by one clock cycle. Thus, it can accept input data only for every 3rd clock cycle. The ready-signal indicates that new data 
//can be sent for the next clock cycle. Structure of pipeline is shown in ForceStretch.pdf 
//
//Latency is nPipeTot=31. Latency is the number of clock cycles from (dx,dy,dy) until (Fx_tot,Fy_tot,Fz_tot) are valid.
//Control signals AddFtot and StoreFtot and are delayed inside routine in dependence of nPipeTot. AddFtot appears at the input at the same time as dx,dy,dz, 
//and StoreFtot one cycle after the last AddFtot. 
//
//Fixed-point representation:
//parameters r2_shift  =4 and invSqrtR2_shift=6 defines range of function. That is, valid r-range is ~rcut/2^(r2_shift/2)/10...rcut/2^(r2_shift/2),
//and the output of InvSqrtR2 is 1/sqrt(r2)/2^invSqrtR2_shift. The latter corresponds to an r_ref=rcut/8, i.e., half of the valid range.
//Parameters of the bond potential:
//Bond equilibrium distance r0:  range 0...2, 17'h10000 corresponds to 1,   defined relative to r_ref=rcut/8                
//Force constant             k:  range 0...16, 17'h02000 corresponds to 1,   when k is given in kJ/mol, needs to be multiplied with vshift*(10^-6)*dt^2/m_ref 
//                                                                          to obtain the correct unit-less forces. With range 0...8, allows timesteps of dt=4fs
//                                                                          for typical force constants, but that will generate overflow issues with the 32bit 
//                                                                          representation when bomd distance is too far from equilibrium distance, so use with care. 
//Frequency in 1/ps is f=1/2Pi sqrt(k/mu), where mu is reduced mass in atomic units and k the force constnat in kJ/mol/nm^2.  



//Equivalent C-type code:
//
//void ForceNonBond (int24 dx, int24 dy, int24 dz, uint17 r0, uint17 r0, bool AddFtot, bool ResetFtot, bool StoreFtot_in,
//                   int32 *Fx_tot, int32 *Fy_tot, int32 *Fz_tot)                                                                                      
//{                                                                                               
//  dx2        = dx * dx 
//  dy2        = dy * dy                                                      
//  dz2        = dz * dz                                                                                          
//  r2         = dx2 + dy2 + dz2           
//  if(r2>=1/16) r2=1/16;
//  iR         = InvSqrt(R2);
//  Force      = k*(1-iR*r0);
//  Fx         = dx * Force;  
//  Fy         = dy * Force;                                             
//  Fz         = dz * Force; 
//  if(ResetFtot) 
//  {                                                                          
//    Fx_tot   = 0;                                                             
//    Fy_tot   = 0;                                                             
//    Fz_tot   = 0;                                                             
//  }                                                                          
//  else if (AddFtot)                                                             
//  {                                                                         
//    Fx_tot  += Fx;                                                           
//    Fy_tot  += Fy;                                                           
//    Fz_tot  += Fz;                                                           
//  }               
//}

//ToDos:


module ForceStretch
(       
input                                     clk,
input                                     MDReset,    
input                                     AddFtot,         
output      reg                           ready=1'b1,             //ready to accept new data      
input                                     StoreFtot,       
output                                    StoreFtot_out,   
input       signed [23:0]                 dx,
input       signed [23:0]                 dy,
input       signed [23:0]                 dz,
input              [16:0]                 r0,              
input              [16:0]                 k,              
output reg  signed [31:0]                 Fx_tot=1'b0,
output reg  signed [31:0]                 Fy_tot=1'b0, 
output reg  signed [31:0]                 Fz_tot=1'b0
);


localparam r2_shift  =4;                    
localparam invSqrtR2_shift =6;                   


localparam nPipe_dq        = 23;               
localparam nPipe_k         = 20;                           
localparam nPipe_r0        = 16;                                                   

localparam nPipeTot        = 31;              //total latency of force calculation                
localparam nPipe_AddFtot   = nPipeTot-3;      //latency of reading data plus ForceNonBond;
localparam nPipe_StoreFtot = nPipeTot-2;      

integer                         i;
reg  signed [48:0]              Fx_tot_long = 1'b0;
reg  signed [48:0]              Fy_tot_long = 1'b0; 
reg  signed [48:0]              Fz_tot_long = 1'b0;
reg  signed [23:0]              dy_d0, dz_d0, dz_d1;

reg  signed [47:0]              r2_tmp = 1'b0;
reg  signed [29:0]              r2;  
reg  signed [23:0]              iR;
reg  signed [24:0]              iR_d1;
reg                             FtotReset=1'b0;



//all shift register
reg  signed [23:0]              dq_pipe[nPipe_dq-1:0]; 
reg         [16:0]              k_pipe[nPipe_k-1:0];
reg         [16:0]              r0_pipe[nPipe_r0-1:0];
reg         [nPipe_AddFtot:0]   AddFtot_pipe    = 1'b0;
reg         [nPipe_StoreFtot:0] StoreFtot_pipe  = 1'b0;
assign                          StoreFtot_out = StoreFtot_pipe[nPipe_StoreFtot];
//****************************Calculation pipeline******************* 
 
  always @(posedge clk) begin       
    if (MDReset) ready <= 1'b1;
    else begin   
      case({AddFtot_pipe[1:0],AddFtot})
//level 1 of pipeline    
        3'b001: begin
          ready      <= 1'b0;
          dq_pipe[0] <= dx;
          dy_d0      <= dy;
          dz_d0      <= dz;
          k_pipe[0]  <= k;
          r0_pipe[0] <= r0;
        end
//level 2 of pipeline          
        3'b010: begin
           ready      <= 1'b1;
           dq_pipe[0] <= dy_d0;
           dz_d1      <= dz_d0;
        end
//level 3 of pipeline
        3'b100: begin
           dq_pipe[0] <= dz_d1;
        end      
      endcase
    end      
  end
  
  wire signed [49:0]  dq2;
  mult_s25xs25_lat4   mult_dq2    (.CLK(clk),.A({dq_pipe[0],1'b0}),.B({dq_pipe[0],1'b0}),.P(dq2));      //is used 3 times for dx, dy and dz    

  always @(posedge clk) begin  //collect results from multipier
    case(AddFtot_pipe[6:4])
//level 6 of pipeline   
      3'b001: begin
        r2_tmp <= dq2[49:2];  
      end
//level 7 of pipeline   
      3'b010: begin
        r2_tmp <= r2_tmp + dq2[49:2];  
      end
//level 8 of pipeline   
      3'b100: begin
        r2_tmp <= r2_tmp + dq2[49:2];
      end      
    endcase  
  end  
  
//level 9 of pipeline    
 always @(posedge clk) begin
   if(AddFtot_pipe[7]) begin
     r2 <= (r2_tmp[47:18]<(31'h4000000>>r2_shift)) ? r2_tmp[47-r2_shift:18-r2_shift] : 31'h3ffffff;  //treat overflow
   end  
 end
 
//level 10 of pipeline  
  wire [25:0] iR_tmp;
  LUTfunction #(.FUNCTIONTYPE(0)) InvSqrt (.clk(clk),.in(r2[25:0]),.out(iR_tmp));

//level 16 of pipeline
  always @(posedge clk) begin
    iR   <= iR_tmp[25:2];
  end  

  
//level 17 of pipeline
  wire  signed [42:0] iR_d0;
  mult_s25xs18_lat3 mult_rs   (.CLK(clk),.A({1'b0,iR}),.B({1'b0,r0_pipe[nPipe_r0-1]}),.P(iR_d0));  
//  mult_s25xs18_lat3 mult_r   (.CLK(clk),.A({iR[23],iR}),.B({1'b0,r0_pipe[nPipe_r0-1]}),.P(iR_d0));     //iR[23] is a bug, which however //has minor effect
                                                                                                         
//level 20 of pipeline
  always @(posedge clk) begin
    iR_d1   <= (25'h400000>>(invSqrtR2_shift-3))-iR_d0[41:17];         
  end  
  
//level 21 of pipeline
  wire signed [42:0] Force;
  mult_s25xs18_lat3 mult_k   (.CLK(clk),.A(iR_d1),.B({1'b0,k_pipe[nPipe_k-1]}),.P(Force));         

//level 24 of pipeline
  wire signed [49:0] Fq;
  mult_s25xs25_lat4  mult_Fq (.CLK(clk),.A(Force[43-(invSqrtR2_shift-2):19-(invSqrtR2_shift-2)]),.B({dq_pipe[nPipe_dq-1],1'b0}),.P(Fq));  //is used three times for dx,dy,dz

//level 28,29,30 of pipeline
  always @(posedge clk) begin
    if(FtotReset) begin  
      Fx_tot_long <= 1'b0;
      Fy_tot_long <= 1'b0;
      Fz_tot_long <= 1'b0;
    end else begin
//accumulating all forces   
      case(AddFtot_pipe[nPipe_AddFtot:nPipe_AddFtot-2])     
        3'b001: Fx_tot_long <= Fx_tot_long + Fq[48:0];      //level 28 of pipeline
        3'b010: Fy_tot_long <= Fy_tot_long + Fq[48:0];      //level 29 of pipeline
        3'b100: Fz_tot_long <= Fz_tot_long + Fq[48:0];      //level 30 of pipeline
      endcase
//output actual force only, for debugging. The way how the current testbank  works, with StoreFtot asserted every 3 cycles, 
//-x-component is always zero, but y- and z- components work even when  accumulating all forces          
//     case(AddFtot_pipe[nPipe_AddFtot-1:nPipe_AddFtot-3])
//        3'b001: Fx_tot_long <=  Fq[49:1];                   //level 28 of pipeline
//        3'b010: Fy_tot_long <=  Fq[49:1];                   //level 29 of pipeline
//        3'b100: Fz_tot_long <=  Fq[49:1];                   //level 30 of pipeline
//      endcase
    end  
  end     
  
//level 31 of pipeline,   
  always @(posedge clk) begin
    if(StoreFtot_pipe[nPipe_StoreFtot-1]) begin
      Fx_tot <= Fx_tot_long[40:9] + {31'b0,Fx_tot_long[8]};   
      Fy_tot <= Fy_tot_long[40:9] + {31'b0,Fy_tot_long[8]};    
      Fz_tot <= Fz_tot_long[40:9] + {31'b0,Fz_tot_long[8]}; 
    end    
  end

//*********************************************************shift intermediate results for later usage**************************************************************
always @(posedge clk) begin
   for(i=1;i<=nPipe_dq-1;i=i+1) begin   
       dq_pipe[i]<=dq_pipe[i-1];
    end 
    
    for(i=1;i<=nPipe_r0-1;i=i+1) begin   
       r0_pipe[i]<=r0_pipe[i-1];
    end 
    
    for(i=1;i<=nPipe_k-1;i=i+1) begin   
       k_pipe[i]<=k_pipe[i-1];
    end 

   AddFtot_pipe   <= {AddFtot_pipe[nPipe_AddFtot-1:0],AddFtot};         
   StoreFtot_pipe <= {StoreFtot_pipe[nPipe_StoreFtot-1:0],StoreFtot};  
   
   FtotReset <= StoreFtot_pipe[nPipe_StoreFtot-2]||MDReset;
 end   
    
endmodule
