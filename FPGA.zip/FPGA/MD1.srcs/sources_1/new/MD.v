
`include "MDSwitches.h" 

module MD   
(   
 input                           sys_clk_p,                    //system clock positive
 input                           sys_clk_n,                    //system clock negative 
 output[1:0]                     led,                          //display network rate status
 output                          ledFPGA, 
 input                           key1,                         //push botton
 input [7:0]                     DipSwitch,      
 input                           Fan,     
 inout                           AllBusyExt11,   
 inout                           errorRxSyncExt11,  
 inout                           AllBusyExt12,   
 inout                           errorRxSyncExt12,   
 inout                           AllBusyExt2,   
 inout                           errorRxSyncExt2,       
//ethernet 1
 output                          e1_reset,                     //phy reset
 output                          e1_mdc,                       //phy emdio clock
 inout                           e1_mdio,                      //phy emdio data
 input	                         e1_rx_clk_from_pins,          //ethernet rx clock
 input                           e1_rx_dv_from_pins,           //recieving data valid
 input [7:0]                     e1_rxd_from_pins,             //recieving data          
 output                          e1_tx_clk_to_pins,            //gmii tx clock  
 output                          e1_tx_en_to_pins,             //ethernet sending data valid  
 output                          e1_tx_er,                     //ethernet error    
 output[7:0]                     e1_txd_to_pins,               //ethernet sending data 
//ethernet 3
 output                          e3_reset,                      //phy reset
 output                          e3_mdc,                        //phy emdio clock
 inout                           e3_mdio,                       //phy emdio data
 input	                         e3_rx_clk_from_pins,           //ethernet rx clock
 input                           e3_rx_dv_from_pins,            //recieving data valid
 input [7:0]                     e3_rxd_from_pins,              //recieving data          
 output                          e3_tx_clk_to_pins,             //gmii tx clock  
 output                          e3_tx_en_to_pins,              //ethernet sending data valid    
 output                          e3_tx_er,                      //ethernet error
 output[7:0]                     e3_txd_to_pins,                //ethernet sending data 
//ethernet 4
 output                          e4_reset,                      //phy reset
 output                          e4_mdc,                        //phy emdio clock
 inout                           e4_mdio,                       //phy emdio data
 input	                         e4_rx_clk_from_pins,           //ethernet rx clock
 input                           e4_rx_dv_from_pins,            //recieving data valid
 input [7:0]                     e4_rxd_from_pins,              //recieving data          
 output                          e4_tx_clk_to_pins,             //gmii tx clock  
 output                          e4_tx_en_to_pins,              //ethernet sending data valid    
 output                          e4_tx_er,                      //ethernet error
 output[7:0]                     e4_txd_to_pins,                //ethernet sending data 
//GTP interfaces
 output[3:0]                     gtp_tx_disable,        
 input                           Q0_CLK0_GTREFCLK_PAD_N_IN,
 input                           Q0_CLK0_GTREFCLK_PAD_P_IN,
 input [3:0]                     RXN_IN, 
 input [3:0]                     RXP_IN,
 output[3:0]                     TXN_OUT,
 output[3:0]                     TXP_OUT,
//DDR3-pins; comment out when using reduced BRAM version of mem_burst
 inout  [31:0]                   ddr3_dq,                    //ddr3 data
 inout  [3:0]                    ddr3_dqs_n,                 //ddr3 dqs negative
 inout  [3:0]                    ddr3_dqs_p,                 //ddr3 dqs positive
 output [14:0]                   ddr3_addr,                  //ddr3 address
 output [2:0]                    ddr3_ba,                    //ddr3 bank
 output                          ddr3_ras_n,                 //ddr3 ras_n
 output                          ddr3_cas_n,                 //ddr3 cas_n
 output                          ddr3_we_n,                  //ddr3 write enable 
 output                          ddr3_reset_n,               //ddr3 reset,
 output [0:0]                    ddr3_ck_p,                  //ddr3 clock negative
 output [0:0]                    ddr3_ck_n,                  //ddr3 clock positive
 output [0:0]                    ddr3_cke,                   //ddr3_cke,
 output [0:0]                    ddr3_cs_n,                  //ddr3 chip select,
 output [3:0]                    ddr3_dm,                    //ddr3_dm
 output [0:0]                    ddr3_odt                    //ddr3_odt
);  

//(* MARK_DEBUG="true" *)
parameter Version             = 8'd24;

parameter DataByteWidth       = 27;      //width of data buses, e.g. 3*24bit to describe atom meta data, (xyz) coordinates and xyz velocities
parameter DataByteWidth_n     = 18;      //reduced data width of neigboring boxes, without velocities
parameter EnsembleByteWidth   = 5'd15;   //width of ensemble data
parameter nBlock              = 50;      //length of a block to be sent at once by UDP; nBlock*DataByteWidth needs to be smaller than about 1500byte
parameter nBox                = 5'd27;   //number of neigboring boxes together with home box
parameter vshift              = 4;       //shift of velocites vs positions. Actual shift is vshift+1, since velocities are defined +/-1, while
                                         //positions are define +/-2. 
parameter nSelForceLUT        = 3;       //width of SelForceLUT 

//position of information in meta data
parameter  metaAtomNr_len     = 16;      //length of atom number in meta data; starts at 0. 2bit reserve
parameter  metaAtomTypeLJ     = 18;      //atomType for LJ
parameter  metaAtomTypeLJ_len = 5;       //its length, leave one bit of reserve
parameter  metaCharge         = 24;      //posiiton of charge in meta data
parameter  metaCharge_len     = 18;      //its length 
parameter  metaMass           = 42;      //position of mass in meta data
parameter  metaMass_len       = 6;       //its length; 16bit reserve
parameter  metaConstraint     = 48;      //position of contraint info in meta data
parameter  metaRoute          = 64;      //information for which box to route; 6bit needed

//stuff for bonded interactions
parameter  DDR3_DATA_WIDTH    = 256;     //data width of DDR3 Ram
parameter  nProteinAtom       = 12;      //2^nProteinAtom is maximum number of protein atoms, whose coordinates are stored indexed by atom number 
                                         //the calculation of bonded inteaction   
parameter  FF_LENGTH          = 36;      //number of force field lines, i.e., 2 more than maximum number of dihedrall interactions.         
parameter  FF_WIDTH           = 6;       //2^FF_WIDTH = Log2(FF_LENGTH)+1
parameter  nCLOSEATOM         = 24;      //maximum number of closeAtoms. 21 is sufficient for villin headpiece; can be increased to maximum 31                                         
parameter  CLOSEATOM_WIDTH    = 5;        //CLOSEATOM_WIDTH=Floor(Log2(nCLOSEATOM))+1  


//Datastructure:
//|                             nProteinAtom                             |
//|        |                    DataByteWidth_n                          |
//|24|24|24| 2r+6|  13r  |    3     |  6 | 18   | 1r+5 | 2r+16|24|24|24|    (*r stands for reserve bits)
//|vz|vy|vz|route|reserve|constraint|mass|charge|LJtype|atomNr| z| y| x|


//************************************wire connecting sub-modules**************************************************
 wire [7:0]                     PacketNr,PacketNrOld;
 wire [DataByteWidth*8-1:0]     DataIn;
 wire [DataByteWidth*8-1:0]     DataHome;

 wire                           nAtomReset;
 wire [47:0]                    errorAll;
 wire [1:0]                     speed1, speed3, speed4;  
 wire [nBox*8-1:0]              nAtom;
 wire [nBox-1:0]                data_valid;
 wire [7:0]                     ETH_error;
 wire [11:0]                    gtp_error;
 wire [DataByteWidth_n*8-1:0]   e3_data_recv,e4_data_recv;
 wire [DataByteWidth_n*8-1:0]   gtp0_data_recv,gtp1_data_recv,gtp2_data_recv,gtp3_data_recv;
 reg                            fan_error=1'b0;    
 reg                            ResetStart=1'b1;
 wire                           Broadcast_busy;
 wire                           MDReset;
 
 wire [7:0]                     SendMacAdr;
 wire [DataByteWidth*8-1:0]     DataSendMac;
 wire [0:0]                     SendMacBox;
 wire                           StartMac;
 wire [7:0]                     nSendMac;
 
 wire [15:0]                    nstep;
 wire [15:0]                    istep;
 wire                           InitCalc;
 wire                           CalcBusy;
 wire                           SyncOut;
 wire [DataByteWidth*8-1:0]     newData;
 wire                           newDataReady;
 wire                           AllBusyIn;
 wire                           errorRxReset;    
 wire                           errorRxSync;
 wire [79:0]                    errorRxCnt;
 wire                           errorRxSyncIn;
 wire [2:0]                     overflowError;
 wire                           wrForceLUT;    
 wire [8:0]                     dataForceLUT;  
 wire [11:0]                    adrForceLUT;   
 wire [nSelForceLUT-1:0]        selForceLUT;    
 assign                         gtp_tx_disable = 4'b0;
 
 wire [EnsembleByteWidth*8-1:0] EnsembleData;           //Ensemble daa such as temperature, etc. 
 wire                           EnsembleReady;                       
 wire [EnsembleByteWidth*8-1:0] EnsembleNeighbor;
 wire                           EnsembleNeighborValid;
 wire [71+nProteinAtom:0]       dataProteinAtom;
 wire                           dataProteinAtom_valid;
 
 wire                           WriteDataThermostat;
 wire [2:0]                     AdrDataThermostat;
 wire [31:0]                    DataThermostat;
 
 wire                           WriteSimParam;
 wire [3:0]                     AdrSimParam;
 wire [16:0]                    SimParam;          
 
 wire [10:0]                    CommandCnt;
 wire                           CommandValid;
 wire [7:0]                     CommandData;     
 wire [7:0]                     MD_error;
 
 
 wire [7:0]                     nShakeTot;
 wire [15:0]                    nIterTot;
 wire [15:0]                    ForceField_cnt; 
 wire                           ForceField_rcv;   
 wire [nProteinAtom-1:0]        ForceField_atom;  
 wire [DDR3_DATA_WIDTH - 1:0]   ForceField_data;   
 
//****************************************clocks****************************************
IBUFDS sys_clk_ibufgds
(
.I                              (sys_clk_p),
.IB                             (sys_clk_n),
.O                              (sys_clk_d0)
);

BUFG sysclk (
    .I(sys_clk_d0),   
    .O(sys_clk)  
);

clk_wiz_0 clkGeneration
   (
    .clk_out1(CalcClk),     // for claculations, 300MHz
    .clk_out2(IOclk),       // for IO, 100MHz
    .clk_out3(clk200MHz),   // for IDELAYCTRL, 200MHz
    .reset(1'b0),           // input reset
    .clk_in1(sys_clk)
//    .clk_in1_p(sys_clk_p),  // input clk_in1_p           //used to be connected directly from pins, but now go through  IBUFDS-BUFG sequence, since clock is used for MMCM, IDELAYCTRL and DDR3
//    .clk_in1_n(sys_clk_n)   // input clk_in1_n
);




//*************************************ETH ports *****************************************

IDELAYCTRL IDELAYCTRL_inst     //needed for the delays in the ports
(
   .RDY(),          // 1-bit output: Ready output
   .REFCLK(sys_clk), // 1-bit input: Reference clock input
   .RST(1'b0)        // 1-bit input: Active high reset input
);

 
assign        e1_tx_er       = 1'b0;
assign        e3_tx_er       = 1'b0;
assign        e4_tx_er       = 1'b0;
wire   [7:0]  e1_txd;
wire          e1_tx_en;
wire   [7:0]  e1_rxd;       
wire          e1_rx_dv;
wire   [7:0]  e3_txd;
wire          e3_tx_en;
wire   [7:0]  e3_rxd;       
wire          e3_rx_dv;
wire   [7:0]  e4_txd;
wire          e4_tx_en;
wire   [7:0]  e4_rxd;       
wire          e4_rx_dv;
 
 
ETH_IOport ETH1_IOport
(
  .e_rx_clk_from_pins   (e1_rx_clk_from_pins),  // Single ended clock input from PHY 
  .e_tx_clk_to_pins     (e1_tx_clk_to_pins),    //forwarded clk signal for PHY tx
  .e_clk                (e1_clk),               //internal eth clk 
  .e_rxd_from_pins      (e1_rxd_from_pins),
  .e_rxd                (e1_rxd),
  .e_rx_dv_from_pins    (e1_rx_dv_from_pins),
  .e_rx_dv              (e1_rx_dv),
  .e_txd                (e1_txd),
  .e_txd_to_pins        (e1_txd_to_pins),
  .e_tx_en              (e1_tx_en),
  .e_tx_en_to_pins      (e1_tx_en_to_pins)
); 

ETH_IOport ETH3_IOport
(
  .e_rx_clk_from_pins   (e3_rx_clk_from_pins),  // Single ended clock input from PHY 
  .e_tx_clk_to_pins     (e3_tx_clk_to_pins),    //forwarded clk signal for PHY tx
  .e_clk                (e3_clk),               //internal eth clk 
  .e_rxd_from_pins      (e3_rxd_from_pins),
  .e_rxd                (e3_rxd),
  .e_rx_dv_from_pins    (e3_rx_dv_from_pins),
  .e_rx_dv              (e3_rx_dv),
  .e_txd                (e3_txd),
  .e_txd_to_pins        (e3_txd_to_pins),
  .e_tx_en              (e3_tx_en),
  .e_tx_en_to_pins      (e3_tx_en_to_pins)
);

ETH_IOport ETH4_IOport
(
  .e_rx_clk_from_pins   (e4_rx_clk_from_pins),  // Single ended clock input from PHY 
  .e_tx_clk_to_pins     (e4_tx_clk_to_pins),    //forwarded clk signal for PHY tx
  .e_clk                (e4_clk),               //internal eth clk 
  .e_rxd_from_pins      (e4_rxd_from_pins),
  .e_rxd                (e4_rxd),
  .e_rx_dv_from_pins    (e4_rx_dv_from_pins),
  .e_rx_dv              (e4_rx_dv),
  .e_txd                (e4_txd),
  .e_txd_to_pins        (e4_txd_to_pins),
  .e_tx_en              (e4_tx_en),
  .e_tx_en_to_pins      (e4_tx_en_to_pins)
);
              
//*****************************************1s-clock********************************
 reg  [25:0]  clk_1s_cnt=1'b0;
 reg  [1:0]   fan2      =1'b0;
 reg  [7:0]   fan_cnt   =1'b0;
 reg  [3:0]   Reset_cnt =1'b0;
 always @(posedge IOclk) begin 
   clk_1s_cnt <= clk_1s_cnt +1'b1;
   if(clk_1s_cnt==0) begin
     if (Reset_cnt<4'hf) begin
       Reset_cnt  <= Reset_cnt +1'b1;
       ResetStart <= 1'b1;               //is on for ca 10s
     end else ResetStart <= 1'b0;       
   end
   if(clk_1s_cnt[17:0]==1'b0) begin
     fan2 <= {fan2[0],Fan};
     if((fan2==2'b01)||(fan2==2'b10)) begin
       fan_cnt   <= 1'b0;
       fan_error <= 1'b0;
     end else begin
       if(fan_cnt<8'd200) fan_cnt <= fan_cnt + 1'b1;
       else               fan_error <= 1'b1;
     end
   end
 end     
 assign ledFPGA= (ResetStart||CalcBusy) ? clk_1s_cnt[23] : clk_1s_cnt[25];    
             

            
/******************************************************************************/
MDmachine
#(
.DataByteWidth      (DataByteWidth),
.DataByteWidth_n    (DataByteWidth_n),
.EnsembleByteWidth  (EnsembleByteWidth),
.nBox               (nBox),
.vshift             (vshift),
.nSelForceLUT       (nSelForceLUT ),
.metaAtomNr_len     (metaAtomNr_len),
.metaAtomTypeLJ     (metaAtomTypeLJ),
.metaAtomTypeLJ_len (metaAtomTypeLJ_len),
.metaCharge         (metaCharge),
.metaCharge_len     (metaCharge_len), 
.metaMass           (metaMass),
.metaMass_len       (metaMass_len),
.metaConstraint     (metaConstraint),
.metaRoute          (metaRoute),
.nProteinAtom       (nProteinAtom),
.DDR3_DATA_WIDTH    (DDR3_DATA_WIDTH),
.FF_LENGTH          (FF_LENGTH),
.FF_WIDTH           (FF_WIDTH ),                                
.nCLOSEATOM         (nCLOSEATOM),                                         
.CLOSEATOM_WIDTH    (CLOSEATOM_WIDTH)
) MDmachine
(
 .IOclk                 (IOclk),  
 .CalcClk               (CalcClk),
 .clk200MHz             (clk200MHz),
 .sys_clk               (sys_clk),
 .MDReset               (MDReset),
 .ResetStart            (ResetStart),
//inputs from BraodcastAtom to write data into brams        
 .data_valid            (data_valid),     
 .DataHomeIn            (DataHome),      
 .gtp0_data_recv        (gtp0_data_recv), 
 .gtp1_data_recv        (gtp1_data_recv), 
 .gtp2_data_recv        (gtp2_data_recv), 
 .gtp3_data_recv        (gtp3_data_recv), 
 .e3_data_recv          (e3_data_recv),   
 .e4_data_recv          (e4_data_recv),    
 .overflowError         (overflowError),
//input from ReadCommand to write force field data into DDR3 RAM; 
 .ForceField_rcv        (ForceField_rcv),                                                        
 .ForceField_data       (ForceField_data),
 .ForceField_atom       (ForceField_atom),            
//write protein atoms into BRAM
 .dataProteinAtom       (dataProteinAtom),                                                           
 .dataProteinAtom_valid (dataProteinAtom_valid),                                                                                                    
//input that writes into Force LUTs 
 .wrForceLUT            (wrForceLUT),    
 .dataForceLUT          (dataForceLUT),  
 .adrForceLUT           (adrForceLUT),   
 .selForceLUT           (selForceLUT),    
//input/output for MD claculation
 .nAtom0                (nAtom),           //on  IOclk              
 .nAtomResetExt         (nAtomReset),  
 .AllBusy               (AllBusyIn), 
 .InitCalc              (InitCalc),
 .nstep                 (nstep), 
 .istepOut              (istep),    
 .SyncOut               (SyncOut),               
 .CalcBusy              (CalcBusy),       
 .errorRxReset          (errorRxReset),    
 .errorRxSync           (errorRxSyncIn),            
 .newData               (newData),
 .newDataReady          (newDataReady),
 .EnsembleData          (EnsembleData),
 .EnsembleReady         (EnsembleReady),
 .EnsembleNeighbor      (EnsembleNeighbor),
 .EnsembleNeighborValid (EnsembleNeighborValid),
 .MD_error              (MD_error),
//parameters for thermostat. 
 .WriteDataThermostat   (WriteDataThermostat),
 .AdrDataThermostat     (AdrDataThermostat),
 .DataThermostat        (DataThermostat), 
 //Simulation parameters
 .WriteSimParam         (WriteSimParam),
 .AdrSimParam           (AdrSimParam),
 .SimParam              (SimParam), 
 //Shake diagnostics
 .nShakeTot             (nShakeTot),
 .nIterTot              (nIterTot),
//input/output to write content of boxes to MAC    
 .SendMacAdr            (SendMacAdr),   
 .SendMacBox            (SendMacBox),
 .DataSendMac           (DataSendMac),
//DDR3-pins; comment out when using reduced BRAM version of mem_burst
 .ddr3_dq               (ddr3_dq),                        //ddr3 data
 .ddr3_dqs_n            (ddr3_dqs_n),                     //ddr3 dqs negative
 .ddr3_dqs_p            (ddr3_dqs_p),                     //ddr3 dqs positive
 .ddr3_addr             (ddr3_addr),                      //ddr3 address
 .ddr3_ba               (ddr3_ba),                        //ddr3 bank
 .ddr3_ras_n            (ddr3_ras_n),                     //ddr3 ras_n
 .ddr3_cas_n            (ddr3_cas_n),                     //ddr3 cas_n
 .ddr3_we_n             (ddr3_we_n),                      //ddr3 write enable 
 .ddr3_reset_n          (ddr3_reset_n),                   //ddr3 reset,
 .ddr3_ck_p             (ddr3_ck_p),                      //ddr3 clock negative            
 .ddr3_ck_n             (ddr3_ck_n),                      //ddr3 clock positive
 .ddr3_cke              (ddr3_cke),                       //ddr3_cke,
 .ddr3_cs_n             (ddr3_cs_n),                      //ddr3 chip select,
 .ddr3_dm               (ddr3_dm),                        //ddr3_dm
 .ddr3_odt              (ddr3_odt)                        //ddr3_odt 
);

 
 
/***************************************************Broadcast atom data*******************************************************************/

BroadcastAtom
#(
.DataByteWidth      (DataByteWidth),
.DataByteWidth_n    (DataByteWidth_n),
.EnsembleByteWidth  (EnsembleByteWidth),
.nBox               (nBox),
.nProteinAtom       (nProteinAtom),
.metaAtomNr_len     (metaAtomNr_len),
.metaRoute          (metaRoute)
) BroadcastAtom
(
    .IOclk                       (IOclk),  
    .ErrorReset                  (ErrorReset),
    .ResetStart                  (ResetStart),
//ETH connections
    .e3_clk                      (e3_clk), 
    .e3_reset                    (e3_reset),
    .e3_tx_en                    (e3_tx_en),          //ETH transmit enable
    .e3_txd                      (e3_txd),            //ETH transmit data
    .e3_rx_dv                    (e3_rx_dv),          //ETH receive data valid 
 //  .e3_rx_er                    (e3_rx_er),          //ETH receive error from PHY
    .e3_rxd                      (e3_rxd),            //ETH receive data
    .e3_mdc                      (e3_mdc),            //mdc interface
    .e3_mdio                     (e3_mdio),           //mdio interface
    .speed3                      (speed3),            //ethernet speed 00: no link, 01: 10M 02:100M 11:1000M
    .e4_clk                      (e4_clk),
    .e4_reset                    (e4_reset),
    .e4_tx_en                    (e4_tx_en),          //ETH transmit enable
    .e4_txd                      (e4_txd),            //ETH transmit data
    .e4_rx_dv                    (e4_rx_dv),          //ETH receive data valid 
    .e4_rxd                      (e4_rxd),            //ETH receive data
  //  .e4_rx_er                    (e4_rx_er),          //ETH receive error from PHY
    .e4_mdc                      (e4_mdc),            //mdc interface
    .e4_mdio                     (e4_mdio),           //mdio interface
    .speed4                      (speed4),            //ethernet speed 00: no link, 01: 10M 02:100M 11:1000M
    .ETH_error                   (ETH_error),         //={e4_rx_error[2:0],e4_tx_error,e3_rx_error[2:0],e3_tx_error}
//    .ReNegotiateETH34            (ReNegotiateETH341[1:0]),
//GTP connections
    .Q0_CLK0_GTREFCLK_PAD_N_IN   (Q0_CLK0_GTREFCLK_PAD_N_IN),  //GTP clock
    .Q0_CLK0_GTREFCLK_PAD_P_IN   (Q0_CLK0_GTREFCLK_PAD_P_IN),  //GTP clock
    .RXN_IN                      (RXN_IN),           //GTP rx pins
    .RXP_IN                      (RXP_IN),           //GTP rx pins  
    .TXN_OUT                     (TXN_OUT),          //GTP tx pins
    .TXP_OUT                     (TXP_OUT ),         //GTP tx pins
    .gtp_error                   (gtp_error),        //={gtp_rx_error,gtp_tx_error}
//inputs   
    .DataIn_req                  (DataIn_req),       //data from PC to be broadcasted ready    
    .DataIn                      (DataIn),           //data to be broadcasted          
    .newData                     (newData),          //newly claculated data
    .newDataReady                (newDataReady),
    .EnsembleData                (EnsembleData),
    .EnsembleReady               (EnsembleReady),
    .EnsembleNeighbor            (EnsembleNeighbor),
    .EnsembleNeighborValid       (EnsembleNeighborValid),
//output results
    .Broadcast_busy             (Broadcast_busy),
    .data_valid                  (data_valid),
    .DataHome                    (DataHome), 
    .gtp0_data_recv_short        (gtp0_data_recv),
    .gtp1_data_recv_short        (gtp1_data_recv),
    .gtp2_data_recv_short        (gtp2_data_recv),
    .gtp3_data_recv_short        (gtp3_data_recv),
    .e3_data_recv_short          (e3_data_recv),
    .e4_data_recv_short          (e4_data_recv),
    .dataProteinAtom             (dataProteinAtom),                                                           
    .dataProteinAtom_valid       (dataProteinAtom_valid),                                                     
    .GatedMuxError               (GatedMuxError)
);

/***********************************Communication with host PC via ETH1**********************************************/
//currently ForceField_cnt is 16bit (i.e. metaAtomNr_len), which is not enough in the long run. Could be increased to 18bit on the expense of nIterTot, the latter of which is also 16bit, but that is not needed
wire [DataByteWidth*8-1:0] statusLine1={nIterTot,nShakeTot,ForceField_cnt,istep,3'b0,AllBusyIn,SyncOut,CalcBusy,Broadcast_busy,(CalcBusy|Broadcast_busy),errorRxCnt,errorAll,Version,PacketNrOld,PacketNr};  
wire [DataByteWidth*8-1:0] statusLine2={{(DataByteWidth-EnsembleByteWidth)*8{1'b0}},EnsembleData};  


 mac_top 
#(
.DataByteWidth (DataByteWidth),
.nBlock        (nBlock)
) mac1
(
 .e_clk                       (e1_clk),      
 .IOclk                       (IOclk),
// .CalcClk                     (CalcClk),  
 .e_reset                     (e1_reset),  
 .ResetStart                  (ResetStart),
//IP-stuff 
 .local_mac_addr              ({40'h00_0a_35_01_fe,DipSwitch}),   //local mac address
 .local_ip_addr               ({24'hc0a801,DipSwitch}),           //local 192.168.1.*
 .local_udp_port              (16'h1f90),                //local udp port
//ETH input/output 
 .e_tx_en                     (e1_tx_en),                //output                       transmit enable        
 .e_txd                       (e1_txd),                  //output [7:0]                 transmit data
 .e_rx_dv                     (e1_rx_dv),                //input                        ETH receive data valid
 .e_rxd                       (e1_rxd),                  //input  [7:0]                 ETH receive data
 .e_mdc                       (e1_mdc),                  //output                       ETH PHY register clock
 .e_mdio                      (e1_mdio),                 //inout                        ETH PHY register data
 .speedCombined               (speed1),                  //output                       ETH speed 00: no link, 01: 10M 02:100M 11:1000M
//udp sending part 
 .statusLine1                 (statusLine1),             //input [DataByteWidth*8-1:0]  statusline, contains errorbits, etc.
 .nAtom                       (nAtom),                   //input [DataByteWidth*8-1:0]  nAtom's of all boxes 
 .statusLine2                 (statusLine2),             //input [DataByteWidth*8-1:0]  2nd statusline, contains ensemble data
 .StartMac                    (StartMac),       
 .nSend                       (nSendMac),              
 .DataSendMac                 (DataSendMac),             //input [DataByteWidth*8-1:0]  actual data, to be read from BRAM
 .SendMacAdr                  (SendMacAdr),              //output[7:0]                  address of BRAM to read data
//UDP receiving part
 .CommandCnt                  (CommandCnt),                  
 .CommandData                 (CommandData),                
 .CommandValid                (CommandValid)        
);

//********************************************read and interpret input commands***********************

ReadCommand
#(
.DataByteWidth   (DataByteWidth),
.nSelForceLUT    (nSelForceLUT),
.nProteinAtom    (nProteinAtom),              
.DDR3_DATA_WIDTH (DDR3_DATA_WIDTH),           
.FF_LENGTH       (FF_LENGTH)                  
) ReadCommand
(  
 .IOclk                       (IOclk),   
 .ResetStart                  (ResetStart),
//in/output to mac_top 
 .CommandCnt                  (CommandCnt),
 .CommandData                 (CommandData),
 .CommandValid                (CommandValid),
//data that are sent higher up 
 .PacketNr                    (PacketNr),                //output [7:0]                 packet number 
 .PacketNrOld                 (PacketNrOld),             //output [7:0]                 previouusly received packet number; to see if packest have been lost
//for command 0: status and reset
 .nAtomReset                  (nAtomReset),              //output                       reset nAtom counts
 .ErrorReset                  (ErrorReset),              //output                       reset Errors
 .MDReset                     (MDReset),                 //output                       reset MD machine
//for command 1: initiate MD  
 .InitCalc                    (InitCalc),
 .nstep                       (nstep),
//for command 2: write Force LUTs
 .wrForceLUT                  (wrForceLUT),    
 .dataForceLUT                (dataForceLUT),  
 .adrForceLUT                 (adrForceLUT),   
 .selForceLUT                 (selForceLUT),    
//for command 3: Thermotstat data 
 .WriteDataThermostat         (WriteDataThermostat),
 .AdrDataThermostat           (AdrDataThermostat),
 .DataThermostat              (DataThermostat), 
//for command 4: simulation parameters.      
 .WriteSimParam               (WriteSimParam),
 .AdrSimParam                 (AdrSimParam),
 .SimParam                    (SimParam),      
//for command 5: protein force field data                                 
 .ForceField_rcv              (ForceField_rcv),                           
 .ForceField_atom             (ForceField_atom),                          
 .ForceField_data             (ForceField_data),                          
 .ForceField_cnt              (ForceField_cnt),                  //is new
//for command 5:  receiving atom data    
 .WriteDataAtom               (DataIn_req),              //output                       write data into BRAM
 .DataAtom                    (DataIn),                  //output [DataByteWidth*8-1:0] data to be written into BRAM
//for command 8: send atom data 
 .SendMacBox                  (SendMacBox),              //output [6:0]                 select box memory
 .nSend                       (nSendMac),
 .SendMem                     (StartMac)
);

/***************************************Synchrinisation of Nodes via 10pin interface******************************************/
SyncNodes SyncNodes
(
.IOclk            (IOclk),
.AllBusyExt11     (AllBusyExt11),   
.errorRxSyncExt11 (errorRxSyncExt11), 
.AllBusyExt12     (AllBusyExt12),   
.errorRxSyncExt12 (errorRxSyncExt12), 
.AllBusyExt2      (AllBusyExt2),   
.errorRxSyncExt2  (errorRxSyncExt2), 
.AllBusy          (SyncOut||Broadcast_busy),
.errorRxSync      (errorRxSync),
.AllBusyIn        (AllBusyIn),
.errorRxSyncIn    (errorRxSyncIn)
);



//*************************************Error Handler**************************** 
ErrorHandler ErrorHandler
    (
    .clk                (IOclk),
    .error_reset        (ErrorReset||(~key1)),  
    .errorRxReset       (errorRxReset),   
    .fan_error          (fan_error),
    .speed3             (speed3),
    .speed4             (speed4),
    .ETH_error          (ETH_error),
    .gtp_error          (gtp_error),
    .GatedMuxError      (GatedMuxError),
    .overflowError      (overflowError),
    .MD_error           (MD_error),
    .errorAll           (errorAll), 
    .errorRxSync        (errorRxSync),   
    .errorRxCnt         (errorRxCnt)  
    );
    
//*************************************LEDs as error indicator*********************************
assign led =~{|errorAll,(speed1==2'b11)};

endmodule