//`define READALLBOX   //if switched on, home box as well as all neigboring boxes can be read out. Inportant for debugging, 
                       //but cost a lot of resources, 1700LUTs and 1900FFs   -> no longer in files
