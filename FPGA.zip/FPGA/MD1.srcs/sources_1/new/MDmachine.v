`timescale 1ns / 1ps
//MD Machine, in essence Fig. 7 of the paper
//- Statemachine CalcState1 (on IOclk): is initiated by InitCalc and loops over time steps, taking care of all synchronisation, etc. Also 
//  initiates HomeState and waits for the completion of all force calculations. 
//
//- Statemachine CalcState2 (currerntly on IOclk):  collects and adds up all forces, devide forces by mass, and calculate new velocities as: 
//    v <= v*Tscale + Ftot/mass - vcm. 
//  
//Synchronisation
//- SyncOut and CalcBusy are indicator of the status of the MD machine.
//  SyncOut is for the synchronisation of all nodes: SyncOut is 1 during idle times, switches to 0 to initiate sync, and switches back 
//  to 1 once calculation starts. It goes to 0 when a MD step is completed for re-synchronisation of all nodes. 
//- CalcBusy is 0 in idle, and switches to 1 during whole calculation.  It is used to switch the access to the box memories. In addition
//  it is output on the status line.  
//
//Datastructure:
//|                             nProteinAtom                             |
//|        |                    DataByteWidth_n                          |
//|24|24|24| 2r+6|  13r  |    3     |  6 | 18   | 1r+5 | 2r+16|24|24|24|    (*r stands for reserve bits)
//|vz|vy|vz|route|reserve|constraint|mass|charge|LJtype|atomNr| z| y| x|
//
//ToDo's: 

`include "MDSwitches.h"
   
module MDmachine
#(
parameter  DataByteWidth      = 5'd27,   //full data width of home box, including velocities 
parameter  DataByteWidth_n    = 5'd18,   //reduced data width of neigboring boxes, without velocities
parameter  EnsembleByteWidth  = 5'd15,
parameter  nBox               = 5'd27,
parameter  vshift             = 4, 
parameter  nSelForceLUT       = 3,      //width of SelForceLUT 
parameter  metaAtomNr_len     = 16,     //length of atom number in meta data; starts at 0. 2bit reserve
parameter  metaAtomTypeLJ     = 18,     //atomType for LJ
parameter  metaAtomTypeLJ_len = 5,      //its length, leave one bit of reserve
parameter  metaCharge         = 24,     //posiiton of charge in meta data
parameter  metaCharge_len     = 18,     //its length 
parameter  metaMass           = 42,     //position of mass in meta data
parameter  metaMass_len       = 6,      //its length; 16bit reserve
parameter  metaConstraint     = 48,     //position of contraint info in meta data
parameter  metaRoute          = 64,      //information for which box to route; 6bit needed
parameter  nProteinAtom       = 12,      //max 2^nProteinAtom protein atoms
parameter  DDR3_DATA_WIDTH    = 256,     //length of a line from  the DDR3 Ram
parameter  FF_LENGTH          = 36,      //Number of lines that defines force field. First 2 lines are for closeAtoms, and then the actual force field. 
parameter  FF_WIDTH           = 6,       //FF_WIDTH = Floor(Log2(FF_LENGTH))+1                                         
parameter  nCLOSEATOM         = 24,      //maximum number of closeAtoms                                       
parameter  CLOSEATOM_WIDTH    = 5        //CLOSEATOM_WIDTH=Floor(Log2(nCLOSEATOM))+1      
)
(
  input                                IOclk,  
  input                                CalcClk,
  input                                clk200MHz,
  input                                sys_clk,
  input                                MDReset,
  input                                ResetStart,
//inputs from BraodcastAtom to write data into boxes
  input      [nBox-1:0]                data_valid,             //data valid for homebox or one of the neigboring boxes
  input      [DataByteWidth*8-1:0]     DataHomeIn,             //actual data from the various sources, see BroadcastAtom for details
  input      [DataByteWidth_n*8-1:0]   gtp0_data_recv, 
  input      [DataByteWidth_n*8-1:0]   gtp1_data_recv, 
  input      [DataByteWidth_n*8-1:0]   gtp2_data_recv, 
  input      [DataByteWidth_n*8-1:0]   gtp3_data_recv, 
  input      [DataByteWidth_n*8-1:0]   e3_data_recv,
  input      [DataByteWidth_n*8-1:0]   e4_data_recv,
  output     [2:0]                     overflowError,          //overflow error in one of the boxes or subboxes
//input from ReadCommand to write force field data into DDR3 RAM; 
  input                                ForceField_rcv,
  input [DDR3_DATA_WIDTH - 1:0]        ForceField_data,
  input [nProteinAtom-1:0]             ForceField_atom,                 
 //input from BroadcastAtom to write into in BRAM that contains all protein atoms indexed by atom number
  input      [71+nProteinAtom:0]       dataProteinAtom,                                                           
  input                                dataProteinAtom_valid,                                                                                     
 //input that writes into Force LUT; is funneled through into ForceNonBond and ForceBox_*
  input                                wrForceLUT,    
  input      [8:0]                     dataForceLUT,  
  input      [11:0]                    adrForceLUT,   
  input      [nSelForceLUT-1:0]        selForceLUT,   
 //input/output for MD claculation
  output     [nBox*8-1:0]              nAtom0,                 //output only for lower half of memory, for status line; on IOclk
  input                                nAtomResetExt,          //reset nAtom counter
  input                                AllBusy,                //some of the other nodes or broadcasting still busy
  input                                InitCalc,               //initiate simulation
  input      [15:0]                    nstep,                  //number of timesteps
  output reg [15:0]                    istepOut,               //istep for status line; is not reset after run 
  output reg                           SyncOut,                //for synchronosation with other nodes
  output reg                           CalcBusy,               //busy signal for controlling access to box BRAMs and for status line
  output reg                           errorRxReset,           //reset communication error since MD step is repeated
  input                                errorRxSync,            //sync communication error with other nodes
  output     [DataByteWidth*8-1:0]     newData,                //new atom data
  output reg                           newDataReady=1'b0,      //new atom data ready for broadcast
  output     [EnsembleByteWidth*8-1:0] EnsembleData,           //ensemble data such as temperature, etc
  output reg                           EnsembleReady=1'b0,     //ensemble data ready for broadcast
  input      [EnsembleByteWidth*8-1:0] EnsembleNeighbor,       //ensemble data from neigboring boxes
  input                                EnsembleNeighborValid,  //ensemble data from neigboring boxes ready   
  output     [7:0]                     MD_error,               //error signals from MD-machine
//Thermostat data       
  input                                WriteDataThermostat,
  input      [2:0]                     AdrDataThermostat,
  input      [31:0]                    DataThermostat,     
//Simulation parameter
  input                                WriteSimParam,
  input      [3:0]                     AdrSimParam,
  input      [16:0]                    SimParam,  
//Shake diagnostics
  output     [7:0]                     nShakeTot,
  output     [15:0]                    nIterTot,
//input/output to write content of boxes to MAC, processed in mac_top 
  input      [7:0]                     SendMacAdr,
  input      [0:0]                     SendMacBox,
  output reg [DataByteWidth*8-1:0]     DataSendMac,
//DDR3-pins; comment out when using reduced BRAM version of mem_burst
  inout  [31:0]                        ddr3_dq,                    //ddr3 data
  inout  [3:0]                         ddr3_dqs_n,                 //ddr3 dqs negative
  inout  [3:0]                         ddr3_dqs_p,                 //ddr3 dqs positive
  output [14:0]                        ddr3_addr,                  //ddr3 address
  output [2:0]                         ddr3_ba,                    //ddr3 bank
  output                               ddr3_ras_n,                 //ddr3 ras_n
  output                               ddr3_cas_n,                 //ddr3 cas_n
  output                               ddr3_we_n,                  //ddr3 write enable 
  output                               ddr3_reset_n,               //ddr3 reset,
  output [0:0]                         ddr3_ck_p,                  //ddr3 clock negative
  output [0:0]                         ddr3_ck_n,                  //ddr3 clock positive
  output [0:0]                         ddr3_cke,                   //ddr3_cke,
  output [0:0]                         ddr3_cs_n,                  //ddr3 chip select,
  output [3:0]                         ddr3_dm,                    //ddr3_dm
  output [0:0]                         ddr3_odt                    //ddr3_odt    
);

localparam  metaTotForce       = metaMass;   //total size of metadata needed for force calculation 
localparam  latHomeBram        = 3;          //Bram itself has latency 2, plus multiplexer for address

reg [2*nBox*8-1:0]                   nAtom        = 1'b0;
reg                                  iHalf; 
reg                                  nAtomReset = 1'b0;
reg                                  start_i2 =1'b0;
reg         [8:0]                    adr_000 = 1'b0;
reg         [7:0]                    i1      = 1'b0;        
wire        [DataByteWidth*8-1:0]    dataHome;
reg         [4:0]                    CalcState1 = 1'b0;
reg         [15:0]                   istep=1'b1; 
wire                                 atomDataReady;
wire                                 slowDownAtomData,slowDown_x,slowDown_y,slowDown_z,slowDown_xy,slowDown_xz,slowDown_yz,slowDown_xyz,slowDown_Bonded;
reg                                  slowDown;
wire                                 forceReady, force_xReady, force_yReady, force_zReady, force_xyReady, force_xzReady, force_yzReady, force_xyzReady, force_StretchReady;
wire                                 overflowSubbox, overflowSubbox_x, overflowSubbox_y, overflowSubbox_z, overflowSubbox_xy, overflowSubbox_xz, overflowSubbox_yz,  overflowSubbox_xyz;
reg                                  overflowHomeBox=1'b0,overflowNeighborBox=1'b0;
reg         [7:0]                    wait_cnt=1'b0;
reg                                  forceAllReady=1'b0;
wire                                 CalcState2_Busy;
wire                                 ThermostatBusy;
wire                                 shakeBusy;
wire                                 newDataFIFOBusy;
reg                                  velOverflow_d0=1'b0;
wire                                 velOverflow;
reg                                  fifoOut = 1'b0;
         
wire        [DataByteWidth_n*8-1:0] dataBox_00p;
wire        [DataByteWidth_n*8-1:0] dataBox_00n;
wire        [DataByteWidth_n*8-1:0] dataBox_0p0;
wire        [DataByteWidth_n*8-1:0] dataBox_0n0;
wire        [DataByteWidth_n*8-1:0] dataBox_p00;
wire        [DataByteWidth_n*8-1:0] dataBox_n00;
wire        [DataByteWidth_n*8-1:0] dataBox_0pp;
wire        [DataByteWidth_n*8-1:0] dataBox_0pn;
wire        [DataByteWidth_n*8-1:0] dataBox_0np;
wire        [DataByteWidth_n*8-1:0] dataBox_0nn;
wire        [DataByteWidth_n*8-1:0] dataBox_p0p;
wire        [DataByteWidth_n*8-1:0] dataBox_p0n;
wire        [DataByteWidth_n*8-1:0] dataBox_n0p;
wire        [DataByteWidth_n*8-1:0] dataBox_n0n;
wire        [DataByteWidth_n*8-1:0] dataBox_pp0;
wire        [DataByteWidth_n*8-1:0] dataBox_pn0;
wire        [DataByteWidth_n*8-1:0] dataBox_np0;
wire        [DataByteWidth_n*8-1:0] dataBox_nn0;
wire        [DataByteWidth_n*8-1:0] dataBox_ppp;
wire        [DataByteWidth_n*8-1:0] dataBox_ppn;
wire        [DataByteWidth_n*8-1:0] dataBox_pnp;
wire        [DataByteWidth_n*8-1:0] dataBox_pnn;
wire        [DataByteWidth_n*8-1:0] dataBox_npp;
wire        [DataByteWidth_n*8-1:0] dataBox_npn;
wire        [DataByteWidth_n*8-1:0] dataBox_nnp;
wire        [DataByteWidth_n*8-1:0] dataBox_nnn;

wire [nCLOSEATOM*nProteinAtom-1:0]  closeAtom; 
wire [nCLOSEATOM-1:0]               pair14;            
wire                                closeAtom_rcv;
wire                                DDR3clk; 
reg  [16:0]                         fudgeQQ=17'd54611;     //0.8333; 0x10000 corresponds to 1  eventually input from ReadCommand   
reg                                 fudgeLJ=1'b0;          //0.5; eventually input from ReadCommand                                

//****************************accumulating nAtom******************************************** 
integer i;
always @(posedge IOclk) begin
  if(nAtomResetExt||nAtomReset)  begin 
    nAtom[iHalf*nBox*8+:nBox*8]        <= 1'b0;
    overflowHomeBox                    <= 1'b0;
    overflowNeighborBox                <= 1'b0;
  end  
  else begin
    if(data_valid[0]) begin
      nAtom[(iHalf*nBox)*8+:8]  <= nAtom[(iHalf*nBox)*8+:8] + 1'b1;
      if(nAtom[(iHalf*nBox)*8+:8]==8'd252) overflowHomeBox <= 1'b1;       //a little smaller than 255 since that would cause  overflows in mac.v
    end  
    for(i=1;i<nBox;i=i+1) begin 
      if(data_valid[i]) begin 
        nAtom[(iHalf*nBox+i)*8+:8]  <= nAtom[(iHalf*nBox+i)*8+:8] + 1'b1; 
        if(nAtom[(iHalf*nBox+i)*8+:8]==8'd252) overflowNeighborBox <= 1'b1;
      end    
    end  
  end  
end  
assign nAtom0 = nAtom[nBox*8-1:0];   //for output via mac.v

ClkTransferStat #(.Width (1))  ClkTransferStat1  
(
    .clkIn   (IOclk),
    .clkOut  (CalcClk),
    .sigIn   (iHalf),
    .sigOut  (iHalf_CalcClk)
); 


 
//memory containing home box (full width), simple-dual, toal latency 3 (including that of the initial adress multiplexer, full width). Despite the fact it is single clk, it still has two clk inputs
always @(posedge IOclk) begin
   adr_000      <= CalcBusy ? {~iHalf,i1} : {SendMacBox[0],SendMacAdr};  
   DataSendMac  <= dataHome;
end   
bram_216x512_singleClk homebox (.clka(IOclk),.ena(1'b1),.wea(data_valid[0]) ,.addra({iHalf,nAtom[(iHalf*nBox+0 )*8 +:8]}),.dina(DataHomeIn),.clkb(IOclk),.enb(1'b1),.addrb(adr_000),.doutb(dataHome));


//***************************************actual MD loop*************************************************
always @(posedge IOclk) begin
  slowDown <= slowDownAtomData||slowDownHome||slowDown_x||slowDown_y||slowDown_z||slowDown_xy||slowDown_xz||slowDown_yz||slowDown_xyz||slowDown_Bonded;
  if(MDReset) begin
    CalcState1 <= 1'b0;
  end else begin  
    case (CalcState1)
      0: begin                         //idle
       CalcBusy      <= 1'b0;
       nAtomReset     <= 1'b0;
       iHalf          <= 1'b0;
       istep          <= 1'b1;
       errorRxReset   <= 1'b0;
       wait_cnt       <= 6'h0;
       if(InitCalc) begin               //initiate calculation
         SyncOut      <= 1'b0;
         CalcState1   <= CalcState1 + 1'b1;
       end else SyncOut   <= 1'b1;   
      end     
      1: begin
        istepOut       <= 1'b1;           //for istepOut, remains at the final istep when finished, for statusline    
        CalcBusy       <= 1'b1;   
        if(~AllBusy) begin              //wait until all nodes are ready
          SyncOut        <= 1'b1;
          iHalf          <= ~iHalf;
          nAtomReset     <= 1'b1; 
          CalcState1     <= CalcState1 + 1'b1;
        end   
      end
      2: begin                       //a few wait cycles for all signals to propagate through
        nAtomReset       <= 1'b0;
        if(wait_cnt==7'h7) begin
          wait_cnt     <= 6'h0;
          CalcState1   <= CalcState1 + 1'b1;
        end else wait_cnt  <= wait_cnt +1'b1;
      end
      3: begin
        if((~iHalf ? nAtom[8*nBox+:8] : nAtom[0+:8]) == 1'b0)   CalcState1 <= 5'd11;  //no atoms; jump over claculation
        else begin
          i1          <= 1'b0;        
          CalcState1  <= CalcState1 + 1'b1;      
        end  
      end  
      4: begin
        if(~slowDown) CalcState1  <= CalcState1 + 1'b1; 
      end
      5,6: begin                      //wait for latency of BRAM
        CalcState1  <= CalcState1 + 1'b1;   
      end 
      7: begin
        start_i2    <= 1'b1;
        CalcState1  <= CalcState1 + 1'b1;
      end  
      8: begin
       start_i2    <= 1'b0;
       if(wait_cnt==7'hf) begin                     //slow down i1-loop 
          wait_cnt     <= 6'h0;
          CalcState1   <= CalcState1 + 1'b1;
        end else wait_cnt  <= wait_cnt +1'b1;
      end 
      9: begin
        i1          <= i1 + 1'b1;
        if (i1<(~iHalf ? nAtom[8*nBox+:8] : nAtom[0+:8])-1'b1)  CalcState1 <= 5'd4;              //loop over i1
        else                                                    CalcState1 <= CalcState1 + 1'b1; //i1-loop done
      end
      10: begin
        if(atomDataReady&&(~CalcState2_Busy)&&(~ThermostatBusy)&&(~shakeBusy)&&(~newDataFIFOBusy)) begin //wait until all pipelines as well as statemachines 2, 3, thermostat and shake are done, CalcState2_Busy and shakeBusy is extended so it has overlap with ThermostatBusy
          CalcState1 <= 5'd12;   
          EnsembleReady <= 1'b1;
        end  
      end
      11: begin                         //entry point when no atom; extra wait
        if(wait_cnt==7'h7f) begin
          wait_cnt     <= 6'h0;
          CalcState1   <= CalcState1 + 1'b1;
        end else wait_cnt  <= wait_cnt +1'b1;
      end  
      12: begin                         // done with i1-loop, now wait for all error and busy signals
        EnsembleReady  <= 1'b0; 
        if(wait_cnt==6'h3f) begin    //used to be h10
          wait_cnt     <= 6'h0;
          SyncOut      <= 1'b0;
          CalcState1   <= CalcState1 + 1'b1;  //wait a little longer until Broadcast_busy takes over busy signal 
        end else wait_cnt  <= wait_cnt +1'b1;
      end
      13: begin         
        if(~AllBusy) CalcState1 <= CalcState1 + 1'b1;
      end      
      14: begin                         //check whether there is rx error
        if(errorRxSync) begin     
          istep         <= istep - 1'b1;  //redo timestep if there has been an error
          iHalf         <= ~iHalf; 
          CalcState1    <= CalcState1 + 1'b1;
        end else begin
          CalcState1    <= 5'd17;        //no error, so do next time step
        end  
      end
      15: begin                        //wait a little for all sync signals;
        if(wait_cnt==8'hff) begin
          errorRxReset  <= 1'b1;
          wait_cnt   <= 6'h0;
          CalcState1 <= CalcState1 + 1'b1;
        end else wait_cnt  <= wait_cnt +1'b1;
      end      
      16: begin                         //wait until all nodes reset the rx_error
        errorRxReset  <=1'b0;
        if(~errorRxSync) CalcState1 <= CalcState1 + 1'b1;   
      end          
      17: begin              
        if(istep<nstep) begin 
          istep        <= istep + 1'b1;
          istepOut     <= istep + 1'b1;
          iHalf        <= ~iHalf; 
          SyncOut      <= 1'b1;
          nAtomReset   <= 1'b1; 
          CalcState1   <= 5'd2;     //loop to next timestep
        end else begin
          CalcState1   <= 4'd0; 
          iHalf        <= 1'b0;    //done
        end   
      end    
      default: CalcState1 <= 5'd0;
    endcase
  end  
end    

//write atom data into FIFO for final calculation of new coordinates and velocities in statemachine 2
wire [DataByteWidth*8-1:0] dataHomeFifo; 
wire atomDataReady_d0;    


FIFO_async 
  #(
   .WIDTH(DataByteWidth*8),
   .DEPTH(64),
   .PROG_FULL_THRESH(55)
   ) atomData 
  (
  .rst(1'b0),
  .wr_clk(IOclk),    
  .rd_clk(clk200MHz),     
  .din(dataHome),      
  .wr_en(start_i2),  
  .rd_en(fifoOut),  
  .dout(dataHomeFifo),    
  .full(),    
  .empty(atomDataReady_d0),  
  .prog_full(slowDownAtomData)                 
);
  
  

reg  [7:0] atomDataReady_ext=1'b0;
reg        atomDataReady_tmp=1'b0;
always @(posedge clk200MHz) begin         
   atomDataReady_tmp <= ~atomDataReady_tmp;    
   if(atomDataReady_tmp) atomDataReady_ext <= {atomDataReady_ext[6:0],atomDataReady_d0};   //extend atomDataReady so that it has temporal overlap with subsequent signals; to dave bits, do only every 2nd clock
end 
ClkTransferStat #(.Width (1))  ClkTransferStat12  (.clkIn(clk200MHz),.clkOut(IOclk),.sigIn(&atomDataReady_ext),.sigOut(atomDataReady)); 


//***********************************************************************************************************************************************
//*                                                  Force Caclulations; on CalcClk                                                             *
//***********************************************************************************************************************************************
wire [7:0] nAtom_CalcClk;
ClkTransferStat #(.Width (8))  ClkTransferStat3 (.clkIn(IOclk),.clkOut(CalcClk),.sigIn(~iHalf ? nAtom[8*nBox+:8] : nAtom[0 +:8]),.sigOut(nAtom_CalcClk)); 

wire        [95:0]    forceHomeFifo;
ForceHomeBox
#(  
.DataByteWidth_n    (DataByteWidth_n),
.nSelForceLUT       (nSelForceLUT),     
.metaAtomNr_len     (metaAtomNr_len),
.metaAtomTypeLJ     (metaAtomTypeLJ),    
.metaAtomTypeLJ_len (metaAtomTypeLJ_len),   
.metaCharge         (metaCharge),   
.metaCharge_len     (metaCharge_len),    
.nProteinAtom       (nProteinAtom),                                                 
.nCLOSEATOM         (nCLOSEATOM)                       
) ForceHomeBox 
(
.IOclk          (IOclk),
.CalcClk        (CalcClk),
.clk200MHz      (clk200MHz),
.DDR3clk        (DDR3clk),                            
.MDReset        (MDReset), 
//write force LUT
.wrForceLUT     (wrForceLUT),    
.dataForceLUT   (dataForceLUT),  
.adrForceLUT    (adrForceLUT),   
.selForceLUT    (selForceLUT),    
//write atom2 data into BRAM; on IOclk
.data_valid     (data_valid[0]),                        //data valid
.iHalf          (iHalf),                                //iHalf on IOclk
.nAtom          (nAtom[(iHalf*nBox+0 )*8 +:8]),         //total number of data, is a running index during writing
.dataIn         (DataHomeIn[DataByteWidth_n*8-1:0]),    //data without velocities    
//write atom1 data into FIFO; on IOclk
.start_i2       (start_i2),
.dataHome       (dataHome[DataByteWidth_n*8-1:0]),
//for exclusion in ForceNonBond
.closeAtom_rcv  (closeAtom_rcv),                        //on DDR3clk,
.closeAtom      (closeAtom),                            //on DDR3clk, 
.pair14         (pair14),                               //on DDR3clk, 
.fudgeQQ        (fudgeQQ),                              //on IOclk    
.fudgeLJ        (fudgeLJ),                              //on IOclk    
//Calculation pipeline
.iHalf_CalcClk  (iHalf_CalcClk),                        //iHalf on CalcClk for reading
.nAtom_CalcClk  (nAtom_CalcClk),
.forceReady     (forceHomeReady),
.fifoOut        (fifoOut),
.forceFifo      (forceHomeFifo),
.slowDown       (slowDownHome)
);

//*****************************parallel pipelines working on neigboring boxes**********************************

//ATTENTION: nomenclature "n" and "p" stands negative and positive relative to home box, respectively. From the 
//perspective of sending data in BroadcastAtom, signs are opposite. Swap nomenclatiure of signs here when writing 
//into BRAM (i.e., compare to assignemnt of data_valid in BroadcastAtom)
//
//Nr  BOX      SIGNAL          DATA SOURCE
//1:  box_00p: data_valid[1],  gtp0_data_recv
//2:  box_00n: data_valid[2],  gtp1_data_recv
//3:  box_0p0: data_valid[3],  gtp2_data_recv
//4:  box_0pp: data_valid[4],  gtp0_data_recv
//5:  box_0pn: data_valid[5],  gtp2_data_recv
//6:  box_0n0: data_valid[6],  gtp3_data_recv
//7:  box_0np: data_valid[7],  gtp3_data_recv
//8:  box_0nn: data_valid[8],  gtp1_data_recv
//9:  box_p00: data_valid[9],  e3_data_recv
//10: box_p0p: data_valid[10], gtp0_data_recv
//11: box_p0n: data_valid[11], gtp1_data_recv
//12: box_pp0: data_valid[12], gtp2_data_recv
//13  box_ppp: data_valid[13], gtp0_data_recv
//14 box_ppn: data_valid[14], gtp2_data_recv
//15 box_pn0: data_valid[15], gtp3_data_recv
//16 box_pnp: data_valid[16], gtp3_data_recv
//17 box_pnn: data_valid[17], gtp1_data_recv
//18 box_n00: data_valid[18], e4_data_recv
//19 box_n0p: data_valid[19], gtp0_data_recv
//20 box_n0n: data_valid[20], gtp1_data_recv
//21 box_np0: data_valid[21], gtp2_data_recv
//22 box_npp: data_valid[22], gtp0_data_recv
//23 box_npn: data_valid[23], gtp2_data_recv
//24 box_nn0: data_valid[24], gtp3_data_recv
//25 box_nnp: data_valid[25], gtp3_data_recv
//26 box_nnn: data_valid[26], gtp1_data_recv



//neighboring boxes in +/- x-direction, i.e. boxes 00p and 00n
wire        [95:0]    force_xFifo;
ForceBox1 
#(  
.DataByteWidth_n    (DataByteWidth_n),
.nSelForceLUT       (nSelForceLUT),     
.q0                 (0),
.q1                 (1),
.q2                 (2),
.metaAtomNr_len     (metaAtomNr_len),
.metaAtomTypeLJ     (metaAtomTypeLJ),    
.metaAtomTypeLJ_len (metaAtomTypeLJ_len),   
.metaCharge         (metaCharge),   
.metaCharge_len     (metaCharge_len),    
.nProteinAtom       (nProteinAtom),                                                
.nCLOSEATOM         (nCLOSEATOM)                       
) ForceBox_x
(
.IOclk          (IOclk),
.CalcClk        (CalcClk),
.clk200MHz      (clk200MHz),
.DDR3clk        (DDR3clk),                            
.MDReset        (MDReset), 
//write force LUT
.wrForceLUT     (wrForceLUT),    
.dataForceLUT   (dataForceLUT),  
.adrForceLUT    (adrForceLUT),   
.selForceLUT    (selForceLUT),    
//write into BRAM
.data_valid_p   (data_valid[1]),
.data_valid_n   (data_valid[2]),
.iHalf          (iHalf),
.nAtom_p        (nAtom[(iHalf*nBox+1 )*8 +:8]),
.nAtom_n        (nAtom[(iHalf*nBox+2 )*8 +:8]),
.data_p         (gtp0_data_recv),
.data_n         (gtp1_data_recv),
.nAtomReset     (nAtomResetExt||nAtomReset),
.overflowSubbox (overflowSubbox_x),                    
//Calculation pipeline
.iHalf_CalcClk  (iHalf_CalcClk),                               //iHalf on CalcClk for reading
.start_i2       (start_i2),
.dataHome       (dataHome[DataByteWidth_n*8-1:0]),
//for exclusion in ForceNonBond
.closeAtom_rcv  (closeAtom_rcv),                        //on DDR3clk, 
.closeAtom      (closeAtom),                            //on DDR3clk, 
.pair14         (pair14),                               //on DDR3clk, 
.fudgeQQ        (fudgeQQ),                              //on IOclk    
.fudgeLJ        (fudgeLJ),                              //on IOclk      
//output results
.forceReady     (force_xReady),
.fifoOut        (fifoOut),
.forceFifo      (force_xFifo),
.slowDown       (slowDown_x)
);

//neighboring boxes in +/- y-direction, i.e. boxes 0p0 and 0n0
wire        [95:0]    force_yFifo;
ForceBox1 
#(  
.DataByteWidth_n    (DataByteWidth_n),
.nSelForceLUT       (nSelForceLUT),
.q0                 (1),     //swap x and y 
.q1                 (0),
.q2                 (2),
.metaAtomNr_len     (metaAtomNr_len),
.metaAtomTypeLJ     (metaAtomTypeLJ),    
.metaAtomTypeLJ_len (metaAtomTypeLJ_len),   
.metaCharge         (metaCharge),   
.metaCharge_len     (metaCharge_len),
.nProteinAtom       (nProteinAtom),                                                   
.nCLOSEATOM         (nCLOSEATOM)                           
) ForceBox_y
(
.IOclk          (IOclk),
.CalcClk        (CalcClk),
.clk200MHz      (clk200MHz),
.DDR3clk        (DDR3clk),                            
.MDReset        (MDReset), 
//write force LUT
.wrForceLUT     (wrForceLUT),    
.dataForceLUT   (dataForceLUT),  
.adrForceLUT    (adrForceLUT),   
.selForceLUT    (selForceLUT),    
//write into BRAM
.data_valid_p   (data_valid[3]),
.data_valid_n   (data_valid[6]),
.iHalf          (iHalf),                            
.nAtom_p        (nAtom[(iHalf*nBox+3 )*8 +:8]),    
.nAtom_n        (nAtom[(iHalf*nBox+6 )*8 +:8]),     
.data_p         (gtp2_data_recv),
.data_n         (gtp3_data_recv),
.nAtomReset     (nAtomResetExt||nAtomReset),
.overflowSubbox (overflowSubbox_y),
//Calculation pipeline
.iHalf_CalcClk  (iHalf_CalcClk),                               //iHalf on CalcClk for reading
.start_i2       (start_i2),
.dataHome       (dataHome[DataByteWidth_n*8-1:0]),     
//for exclusion in ForceNonBond
.closeAtom_rcv  (closeAtom_rcv),                        //on DDR3clk,
.closeAtom      (closeAtom),                            //on DDR3clk, 
.pair14         (pair14),                               //on DDR3clk, 
.fudgeQQ        (fudgeQQ),                              //on IOclk    
.fudgeLJ        (fudgeLJ),                              //on IOclk     
//output results                 
.forceReady     (force_yReady),
.fifoOut        (fifoOut),
.forceFifo      (force_yFifo),
.slowDown       (slowDown_y)
);

//neighboring boxes in +/- z-direction i.e. boxes p00 and n00
wire        [95:0]    force_zFifo;
ForceBox1 
#(  
.DataByteWidth_n    (DataByteWidth_n),
.nSelForceLUT       (nSelForceLUT),
.q0                 (2),     //swap x and z 
.q1                 (1),
.q2                 (0),
.metaAtomNr_len     (metaAtomNr_len),
.metaAtomTypeLJ     (metaAtomTypeLJ),    
.metaAtomTypeLJ_len (metaAtomTypeLJ_len),   
.metaCharge         (metaCharge),   
.metaCharge_len     (metaCharge_len),
.nProteinAtom       (nProteinAtom),                                           
.nCLOSEATOM         (nCLOSEATOM)                     
) ForceBox_z
(
.IOclk          (IOclk),
.CalcClk        (CalcClk),
.clk200MHz      (clk200MHz),
.DDR3clk        (DDR3clk),                           
.MDReset        (MDReset), 
//write force LUT
.wrForceLUT     (wrForceLUT),    
.dataForceLUT   (dataForceLUT),  
.adrForceLUT    (adrForceLUT),   
.selForceLUT    (selForceLUT),    
//write into BRAM
.data_valid_p   (data_valid[9]),
.data_valid_n   (data_valid[18]),
.iHalf          (iHalf),
.nAtom_p        (nAtom[(iHalf*nBox+9 )*8 +:8]),
.nAtom_n        (nAtom[(iHalf*nBox+18)*8 +:8]),
.data_p         (e3_data_recv),
.data_n         (e4_data_recv),
.nAtomReset     (nAtomResetExt||nAtomReset),
.overflowSubbox (overflowSubbox_z),
//Calculation pipeline
.iHalf_CalcClk  (iHalf_CalcClk),                               //iHalf on CalcClk for reading
.start_i2       (start_i2),
.dataHome       (dataHome[DataByteWidth_n*8-1:0]),
//for exclusion in ForceNonBond
.closeAtom_rcv  (closeAtom_rcv),                        //on DDR3clk, 
.closeAtom      (closeAtom),                            //on DDR3clk,
.pair14         (pair14),                               //on DDR3clk, 
.fudgeQQ        (fudgeQQ),                              //on IOclk    
.fudgeLJ        (fudgeLJ),                              //on IOclk    
//output results
.forceReady     (force_zReady),
.fifoOut        (fifoOut),
.forceFifo      (force_zFifo),
.slowDown       (slowDown_z)
);


//neighboring boxes in the (xy)-corners, i.e. boxes 0pp, 0pn, 0np, 0nn
wire        [95:0]    force_xyFifo;
ForceBox12 
#(  
.DataByteWidth_n    (DataByteWidth_n),
.nSelForceLUT       (nSelForceLUT),
.q0                 (0),     
.q1                 (1),
.q2                 (2),
.metaAtomNr_len     (metaAtomNr_len),
.metaAtomTypeLJ     (metaAtomTypeLJ),    
.metaAtomTypeLJ_len (metaAtomTypeLJ_len),   
.metaCharge         (metaCharge),   
.metaCharge_len     (metaCharge_len),
.nProteinAtom       (nProteinAtom),                                                  
.nCLOSEATOM         (nCLOSEATOM)                       
) ForceBox_xy
(
.IOclk          (IOclk),
.CalcClk        (CalcClk),
.clk200MHz      (clk200MHz),
.DDR3clk        (DDR3clk),                            
.MDReset        (MDReset), 
//write force LUT
.wrForceLUT     (wrForceLUT),    
.dataForceLUT   (dataForceLUT),  
.adrForceLUT    (adrForceLUT),   
.selForceLUT    (selForceLUT),    
//write into BRAM
.data_valid_pp  (data_valid[4]),
.data_valid_pn  (data_valid[5]),
.data_valid_np  (data_valid[7]),
.data_valid_nn  (data_valid[8]),
.iHalf          (iHalf),
.nAtom_pp       (nAtom[(iHalf*nBox+4 )*8 +:8]),
.nAtom_pn       (nAtom[(iHalf*nBox+5 )*8 +:8]),
.nAtom_np       (nAtom[(iHalf*nBox+7 )*8 +:8]),
.nAtom_nn       (nAtom[(iHalf*nBox+8 )*8 +:8]),
.data_pp        (gtp0_data_recv),
.data_pn        (gtp2_data_recv),
.data_np        (gtp3_data_recv),
.data_nn        (gtp1_data_recv),
.nAtomReset     (nAtomResetExt||nAtomReset),
.overflowSubbox (overflowSubbox_xy), 
//Calculation pipeline
.iHalf_CalcClk  (iHalf_CalcClk),                               //iHalf on CalcClk for reading
.start_i2       (start_i2),
.dataHome       (dataHome[DataByteWidth_n*8-1:0]),
//for exclusion in ForceNonBond
.closeAtom_rcv  (closeAtom_rcv),                        //on DDR3clk,
.closeAtom      (closeAtom),                            //on DDR3clk,
.pair14         (pair14),                               //on DDR3clk, 
.fudgeQQ        (fudgeQQ),                              //on IOclk    
.fudgeLJ        (fudgeLJ),                              //on IOclk     
//output results
.forceReady     (force_xyReady),
.fifoOut        (fifoOut),
.forceFifo      (force_xyFifo),
.slowDown       (slowDown_xy)
);


//neighboring boxes in the (xz)-corners, i.e. boxes p0p, p0n, n0p, n0n
wire        [95:0]    force_xzFifo;
ForceBox12 
#(  
.DataByteWidth_n    (DataByteWidth_n),
.nSelForceLUT       (nSelForceLUT),
.q0                 (0),     //swap y and z 
.q1                 (2),
.q2                 (1),
.metaAtomNr_len     (metaAtomNr_len),
.metaAtomTypeLJ     (metaAtomTypeLJ),    
.metaAtomTypeLJ_len (metaAtomTypeLJ_len),   
.metaCharge         (metaCharge),   
.metaCharge_len     (metaCharge_len),
.nProteinAtom       (nProteinAtom),                                                
.nCLOSEATOM         (nCLOSEATOM)                     
) ForceBox_xz
(
.IOclk          (IOclk),
.CalcClk        (CalcClk),
.clk200MHz      (clk200MHz),
.DDR3clk        (DDR3clk),                            
.MDReset        (MDReset), 
//write force LUT
.wrForceLUT     (wrForceLUT),    
.dataForceLUT   (dataForceLUT),  
.adrForceLUT    (adrForceLUT),   
.selForceLUT    (selForceLUT),    
//write into BRAM
.data_valid_pp  (data_valid[10]),
.data_valid_pn  (data_valid[11]),
.data_valid_np  (data_valid[19]),
.data_valid_nn  (data_valid[20]),
.iHalf          (iHalf),
.nAtom_pp       (nAtom[(iHalf*nBox+10)*8 +:8]),
.nAtom_pn       (nAtom[(iHalf*nBox+11)*8 +:8]),
.nAtom_np       (nAtom[(iHalf*nBox+19)*8 +:8]),
.nAtom_nn       (nAtom[(iHalf*nBox+20)*8 +:8]),
.data_pp        (gtp0_data_recv),
.data_pn        (gtp1_data_recv),
.data_np        (gtp0_data_recv),
.data_nn        (gtp1_data_recv),
.nAtomReset     (nAtomResetExt||nAtomReset),
.overflowSubbox (overflowSubbox_xz),
//Calculation pipeline
.iHalf_CalcClk  (iHalf_CalcClk),                               //iHalf on CalcClk for reading
.start_i2       (start_i2),
.dataHome       (dataHome[DataByteWidth_n*8-1:0]),
//for exclusion in ForceNonBond
.closeAtom_rcv  (closeAtom_rcv),                        //on DDR3clk, 
.closeAtom      (closeAtom),                            //on DDR3clk, 
.pair14         (pair14),                               //on DDR3clk, 
.fudgeQQ        (fudgeQQ),                              //on IOclk    
.fudgeLJ        (fudgeLJ),                              //on IOclk       
//output results
.forceReady     (force_xzReady),
.fifoOut        (fifoOut),
.forceFifo      (force_xzFifo),
.slowDown       (slowDown_xz)
);

//neighboring boxes in the (yz)-corners, i.e. boxes pp0, pn0, np0, nn0
wire        [95:0]    force_yzFifo;
ForceBox12 
#(  
.DataByteWidth_n    (DataByteWidth_n),
.nSelForceLUT       (nSelForceLUT),
.q0                 (2),     //swap x and z 
.q1                 (1),
.q2                 (0),
.metaAtomNr_len     (metaAtomNr_len),
.metaAtomTypeLJ     (metaAtomTypeLJ),    
.metaAtomTypeLJ_len (metaAtomTypeLJ_len),   
.metaCharge         (metaCharge),   
.metaCharge_len     (metaCharge_len),
.nProteinAtom       (nProteinAtom),                                                 
.nCLOSEATOM         (nCLOSEATOM)                           
) ForceBox_yz
(
.IOclk          (IOclk),
.CalcClk        (CalcClk),
.clk200MHz      (clk200MHz),
.DDR3clk        (DDR3clk),                            
.MDReset        (MDReset), 
//write force LUT
.wrForceLUT     (wrForceLUT),    
.dataForceLUT   (dataForceLUT),  
.adrForceLUT    (adrForceLUT),   
.selForceLUT    (selForceLUT),    
//write into BRAM
.data_valid_pp  (data_valid[12]),
.data_valid_pn  (data_valid[21]),                    //pn and np swapped due to xz swapping
.data_valid_np  (data_valid[15]),
.data_valid_nn  (data_valid[24]),
.iHalf          (iHalf),
.nAtom_pp       (nAtom[(iHalf*nBox+12)*8 +:8]),
.nAtom_pn       (nAtom[(iHalf*nBox+21)*8 +:8]),     //pn and np swapped due to xz swapping
.nAtom_np       (nAtom[(iHalf*nBox+15)*8 +:8]),
.nAtom_nn       (nAtom[(iHalf*nBox+24)*8 +:8]),
.data_pp        (gtp2_data_recv),
.data_pn        (gtp2_data_recv),                  //pn and np swapped due to xz swapping
.data_np        (gtp3_data_recv),
.data_nn        (gtp3_data_recv),
.nAtomReset     (nAtomResetExt||nAtomReset),
.overflowSubbox (overflowSubbox_yz),
//Calculation pipeline
.iHalf_CalcClk  (iHalf_CalcClk),                               //iHalf on CalcClk for reading
.start_i2       (start_i2),
.dataHome       (dataHome[DataByteWidth_n*8-1:0]),
//for exclusion in ForceNonBond
.closeAtom_rcv  (closeAtom_rcv),                        //on DDR3clk,
.closeAtom      (closeAtom),                            //on DDR3clk, 
.pair14         (pair14),                               //on DDR3clk, 
.fudgeQQ        (fudgeQQ),                              //on IOclk    
.fudgeLJ        (fudgeLJ),                              //on IOclk        
//output results
.forceReady     (force_yzReady),
.fifoOut        (fifoOut),
.forceFifo      (force_yzFifo),
.slowDown       (slowDown_yz)
);

//neighboring boxes in the (xyz)-corners, i.e. boxes ppp, ppn, pnp, pnn, npp, npn, nnp, nnn
wire        [95:0]    force_xyzFifo;
ForceBox123
#(  
.DataByteWidth_n    (DataByteWidth_n),
.nSelForceLUT       (nSelForceLUT),
.metaAtomNr_len     (metaAtomNr_len),
.metaAtomTypeLJ     (metaAtomTypeLJ),    
.metaAtomTypeLJ_len (metaAtomTypeLJ_len),   
.metaCharge         (metaCharge),   
.metaCharge_len     (metaCharge_len),
.nProteinAtom       (nProteinAtom),                                               
.nCLOSEATOM         (nCLOSEATOM)                         
) ForceBox_xyz
(
.IOclk          (IOclk),
.CalcClk        (CalcClk),
.clk200MHz      (clk200MHz),
.DDR3clk        (DDR3clk),                            
.MDReset        (MDReset), 
//write force LUT
.wrForceLUT     (wrForceLUT),    
.dataForceLUT   (dataForceLUT),  
.adrForceLUT    (adrForceLUT),   
.selForceLUT    (selForceLUT),    
//write into BRAM
.data_valid_ppp (data_valid[13]),
.data_valid_ppn (data_valid[14]),
.data_valid_pnp (data_valid[16]),
.data_valid_pnn (data_valid[17]),
.data_valid_npp (data_valid[22]),
.data_valid_npn (data_valid[23]),
.data_valid_nnp (data_valid[25]),
.data_valid_nnn (data_valid[26]),
.iHalf          (iHalf),
.nAtom_ppp      (nAtom[(iHalf*nBox+13)*8 +:8]),
.nAtom_ppn      (nAtom[(iHalf*nBox+14)*8 +:8]),
.nAtom_pnp      (nAtom[(iHalf*nBox+16)*8 +:8]),
.nAtom_pnn      (nAtom[(iHalf*nBox+17)*8 +:8]),
.nAtom_npp      (nAtom[(iHalf*nBox+22)*8 +:8]),
.nAtom_npn      (nAtom[(iHalf*nBox+23)*8 +:8]),
.nAtom_nnp      (nAtom[(iHalf*nBox+25)*8 +:8]),
.nAtom_nnn      (nAtom[(iHalf*nBox+26)*8 +:8]),
.data_ppp       (gtp0_data_recv),
.data_ppn       (gtp2_data_recv),
.data_pnp       (gtp3_data_recv),
.data_pnn       (gtp1_data_recv),
.data_npp       (gtp0_data_recv),
.data_npn       (gtp2_data_recv),
.data_nnp       (gtp3_data_recv),
.data_nnn       (gtp1_data_recv),
.nAtomReset     (nAtomResetExt||nAtomReset),
.overflowSubbox (overflowSubbox_xyz),
//Calculation pipeline
.iHalf_CalcClk  (iHalf_CalcClk),                               //iHalf on CalcClk for reading
.start_i2       (start_i2),
.dataHome       (dataHome[DataByteWidth_n*8-1:0]),
//for exclusion in ForceNonBond
.closeAtom_rcv  (closeAtom_rcv),                        //on DDR3clk, 
.closeAtom      (closeAtom),                            //on DDR3clk,
.pair14         (pair14),                               //on DDR3clk, 
.fudgeQQ        (fudgeQQ),                              //on IOclk    
.fudgeLJ        (fudgeLJ),                              //on IOclk      
//output results
.forceReady     (force_xyzReady),
.fifoOut        (fifoOut),
.forceFifo      (force_xyzFifo),
.slowDown       (slowDown_xyz)
);

//bonded interactions
wire        [95:0]    force_Stretch, force_Bend, force_Dihed;
wire        [2:0]     BondInteraction_error;    
BondedInteractions
#(  
.metaAtomNr_len     (metaAtomNr_len),
.nProteinAtom       (nProteinAtom),
.DDR3_DATA_WIDTH    (DDR3_DATA_WIDTH),
.FF_LENGTH          (FF_LENGTH),
.FF_WIDTH           (FF_WIDTH ),                                
.nCLOSEATOM         (nCLOSEATOM),                                         
.CLOSEATOM_WIDTH    (CLOSEATOM_WIDTH)
) BondedInteractions
(
  .IOclk                 (IOclk),
  .clk200MHz             (clk200MHz),       
  .sys_clk               (sys_clk), 
  .DDR3clk               (DDR3clk),                       
  .MDReset               (MDReset),      
  .ResetStart            (ResetStart),  
  .BondInteraction_error (BondInteraction_error), 
//input from ReadCommand to write force field data into DDR3 RAM; 
  .ForceField_rcv        (ForceField_rcv),                                                        
  .ForceField_data       (ForceField_data),
  .ForceField_atom       (ForceField_atom),                     
//write protein atoms into BRAM
//  .nAtomReset            (nAtomResetExt||nAtomReset),    //has been there for debuging only, no longer used
  .iHalf                 (iHalf),                          //iHalf on IOclk
  .dataProteinAtom       (dataProteinAtom),                                                           
  .dataProteinAtom_valid (dataProteinAtom_valid),      
//initiate calculation pipeline for atom in home box                          
  .start_i2              (start_i2),
  .dataHome              (dataHome[24*3+:metaAtomNr_len]),  //only atom1-number needed for DDR3-version
//  .dataHome              (dataHome[DataByteWidth_n*8-1:0]),   //for the hardcoded version, also need coordinates              
  .slowDown              (slowDown_Bonded),
//output of closeAtom, for exclusion in ForceNonBond
  .closeAtom             (closeAtom),                      //on DDR3clk,
  .pair14                (pair14),                         //on DDR3clk, 
  .closeAtom_rcv         (closeAtom_rcv),                  //on DDR3clk, 
//output of stretch calculation
  .fifoAllForcesOut      (fifoOut),                        //read FIFOs of all forces
  .forceStretchReady     (force_StretchReady),
  .forceStretchFifo      (force_Stretch),
//output of bend calculation
  .forceBendReady        (force_BendReady),            
  .forceBendFifo         (force_Bend),                  
//output of dihedral calculation
  .forceDihedReady       (force_DihedReady),           
  .forceDihedFifo        (force_Dihed),                  
//DDR3-pins; comment out when using reduced BRAM version of mem_burst
  .ddr3_dq               (ddr3_dq),                        //ddr3 data
  .ddr3_dqs_n            (ddr3_dqs_n),                     //ddr3 dqs negative
  .ddr3_dqs_p            (ddr3_dqs_p),                     //ddr3 dqs positive
  .ddr3_addr             (ddr3_addr),                      //ddr3 address
  .ddr3_ba               (ddr3_ba),                        //ddr3 bank
  .ddr3_ras_n            (ddr3_ras_n),                     //ddr3 ras_n
  .ddr3_cas_n            (ddr3_cas_n),                     //ddr3 cas_n
  .ddr3_we_n             (ddr3_we_n),                      //ddr3 write enable 
  .ddr3_reset_n          (ddr3_reset_n),                   //ddr3 reset,
  .ddr3_ck_p             (ddr3_ck_p),                      //ddr3 clock negative            
  .ddr3_ck_n             (ddr3_ck_n),                      //ddr3 clock positive
  .ddr3_cke              (ddr3_cke),                       //ddr3_cke,
  .ddr3_cs_n             (ddr3_cs_n),                      //ddr3 chip select,
  .ddr3_dm               (ddr3_dm),                        //ddr3_dm
  .ddr3_odt              (ddr3_odt)                        //ddr3_odt    
);


//**********************************************accumulate ensemble data and thermostat**********************************
//**********************************************                   on IOclk            **********************************
wire signed [31:0] vxcm, vycm,vzcm;         
wire signed [31:0] vxcm_d0, vycm_d0,vzcm_d0;                              
wire        [5:0]  mass1_d2;
wire        [23:0] Tscale,Tscale_d0;
wire signed [23:0] vx_d2,vy_d2,vz_d2;

Thermostat
#(
  .EnsembleByteWidth       (EnsembleByteWidth),
  .vshift                  (vshift) 
) Thermostat
(
  .IOclk                  (IOclk),
  .busy                   (ThermostatBusy),
  .nAtomReset             (nAtomReset),
  .newDataReady           (newDataReady),
//ensemble data from neigboring boxes 
  .EnsembleNeighborValid  (EnsembleNeighborValid),
  .EnsembleNeighbor       (EnsembleNeighbor),       
//Thermostat data       
  .WriteDataThermostat    (WriteDataThermostat),
  .AdrDataThermostat      (AdrDataThermostat),
  .DataThermostat         (DataThermostat),  
//velocity data 
  .mass                   (mass1_d2),          //mass, on IOclk, also all subsequent
  .vx                     (vx_d2),             //input velocities after Shake, 
  .vy                     (vy_d2),
  .vz                     (vz_d2),
  .vxcm                   (vxcm_d0),           
  .vycm                   (vycm_d0),           
  .vzcm                   (vzcm_d0),           
  .Tscale                 (Tscale_d0),          
  .EnsembleData           (EnsembleData)
);     

//ClkTransferNoSync #(.Width(32))  ClkTransferStat8  (.sigIn(vxcm_d0),.sigOut(vxcm));
ClkTransferStat #(.Width(32))  ClkTransferStat8  (.clkIn(IOclk),.clkOut(clk200MHz),.sigIn(vxcm_d0),.sigOut(vxcm));
ClkTransferStat #(.Width(32))  ClkTransferStat9  (.clkIn(IOclk),.clkOut(clk200MHz),.sigIn(vycm_d0),.sigOut(vycm));
ClkTransferStat #(.Width(32))  ClkTransferStat10 (.clkIn(IOclk),.clkOut(clk200MHz),.sigIn(vzcm_d0),.sigOut(vzcm));
ClkTransferStat #(.Width(24))  ClkTransferStat11 (.clkIn(IOclk),.clkOut(clk200MHz),.sigIn(Tscale_d0),.sigOut(Tscale));

//****************************************************************************************************************************
//               statemachine 2 that collects forces from various pipelines, and adds them up                                * 
//                                    runs at 200MHz                                                                         *
//****************************************************************************************************************************
 
wire signed [31:0]          Fx_x_Fifo   = force_xFifo[32*0 +:32]; 
wire signed [31:0]          Fy_x_Fifo   = force_xFifo[32*1 +:32];  
wire signed [31:0]          Fz_x_Fifo   = force_xFifo[32*2 +:32]; 
wire signed [31:0]          Fx_y_Fifo   = force_yFifo[32*0 +:32]; 
wire signed [31:0]          Fy_y_Fifo   = force_yFifo[32*1 +:32];  
wire signed [31:0]          Fz_y_Fifo   = force_yFifo[32*2 +:32]; 
wire signed [31:0]          Fx_z_Fifo   = force_zFifo[32*0 +:32]; 
wire signed [31:0]          Fy_z_Fifo   = force_zFifo[32*1 +:32];  
wire signed [31:0]          Fz_z_Fifo   = force_zFifo[32*2 +:32]; 
wire signed [31:0]          Fx_xy_Fifo  = force_xyFifo[32*0 +:32]; 
wire signed [31:0]          Fy_xy_Fifo  = force_xyFifo[32*1 +:32];  
wire signed [31:0]          Fz_xy_Fifo  = force_xyFifo[32*2 +:32]; 
wire signed [31:0]          Fx_xz_Fifo  = force_xzFifo[32*0 +:32]; 
wire signed [31:0]          Fy_xz_Fifo  = force_xzFifo[32*1 +:32];  
wire signed [31:0]          Fz_xz_Fifo  = force_xzFifo[32*2 +:32];
wire signed [31:0]          Fx_yz_Fifo  = force_yzFifo[32*0 +:32]; 
wire signed [31:0]          Fy_yz_Fifo  = force_yzFifo[32*1 +:32];  
wire signed [31:0]          Fz_yz_Fifo  = force_yzFifo[32*2 +:32];
wire signed [31:0]          Fx_xyz_Fifo = force_xyzFifo[32*0 +:32]; 
wire signed [31:0]          Fy_xyz_Fifo = force_xyzFifo[32*1 +:32];  
wire signed [31:0]          Fz_xyz_Fifo = force_xyzFifo[32*2 +:32];
wire signed [31:0]          Fx_Stretch  = force_Stretch[32*0 +:32]; 
wire signed [31:0]          Fy_Stretch  = force_Stretch[32*1 +:32];  
wire signed [31:0]          Fz_Stretch  = force_Stretch[32*2 +:32];
wire signed [31:0]          Fx_Bend     = force_Bend[32*0 +:32]; 
wire signed [31:0]          Fy_Bend     = force_Bend[32*1 +:32];  
wire signed [31:0]          Fz_Bend     = force_Bend[32*2 +:32]; 
wire signed [31:0]          Fx_Dihed    = force_Dihed[32*0 +:32]; 
wire signed [31:0]          Fy_Dihed    = force_Dihed[32*1 +:32];  
wire signed [31:0]          Fz_Dihed    = force_Dihed[32*2 +:32]; 
 
reg         [3:0]           CalcState2   = 1'b0;
wire signed [23:0]          x1_d0        = dataHomeFifo[24*0 +:24];   
wire signed [23:0]          y1_d0        = dataHomeFifo[24*1 +:24]; 
wire signed [23:0]          z1_d0        = dataHomeFifo[24*2 +:24];
reg  signed [23:0]          x1_d1, y1_d1, z1_d1;
wire        [metaRoute-1:0] metaData1_d0 = dataHomeFifo[24*3 +:metaRoute];      
wire signed [23:0]          vx_d0        = dataHomeFifo[24*6 +:24];
wire signed [23:0]          vy_d0        = dataHomeFifo[24*7 +:24];
wire signed [23:0]          vz_d0        = dataHomeFifo[24*8 +:24];
reg  signed [23:0]          v_d0         = 1'b0; 

wire signed [31:0]          Fx_HomeFifo  = forceHomeFifo[32*0 +:32]; 
wire signed [31:0]          Fy_HomeFifo  = forceHomeFifo[32*1 +:32]; 
wire signed [31:0]          Fz_HomeFifo  = forceHomeFifo[32*2 +:32]; 

reg  signed [31:0]          F_1=1'b0, F_2=1'b0, F_3=1'b0, F_4=1'b0, F_5=1'b0, F_12=1'b0, F_34=1'b0, F_56=1'b0, F_1234=1'b0,  F_all=1'b0; 
reg  signed [31:0]          vx_d1 = 1'b0, vy_d1 = 1'b0, vz_d1 = 1'b0;    

reg                             atomShakeRcv = 1'b0, atomDirectRcv=1'b0;
wire                            readyCollectConstraint;
wire [3:0]                      DataCollectValid,DataCollectValid1,DataCollectValid2;
wire [DataByteWidth_n*8-9+84:0] atomDataCollect;                                       //upper 8bit, which eventually will become route, are not included; velocities are 28bit each
wire                            readyShake,readyShake1,readyShake2;
wire                            errorCollectOvfl;
wire                            DataOutBusy;
wire [1:0]                      errorShake1,errorShake2;


assign forceReady = (~forceHomeReady)&&(~force_xReady)&&(~force_yReady)&&(~force_xyReady)&&(~force_zReady)&&(~force_xzReady)&&(~force_yzReady)&&(~force_xyzReady)&&(~force_StretchReady)&&(~force_BendReady)&&(~force_DihedReady); 
//force_BendReady commented out: 
//assign forceReady = (~forceHomeReady)&&(~force_xReady)&&(~force_yReady)&&(~force_xyReady)&&(~force_zReady)&&(~force_xzReady)&&(~force_yzReady)&&(~force_xyzReady)&&(~force_StretchReady);  
assign overflowSubbox = overflowSubbox_x||overflowSubbox_y||overflowSubbox_xy||overflowSubbox_z||overflowSubbox_xz||overflowSubbox_yz||overflowSubbox_xyz;
assign overflowError = {overflowSubbox,overflowNeighborBox,overflowHomeBox};


//calculation of inverse mass via lookup table
wire signed [55:0] F_scale_tmp;
wire signed [23:0] invMass;
wire        [5:0]  mass1=metaData1_d0[metaMass +: metaMass_len];
InvertMass_64x24   InvMassLUT (.a(mass1), .clk(clk200MHz), .qspo(invMass) );
mult_s32xu24_lat2  mult_invmass (.CLK(clk200MHz),.A(F_all),.B(invMass),.P(F_scale_tmp));
wire signed [31:0] F_scale = F_scale_tmp[54:23];                                        //reference mass is 16, whose inverse is 0x080000. Shifted output of force such that this is considered to be 1.

//calculation of scaled velocities
wire signed [49:0] v_Tscale_tmp;
mult_s25xs25_lat2  mult_vscale (.CLK(clk200MHz),.A({v_d0,1'b0}),.B({1'b0,Tscale}),.P(v_Tscale_tmp));
wire [28:0] v_Tscale = v_Tscale_tmp[47:19];                                              //Tscale=24h800000 is equal to 1; in addition, extend by 4 bits on lower side 
                                                                                         //add one bit on the lower side for rounding                                   
reg [7:0] CalcState2_Busy_ext=1'b0;                                                                                         
always @(posedge clk200MHz) begin  
  velOverflow_d0 <= 1'b0;
  case (CalcState2)
    0: begin
      if(forceReady) begin 
        CalcState2_Busy_ext[0] <= 1'b1;
        fifoOut                <= 1'b1;
        CalcState2             <= CalcState2+1'b1; 
      end else begin
        CalcState2_Busy_ext[0] <= 1'b0;
      end 
    end
    1: begin
      fifoOut    <= 1'b0;
      CalcState2 <= CalcState2 + 1'b1;  //wait for FIFO latency
    end
    2: begin  
      F_1        <= Fx_HomeFifo+ Fx_x_Fifo;     
      F_2        <= Fx_y_Fifo  + Fx_z_Fifo;
      F_3        <= Fx_xy_Fifo + Fx_xz_Fifo; 
      F_4        <= Fx_yz_Fifo + Fx_xyz_Fifo;  
      CalcState2 <= CalcState2 + 1'b1;   
    end
    3: begin
      F_12       <= F_1 + F_2;
      F_34       <= F_3 + F_4;
      F_1        <= Fy_HomeFifo+ Fy_x_Fifo;     
      F_2        <= Fy_y_Fifo  + Fy_z_Fifo;
      F_3        <= Fy_xy_Fifo + Fy_xz_Fifo; 
      F_4        <= Fy_yz_Fifo + Fy_xyz_Fifo;  
      F_5        <= Fx_Bend    + Fx_Stretch;     
//      F_5        <=  Fx_Stretch;                   //if no bending forces
      CalcState2 <= CalcState2 + 1'b1; 
    end  
    4: begin                 
      F_1234     <= F_12 + F_34;           
      F_12       <= F_1 + F_2;
      F_34       <= F_3 + F_4;
      F_56       <= F_5 + Fx_Dihed;                      
      F_1        <= Fz_HomeFifo+ Fz_x_Fifo;     
      F_2        <= Fz_y_Fifo  + Fz_z_Fifo;
      F_3        <= Fz_xy_Fifo + Fz_xz_Fifo; 
      F_4        <= Fz_yz_Fifo + Fz_xyz_Fifo;  
      F_5        <= Fy_Bend    + Fy_Stretch;   
//      F_5        <= Fy_Stretch;                 //if no bending forces
      CalcState2 <= CalcState2 + 1'b1; 
    end  
    5:begin
      v_d0       <= vx_d0;                   //send to mult_vscale
      F_all      <= F_1234 + F_56;           //send to mult_invmass
      F_1234     <= F_12 + F_34;             
      F_12       <= F_1 + F_2;
      F_34       <= F_3 + F_4;
      F_56       <= F_5 + Fy_Dihed;                     
      F_5        <= Fz_Bend    + Fz_Stretch;    
//      F_5        <= Fz_Stretch;             //if no bending forces
      CalcState2 <= CalcState2 + 1'b1; 
    end
    6:begin
      v_d0       <= vy_d0;                   //send to mult_vscale
      F_all      <= F_1234 + F_56;           //send to mult_invmass
      F_1234     <= F_12 + F_34;             
      F_56       <= F_5  + Fz_Dihed;                      
      CalcState2 <= CalcState2 + 1'b1; 
    end  
    7:begin
      v_d0       <= vz_d0;                   //send to mult_vscale
      F_all      <= F_1234 + F_56;           //send to mult_invmass          
      CalcState2 <= CalcState2 + 1'b1; 
    end    
    8:begin
      vx_d1      <= {{4{v_Tscale[28]}},v_Tscale[28:1]} + {31'b0,v_Tscale[0]} + F_scale - vxcm;  
      CalcState2 <= CalcState2 + 1'b1; 
    end
    9: begin
      if((vx_d1[31:27]!=5'h1f)&&(vx_d1[31:27]!=5'h0)) velOverflow_d0 <= 1'b1;  
      vy_d1      <= {{4{v_Tscale[28]}},v_Tscale[28:1]} + {31'b0,v_Tscale[0]} + F_scale - vycm;
      CalcState2 <= CalcState2 + 1'b1; 
    end
    10: begin
      if((vy_d1[31:27]!=5'h1f)&&(vy_d1[31:27]!=5'h0)) velOverflow_d0 <= 1'b1; 
      vz_d1      <= {{4{v_Tscale[28]}},v_Tscale[28:1]} + {31'b0,v_Tscale[0]} + F_scale - vzcm;
      CalcState2 <= CalcState2 + 1'b1; 
    end
    11: begin
      if((vz_d1[31:27]!=5'h1f)&&(vz_d1[31:27]!=5'h0)) velOverflow_d0 <= 1'b1; 
      x1_d1    <= x1_d0 +{{vshift+1{vx_d1[27]}},vx_d1[27:vshift+5]}+{23'b0,vx_d1[vshift+4]};             
      y1_d1    <= y1_d0 +{{vshift+1{vy_d1[27]}},vy_d1[27:vshift+5]}+{23'b0,vy_d1[vshift+4]};               
      z1_d1    <= z1_d0 +{{vshift+1{vz_d1[27]}},vz_d1[27:vshift+5]}+{23'b0,vz_d1[vshift+4]};   
      if(metaData1_d0[metaConstraint +:2]==2'b0) begin             //atom that is not in a constrain group; bypass shake 
        atomDirectRcv    <= 1'b1;   
        CalcState2 <= CalcState2 + 1'b1;
      end else begin                                              //atom that is  in a constrain group; colelct all atoms first and then enter shake 
        if(readyCollectConstraint) begin 
          atomShakeRcv    <= 1'b1;   
          CalcState2 <= CalcState2 + 1'b1;
        end
      end     
    end
    12: begin
      atomDirectRcv          <= 1'b0; 
      atomShakeRcv           <= 1'b0; 
      CalcState2             <= 4'd0;
    end
    default: CalcState2 <= 4'd0;
  endcase      
  CalcState2_Busy_ext[7:1] <= CalcState2_Busy_ext[6:0];   //extend it so that it has temporal overlap with ThermostatBusy
end

 ClkTransferStat #(.Width(1))  ClkTransferStat4  (.clkIn(clk200MHz),.clkOut(IOclk),.sigIn(|CalcState2_Busy_ext),.sigOut(CalcState2_Busy)); 
 ClkTransfer     #(.extend(2)) ClkTransfer1      (.clkIn(clk200MHz),.clkOut(IOclk),.sigIn(velOverflow_d0),.sigOut(velOverflow));  
 
 wire [DataByteWidth_n*8-9+84:0] atomDataShakeIn={vz_d1[27:0],vy_d1[27:0],vx_d1[27:0],metaData1_d0,z1_d0,y1_d0,x1_d0};  //velocities are 28bit; will be rounded after Shake; 8bits, which eventually will become route, are not yet included
 wire [DataByteWidth*8-1:0]      atomDataDirect ={vz_d1[27:4]+{23'b0,vz_d1[3]},vy_d1[27:4]+{23'b0,vy_d1[3]},vx_d1[27:4]+{23'b0,vx_d1[3]},2'b0,z1_d1[23:22],y1_d1[23:22],x1_d1[23:22],metaData1_d0,z1_d1,y1_d1,x1_d1};

 
/*********************************************************************************************/
//collects constraint group and initiates Shake 

CollectContraintGroup 
#(
.metaAtomNr_len    (metaAtomNr_len),
.DataByteWidth_n   (DataByteWidth_n),
.metaConstraint    (metaConstraint)
) CollectContraintGroup 
(   
.IOclk            (IOclk),
.clk              (clk200MHz),
.MDReset          (MDReset),                  //input, reset upon start
.inReady          (readyCollectConstraint),   //output, indicate that module is ready to accept data, can also be used as a busy signal //STILL NEED TO DO
.atomRcv          (atomShakeRcv),             //input, new atom that is in a constraint group is received
.atomDataIn       (atomDataShakeIn),          //input, new atom data, in contrast to typical data structure, velocities are 28bit
.outReady         (readyShake),               //input from downstream module when it is ready to accept data 
.DataOutBusy      (DataOutBusy),              //output, blocks a short period before and after data out
.DataOutValid     (DataCollectValid),         //output, grouped data valid, one bit for  center atom (bit0) and each of the varios H's
.atomDataCollect  (atomDataCollect),          //output, grouped atom data, velocities are 28bit 
.errorCollectOvfl (errorCollectOvfl)          //output, error on FIFO overflow
);

//distribute atom data over two Shake routines
reg  shakeSwitch  = 1'b0; 
always @(posedge clk200MHz) begin
  if (DataCollectValid[0])           shakeSwitch <= ~shakeSwitch;
  else if (~DataOutBusy&&shakeDone1) shakeSwitch <= 1'b0;    //switches when one shake is ready before the other one. DataOutBusy is active one cycle before and after communication, 
  else if (~DataOutBusy&&shakeDone2) shakeSwitch <= 1'b1;    //to avoid it switches during communication. Makes maximum use of both Shake's
end
assign   DataCollectValid1 = (shakeSwitch==1'b0) ? DataCollectValid : 4'b0;
assign   DataCollectValid2 = (shakeSwitch==1'b1) ? DataCollectValid : 4'b0;
assign   readyShake        = (shakeSwitch==1'b0) ? readyShake1 : readyShake2;

//1st Shake routine
wire [DataByteWidth*8-1:0] atomDataShake1;
wire [7:0]                 nIter1;
shake 
#(
 .DataByteWidth_n  (DataByteWidth_n),
 .DataByteWidth    (DataByteWidth),
 .vshift           (vshift),  
 .metaMass         (metaMass),
 .metaMass_len     (metaMass_len), 
 .metaConstraint   (metaConstraint),                  
 .metaRoute        (metaRoute)
) shake1
(   
 .IOclk            (IOclk),
 .clk              (clk200MHz),
 .MDReset          (MDReset),                   //input, reset upon start
 .inReady          (readyShake1),               //output, indicates that module is ready to accept data, can also be used as a busy signal
 .DataInRcv        (DataCollectValid1),         //input, new atom data received
 .atomDataIn       (atomDataCollect),           //input, new atom data, in contrast to typical data structure, velocities are 28bit
 .atomDataOutValid (atomDataShakeValid1),       //output, data valid 
 .atomDataOut      (atomDataShake1),            //output, data, velocities 24bit
 .shakeDone        (shakeDone1),                //output, shake finished
 .nIter            (nIter1),                    //output, number of iterations that were needed to reach convergence, for statistics
 .errorShake       (errorShake1),               //output, error signal either when number of iterations has not been sufficient (bit1), or, when the initial  
                                                //velocities have been to large (in the range of the bond distance, bit0)
//receive constraint data from host computer                                                
 .WriteSimParam    (WriteSimParam),            //write shake data
 .AdrSimParam      (AdrSimParam),              //adress of shake data, 0: accuracy, 1: rOHw, 2: rHHw, 3: rCH, 4: rNH, 5: rOH, 6: rSH
 .SimParam         (SimParam)                  //Shake data, inverse distance square, 17'h10000 corresponds to r=rcut/16                                          
);

//2nd Shake routine
wire [DataByteWidth*8-1:0] atomDataShake2;
wire [7:0]                 nIter2;
shake 
#(
 .DataByteWidth_n  (DataByteWidth_n),
 .DataByteWidth    (DataByteWidth),
 .vshift           (vshift),    
 .metaMass         (metaMass),
 .metaMass_len     (metaMass_len), 
 .metaConstraint   (metaConstraint),                 
 .metaRoute        (metaRoute)
) shake2
( 
 .IOclk            (IOclk),  
 .clk              (clk200MHz),
 .MDReset          (MDReset),                   //input, reset upon start
 .inReady          (readyShake2),               //output, indicates that module is ready to accept data, can also be used as a busy signal
 .DataInRcv        (DataCollectValid2),         //input, new atom data received
 .atomDataIn       (atomDataCollect),           //input, new atom data, in contrast to typical data structure, velocities are 28bit
 .atomDataOutValid (atomDataShakeValid2),       //output, data valid 
 .atomDataOut      (atomDataShake2),            //output, data, velocities 24bit
 .shakeDone        (shakeDone2),                //output, shake finished
 .nIter            (nIter2),                    //output, number of iterations that were needed to reach convergence, for statistics
 .errorShake       (errorShake2),               //output, error signal either when number of iterations has not been sufficient (bit1), or, when the initial  
                                                //velocities have been to large (in the range of the bond distance, bit0)
//receive constraint data from host computer                                                
 .WriteSimParam    (WriteSimParam),            //write shake data
 .AdrSimParam      (AdrSimParam),              //adress of shake data, 0: accuracy, 1: rOHw, 2: rHHw, 3: rCH, 4: rNH, 5: rOH, 6: rSH
 .SimParam         (SimParam)                  //Shake data, inverse distance square, 17'h10000 corresponds to r=rcut/16                                                 
);

//sum up number of iterations; needed for analysis only
wire        shakeDone;
wire [7:0]  nIter;
GatedMultplx #(.nPort(2),.nWidth(8)) GatedMultplx2
 (
  .clk               (clk200MHz),
  .data_port         ({nIter2,nIter1}),               
  .data_port_valid   ({shakeDone2}),
  .tx_req_port       ({shakeDone2,shakeDone1}),
  .tx_req            (shakeDone),
  .dataout           (nIter),                                   
  .error             ()
 ); 

 

 reg [7:0]   nShakeTot_d0 = 1'b0;
 reg [15:0]  nIterTot_d0  = 1'b0;
 wire        nAtomReset_d0;
 ClkTransfer #(.extend (2)) ClkTransfer3 (.clkIn(IOclk),.clkOut(clk200MHz),.sigIn(nAtomReset),.sigOut(nAtomReset_d0)); 
 always @(posedge clk200MHz) begin
   if(nAtomReset_d0) begin
     nShakeTot_d0 <= 1'b0;
     nIterTot_d0  <= 1'b0;
   end else begin
     if(shakeDone) begin
       nShakeTot_d0 <= nShakeTot_d0 + 1'b1;
       nIterTot_d0  <= nIterTot_d0  + nIter;
     end
   end
 end
 ClkTransferStat #(.Width(8))  ClkTransferStat5  (.clkIn(clk200MHz),.clkOut(IOclk),.sigIn(nShakeTot_d0),.sigOut(nShakeTot)); 
 ClkTransferStat #(.Width(16))  ClkTransferStat6 (.clkIn(clk200MHz),.clkOut(IOclk),.sigIn(nIterTot_d0), .sigOut(nIterTot));   

 reg  [7:0] shakeBusy_ext=1'b0;
 always @(posedge clk200MHz) begin
   shakeBusy_ext<={shakeBusy_ext[6:0],(~readyShake1)||(~readyShake2)};   //extend shakeBusy so that it has temporal overlap with thermostatBusy
 end 
 ClkTransferStat #(.Width(1))  ClkTransferStat7  (.clkIn(clk200MHz),.clkOut(IOclk),.sigIn(|shakeBusy_ext),.sigOut(shakeBusy)); 

//combine data from the two shake routines, as well as those that are bypassed;
wire [DataByteWidth*8-1:0]     newData_d0;
wire                           newDataReady_d0;
GatedMultplx
#(
.nPort   (3),
.nWidth  (DataByteWidth*8)                 
) GatedMultplx1
(
 .clk               (clk200MHz),
 .data_port         ({atomDataShake2,atomDataShake1,atomDataDirect}),               
 .data_port_valid   ({atomDataShakeValid2,atomDataShakeValid1}),
 .tx_req_port       ({atomDataShakeValid2,atomDataShakeValid1,atomDirectRcv}),
 .tx_req            (newDataReady_d0),
 .dataout           (newData_d0),                                   
 .error             (GatedMuxError_d0)
); 
ClkTransfer #(.extend (2)) ClkTransfer2 (.clkIn(clk200MHz),.clkOut(IOclk),.sigIn(GatedMuxError_d0),.sigOut(GatedMuxError));  


//FIFO new data, to slow them down and also as a clock transfer
wire newDataFIFOReady;
reg  newDataFIFOOut=1'b0;

FIFO_async 
  #(
   .WIDTH(DataByteWidth*8),
   .DEPTH(64),
   .PROG_FULL_THRESH(55)
   ) newDataFIFO 
  (
  .rst(1'b0),
  .wr_clk(clk200MHz),    
  .rd_clk(IOclk),     
  .din(newData_d0),      
  .wr_en(newDataReady_d0),  
  .rd_en(newDataFIFOOut),  
  .dout(newData),    
  .full(),    
  .empty(newDataFIFOReady),  
  .prog_full()                 
);

 reg  [7:0] newDataFIFOBusy_ext=1'b0;
 always @(posedge IOclk) begin
   newDataFIFOBusy_ext<={newDataFIFOBusy_ext[6:0],(~newDataFIFOReady)};   //extend so that it has temporal overlap with thermostatBusy
 end 
assign newDataFIFOBusy=(|newDataFIFOBusy_ext);

//*******************************from here on, is on IOclk again************************
 reg [3:0] CalcState3=1'b0;
 always @(posedge IOclk) begin
   case (CalcState3)
     0: begin
       if(~newDataFIFOReady) begin
         CalcState3     <= CalcState3 +1'b1;
         newDataFIFOOut <= 1'b1;
       end
     end  
     1: begin                                
       CalcState3     <= CalcState3 +1'b1;
       newDataFIFOOut <= 1'b0;
       newDataReady   <= 1'b1;
     end
     default: begin
       CalcState3     <= CalcState3 +1'b1;  //count up until full in order to generate a gap of 16 clock cycles between data  
       newDataReady   <= 1'b0;
     end
   endcase 
 end 

//extract data needed for thermostat
  assign vx_d2    = newData[DataByteWidth_n*8+0*24 +:24];
  assign vy_d2    = newData[DataByteWidth_n*8+1*24 +:24];
  assign vz_d2    = newData[DataByteWidth_n*8+2*24 +:24];
  assign mass1_d2 = newData[3*24 + metaMass        +:metaMass_len];
  
//collect error signals
  wire [1:0] errorShake = errorShake1|errorShake2;
  assign MD_error={BondInteraction_error,GatedMuxError,errorShake,errorCollectOvfl,velOverflow};
 
//***********************************************************************
//collect some of the simulation parameter
always @(posedge IOclk) begin
  if (WriteSimParam) begin
    case (AdrSimParam)
      7: fudgeQQ  <= SimParam;    
      8: fudgeLJ  <= SimParam[0];        
    endcase         
  end
end 

endmodule
