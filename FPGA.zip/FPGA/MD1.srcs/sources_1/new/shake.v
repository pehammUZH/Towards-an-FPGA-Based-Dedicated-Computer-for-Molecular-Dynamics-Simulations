`timescale 1ns / 1ps

//- Performs Shake by iteratatevly calculating (r^2/r_0^2-1)/2, where r0 is the desired distance. That term is a correction factor for the corresponding  
//  connecting vector. Iterates over the nBond bonds, and as an outer loop until convergence is achieved. Has a stop criterion, which corresponds to 
//  about 10^-5 of the bond distance. 
//- Contraint data in meta data of central atom (O, C, N, or S) controls function. Contraint data consist of 3bit. The highest bit determines whether it 
//  is water, and the two lower bits the number of hydrogens nH. If it is water, nH must be 2, the H..H distance is constrained as well, and iR2_OHw as 
//  well as iR2_HH are the chosen as target distances. If it is not water, nH can be 1..3, only the X..H diances are constrained, and depending on mass of 
//  central atom, iR2_CH, iR2_NH, iR2_OH, or iR2_SH is chosen as trarget distance, with masses 12, 14, 16 and 32, respectively.  
//- Mass ratios consider masses of central atom (12, 14, 16 or 32), as well as of first hydrogen, which can be either 1 or 2. Masses of the other
//  hydrogens are not read but are assumed to be the same.
//- When done, new velocities are added to positions with proper round-off. The routing information is that of the center atom also for all H's, so that 
//  they appear in the same box at the next MD step, even when they are slightly outside. Otherwise, CollectConstraintGroup would not find all H's.
//- If the maximum number of iterations (nIterMax=5'h1f) is exceeded, stops as well but generates an error signal (errorShake[1]). The date might
//  still be valid in that case. Input velocities can be up to 0.7 of bond distance, but it converges slowly if it is getting close to that limit,  
//  which in turn might cause errorShake[1]. If velocities are larger than that limit, another error signal is generated (errorShake[0]), as convergence 
//  is no longer possible. 
//- A lower bit-resolution version was tested, which needs fewer DSP (7 instead of 10) and one fewer clock cycle. In terms of bond distance was equally good,  
//  i.e., 10^-5, which  is close to bit resolution of atom positions. However, generated 200times larger center-of-mass motion.
//- Number of required iterations typically between 10-15. Requires 15 clock cycle per single calculation, i.e., 1us for 3 iterations at 100MHz, or 4-5us 
//  in total per water. As about 1 water appears per 3us, should include at least two parallel  shake modules. Outputs number of required iterations (nIter) for a statistics.
//- bit size velocities 28 at input and 24 at output 
//
//- Required resources: 10DSP, no BRAM, and a relatively high number of FFs and LUTs. 
//



module shake
#(
parameter  DataByteWidth_n    = 18,                  //reduced data width without velocities
parameter  DataByteWidth      = 27,
parameter  vshift             = 4,                   //
parameter  metaMass           = 42,                  //position of mass in meta data
parameter  metaMass_len       = 6,                   //its length; 
parameter  metaConstraint     = 48,                  //position of contraint info in meta data
parameter  metaRoute          = 64
)
(    
  input                                        IOclk,
  input                                        clk,
  input                                        MDReset,          //reset upon start, on IOclk
  output reg                                   inReady=1'b1,     //ready to accept input, can also be used as a busy signal
  input             [3:0]                      DataInRcv,        //new atom data received
  input             [DataByteWidth_n*8-9+84:0] atomDataIn,       //new atom data; 8bit, which eventually will become route, not included; velocities 28bit each
  output reg                                   atomDataOutValid, //output data valid 
  output reg        [DataByteWidth*8-1:0]      atomDataOut,      //output data; route now included and standard data structure
  output reg                                   shakeDone,        //shake finished
  output reg        [7:0]                      nIter=1'b0,       //number of iterations that were needed to reach convergence, for statistics
  output            [1:0]                      errorShake,       //error signal either whne number of iterations has not been sufficient (bit1), or, when the initial  
                                                                 //velocities have been to large (in the range of the bond distance, bit0)
//receive constraint data from host computer 
  input                                        WriteSimParam,    //write shake data
  input             [3:0]                      AdrSimParam,      //adress of shake data, 0: accuracy, 1: rOHw, 2: rHHw, 3: rCH, 4: rNH, 5: rOH, 6: rSH
  input             [16:0]                     SimParam          //Shake parameter, accuracy and inverse distance square, 17'h10000 corresponds to r=rcut/16             
//the following outputs the velocities during the iteration; for debugging only  
/*
 output reg                                 iterDone,            //signal that an iteration is done; is commented out in state machine                                         
 output reg signed [27:0]                   vx0_out,             //velocities during iteration
 output reg signed [27:0]                   vy0_out,
 output reg signed [27:0]                   vz0_out,
 output reg signed [27:0]                   vx1_out,
 output reg signed [27:0]                   vy1_out,
 output reg signed [27:0]                   vz1_out,
 output reg signed [27:0]                   vx2_out,
 output reg signed [27:0]                   vy2_out,
 output reg signed [27:0]                   vz2_out,
 output reg signed [27:0]                   vx3_out,
 output reg signed [27:0]                   vy3_out,
 output reg signed [27:0]                   vz3_out
*/
);

reg signed [27:0]                           vx0_out,vy0_out,vz0_out,vx1_out,vy1_out,vz1_out,vx2_out,vy2_out,vz2_out,vx3_out,vy3_out,vz3_out;

localparam massRatioHH = 24'h800000;        //0.5
localparam massRatioOH = 24'd986895;        //1/17 m_H/(m_H+m_O)
localparam massRatioOD = 24'd1864135;       //2/18 m_D/(m_D+m_O)
localparam massRatioCH = 24'd1290555;       //1/13 
localparam massRatioCD = 24'd2396745;       //2/14 
localparam massRatioNH = 24'd1118481;       //1/15 
localparam massRatioND = 24'd2097152;       //2/16
localparam massRatioSH = 24'd508400;        //1/33 
localparam massRatioSD = 24'd986895;        //2/34


localparam nIterMax    = 5'h1f;             //max is 1f; might be a bit tight
 

//receiving shake data from host computer
reg   [16:0] iR2_OHw = 17'd27849;    //1/16 is refernce distance, in which case ir2_OHw is 2^16. With rOH=0.1 and rcut=1.043: (rcut/rOH/16)^2*2^16 
reg   [16:0] iR2_HHw = 17'd10482;    //rHH=0.163  
reg   [16:0] iR2_OH  = 17'd43264;    //default value for rXH=.1, rcut=1.3        
reg   [16:0] iR2_CH  = 17'd43264;    //default value for rXH=.1, rcut=1.3   
reg   [16:0] iR2_NH  = 17'd43264;    //default value for rXH=.1, rcut=1.3  , 
reg   [16:0] iR2_SH  = 17'd43264;    //default value for rXH=.1, rcut=1.3  
reg   [16:0] iR2_XH  = 1'b0;
reg   [7:0]  accur   = 7'h10;         //gives about 10^-5 convergence

always @(posedge IOclk) begin
  if (WriteSimParam) begin
    case (AdrSimParam)
      0: accur    <= SimParam[7:0];   //accuracy 
      1: iR2_OHw  <= SimParam;        //inverse-square r_OHw^2, for water, 
      2: iR2_HHw  <= SimParam;        //inverse-square r_HHw^2, for water, 
      3: iR2_CH   <= SimParam;        //inverse-square r_CH^2, CH_x groups
      4: iR2_NH   <= SimParam;        //inverse-square r_NH^2, NH_x groups
      5: iR2_OH   <= SimParam;        //inverse-square r_OH^2, OH group; not water
      6: iR2_SH   <= SimParam;        //inverse-square r_SH^2, SH group
    endcase         
  end
end

wire [7:0] accur_d0;
ClkTransferStat #(.Width (8))  ClkTransferStat1  //is new
(
    .clkIn   (IOclk),
    .clkOut  (clk),
    .sigIn   (accur),
    .sigOut  (accur_d0)
); 

wire MDReset_clk;
ClkTransfer #(.extend (2)) ClkTransfer0  
(
    .clkIn      (IOclk),
    .clkOut     (clk),
    .sigIn      (MDReset),
    .sigOut     (MDReset_clk)
); 

//actual shake routine
reg           [4:0]                   state      = 1'b0; 
reg           [2:0]                   iBond      = 1'b0;
reg           [4:0]                   iIter      = 1'b0;
reg           [2:0]                   nBond      = 1'b0;
reg                                   isWater    = 1'b0;
reg           [metaMass_len-1:0]      massX      = 1'b0;
reg           [1:0]                   massH      = 1'b0;


reg           [DataByteWidth_n*8-9:0] atomData0, atomData1, atomData2, atomData3;   //8bit, which eventually will become route, are not included;
reg    signed [23:0]                  dx21;
reg    signed [23:0]                  dy21;
reg    signed [23:0]                  dz21;
reg    signed [23:0]                  dx10;
reg    signed [23:0]                  dy10;
reg    signed [23:0]                  dz10;
reg    signed [23:0]                  dx20;
reg    signed [23:0]                  dy20;
reg    signed [23:0]                  dz20;
reg    signed [23:0]                  dx30;
reg    signed [23:0]                  dy30;
reg    signed [23:0]                  dz30;
reg    signed [24:0]                  dq;
reg    signed [23:0]                  dx0,dy0,dz0;
reg           [1:0]                   cnt=1'b0;
reg           [23:0]                  r2=1'b0;
reg           [16:0]                  iR2=1'b0;
reg   signed  [17:0]                  fact,fact21,fact10,fact20,fact30;
reg           [23:0]                  massRatio1,massRatio2,massRatio;
reg           [23:0]                  massRatioXH;
reg           [1:0]                   errorShakeOvfl=1'b0;

                                                                   
wire   errorShakeConv,errorShakeOvfl_d0;                                                                   
ClkTransfer #(.extend (2)) ClkTransfer1  
(
    .clkIn      (clk),
    .clkOut     (IOclk),
    .sigIn      (iIter==nIterMax),                     //error when iteration does not converge
    .sigOut     (errorShakeConv)
);  
                                                                  
ClkTransfer #(.extend (2)) ClkTransfer2  
(
    .clkIn      (clk),
    .clkOut     (IOclk),
    .sigIn      (errorShakeOvfl==2'b01),                //detect rising slope, as it might persist
    .sigOut     (errorShakeOvfl_d0)
);                                                                    
assign errorShake      = {errorShakeConv,errorShakeOvfl_d0};   
 
 
  wire [49:0] dq2_tmp;
  mult_s25xs25_lat2   mult_dq2    (.CLK(clk),.A(dq),.B(dq),.P(dq2_tmp));           
  wire [23:0] dq2=dq2_tmp[43:20];  

  wire [42:0] r2rel_tmp;
  mult_s25xs18_lat1   mult_iR2    (.CLK(clk),.A({1'b0,r2}),.B({1'b0,iR2}),.P(r2rel_tmp));      
  wire  signed  [17:0] r2rel = r2rel_tmp[35:18];                                                //range 0...4, but usable is only 0...3
 
  wire          [42:0]            fact_r;
  mult_s25xs18_lat1   mult_fact   (.CLK(clk),.A({1'b0,massRatio}),.B(fact),.P(fact_r)); 
  
  wire  signed  [49:0]            dvx,dvy,dvz;
  mult_s25xs25_lat2   mult_dx     (.CLK(clk),.A({dx0,1'b0}),.B(fact_r[41:17]),.P(dvx));     
  mult_s25xs25_lat2   mult_dy     (.CLK(clk),.A({dy0,1'b0}),.B(fact_r[41:17]),.P(dvy));    
  mult_s25xs25_lat2   mult_dz     (.CLK(clk),.A({dz0,1'b0}),.B(fact_r[41:17]),.P(dvz));    
 
  
  reg signed [27:0]  dv   = 1'b0;
  reg signed [24:0]  dv_r = 1'b0;
 
  
  wire signed [17:0] accur_p = {{10{1'b0}},accur_d0};
  wire signed [17:0] accur_n = {{10{1'b1}},-accur_d0};
  reg                conv21  = 1'b0;
  reg                conv10  = 1'b0;
  reg                conv20  = 1'b0;
  reg                conv30  = 1'b0;
  reg                convAll = 1'b0;
  
  reg [7:0] route    = 1'b0;  
  

  always @(posedge clk) begin
    errorShakeOvfl[1] <= errorShakeOvfl[0];
    if(MDReset_clk) begin
      state   <= 0; 
      inReady <= 1'b1;
    end else begin
      case (state) 
        0: begin
          iIter            <= 1'b0;
          atomDataOutValid <= 1'b0;
          cnt              <= 1'b0;
          shakeDone        <= 1'b0;
          fact21           <= 1'b0;
          fact10           <= 1'b0;
          fact20           <= 1'b0;
          fact30           <= 1'b0;
          if (DataInRcv[3]) begin
            atomData3  <= atomDataIn[DataByteWidth_n*8-9:0];                
            vx3_out    <= atomDataIn[DataByteWidth_n*8-8+0*28 +:28];
            vy3_out    <= atomDataIn[DataByteWidth_n*8-8+1*28 +:28];
            vz3_out    <= atomDataIn[DataByteWidth_n*8-8+2*28 +:28];
          end
          if (DataInRcv[2]) begin
            atomData2  <= atomDataIn[DataByteWidth_n*8-9:0];            
            vx2_out    <= atomDataIn[DataByteWidth_n*8-8+0*28 +:28];
            vy2_out    <= atomDataIn[DataByteWidth_n*8-8+1*28 +:28];
            vz2_out    <= atomDataIn[DataByteWidth_n*8-8+2*28 +:28];
          end
          if (DataInRcv[1]) begin
            atomData1  <= atomDataIn[DataByteWidth_n*8-9:0];            
            vx1_out    <= atomDataIn[DataByteWidth_n*8-8+0*28 +:28];
            vy1_out    <= atomDataIn[DataByteWidth_n*8-8+1*28 +:28];
            vz1_out    <= atomDataIn[DataByteWidth_n*8-8+2*28 +:28];
            massH      <= atomDataIn[72+metaMass +: 2];
          end
          if (DataInRcv[0]) begin
            atomData0  <= atomDataIn[DataByteWidth_n*8-9:0];         
            vx0_out    <= atomDataIn[DataByteWidth_n*8-8+0*28 +:28];
            vy0_out    <= atomDataIn[DataByteWidth_n*8-8+1*28 +:28];
            vz0_out    <= atomDataIn[DataByteWidth_n*8-8+2*28 +:28];
                                                                                  //commented out when shake is bypassed
            dx21       <= atomData2[0*24 +:24] - atomData1[0*24 +:24];
            dy21       <= atomData2[1*24 +:24] - atomData1[1*24 +:24];
            dz21       <= atomData2[2*24 +:24] - atomData1[2*24 +:24];
            dx10       <= atomData1[0*24 +:24] - atomDataIn[0*24 +:24];
            dy10       <= atomData1[1*24 +:24] - atomDataIn[1*24 +:24];
            dz10       <= atomData1[2*24 +:24] - atomDataIn[2*24 +:24];
            dx20       <= atomData2[0*24 +:24] - atomDataIn[0*24 +:24];
            dy20       <= atomData2[1*24 +:24] - atomDataIn[1*24 +:24];
            dz20       <= atomData2[2*24 +:24] - atomDataIn[2*24 +:24];
            dx30       <= atomData3[0*24 +:24] - atomDataIn[0*24 +:24];
            dy30       <= atomData3[1*24 +:24] - atomDataIn[1*24 +:24];
            dz30       <= atomData3[2*24 +:24] - atomDataIn[2*24 +:24];
            massX      <= atomDataIn[72+metaMass +: 6];    
                    
            nBond      <= atomDataIn[72+metaConstraint +: 2] + 1'b1;
            isWater    <= atomDataIn[72+metaConstraint + 2];             
            inReady    <= 1'b0;            
            state      <= state +1'b1;
          end  
        end
                                                                                     
        1: begin
          iBond               <= {2'b0,~isWater};
          if (isWater) iR2_XH <= iR2_OHw;
          else begin
            case(massX)
              6'd12:      iR2_XH <= iR2_CH;
              6'd14:      iR2_XH <= iR2_NH; 
              6'd16:      iR2_XH <= iR2_OH;
              6'd32:      iR2_XH <= iR2_SH;
              default:    iR2_XH <= iR2_OH;
            endcase
          end
          case (massH)
            2'd1: begin
              case (massX)
                6'd12:   massRatioXH <= massRatioCH;
                6'd14:   massRatioXH <= massRatioNH;
                6'd16:   massRatioXH <= massRatioOH;
                6'd32:   massRatioXH <= massRatioSH;
                default: massRatioXH <= massRatioOH;
              endcase
            end
            2'd2: begin
              case (massX)
                6'd12:   massRatioXH <= massRatioCD;
                6'd14:   massRatioXH <= massRatioND;
                6'd16:   massRatioXH <= massRatioOD;
                6'd32:   massRatioXH <= massRatioSD;
                default: massRatioXH <= massRatioOD;
              endcase           
            end
            default: massRatioXH <= massRatioOD;
          endcase
          state      <= state +1'b1;
        end
//entry point of loop over iBond and iIter        
        2: begin
          case (iBond)
            0: dv   <= (vx2_out-vx1_out);
            1: dv   <= (vx1_out-vx0_out);
            2: dv   <= (vx2_out-vx0_out);
            3: dv   <= (vx3_out-vx0_out);
          endcase  
          state   <= state +1'b1;
        end
        3: begin
          case (iBond)
            0: dv   <= (vy2_out-vy1_out);
            1: dv   <= (vy1_out-vy0_out);
            2: dv   <= (vy2_out-vy0_out);
            3: dv   <= (vy3_out-vy0_out);
          endcase  
          dv_r <= {{vshift+1{dv[27]}},dv[27:vshift+4]} + {24'b0,dv[vshift+3]};
          state   <= state +1'b1;
        end
        4: begin
          dv_r <= {{vshift+1{dv[27]}},dv[27:vshift+4]} + {24'b0,dv[vshift+3]};
          case (iBond)
            0: begin
              dv         <= (vz2_out-vz1_out);
              dq         <= {dx21,1'b0} + dv_r;        //enters mult_dq2
              dx0        <= dx21; 
              dy0        <= dy21;
              dz0        <= dz21;
              iR2        <= iR2_HHw;
              massRatio1 <= massRatioHH;
              massRatio2 <= -massRatioHH;            //=1-massRatio
            end
            1: begin
              dv         <= (vz1_out-vz0_out);
              dq         <= {dx10,1'b0} + dv_r;        //enters mult_dq2
              dx0        <= dx10; 
              dy0        <= dy10; 
              dz0        <= dz10; 
              iR2        <= iR2_XH;
              massRatio1 <=  massRatioXH;
              massRatio2 <= -massRatioXH;       
            end
            2: begin
              dv         <= (vz2_out-vz0_out);
              dq         <= {dx20,1'b0} + dv_r;         //enters mult_dq2
              dx0        <= dx20;
              dy0        <= dy20;
              dz0        <= dz20; 
              iR2        <= iR2_XH;        
              massRatio1 <=  massRatioXH;
              massRatio2 <= -massRatioXH;       
            end         
            3: begin
              dv         <= (vz3_out-vz0_out);
              dq         <= {dx30,1'b0} + dv_r;         //enters mult_dq2
              dx0        <= dx30;
              dy0        <= dy30;
              dz0        <= dz30; 
              iR2        <= iR2_XH;        
              massRatio1 <=  massRatioXH;
              massRatio2 <= -massRatioXH;       
            end         
          endcase
          state <= state + 1'b1;  
        end
        5: begin
          dv_r <= {{vshift+1{dv[27]}},dv[27:vshift+4]} + {24'b0,dv[vshift+3]};
          case (iBond)
            0: dq  <= {dy21,1'b0} + dv_r;            //enters mult_dq2
            1: dq  <= {dy10,1'b0} + dv_r;
            2: dq  <= {dy20,1'b0} + dv_r;    
            3: dq  <= {dy30,1'b0} + dv_r;    
          endcase
          state <= state + 1'b1;  
        end
        6: begin
          case (iBond)
            0: dq  <= {dz21,1'b0} + dv_r;            //enters mult_dq2
            1: dq  <= {dz10,1'b0} + dv_r;
            2: dq  <= {dz20,1'b0} + dv_r;  
            3: dq  <= {dz30,1'b0} + dv_r;    
          endcase
          state  <= state + 1'b1;  
        end
        7: begin
          r2     <= dq2;               
          state  <= state + 1'b1;         
        end
        8: begin
          r2     <= r2 + dq2; 
          state  <= state + 1'b1;         
        end
        9: begin
          r2     <= r2 + dq2;             //enters mult_iR2 together with iR2
          state  <= state + 1'b1;         
        end
        10: begin                         //wait for latency mult_iR2
          state  <= state + 1'b1;          
        end
        11: begin
          massRatio         <= massRatio1;                    //enters mult_fact together with fact
          fact              <= r2rel  - 18'sh10000;           //range -1....2, or -0.5....1 after division by 2 (which is not done explixitly)
          errorShakeOvfl[0] <= (r2rel_tmp[40:34]>=2'h3);      //error when initial velocities are too large (in the range of bond distance)
          state             <= state + 1'b1;          
        end
        12: begin
          case (iBond)
            0: fact21 <= fact;                                //store for stop criterion
            1: fact10 <= fact;    
            2: fact20 <= fact;      
            3: fact30 <= fact;    
          endcase
          massRatio <= massRatio2;                            //enters mult_fact together with fact
          state <= state + 1'b1; 
        end     
        13: begin                                             //wait for latency multiplier mult_fact and  mult_d*
          conv21  <= (fact21<=accur_p)&&(fact21>=accur_n);                                   //is new
          conv10  <= (fact10<=accur_p)&&(fact10>=accur_n);                                   //is new
          conv20  <= (fact20<=accur_p)&&(fact20>=accur_n);                                   //is new
          conv30  <= (fact30<=accur_p)&&(fact30>=accur_n);                                   //is new
          state   <= state + 1'b1; 
        end
        14: begin                                              //wait for latency multiplier mult_fact and  mult_d*
          convAll <= (conv21&&conv20&&conv10&&conv30);                                       //is new
          state   <= state + 1'b1; 
        end
        15: begin
          case (iBond)
            0: begin
              vx2_out <= vx2_out - dvx[48-(vshift+1):21-(vshift+1)];
              vy2_out <= vy2_out - dvy[48-(vshift+1):21-(vshift+1)];
              vz2_out <= vz2_out - dvz[48-(vshift+1):21-(vshift+1)];
            end
            1,2,3: begin
              vx0_out <= vx0_out + dvx[48-(vshift+1):21-(vshift+1)];
              vy0_out <= vy0_out + dvy[48-(vshift+1):21-(vshift+1)];
              vz0_out <= vz0_out + dvz[48-(vshift+1):21-(vshift+1)];
            end   
          endcase
          state <= state + 1'b1; 
        end  
        16: begin
          case (iBond)
            0: begin
              vx1_out <= vx1_out + dvx[48-(vshift+1):21-(vshift+1)];
              vy1_out <= vy1_out + dvy[48-(vshift+1):21-(vshift+1)];
              vz1_out <= vz1_out + dvz[48-(vshift+1):21-(vshift+1)];
            end
            1: begin
              vx1_out <= vx1_out - dvx[48-(vshift+1):21-(vshift+1)];
              vy1_out <= vy1_out - dvy[48-(vshift+1):21-(vshift+1)];
              vz1_out <= vz1_out - dvz[48-(vshift+1):21-(vshift+1)];
            end
            2: begin
              vx2_out <= vx2_out - dvx[48-(vshift+1):21-(vshift+1)];
              vy2_out <= vy2_out - dvy[48-(vshift+1):21-(vshift+1)];
              vz2_out <= vz2_out - dvz[48-(vshift+1):21-(vshift+1)];
            end     
            3: begin
              vx3_out <= vx3_out - dvx[48-(vshift+1):21-(vshift+1)];
              vy3_out <= vy3_out - dvy[48-(vshift+1):21-(vshift+1)];
              vz3_out <= vz3_out - dvz[48-(vshift+1):21-(vshift+1)];
            end       
          endcase
          if(iBond<nBond-1) begin 
            state    <= 2;             //loop over the various distances
            iBond    <= iBond + 1'b1;
          end else begin 
            state    <= state + 1'b1; 
            iBond    <= {2'b0,~isWater}; 
          end
        end  
        17: begin
          if(iIter==nIterMax|convAll) begin                                                       //is new
            state     <= state + 1'b1;           
          end else begin 
            iIter     <= iIter + 1'b1;  //loop over iterations
            state     <= 2; 
          end     
        end   
        18: begin
          nIter            <= iIter;
          atomDataOut      <= {vz0_out[27:4]+{23'b0,vz0_out[3]},vy0_out[27:4]+{23'b0,vy0_out[3]},vx0_out[27:4]+{23'b0,vx0_out[3]},8'b0,atomData0[72 +:metaRoute],
                               atomData0[24*2 +:24]+{{vshift+1{vz0_out[27]}},vz0_out[27:vshift+5]}+{23'b0,vz0_out[vshift+4]},
                               atomData0[24*1 +:24]+{{vshift+1{vy0_out[27]}},vy0_out[27:vshift+5]}+{23'b0,vy0_out[vshift+4]},
                               atomData0[24*0 +:24]+{{vshift+1{vx0_out[27]}},vx0_out[27:vshift+5]}+{23'b0,vx0_out[vshift+4]}};
          state            <= state + 1'b1;
        end
        19: begin
          atomDataOutValid               <= 1'b1;                                                                                 
          route                          <= {2'b0, atomDataOut[24*2+22 +:2], atomDataOut[24*1+22 +:2], atomDataOut[24*0+22 +:2]};   //routing info from central atom, which is also used for all H's 
          atomDataOut[72+metaRoute +: 8] <= {2'b0, atomDataOut[24*2+22 +:2], atomDataOut[24*1+22 +:2], atomDataOut[24*0+22 +:2]}; 
          state                          <= state + 1'b1;
        end
        20: begin                
           atomDataOutValid     <= 1'b0;           //slow down output to avoid congestion of downsteam data flow  
           cnt                  <= cnt + 1'b1;
           if (cnt==2'h3) state <= state + 1'b1;   
        end
        21: begin
          atomDataOutValid <= 1'b1;
          atomDataOut      <= {vz1_out[27:4]+{23'b0,vz1_out[3]},vy1_out[27:4]+{23'b0,vy1_out[3]},vx1_out[27:4]+{23'b0,vx1_out[3]},route,atomData1[72 +:metaRoute],
                               atomData1[24*2 +:24]+{{vshift+1{vz1_out[27]}},vz1_out[27:vshift+5]}+{23'b0,vz1_out[vshift+4]},
                               atomData1[24*1 +:24]+{{vshift+1{vy1_out[27]}},vy1_out[27:vshift+5]}+{23'b0,vy1_out[vshift+4]},
                               atomData1[24*0 +:24]+{{vshift+1{vx1_out[27]}},vx1_out[27:vshift+5]}+{23'b0,vx1_out[vshift+4]}};
          if(nBond==2) begin
            state            <= 0;    
            inReady          <= 1'b1;  
            shakeDone        <= 1'b1;       
          end else state <= state + 1'b1;
        end       
        22: begin                
          atomDataOutValid     <= 1'b0;           //slow down output to avoid congestion of downsteam data flow 
          cnt                  <= cnt + 1'b1;
          if (cnt==2'h3) state <= state + 1'b1;   
        end       
        23: begin
          atomDataOutValid <= 1'b1;
          atomDataOut      <= {vz2_out[27:4]+{23'b0,vz2_out[3]},vy2_out[27:4]+{23'b0,vy2_out[3]},vx2_out[27:4]+{23'b0,vx2_out[3]},route,atomData2[72 +:metaRoute],
                               atomData2[24*2 +:24]+{{vshift+1{vz2_out[27]}},vz2_out[27:vshift+5]}+{23'b0,vz2_out[vshift+4]},
                               atomData2[24*1 +:24]+{{vshift+1{vy2_out[27]}},vy2_out[27:vshift+5]}+{23'b0,vy2_out[vshift+4]},
                               atomData2[24*0 +:24]+{{vshift+1{vx2_out[27]}},vx2_out[27:vshift+5]}+{23'b0,vx2_out[vshift+4]}};
          if(nBond==3) begin
            state            <= 0;    
            inReady          <= 1'b1;  
            shakeDone        <= 1'b1;       
          end else state <= state + 1'b1;
        end       
        24: begin                
          atomDataOutValid     <= 1'b0;           //slow down output to avoid congestion of downsteam data flow 
          cnt                  <= cnt + 1'b1;
          if (cnt==2'h3) state <= state + 1'b1;   
        end       
        25: begin
          atomDataOutValid <= 1'b1;
          atomDataOut      <= {vz3_out[27:4]+{23'b0,vz3_out[3]},vy3_out[27:4]+{23'b0,vy3_out[3]},vx3_out[27:4]+{23'b0,vx3_out[3]},route,atomData3[72 +:metaRoute],
                               atomData3[24*2 +:24]+{{vshift+1{vz3_out[27]}},vz3_out[27:vshift+5]}+{23'b0,vz3_out[vshift+4]},
                               atomData3[24*1 +:24]+{{vshift+1{vy3_out[27]}},vy3_out[27:vshift+5]}+{23'b0,vy3_out[vshift+4]},
                               atomData3[24*0 +:24]+{{vshift+1{vx3_out[27]}},vx3_out[27:vshift+5]}+{23'b0,vx3_out[vshift+4]}};
          inReady          <= 1'b1;  
          shakeDone        <= 1'b1;
          state            <= 0;
        end       
      endcase
    end  
  end  


endmodule
