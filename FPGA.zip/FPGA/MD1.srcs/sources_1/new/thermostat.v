`timescale 1ns / 1ps

//- thermostat related things. Module performs 4 tasks triggered by 4 different signals:
//- signal WriteDataThermostat: receice thermostat data from host computer (command 3). Each word DataThermostat is 32bit 
//  AdrDataThermostat = 0: bit0...3 tau_T, bit8..,11: tau_cm
//                      1: T_target (lower 24bit)
//                      2: initial T (32bit)
//                      3: initial vxcm (32bit)
//                      4: initial vycm (32bit)
//                      5: initial vzcm (32bit)
//- signal EnsembleNeighborValid: receives and adds up ensemble data (i.e. T_all and vcm_all) from neigboring boxes
//- signal nAtomReset: before each new time-step, calculate T-scaling factor and vcm from ensemble data of the previous MD step. Ensemble data
//  are those from the neghboring nodes (T_all, v_cm) as well as from the home-box (T_new, vcm_new). To that end, the sum of both is
//  initially calculated (T and vcm). To calculate the T-scaling factor, a pipeline pipe is launched.
//- signal newDataReady: During each time-step, T_new and vcm_new are summed up over all atoms of the home box. Done in state1. Input through 
//  a FIFO, since data may appear without gap. 
//Further remarks  
//- vx,vy,vz are 24bit, and they are all added up into a 32 bit number to reveal v*cm_new, and eventually into vcm_d1, which also includes neigboring nodes.
//  Hence, vcm_d1 is 256*27 = 13 bits (#atoms/box*27boxes) larger than velocities in the worst case. However, in realty only about 1/2 of the atoms 
//  are heavy atoms, the rest are hydrogens, which barely contribute to mtot, so is more like 12 bits. When vcm is added to v_Tscale 
//  and F_scale in MDmschine, it is effectively shifted down by 4bit, since the latter include 4 more lower bits. 
//  tau_cm_base is set to 4, so shifted down by 8bit in total. The remaining shift is done by tau_cm, which is one of the thermostat parameters. 
//  tau_cm should be calculated from mtot: 
//     tau_cm=Floor(log(mtot)/log(2))+1-8
//  in which case division factor is larger than mtot, and feedback loop is damped with some time-constant dt < tau < 2*dt.
//- Thermostat.v currently works only if there are 27 nodes, i.e., each nodes sees all others.

module Thermostat
#(
parameter  EnsembleByteWidth  = 5'd15,
parameter  vshift             = 4 
)
(
 input                                       IOclk,
 output                                      busy,                   //statemachine 1 busy (calculation of ensemble data)
 input                                       nAtomReset,             //start new time step
 //ensemble data from neigboring boxes 
 input                                       EnsembleNeighborValid,  //ensemble data from neigboring nodes ready
 input             [EnsembleByteWidth*8-1:0] EnsembleNeighbor,       //ensemble data from neigboring nodes
//Thermostat data       
 input                                       WriteDataThermostat,    //write thermostat data
 input             [2:0]                     AdrDataThermostat,      //adress of thermostat data, 
 input             [31:0]                    DataThermostat,         //thermostat data
//atom data 
 input                                       newDataReady,           //new atom data ready
 input signed      [23:0]                    vx,                     //velocity x of new atom 
 input signed      [23:0]                    vy,                     //velocity y of new atom 
 input signed      [23:0]                    vz,                     //velocity z of new atom 
 input             [5:0]                     mass,                   //mass of new atom
 output signed     [31:0]                    vxcm,                   //output, center of mass vx      //used to be [27:0]
 output signed     [31:0]                    vycm,                   //output, center of mass vy
 output signed     [31:0]                    vzcm,                   //output, center of mass vz
 output reg signed [23:0]                    Tscale=24'h800000,      //output, scaling factor temperature, 24'h800000 corresponds to 1.
 output            [EnsembleByteWidth*8-1:0] EnsembleData            //output, enesembe data to be sent to neighboring nodes
);

localparam tau_cm_base = 4; 

reg  signed [31:0]          vxcm_new = 1'b0;
reg  signed [31:0]          vycm_new = 1'b0;
reg  signed [31:0]          vzcm_new = 1'b0;
reg  signed [31:0]          vxcm_d1 = 1'b0, vycm_d1 = 1'b0, vzcm_d1 = 1'b0;         
reg  signed [31:0]          vxcm_all = 1'b0;   
reg  signed [31:0]          vycm_all = 1'b0;
reg  signed [31:0]          vzcm_all = 1'b0;
reg         [23:0]          T_all    = 1'b0;
reg         [23:0]          T_new    = 1'b0;         
reg         [23:0]          T        = 1'b0;         
reg  signed [31:0]          T_target = 1'b0;
reg  signed [11:0]          tau      = 1'b0;


wire [3:0]       tau_cm        = tau[11:8];
wire [3:0]       tau_T         = tau[3:0];
reg  [3:0]       state1        = 1'b0;
reg              fifoOut       = 1'b0;
reg              busy_d0       = 1'b0;
assign busy = busy_d0||(~newDataReady_d0);


//entrance FIFO
wire [77:0] dataFifoOut;
FIFO_sync 
  #(
   .WIDTH(78),
   .DEPTH(64)
  ) FIFOForceDihed 
  (
  .rst(1'b0),
  .clk(IOclk),         
  .din({mass,vz,vy,vx}),      
  .wr_en(newDataReady),  
  .rd_en(fifoOut),  
  .dout(dataFifoOut),    
  .full(),    
  .empty(newDataReady_d0),  
  .prog_full()
  );
  
wire signed [23:0] vx_FIFO   = dataFifoOut[24*0 +:24];    
wire signed [23:0] vy_FIFO   = dataFifoOut[24*1 +:24];
wire signed [23:0] vz_FIFO   = dataFifoOut[24*2 +:24];
wire signed [5:0]  mass_FIFO = dataFifoOut [24*3 +:6];

//two cascaded multipliers, that first calculate m*v (for center-of-mass motion), and in an second step m*v^2 (for temperature)
reg  signed [23:0] v=1'b0, v_d0;
wire signed [42:0] v_mass_tmp;
mult_s25xs18_lat1  mult_mass   (.CLK(IOclk),.A({v,1'b0}),.B({1'b0,mass_FIFO,11'b0}),.P(v_mass_tmp)); 
wire signed [24:0] v_mass = v_mass_tmp[39:15];      //mass 16 is equal to 1, i.e. v and v_mass should be the same

wire signed [49:0] v2_tmp;                       
mult_s25xs25_lat2  mult_v2     (.CLK(IOclk),.A({v_d0,1'b0}),.B(v_mass),.P(v2_tmp));
wire signed [23:0] v2=v2_tmp[48:25];

localparam npipe = 3;
reg           pipe0 = 1'b0;
reg [npipe:0] pipe  = 1'b0;

always @(posedge IOclk) begin
  v_d0          <= v;      
  pipe0         <= 1'b0;
  if(WriteDataThermostat) begin               //load ensemble data before new start of MD
    case(AdrDataThermostat)
      0: tau      <= DataThermostat[11:0];   //contains both tau_cm and tau_T
      1: T_target <= DataThermostat;
      2: begin
        T_all    <= DataThermostat[27:0];   //when starting MD, vcm and T are set from host computer, which contains all boxes, including home box.
        T_new    <= 1'b0;                   //In subsequent time steps, it will be only the neigboring boxes, and the one of the home box is added extra.
      end                                   //For this to work poperly, vcm_new and T_new needs to be set to 0 here 
      3: begin
        vzcm_all <= DataThermostat;
        vzcm_new <= 1'b0;
      end  
      4: begin
        vycm_all <= DataThermostat;
        vycm_new <= 1'b0;
      end  
      5: begin
        vxcm_all <= DataThermostat;
        vxcm_new <= 1'b0;
      end  
    endcase
  end else if(nAtomReset) begin 
    pipe0    <= 1'b1;                                                          //initiate pipeline to calculate scaling factor
    vxcm_d1  <= vxcm_all +  vxcm_new;                                                
    vycm_d1  <= vycm_all +  vycm_new;            
    vzcm_d1  <= vzcm_all +  vzcm_new;       
    T        <= T_all    +  {4'b0,T_new};  
    T_all    <= 1'b0;
    vxcm_all <= 1'b0;  
    vycm_all <= 1'b0;
    vzcm_all <= 1'b0;
    vxcm_new <= 1'b0;                                    
    vycm_new <= 1'b0;                                   
    vzcm_new <= 1'b0;                                   
    T_new    <= 1'b0;                                    
  end else begin
    if(EnsembleNeighborValid) begin
      T_all    <= T_all    + EnsembleNeighbor[23:0];                               //is positive, so extension of sign not needed
      vxcm_all <= vxcm_all + EnsembleNeighbor[24+:32];
      vycm_all <= vycm_all + EnsembleNeighbor[56+:32];
      vzcm_all <= vzcm_all + EnsembleNeighbor[88+:32];
    end
    case (state1)                                                                //state machine that accumulates vcm=sum_i m_i v_i  and T = sum_i m_i v_i^2
      0: begin
        if(~newDataReady_d0) begin
           busy_d0 <= 1'b1;
           fifoOut <= 1'b1;
           state1  <= state1 +1'b1;
        end
      end  
      1: begin
        fifoOut   <= 1'b0;
        state1    <= state1 +1'b1;
      end
      2: begin
        v        <= vx_FIFO;
        state1   <= state1 +1'b1;
      end
      3: begin
        v        <= vy_FIFO;                         
        state1   <= state1 +1'b1;
      end
      4: begin
        v        <= vz_FIFO;
        vxcm_new <= vxcm_new + {{8{v_mass[24]}},v_mass[24:1]};  
        state1   <= state1 +1'b1;
      end
      5: begin
        vycm_new <= vycm_new + {{8{v_mass[24]}},v_mass[24:1]};
        state1   <= state1 +1'b1;
      end
      6: begin
        vzcm_new <= vzcm_new + {{8{v_mass[24]}},v_mass[24:1]};
        T_new    <= T_new + v2; 
        state1   <= state1 +1'b1;
      end
      7: begin
        T_new    <= T_new + v2; 
        state1   <= state1 +1'b1;
      end
      8: begin
        T_new    <= T_new + v2;
        busy_d0  <= 1'b0; 
        state1   <= 0;        
      end
    endcase
  end
end

  wire signed [31:0] vxcm_d0 = vxcm_d1>>>(tau_cm_base + tau_cm);                             //didn't work when writing that in the if-block below; did not recognize as signed, in which case ">>>" is not working
  wire signed [31:0] vycm_d0 = vycm_d1>>>(tau_cm_base + tau_cm);
  wire signed [31:0] vzcm_d0 = vzcm_d1>>>(tau_cm_base + tau_cm);
  assign  vxcm  = (tau_cm==4'h0) ? 1'b0 : vxcm_d0 + {31'b0,vxcm_d1[tau_cm_base + tau_cm-1]};        
  assign  vycm  = (tau_cm==4'h0) ? 1'b0 : vycm_d0 + {31'b0,vycm_d1[tau_cm_base + tau_cm-1]};  
  assign  vzcm  = (tau_cm==4'h0) ? 1'b0 : vzcm_d0 + {31'b0,vzcm_d1[tau_cm_base + tau_cm-1]}; 

  assign EnsembleData     = {vzcm_new,vycm_new,vxcm_new,T_new};  
  
//pipeline that calculates T-scaling factor, initiated by nAtomReset
  wire [55:0] Trel_tmp;
  mult_s32xu24_lat2  mult_invmass (.CLK(IOclk),.A(T_target),.B(T),.P(Trel_tmp));
  wire        [23:0] Trel = Trel_tmp[52:29];
  always @(posedge IOclk) begin
    pipe             <= {pipe[npipe-1:0],pipe0};
    case(pipe)
      4'b0010: Tscale <= Trel-24'h800000;
      4'b0100: Tscale <= (Tscale>>>tau_T);
      4'b1000: Tscale <= (tau_T==0) ? 24'h800000 : 24'h800000 - Tscale;    
    endcase
  end

  
 
endmodule
