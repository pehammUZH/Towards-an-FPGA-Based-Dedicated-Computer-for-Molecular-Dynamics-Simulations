//- collection of FIFOs (synchronous and asynchronous) with adjustable width and depths, wiring out only the signals that will be needed.
//- see UG974 for description
//- depending on DEPTHS, it is decided whether distributed (DEPTH=64) or block ram (DEPTH=512) is used.  If DEPTH in neither one of these 
//  values, let Vivado decide what it prefers

module FIFO_async #(                             //FIFO with different wr- and rd-clk; also works as a clock transfer of data
    parameter integer WIDTH = 32,
    parameter integer DEPTH  = 64,              
    parameter integer PROG_FULL_THRESH =10,
    parameter         READ_MODE ="std"          //"std" for standard FIFO, "fwft" for firts-word-fall-through
)(
    input  wire              rst,
// write domain
    input  wire              wr_clk,
    input  wire              wr_en,
    input  wire [WIDTH-1:0]  din,
    output wire              full,
    output wire              prog_full,
// read domain
    input  wire              rd_clk,
    input  wire              rd_en,
    output wire [WIDTH-1:0]  dout,
    output wire              empty
);

localparam FIFO_MEMORY_TYPE =
    (DEPTH == 64)  ? "distributed" :
    (DEPTH == 512) ? "block" :
                     "auto";
 
   xpm_fifo_async #(
    .FIFO_MEMORY_TYPE (FIFO_MEMORY_TYPE), 
    .FIFO_WRITE_DEPTH (DEPTH),
    .WRITE_DATA_WIDTH (WIDTH),
    .READ_DATA_WIDTH  (WIDTH),
    .READ_MODE        (READ_MODE),
    .FIFO_READ_LATENCY(1),
    .CDC_SYNC_STAGES  (2),
    .DOUT_RESET_VALUE ("0"),
    .PROG_FULL_THRESH (PROG_FULL_THRESH)
   ) u_fifo (
    .sleep         (1'b0),
    .rst           (rst),
    // write side
    .wr_clk        (wr_clk),
    .wr_en         (wr_en),
    .din           (din),
    .full          (full),
    .wr_ack        (),
    .overflow      (),
    .wr_rst_busy   (),
    .prog_full     (prog_full),
    // read side
    .rd_clk        (rd_clk),
    .rd_en         (rd_en),
    .dout          (dout),
    .empty         (empty),
    .underflow     (),
    .rd_rst_busy   (),
    .data_valid    (),
    // unused
    .prog_empty    (),
    .wr_data_count (),
    .rd_data_count (),
    .almost_full   (),
    .almost_empty  (),
    .injectsbiterr (1'b0),
    .injectdbiterr (1'b0),
    .sbiterr       (),
    .dbiterr       ()
   );

endmodule


//******************************************************************************************************


module FIFO_sync #(                                  //FIFO with common wr- and rd-clk
    parameter integer WIDTH = 32,
    parameter integer DEPTH  = 64,              
    parameter integer PROG_FULL_THRESH =10,
    parameter         READ_MODE ="std"                //"std" for standard FIFO, "fwft" for firts-word-fall-through
)(
    input  wire              rst,
    input  wire              clk,
 // write domain   
    input  wire              wr_en,
    input  wire [WIDTH-1:0]  din,
    output wire              full,
    output wire              prog_full,
// read domain
    input  wire              rd_en,
    output wire [WIDTH-1:0]  dout,
    output wire              empty
);

localparam FIFO_MEMORY_TYPE =
    (DEPTH == 64)  ? "distributed" :
    (DEPTH == 512) ? "block" :
                     "auto";

   xpm_fifo_sync #(
    .FIFO_MEMORY_TYPE (FIFO_MEMORY_TYPE), 
    .FIFO_WRITE_DEPTH (DEPTH),
    .WRITE_DATA_WIDTH (WIDTH),
    .READ_DATA_WIDTH  (WIDTH),
    .FIFO_READ_LATENCY(1),
    .READ_MODE        (READ_MODE),
    .PROG_FULL_THRESH (PROG_FULL_THRESH)
   ) u_fifo (
    .sleep         (1'b0),
    .rst           (rst),
    .wr_clk        (clk),
    .wr_en         (wr_en),
    .din           (din),
    .full          (full),
    .wr_ack        (),
    .overflow      (),
    .wr_rst_busy   (),
    .rd_en         (rd_en),
    .dout          (dout),
    .empty         (empty),
    .underflow     (),
    .rd_rst_busy   (),
    .data_valid    (),
    .prog_full     (prog_full),
    .prog_empty    (),
    .wr_data_count (),
    .rd_data_count (),
    .almost_full   (),
    .almost_empty  (),
    .injectsbiterr (1'b0),
    .injectdbiterr (1'b0),
    .sbiterr       (),
    .dbiterr       ()
   );

endmodule