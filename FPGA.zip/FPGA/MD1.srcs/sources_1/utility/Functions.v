`timescale 1ns / 1ps

//- calculates functions tabularized in correponding LUT, based on a 2nd-order interpolationm, where zero 1st and 2nd-order terms are tabularized in a LUT, 
//  A0,A1 and A2, respectively.
//  That is, the input is separated into two parts, in[25:17] and in[16:0]. The upper part is used as address for the LUT, retrieving A0,A1 and A2. 
//  The value of the function is then calculated as:
//
//    f=A0 + A1 * x + A2 * x^2
//
//  where x=in[16:0] is assumed to be a number 0...1.
//- parameter FUNCTIONTYPE determines which LUT is used, and in that way which function is been calculated. Current  FUNCTIONTYPEs are:
//  0: InvSqrtR2             
//  1: SqrtR2
//  2: InvR2SqrtR2
//  3: ArcCos
//  4: InvSin
//- Versions:
//  - LUTfunction: runs one fixed function
//  - LUTfunction2: runs two fixed functions with same input value, run in parallel, share some of the resources
//  - LUTfucntionProg: runs one function that can be programmed from host computer
//- input 26bit, positive number that is interpreted as 0...1, using maximum bit resoultion of LUT and the multiplier used for the interpolation
//- output 26bit, typpically also a positive number 0...1
//- bit reslution of in and output are the same -> can be cascaded
//- is fully pipelined
//- total latency 6
//- different functions differ only by the content of the LUT 


module LUTfunction      
   #(
    FUNCTIONTYPE=0    //eventually use defines for more readable values of these functions
    )
    (
    input                clk,
    input  [25:0]        in,
    output [25:0]        out 
    );

 reg         [16:0]  in_d0,in_d1;
 reg  signed [23:0]  dd_LUT_d0;
 reg  signed [23:0]  LUT_d0,LUT_d1,LUT_d2;
 reg  signed [25:0]  tmp;
 
 //level 1 of pipeline
 wire [71:0]  LUT_all;
 
 generate
    if (FUNCTIONTYPE == 0) begin 
      InvSqrtR2_72x512 InvSqrtR2_LUT (.clka(clk),.ena(1'b1),.addra(in[25:17]),.douta(LUT_all));
    end else if (FUNCTIONTYPE == 1) begin 
      SqrtR2_72x512 SqrtR2_LUT (.clka(clk),.ena(1'b1),.addra(in[25:17]),.douta(LUT_all));
    end else if (FUNCTIONTYPE == 2) begin 
      InvR2SqrtR2_72x512 InvR2SqrtR2 (.clka(clk),.ena(1'b1),.addra(in[25:17]),.douta(LUT_all));
    end else if (FUNCTIONTYPE == 3) begin 
      ArcCos_72x512    arccos (.clka(clk),.ena(1'b1),.addra(in[25:17]),.douta(LUT_all));
    end else if (FUNCTIONTYPE == 4) begin 
     InvSinPhi_72x512 invsin (.clka(clk),.ena(1'b1),.addra(in[25:17]),.douta(LUT_all));    
    end  
 endgenerate

 wire [35:0]       in2;
 mult_s18xs18_lat3 mult_in2 (.CLK(clk),.A({1'b0,in[16:0]}),.B({1'b0,in[16:0]}),.P(in2));     

 always @(posedge clk) begin
    in_d0  <= in[16:0];  //level 1 of pipeline
    in_d1  <= in_d0;     //level 2 of pipeline
 end
  
//level 3 of pipeline
  wire signed [23:0] d_LUT = LUT_all[47:24];
  always @(posedge clk) begin
    dd_LUT_d0   <= LUT_all[23:0];
    LUT_d0      <= LUT_all[71:48];      
    LUT_d1      <= LUT_d0;           //level 4 of pipeline
    LUT_d2      <= LUT_d1;           //level 5 of pipeline
  end   
  wire signed [42:0] d;
  mult_s25xs18_lat3  mult_d (.CLK(clk),.A({d_LUT,1'b0}),.B({1'b0,in_d1}), .P(d));  

//level 4 of pipeline  
  wire signed [42:0] dd;
  mult_s25xs18_lat3  mult_dd  (.CLK(clk),.A({dd_LUT_d0,1'b0}) ,.B({1'b0,in2[33:17]}) ,.P(dd));  
  
//level 6 of pipeline
  always @(posedge clk) begin
    tmp    <= {LUT_d2,2'b0} + d[41:16];  
  end  
 
//level 7 of pipeline; currently not latched, in order not to disturb the timing of existing routines (but it should)    
  assign out=tmp + dd[41:16];
 
endmodule

//****************************************************************************
//runs two functions in parallel with the same input; can share the in2-multiplier and thus saves a little bit of resources

module LUTfunction2    
   #(
    FUNCTIONTYPE1=0,    //eventually use defines for more readable values of these functions
    FUNCTIONTYPE2=1    //eventually use defines for more readable values of these functions
    )
   (
    input                clk,
    input  [25:0]        in,
    output [25:0]        out1,
    output [25:0]        out2
    );      
    
 reg         [16:0]  in_d0,in_d1;
 reg  signed [23:0]  dd_LUT1_d0,dd_LUT2_d0;
 reg  signed [23:0]  LUT1_d0,LUT1_d1,LUT1_d2,LUT2_d0,LUT2_d1,LUT2_d2;
 reg  signed [25:0]  tmp1,tmp2;


 //level 1 of pipeline
  wire [71:0]  LUT1_all,LUT2_all;
  generate
    if (FUNCTIONTYPE1 == 0) begin 
      InvSqrtR2_72x512 InvSqrtR2_LUT (.clka(clk),.ena(1'b1),.addra(in[25:17]),.douta(LUT1_all));
    end else if (FUNCTIONTYPE1 == 1) begin 
      SqrtR2_72x512 SqrtR2_LUT (.clka(clk),.ena(1'b1),.addra(in[25:17]),.douta(LUT1_all));
    end else if (FUNCTIONTYPE1 == 2) begin 
      InvR2SqrtR2_72x512 InvR2SqrtR2 (.clka(clk),.ena(1'b1),.addra(in[25:17]),.douta(LUT1_all));
    end else if (FUNCTIONTYPE1 == 3) begin 
      ArcCos_72x512    arccos (.clka(clk),.ena(1'b1),.addra(in[25:17]),.douta(LUT1_all));
    end else if (FUNCTIONTYPE1 == 4) begin 
     InvSinPhi_72x512 invsin (.clka(clk),.ena(1'b1),.addra(in[25:17]),.douta(LUT1_all));      
    end
    if (FUNCTIONTYPE2 == 0) begin 
      InvSqrtR2_72x512 InvSqrtR2_LUT (.clka(clk),.ena(1'b1),.addra(in[25:17]),.douta(LUT2_all));
    end else if (FUNCTIONTYPE2 == 1) begin 
      SqrtR2_72x512 SqrtR2_LUT (.clka(clk),.ena(1'b1),.addra(in[25:17]),.douta(LUT2_all));
    end else if (FUNCTIONTYPE2 == 2) begin 
      InvR2SqrtR2_72x512 InvR2SqrtR2 (.clka(clk),.ena(1'b1),.addra(in[25:17]),.douta(LUT2_all));
    end else if (FUNCTIONTYPE2 == 3) begin 
      ArcCos_72x512    arccos (.clka(clk),.ena(1'b1),.addra(in[25:17]),.douta(LUT2_all));
    end else if (FUNCTIONTYPE2 == 4) begin 
     InvSinPhi_72x512 invsin (.clka(clk),.ena(1'b1),.addra(in[25:17]),.douta(LUT2_all));      
    end
 endgenerate
  
 
  wire [35:0]       in2;
  mult_s18xs18_lat3 mult_in2 (.CLK(clk),.A({1'b0,in[16:0]}),.B({1'b0,in[16:0]}),.P(in2));     

 always @(posedge clk) begin
    in_d0  <= in[16:0];  //level 1 of pipeline
    in_d1  <= in_d0;     //level 2 of pipeline
 end
  
//level 3 of pipeline
  wire signed [23:0] d_LUT1 = LUT1_all[47:24];
  wire signed [23:0] d_LUT2 = LUT2_all[47:24];
  always @(posedge clk) begin
    dd_LUT1_d0   <= LUT1_all[23:0];
    LUT1_d0      <= LUT1_all[71:48];      
    LUT1_d1      <= LUT1_d0;           //level 4 of pipeline
    LUT1_d2      <= LUT1_d1;           //level 5 of pipeline
    dd_LUT2_d0   <= LUT2_all[23:0];
    LUT2_d0      <= LUT2_all[71:48];      
    LUT2_d1      <= LUT2_d0;           //level 4 of pipeline
    LUT2_d2      <= LUT2_d1;           //level 5 of pipeline
  end   
  wire signed [42:0] d1,d2;
  mult_s25xs18_lat3  mult_d1 (.CLK(clk),.A({d_LUT1,1'b0}),.B({1'b0,in_d1}), .P(d1)); 
  mult_s25xs18_lat3  mult_d2 (.CLK(clk),.A({d_LUT2,1'b0}),.B({1'b0,in_d1}), .P(d2));  

//level 4 of pipeline  
  wire signed [42:0] dd1,dd2;
  mult_s25xs18_lat3  mult_dd1  (.CLK(clk),.A({dd_LUT1_d0,1'b0}) ,.B({1'b0,in2[33:17]}) ,.P(dd1));  
  mult_s25xs18_lat3  mult_dd2  (.CLK(clk),.A({dd_LUT2_d0,1'b0}) ,.B({1'b0,in2[33:17]}) ,.P(dd2));
  
//level 6 of pipeline
  always @(posedge clk) begin
    tmp1    <= {LUT1_d2,2'b0} + d1[41:16]; 
    tmp2    <= {LUT2_d2,2'b0} + d2[41:16]; 
  end  
 
//level 7 of pipeline; currently not latched, in order not to disturb the timing of existing routines (but it should)    
  assign out1=tmp1 + dd1[41:16];
  assign out2=tmp2 + dd2[41:16];
  
endmodule

//****************************************************************************************************************

module LUTfunctionProg      
    (
//input that writes into Force-LUT; on IOclk
    input                IOclk,
    input                wrForceLUT,    
    input  [8:0]         dataForceLUT, 
    input  [11:0]        adrForceLUT,     
    input                selForceLUT,   
//actual force calculation      
    input                clk,
    input  [25:0]        in,
    output [25:0]        out 
    );

 reg         [16:0]  in_d0,in_d1;
 reg  signed [23:0]  dd_LUT_d0;
 reg  signed [23:0]  LUT_d0,LUT_d1,LUT_d2;
 reg  signed [25:0]  tmp;
 
 //level 1 of pipeline
 wire [71:0]  LUT_all;
 bram_9x4096_72x512 LUT_LJ  (.clka(IOclk),.ena(selForceLUT),.wea(wrForceLUT),.addra(adrForceLUT),.dina(dataForceLUT),.clkb(clk),.enb(1'b1),.addrb(in[25:17]),.doutb(LUT_all));

 wire [35:0]       in2;
 mult_s18xs18_lat3 mult_in2 (.CLK(clk),.A({1'b0,in[16:0]}),.B({1'b0,in[16:0]}),.P(in2));     

 always @(posedge clk) begin
    in_d0  <= in[16:0];  //level 1 of pipeline
    in_d1  <= in_d0;     //level 2 of pipeline
 end
  
//level 3 of pipeline
  wire signed [23:0] d_LUT = LUT_all[47:24];
  always @(posedge clk) begin
    dd_LUT_d0   <= LUT_all[23:0];
    LUT_d0      <= LUT_all[71:48];      
    LUT_d1      <= LUT_d0;           //level 4 of pipeline
    LUT_d2      <= LUT_d1;           //level 5 of pipeline
  end   
  wire signed [42:0] d;
  mult_s25xs18_lat3  mult_d (.CLK(clk),.A({d_LUT,1'b0}),.B({1'b0,in_d1}), .P(d));  

//level 4 of pipeline  
  wire signed [42:0] dd;
  mult_s25xs18_lat3  mult_dd  (.CLK(clk),.A({dd_LUT_d0,1'b0}) ,.B({1'b0,in2[33:17]}) ,.P(dd));  
  
//level 6 of pipeline
  always @(posedge clk) begin
    tmp    <= {LUT_d2,2'b0} + d[41:16];  
  end  
 
//level 7 of pipeline; currently not latched, in order not to disturb the timing of existing routines (but it should)    
  assign out=tmp + dd[41:16];
 
endmodule