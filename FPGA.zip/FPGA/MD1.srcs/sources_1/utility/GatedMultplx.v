`timescale 1ns / 1ps

//Gated multiplexer with nPort input ports, each with width nWidth. Inputs are sent out
//with different priority (port 0; highest priority, port nPort-1: lowest priority). Port 0 is special, 
//as it is sent through right away, and data can appear without gap, whereas all other ports need a gap of one clock 
//cycle minimum between requests. Hence, port0 is not bufferd and has guaranteed delivery time. ports>0 used to have 
//buffer but that cost a lot of resources; overall 4700FFs. They are no longer buffered (a buffered version is 
//found under GatedMultplx_buffered.v). The price one has to pay for that is an extra signal for all ports>0
//(i.e., data_port_valid), which says that data are still valid and which is used to generate an error signal is data 
//change before being sent out. Whenever tx_req_port is 1, data_port_valid should be 1 as well, but not vice versa, i.e.,   
//data_port_valid can be 1, but tx_req_port=0, in which case the data are not sent. In other words, data_port_valid  
//says when new data appear at an input port, but tx_req_port is a filtered a signal that says that these data should 
//be forwarded to the output. Tested thoroughly on the simulator level    
//
//Input buffer requires about 4700; try to avoid it 
//
//input:
//data_port       [nWidth*nPort-1:0]    vector with all input data
//data_port_valid [nPort-2:0]
//tx_req_port     [nPort-1:0]            request to send data
//
//output                          
//tx_req                                 data valid at the output
//dataout                                output data
//error                                  fatal error upon overflow of port_1...port_nPort-1; indicates wrong data have been sent

module GatedMultplx
#(
parameter nPort  =  4,    //number of Ports
parameter nWidth  =  28   //byte width of each poret
)
(
  input                           clk,
  input       [nWidth*nPort-1:0]  data_port,
  input       [nPort-2:0]         data_port_valid,
  input       [nPort-1:0]         tx_req_port,
  output reg                      tx_req,
  output reg  [nWidth-1:0]        dataout,
  output                          error 
);
   

reg  [nPort-2:0]              tx_req_reg   = 1'b0;  
reg  [nPort-2:0]              error_port   = 1'b0;  
assign error = |error_port;

integer i;    
always @(posedge clk) begin
  if((|tx_req_reg==1'b0)&&(tx_req_port[0]==1'b0)) tx_req <= 1'b0;    //no data in any of the ports
  if(tx_req_port[0]) begin                        //treat port 0 priviledged
    tx_req        <= 1'b1;
    dataout       <= data_port[0+:nWidth];
  end   
  for(i=1;i<nPort;i=i+1) begin                 //from remaining ports, port 1 has highest priority, all subsequent ports have succesively lower priority
    error_port[i-1] <= (data_port_valid[i-1]==1'b1)&&(tx_req_reg[i-1]==1'b1);  
    if(tx_req_reg[i-1]==1'b0) begin                  
      if (tx_req_port[i]==1'b1) begin
        tx_req_reg[i-1] <= 1'b1;
      end    
    end else if (~tx_req_port[0]&&((tx_req_reg&(~({nPort-1{1'b1}}<<(i-1))))==1'b0)) begin        //will AND with 0000, 0001, 0011, ...             
      dataout         <= data_port[i*nWidth+:nWidth];
      tx_req          <= 1'b1;
      tx_req_reg[i-1] <= 1'b0;  
      end 
    end
end

  

    
endmodule
