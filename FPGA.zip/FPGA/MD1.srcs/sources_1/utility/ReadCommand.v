`timescale 1ns / 1ps

//interpretes incoming commands, and sends resceived parameters as well as atom data to corresponding module. 
//
//Command structure: 
//packetNr(1Byte), command (1 Byte), arguments (can be up to 1500Bytes which is the maximum UDP allows)
//
//Commands:
//0:  Reset                                             send status bytes and initate resets. bit0: ErrorReset. bit1: nAtomReset, bit2: MD reset, bit 3: reset ForceField_cnt.
//1:  nstep(MSB) nstep(LSB)                             initiate MD run with nstep steps
//2:  start(MSB) start(LSB) nLine1 nLine2 sel data      write ForceLUT; start is start adress (12bit), nLine1 the number of lines (8bit), nLine2 the number of 9bit entries per line (4bit,the number of 8bit entries is nLine2+1), 
//                                                      sel selects LUT (currently 1bit only) 
//3:  data                                              thermostat parameters: 6 words of 32bits each 
//4:  data                                              simulation parameters: 9 words of 17bits each 
//5:  ForceField_atom(MSB) ForceField_atom(LSB) data    data is force field parameters: FF_LENGTH lines of DDR3_DATA_WIDTH/8 bytes each
//6:  nReceived  data                                   received nReceived atom data from host computer, each DataByteWidth long.  
//8:  sel        nSend                                  send nSend atom data to host computer. LSB of sel selects 256 block in 512 memory, the higher 5 bits (0..26) address a box (home box as well as all neighboring boxes)
//
//... to be continued
//
//
//parameters that are produced:
//- PacketNr            subsequent number, is send back via statusline, allows to determine whether all packest have been received
//- PacketNrOld         previosly received packerNr; allows to determine whether a lost packet was lost on the sending or receiveing side
//- WriteDataAtom       atom data valid 
//- DataAtom            atom data; data are valid at the same time as WriteDataAtom, and until one clock cycle before the next WriteDataAtom
//- SendMacBox          selects 256 block in 512 memory, as well as box (home box and neighbring boxes) 
//- SendMem             request to send data to MAC, triggered after every command as a handshake.
//- nSend               number of data to be sent. Is 0 for all commands except of command 8. When it is 0, only 3 status lines are sent, otherwise atom data are sent as well
//- nAtomReset          reset nAtom counts
//- ErrorReset          reset error_all
//- MDReset             reset MD machine
//- InitCalc            start MD machine
//- nstep               number of time steps
//- wrForceLUT          write into force LUT
//- dataForceLUT        data to be written into force LUT
//- adrForceLUT         address of data to be written into force LUT 
//- selForceLUT         select force LUT   
//- WriteDataThermostat thermostat data ready
//- AdrDataThermostat   counter for the vearios themostat data
//- DataThermostat      actual data
//- WriteSimParam       simualtion parameter ready
//- AdrSimParam         counter for the vearios simualtion parameter
//- SimParam            actual simulation parameter
//- ForceField_atom     protein atom for which subsequent force field data are sent; is valid for only one clock cycle when ForceField_rcv appears; is ok since it is written directly into FIFO
//- ForceField_rcv      one line of ForceField data of length DDR3_DATA_WIDTH ready
//- ForceField_data     actual force field data
//- ForceField_cnt      counts for how many atoms force field data have been written; is reset with Command0, bit3. Currently, 16bits


`include "MDSwitches.h"

module ReadCommand
#(
parameter  DataByteWidth   = 27,         //length of atom data line
parameter  nSelForceLUT    = 3,          //width of SelForceLUT 
parameter  nProteinAtom    = 12,         //defines maximum number of protein atoms,                                          
parameter  DDR3_DATA_WIDTH = 256,        //length of a line of DDR3 Ram, that stores protein force field parameter,          
parameter  FF_LENGTH       = 36          //Number of lines that defines force field.                                         
)      
(
        input                               IOclk,
        input                               ResetStart,
//in/output that reads from mac_top                  
        output  reg [10:0]                  CommandCnt,
        input       [7:0]                   CommandData,
        input                               CommandValid,
//data that are sent higher up                   
        output  reg [7:0]                   PacketNr,
        output  reg [7:0]                   PacketNrOld,
//for command 0: status and reset        
        output                              nAtomReset,
        output                              ErrorReset,
        output  reg                         MDReset,
//for command 1: initiate MD        
        output  reg                         InitCalc,     
        output  reg [15:0]                  nstep,    
//for command 2: write Force LUTs
        output  reg                         wrForceLUT,    
        output  reg [8:0]                   dataForceLUT,  
        output  reg [11:0]                  adrForceLUT,  
        output  reg [nSelForceLUT-1:0]      selForceLUT,    
//for command 3: thermostat parameters.       
        output  reg                         WriteDataThermostat=1'b0,
        output  reg [2:0]                   AdrDataThermostat,
        output  reg [31:0]                  DataThermostat,       
//for command 4: shake parameters.      
        output  reg                         WriteSimParam=1'b0,
        output  reg [3:0]                   AdrSimParam,
        output  reg [16:0]                  SimParam,               
//for command 5: protein force field data                                 
        output  reg                         ForceField_rcv=1'b0,   
        output  reg [nProteinAtom-1:0]      ForceField_atom,  
        output  reg [DDR3_DATA_WIDTH - 1:0] ForceField_data=1'b0,            
        output  reg [15:0]                  ForceField_cnt=1'b0,
//for command 6:  receiving atom data                                       
        output  reg                         WriteDataAtom=1'b0,                  
        output  reg [DataByteWidth*8-1:0]   DataAtom,      
//for command 8: send atom data   
        output  reg [0:0]                   SendMacBox,
        output  reg [7:0]                   nSend=1'b0,
        output                              SendMem                  //also triggered by all other commands with nsend=0 to initiate sending of status line          
);

localparam nDataThermostat=6;
localparam nSimParam=9;             //is new

reg  [7:0]                   Command    = 1'b0;
reg  [7:0]                   nReceived  = 8'd0;
reg  [4:0]                   cntLine    = 1'b0;  
reg  [7:0]                   cntLine1   = 1'b0;
reg  [3:0]                   cntLine2   = 1'b0;
reg  [DataByteWidth*8-9:0]   DataAtom_d0= 1'b0;             //highest byte  not needed 
reg  [23:0]                  DataThermostat_d0= 1'b0;        //highest byte  not needed 
reg  [8:0]                   SimParam_d0= 1'b0;              //highest 8bits  not needed 
reg                          nAtomReset_d0=1'b0;
reg  [2:0]                   nAtomReset_d;
assign                       nAtomReset = nAtomReset_d[2];
reg                          ErrorReset_d0=1'b0;
reg  [3:0]                   ErrorReset_d;
assign                       ErrorReset = ErrorReset_d[3];
reg                          SendMem_d0=1'b0;
reg  [4:0]                   SendMem_d;
assign                       SendMem = SendMem_d[4];
reg                          wrForceLUT_d1;
reg  [7:0]                   dataForceLUT_d0=1'b0;       
reg [8:0]                    dataForceLUT_d1;  
reg [11:0]                   adrForceLUT_d0;
reg [11:0]                   adrForceLUT_d1;   
reg [nSelForceLUT-1:0]       selForceLUT_d1;    
reg [7:0]                    nLine1 = 1'b0;
reg [3:0]                    nLine2 = 1'b0;
wire [3:0]                   cntLine2Start=4'h8-nLine2;



always @(posedge IOclk) begin 
 nAtomReset_d <= {nAtomReset_d[1:0],nAtomReset_d0}; //needs to be delayed with respect to MDReset
 ErrorReset_d <= {ErrorReset_d[2:0],ErrorReset_d0}; //needs to be delayed even more
 SendMem_d    <=    {SendMem_d[3:0],SendMem_d0};    //needs to be delayed even more
 wrForceLUT   <= wrForceLUT_d1;                     //add one FIFO stage for better routing   
 dataForceLUT <= dataForceLUT_d1;
 adrForceLUT  <= adrForceLUT_d1;
 selForceLUT  <= selForceLUT_d1;

//reset signals 
 WriteDataAtom       <= 1'b0;     
 WriteDataThermostat <= 1'b0;
 wrForceLUT_d1       <= 1'b0;
 InitCalc            <= 1'b0;
 nAtomReset_d0       <= 1'b0;
 ErrorReset_d0       <= 1'b0;
 MDReset             <= 1'b0;
 SendMem_d0          <= 1'b0;
 ForceField_rcv      <= 1'b0;
 WriteSimParam       <= 1'b0;
 //ForceField_cnt      <= 1'b0;  //is new
 
//major state machine 
 if(ResetStart)          CommandCnt<=11'h7ff;  
 else begin
   if(CommandValid==1'b1) begin
     CommandCnt<=1'b0;
   end else begin
     if(CommandCnt<11'h7ff) begin
       if(CommandCnt==11'd0) CommandCnt<=CommandCnt+1'b1; //wait for memory latancy 2
       if(CommandCnt==11'd1) CommandCnt<=CommandCnt+1'b1; //wait for memory latancy 2
       if(CommandCnt==11'd2) begin
         PacketNr    <= CommandData;
         PacketNrOld <= PacketNr;
         CommandCnt  <= CommandCnt+1'b1;   
       end  
       if(CommandCnt==11'd3) begin 
         Command           <= CommandData;
         cntLine           <= 1'b0;
         AdrDataThermostat <= 3'h7;                //effectively -1
         AdrSimParam       <= 4'hf;                //effectively -1
         CommandCnt        <= CommandCnt+1'b1;
       end  
       if(CommandCnt>11'd3) begin
         case (Command)
           0: begin                                //read status  and send reset signals          
                CommandCnt<=11'h7ff; 
                ErrorReset_d0       <= CommandData[0];
                nAtomReset_d0       <= CommandData[1];
                MDReset             <= CommandData[2];
                if(CommandData[0])  PacketNrOld    <= 1'b0;   //upon ErrorReset
                if(CommandData[3])  ForceField_cnt <= 1'b0;
                nSend      <=1'b0;       
                SendMem_d0 <=1'b1;
              end            
           1: begin                                //initiate calculation;           
                if(CommandCnt==11'd4) begin                                                    
                  CommandCnt  <= CommandCnt+1'b1;
                  nstep<={nstep[7:0],CommandData};  
                end 
                if(CommandCnt==11'd5) begin
                  CommandCnt<=11'h7ff;  
                  nstep      <= {nstep[7:0],CommandData};                    
                  InitCalc   <= 1'b1;
                  nSend      <= 1'b0;                 //return status line for handshake
                  SendMem_d0 <= 1'b1;
                end  
              end 
          2: begin                                      //write Force LUTs
                if(CommandCnt==11'd4) begin             //sent in 128 line blocks; number of block
                  CommandCnt       <= CommandCnt+1'b1; 
                  adrForceLUT_d0   <= CommandData[3:0];
                end      
                if(CommandCnt==11'd5) begin
                  CommandCnt       <= CommandCnt+1'b1;
                  adrForceLUT_d0   <= {adrForceLUT_d0[3:0],CommandData};
                end 
                if(CommandCnt==11'd6) begin
                  CommandCnt       <= CommandCnt+1'b1;
                  nLine1           <= CommandData;
                end 
                if(CommandCnt==11'd7) begin
                  CommandCnt       <= CommandCnt+1'b1;
                  nLine2           <= CommandData[3:0];
                end              
                if(CommandCnt==11'd8) begin            
                  CommandCnt       <= CommandCnt+1'b1; 
                  selForceLUT_d1   <= CommandData[nSelForceLUT-1:0];
                  cntLine1         <= 1'b0;
                  cntLine2         <= cntLine2Start;           //=4'h8-nLine2, defined above as wire
                  adrForceLUT_d0   <= adrForceLUT_d0+4'h8;
                end   
                if((CommandCnt>11'd8)&&(CommandCnt<11'h7ff)) begin 
                  CommandCnt       <= CommandCnt + 1'b1;
                  dataForceLUT_d0  <= CommandData;  
                  if(cntLine2<4'h8) begin
                    cntLine2       <= cntLine2 + 1'b1;
                  end else begin  
                    cntLine2       <= cntLine2Start;           //=4'h8-nLine2, defined above as wire
                    cntLine1       <= cntLine1 + 1'b1;
                    adrForceLUT_d0 <= adrForceLUT_d0 +nLine2;
                  end   
                  adrForceLUT_d1   <= adrForceLUT_d0-cntLine2; 
                  wrForceLUT_d1    <= (cntLine2>cntLine2Start);
                  case (cntLine2) 
                    4'h1: dataForceLUT_d1 <= {dataForceLUT_d0[7:0],CommandData[7:7]};
                    4'h2: dataForceLUT_d1 <= {dataForceLUT_d0[6:0],CommandData[7:6]};
                    4'h3: dataForceLUT_d1 <= {dataForceLUT_d0[5:0],CommandData[7:5]};
                    4'h4: dataForceLUT_d1 <= {dataForceLUT_d0[4:0],CommandData[7:4]};
                    4'h5: dataForceLUT_d1 <= {dataForceLUT_d0[3:0],CommandData[7:3]};
                    4'h6: dataForceLUT_d1 <= {dataForceLUT_d0[2:0],CommandData[7:2]};
                    4'h7: dataForceLUT_d1 <= {dataForceLUT_d0[1:0],CommandData[7:1]};
                    4'h8: dataForceLUT_d1 <= {dataForceLUT_d0[0:0],CommandData[7:0]};
                  endcase   
                end 
                if((CommandCnt>11'd8)&&(cntLine1==nLine1)) begin          
                  CommandCnt    <= 11'h7ff;  
                  nSend         <= 1'b0;   //return status line for handshake;    
                  SendMem_d0    <= 1'b1;    
                end 
              end
           3: begin                                //receive thermostat data from host computer, 6 words with 4 bytes each                             
                if(CommandCnt<nDataThermostat*4+4) begin 
                  CommandCnt        <= CommandCnt + 1'b1;
                  DataThermostat_d0 <={DataThermostat_d0[15:0],CommandData};      
                  if(cntLine <3) begin
                    cntLine             <= cntLine + 1'b1; 
                  end else begin  
                    cntLine             <= 1'b0; 
                    WriteDataThermostat <= 1'b1;
                    AdrDataThermostat   <= AdrDataThermostat +1'b1;   
                    DataThermostat      <= {DataThermostat_d0,CommandData};
                  end   
                end 
                if(CommandCnt==nDataThermostat*4+4) begin          
                  CommandCnt    <= 11'h7ff;  
                  nSend         <= 1'b0;   //return status line for handshake;    
                  SendMem_d0    <= 1'b1;  
                end 
              end                    
           4: begin                                //receive simulation paramert from host computer, 9 words with 3 bystes each, eventually reduced to 17bits                             
                if(CommandCnt<nSimParam*3+4) begin 
                  CommandCnt        <= CommandCnt + 1'b1;
                  SimParam_d0      <= {SimParam_d0[0],CommandData};      
                  if(cntLine <2) begin
                    cntLine             <= cntLine + 1'b1; 
                  end else begin  
                    cntLine             <= 1'b0; 
                    WriteSimParam       <= 1'b1;
                    AdrSimParam         <= AdrSimParam +1'b1;   
                    SimParam           <= {SimParam_d0,CommandData};
                  end   
                end 
                if(CommandCnt==nSimParam*3+4) begin          
                  CommandCnt    <= 11'h7ff;  
                  nSend         <= 1'b0;   //return status line for handshake;    
                  SendMem_d0    <= 1'b1;  
                end 
              end    
           5: begin                                                                        
                if(CommandCnt==11'd4) begin             
                  CommandCnt          <= CommandCnt+1'b1; 
                  ForceField_atom     <= CommandData[nProteinAtom-9:0];
                  ForceField_cnt      <= ForceField_cnt + 1'b1;              //counts how many force field atoms have been written
                  cntLine             <= 1'b0;
                end      
                if(CommandCnt==11'd5) begin
                  CommandCnt          <= CommandCnt+1'b1;
                  ForceField_atom     <= {ForceField_atom[nProteinAtom-9:0],CommandData};
                end                                                             
                if((CommandCnt>11'd5)&&(CommandCnt<FF_LENGTH*DDR3_DATA_WIDTH/8+11'd6)) begin 
                  CommandCnt        <= CommandCnt + 1'b1;     
                  ForceField_data   <= {ForceField_data[DDR3_DATA_WIDTH-9:0],CommandData};    
                  cntLine           <= cntLine + 1'b1; 
                  if(cntLine == DDR3_DATA_WIDTH/8-1) begin
                    cntLine        <= 1'b0;
                    ForceField_rcv <= 1'b1;
//                    ForceField_data<={ForceField_data_d0[DDR3_DATA_WIDTH-9:0],CommandData}; 
                  end   
                end 
                if(CommandCnt==FF_LENGTH*DDR3_DATA_WIDTH/8+11'd6) begin          
                  CommandCnt    <= 11'h7ff;  
                  nSend         <= 1'b0;   //return status line for handshake;    
                  SendMem_d0    <= 1'b1;   
                end               
              end                                                         
           6: begin                                //receive atom data from host computer (velocities, coordinates, metadata)        
                if(CommandCnt==11'd4) begin             //number of data in that block
                  CommandCnt  <= CommandCnt+1'b1; 
                  nReceived   <= CommandData;
                  cntLine     <= 1'b0;
                end                    
                if((CommandCnt>11'd4)&&(CommandCnt<nReceived*DataByteWidth+11'd5)) begin 
                  CommandCnt  <= CommandCnt + 1'b1;
                  DataAtom_d0<={DataAtom_d0[DataByteWidth*8-17:0],CommandData};                 
                  if(cntLine <DataByteWidth-1) begin
                    cntLine       <= cntLine + 1'b1; 
                  end else begin  
                    cntLine       <= 1'b0; 
                    WriteDataAtom <= 1'b1;
                    DataAtom      <= {DataAtom_d0[DataByteWidth*8-9:0],CommandData};               //need to latch it, since it might take some time until data are really taken over
                  end   
                end 
                if(CommandCnt==nReceived*DataByteWidth+11'd5) begin          
                  CommandCnt    <= 11'h7ff;  
                  nSend         <= 1'b0;   //return status line for handshake;    
                  SendMem_d0    <= 1'b1;  
                end 
              end
           8: begin
                if(CommandCnt==11'd4) begin                           //send atom data to host computer from various memories                          
                  CommandCnt  <= CommandCnt+1'b1; 
                  SendMacBox  <= CommandData[0:0];  
                end 
                if(CommandCnt==11'd5) begin 
                  CommandCnt <= 11'h7ff; 
                  nSend      <= CommandData;       
                  SendMem_d0 <= 1'b1;
                end                   
              end              
           default: CommandCnt<=11'h7ff;  
         endcase   
         end
       end   
     end
   end  
 end

endmodule
