`timescale 1ns / 1ps

module SyncNodes
    (
    input             IOclk,
    inout             AllBusyExt11,   
    inout             errorRxSyncExt11,
    inout             AllBusyExt12,   
    inout             errorRxSyncExt12,
    inout             AllBusyExt2,   
    inout             errorRxSyncExt2,  
    input             AllBusy,
    input             errorRxSync,
    output reg        AllBusyIn,
    output reg        errorRxSyncIn
    );


//When AllBusy is 1, it is output to AllBusyExt11, where all nodes are wired in parallel. Is set to 0 
//immedeatly, but to 1 delayed so that all nodes see the 0. The output is configured as biderectional 
//with pull-down resistor (internal as well as 2.2K external). When AllBusy is 1, AllBusyExt11 is 1. When it switches 
//to 0, it goes into high-impedance. On the receiving side, when all nodes on AllBusyExt1 are 
//0 for at least 7 clock cycles, it is considered to be a 0.
//
//In addition, there is a perpendicular network (AllBusyExt2), that connects various AllBusyExt1 strings.
//Since connecting it to AllBusyExt11 would lock it to 1 for ever, a second string AllBusyExt12 runs in 
//parralel to AllBusyExt11. The output is an OR of AllBusyExt11 and AllBusyExt11. Some signals need to be extended
//so that all nodes see it.
//The data flow is:
//  
//           11     12                            11     12
//           |      |                             |      | 
//           |      |                             |      | 
//           o->|   o<-|                          o->|   o<-|
//        ---|--o---|--o-------------2------------|--o---|--o---
//           |      |                             |      | 
//           |      |                             |      | 
// in local->o      |                   in local->o      |
//           |      |                             |      |
//           o------|->-|                         o------|->-|
//           |      |  OR -> out local            |      |   OR -> out local             
//           |      o->-|                         |      o->-|
//           |      |                             |      |
//
//
//Same is done for errorRxSync, without the initial wait for going high



reg       AllBusy_d0;
reg [5:0] AllBusyCnt1_1=1'b0, AllBusyCnt1_2=1'b0; 
reg [5:0] AllBusyCnt2=1'b0;  
reg       AllBusyExt11_d0;

always @(posedge IOclk) begin

  if(~(AllBusy)) begin          //set low immedeatly, but high delayed, so that all nodes see the 0
     AllBusyCnt1_1 <= 1'b0;
     AllBusy_d0    <= 1'b0;
  end else begin 
    if (AllBusyCnt1_1<6'h30) AllBusyCnt1_1 <= AllBusyCnt1_1 +1'b1;
    else                      AllBusy_d0    <= 1'b1;       
  end  
  
 if(~(AllBusyExt11)) begin          //set low immedeatly, but high delayed, so that all nodes see the 0
     AllBusyCnt1_2   <= 1'b0;
     AllBusyExt11_d0 <= 1'b0;
  end else begin 
    if (AllBusyCnt1_2<6'h30) AllBusyCnt1_2   <= AllBusyCnt1_2 +1'b1;
    else                      AllBusyExt11_d0 <= 1'b1;       
  end  
 
end
 
assign AllBusyExt11 =  AllBusy_d0       ? 1'b1 : 1'bz;       
assign AllBusyExt2  =  AllBusyExt11_d0  ? 1'b1 : 1'bz;         
assign AllBusyExt12 =  AllBusyExt2      ? 1'b1 : 1'bz;        
        
                  
always @(posedge IOclk) begin                           //input needs to be low for at least 7 cycles to consider it low
  if(AllBusyExt11||AllBusyExt12) begin 
    AllBusyCnt2 <= 1'b0;
    AllBusyIn   <= 1'b1;
  end else begin 
    if (AllBusyCnt2<6'h7) AllBusyCnt2 <= AllBusyCnt2 +1'b1;
    else                  AllBusyIn   <= 1'b0;         
  end
end         



//***********************************************************same for error signal, without the initial wait

reg [2:0] errorRxSyncCnt2=1'b0; 



assign errorRxSyncExt11 = errorRxSync      ? 1'b1 : 1'bz;       
assign errorRxSyncExt12 = errorRxSyncExt2  ? 1'b1 : 1'bz;       
assign errorRxSyncExt2  = errorRxSyncExt11 ? 1'b1 : 1'bz;      
     

                  
always @(posedge IOclk) begin                           //input needs to be low for at least 7 cycles to consider it low
  if(errorRxSyncExt11||errorRxSyncExt12) begin 
    errorRxSyncCnt2 <= 1'b0;
    errorRxSyncIn   <= 1'b1;
  end else begin 
    if (errorRxSyncCnt2<3'h7)  errorRxSyncCnt2 <= errorRxSyncCnt2 +1'b1;
    else                       errorRxSyncIn   <= 1'b0;         
  end
end      


endmodule
