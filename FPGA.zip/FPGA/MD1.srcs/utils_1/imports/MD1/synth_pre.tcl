set_msg_config -id {Synth 8-6014} -string {xpm_cdc.sv} -suppress
set_msg_config -id {Synth 8-7129} -string {xpm_memory_base} -suppress
set_msg_config -id {Synth 8-7129} -string {xpm_fifo_rst} -suppress


