// UDP communication from https://stackoverflow.com/questions/679145/how-to-set-up-a-winsock-udp-socket

#define _CRT_SECURE_NO_WARNINGS
#include <string>
#include <WinSock2.h>
#include <Ws2tcpip.h>
#include <windows.h>
#include <stdint.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <cstdlib> 
#include <time.h> 



//parameters specific to the hardware configuration and FPGA prpgram
#define nBlock    50              //number of lines writen in a single block
#define nxNode    3               //number of nodes in x-direction
#define nyNode    3               //number of nodes in y-direction
#define nzNode    3               //number of nodes in z-direction
#define v_shift   16              //velocities shifted down by 4 bit relative to position +1 extra bit, since positions are defined in +/-2

#define statusBussy      7        //position of bussy bits in status line
#define statusRestartCnt 17       //position of restart counts in status line
#define statusErr        23       //position of error word in status line
#define statusPcktCnt    26       //position of PacketNr's in status line
#define statusVersion    24       //position of Version in status line 
#define statusNatom      53       //position of natom[inode] in status line
#define PosTemp          2        //position of temperature

#define path      "../../"        //path of in/output file

//parameters that are needed wen a new box is generated; currently commented out
//#define nxSide    18              //number of atoms in x-direction
//#define nySide    18              //number of atoms in y-direction
//#define nzSide    18              //number of atoms in z-direction


#define rLJ        0.3554         //SPC LennardJones parameter, in nm      
#define eLJ        0.65           //SPC LennardJones parameter, in kJ/mol
#define mO         16             //mass oxygen
//#define qO         -0.82        //charge O, SPC model
//#define qH         0.41         //charge H, SPC model
//#define e0         8.854188E-12 //vacuum permetivity, in SI units
//#define e          1.602177E-19 //elementary charge, in SI units
#define NA         6.022141E23    //avogdro constant
#define kB         1.380649E-23   //Boltzmann constant in J/K
#define PI         3.14159265358979323846

//switches on/off certain analysis routines, which however will take time on host computer
//#define RunIntMD
//#define CalcRDF
//#define CalcQ6
#define n_gr      500            //number of points used for rdf


#pragma comment(lib, "ws2_32.lib")
using namespace std;

int      ReadStatus(uint8_t* inbuff, int iNode, uint8_t Reset, sockaddr_in* dest, SOCKET sock, uint8_t* PacketNr);
int      SetThermostat(int T_onoff, float T_target1, int T_tau, int natom, uint8_t* inbuff, int iNode, sockaddr_in* dest, SOCKET sock, uint8_t* PacketNr);
int      WriteAtomData(float** q, float** v, int* atomNr, uint8_t natom, int iNode, sockaddr_in* dest, SOCKET sock, uint8_t* PacketNr);
void     WriteForceLUT(int iNode, sockaddr_in* dest, SOCKET sock, uint8_t* PacketNr);
void     ReadAtomData(float** q, float** v, int* atomNr, uint8_t natom, uint8_t BoxNr, int iNode, sockaddr_in* dest, SOCKET sock, uint8_t* PacketNr);
void     StartMD(uint16_t nStepMD, int iNode, sockaddr_in* dest, SOCKET sock, uint8_t* PacketNr);
int      CheckError(uint8_t* inbuff, uint8_t PacketNr, int iNode);
void     readParam(FILE* paramfile);
void     NodeNr(int iNode, int* ixNode, int* iyNode, int* izNode);

void     mdstep(float** q, float** v, int natom);
void     writetraj(int *atomNr, float** q, float** v, int *connect, float t, float T, int natom, FILE* out);
float    LennardJones(float r2);
float    Temperature(float** v, int natom);
void     Radial(int* gr, float** q, int natom);
int      Q6(int **connect, int *hist_cluster, float** q, int natom);
double   legendre(int m, double costheta);




float    sign(float in);
float    gasdev(long* idum);
float    ran1(long* idum);
int*     ivector(long long nrow);
float**  matrix(long long nrow, long long ncol);
double** dmatrix(long long nrow, long long ncol);
int**    imatrix(long long nrow, long long ncol);
float*** f3tensor(long long nrow, long long ncol, long long ndep);
void     free_ivector(int* v);
void     free_dmatrix(double** m, int nrow);
void     free_imatrix(int** m, int nrow);

void     float_int24_pm2(float x, uint8_t* intbuff);
void     float_int24_pm1(float x, uint8_t* intbuff);
void     float_int24_p1(float x, uint8_t* intbuff);
float    int24_float_pm2(uint8_t* readbuff);
float    int24_float_pm1(uint8_t* readbuff);
float    int24_float_p1(uint8_t* readbuff);

/******************************Gloabel Variables that will be read from parameter file, etc***************************************/
FILE *logfile;
int nStep1, nStep2,T_coupl, tauT, gen_vel, gen_seed;
float rcut,dt,T_target;
char  startfile[50],traj_file[50],outfile[50],ener_file[50];



int main() 
{
//IP stuff
    const char* srcIP = "192.168.1.131";  //IP adress of the ETH interface connectic to FPGAs; needs to be a static IP
    char        destIP[16];
    sockaddr_in dest[nxNode * nyNode * nzNode];
    sockaddr_in local;
    SOCKET      sock;
    WSAData     wsaddata;
    int         destSize = sizeof(dest[0]);

 //remaining stuff
    char        filename[100];
    char        atomName[4];
    uint8_t     status[100];
    int         iNode,ixNode,iyNode,izNode,m;
    int         nNode,it1;
    uint8_t     PacketNr[nxNode * nyNode * nzNode];
    uint8_t     version[nxNode * nyNode * nzNode];
    uint32_t    itmp, i, j, i2;
    uint64_t    fint;
    float       **qext, **vext, v_sd;
    float       **vint, **qint;
    float       **qtmp, **vtmp;
    int         *atomNrtmp;
    int         *atomNrExt;
    int         natomAll,natomAll2, natomAll3, ix,iy,iz,i1;
    uint8_t     natom[nxNode * nyNode * nzNode];
    uint16_t    iStep;
    long        idum = -1;
    FILE        *trajfile,*trajfile2, *enerfile,*atomfile,*grfile, *histfile, *paramfile;
    uint8_t     outbuff[9];
    float       Tint=0,Text,vcm[3],T_FPGA;
    int         err, errETH;
    int         **ErrorStat;
    clock_t     timer;
    float       calcTime = 0,Tconv;
    int         *gr,*hist_cluster;
    float       rc, vb, nid;
    double      q6=0;
    char        tmpbuff[100];
    int         nconnect=0, **connect;

//open files and read parameter file  
    sprintf(filename, "%smd.log", path);
    logfile = fopen(filename, "w");
    sprintf(filename, "%sparam.dat", path);
    paramfile = fopen(filename, "r");

    printf("\nRead parameter file\n");
    fprintf(logfile, "\nRead parameter file\n");
    readParam(paramfile);

    sprintf(filename, "%s%s", path,traj_file);
    trajfile = fopen(filename, "w");
    sprintf(filename, "%s%s", path,ener_file);
    enerfile = fopen(filename, "w");

//initialize UDP communication
    if (WSAStartup(MAKEWORD(2, 2), &wsaddata) != 0) 
    { 
        printf("WSAStartup failed\n"); 
        fprintf(logfile,"WSAStartup failed\n");
        exit(1); 
    }
    local.sin_family = AF_INET;
    itmp = inet_pton(AF_INET, srcIP, &local.sin_addr.s_addr);
    local.sin_port = htons(8080);
    sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    bind(sock, (sockaddr*)&local, sizeof(local));

//initialize/open nodes
    nNode = nxNode * nyNode * nzNode;
    ErrorStat = imatrix(nNode, 6);
    for (iNode = 0; iNode < nNode; iNode++)
    {
        sprintf_s(destIP, "192.168.1.%d", 192 + iNode);    //IP adresses of FPGAs; start at 192.168.1.192 with node0, is set by dip switches
        printf("Initializing node %2d, IP: %s\n", iNode, destIP);
        fprintf(logfile,"Initializing node %2d, IP: %s\n", iNode, destIP);
        dest[iNode].sin_family = AF_INET;
        itmp = inet_pton(AF_INET, destIP, &dest[iNode].sin_addr.s_addr);
        dest[iNode].sin_port = htons(8080);
        ReadStatus(status, iNode, 7,dest,sock, PacketNr);   //test whether nodes respond, and if yes, report its status; reset nodes
        version[iNode] = status[statusVersion];
        if (version[iNode] != version[0])
        {
            printf("Warning: FPGA version of node %d (%d) is different from that of node 0 (%d).\n", iNode, version[iNode], version[0]);
            fprintf(logfile,"Warning: FPGA version of node %d (%d) is different from that of node 0 (%d).\n", iNode, version[iNode], version[0]);
        }
    }
    printf("FPGA version %d\n",version[0]);
    fprintf(logfile,"FPGA version %d\n", version[0]);

//read coordinates and velocities from starting file
    printf("\nRead atom data from %s\n",startfile);
    fprintf(logfile,"\nRead atom data from %s\n",startfile);
    sprintf(filename, "%s%s", path, startfile);
    atomfile = fopen(filename, "r");
    fgets(tmpbuff, 100, atomfile);
    itmp=sscanf(tmpbuff, "%d", &natomAll);
    printf("File contains %4d atoms\n",natomAll);
    fprintf(logfile,"File contains %4d atoms\n", natomAll);

//allocate memory
    qext = matrix(natomAll, 3);
    vext = matrix(natomAll, 3);
    qtmp = matrix(256, 3);
    vtmp = matrix(256, 3);
    qint = matrix(natomAll, 3);
    vint = matrix(natomAll, 3);
    atomNrExt = ivector(natomAll);
    atomNrtmp = ivector(256);
    connect = imatrix(2, natomAll);

 //continue reading file
    fgets(tmpbuff,100,atomfile);  //skip line
    for (i = 0; i <= 4; i++) gasdev(&idum);
    v_sd = sqrt(kB * T_target * NA * 1E3 / mO) * dt * 1E-15 / (rcut * 1E-9);
    for (i = 0; i <= gen_seed; i++) gasdev(&idum);

    for (i = 0; i < natomAll; i++)
    {
        itmp=fscanf(atomfile, "%s %f %f %f %f %f %f %d",atomName, &qext[i][0], &qext[i][1], &qext[i][2], &vext[i][0], &vext[i][1], &vext[i][2], &atomNrExt[i]);
        qext[i][0] /= 10. * rcut;
        qext[i][1] /= 10. * rcut;
        qext[i][2] /= 10. * rcut;
        vext[i][0] /= 10. * rcut / dt;
        vext[i][1] /= 10. * rcut / dt;
        vext[i][2] /= 10. * rcut / dt;

        if (gen_vel != 0)
        {
            vext[i][0] = v_sd * gasdev(&idum);
            vext[i][1] = v_sd * gasdev(&idum);
            vext[i][2] = v_sd * gasdev(&idum);
        }
#ifdef RunIntMD
        qint[i][0] = qext[i][0];
        qint[i][1] = qext[i][1];
        qint[i][2] = qext[i][2];
        vint[i][0] = vext[i][0];
        vint[i][1] = vext[i][1];
        vint[i][2] = vext[i][2];
#endif
    }
    fclose(atomfile);

//remove center of mass motion
    for (i = 0, vcm[0] = 0, vcm[1] = 0, vcm[2] = 0; i < natomAll; i++) { vcm[0] += vext[i][0]; vcm[1] += vext[i][1]; vcm[2] += vext[i][2]; }
    printf("Center of mass motion: %10.6f %10.6f %10.6f\n", vcm[0] / natomAll, vcm[1] / natomAll, vcm[2] / natomAll);
    fprintf(logfile,"Center of mass motion: %10.6f %10.6f %10.6f\n", vcm[0] / natomAll, vcm[1] / natomAll, vcm[2] / natomAll);
    for (i = 0; i < natomAll; i++) { vext[i][0] -= vcm[0] / natomAll; vext[i][1] -= vcm[1] / natomAll; vext[i][2] -= vcm[2] / natomAll; }
    Text = Temperature(vext, natomAll);
    printf("Center of mass motion removed\nT=%5.1f\n", Text);
    fprintf(logfile,"Center of mass motion removed\nT=%5.1f\n", Text);


#ifdef CalcRDF
    gr = ivector(n_gr); for (i = 0; i < n_gr; i++) gr[i] = 0;
#endif
#ifdef CalcQ6
    hist_cluster = ivector(natomAll / 10); for (i = 0; i < natomAll / 10; i++) hist_cluster[i] = 0;
#endif

//write force LUTs
    printf("\nWrite Force LUTs\n");
    fprintf(logfile, "\nWrite Force LUTs\n");
    for (iNode = 0; iNode < nNode; iNode++)
    {
        WriteForceLUT(iNode, dest, sock, PacketNr);
    }

//set thermostat
    Tconv = mO / (3 * NA * 1E3) * rcut * rcut / (dt * dt) * 1E12 / kB / 512.;
    printf("\nSet Thermostat: Tcoupl=%1d Tref=%5.1fK tau= %4.0f fs\n",T_coupl,T_target,dt*pow(2,tauT));
    fprintf(logfile,"\nSet Thermostat\n");
    for (iNode = 0; iNode < nNode; iNode++)
    {
        SetThermostat(1+2*T_coupl, T_target, tauT, natomAll, status, iNode, dest, sock, PacketNr);  //center of mass removal always on, but thermostat can be switched on/off
    }


/*
//generate a new box with nxSide*nySide*nzSide atoms that are equally diszributed, and with random velocities according to T_target
    for (i = 0; i <= 4; i++) gasdev(&idum);
    v_sd = sqrt(kB * T_target * NA * 1E3 / mO) * dt * 1E-15 / (rcut * 1E-9);
    printf("Standard deviation velocities: %11.8f\n", v_sd);
    for (iz = 0, i = 0; iz < nzSide ; iz++)
        for (iy = 0; iy < nySide ; iy++)
            for (ix = 0; ix < nxSide ; ix++)
            {
                atomNrExt[i] = i+1;
                qext[i][0]   = nxNode * ((float)ix + 0.5) / nxSide;
                qext[i][1]   = nyNode * ((float)iy + 0.5) / nySide;
                qext[i][2]   = nzNode * ((float)iz + 0.5) / nzSide;
                vext[i][0]   = v_sd * gasdev(&idum);
                vext[i][1]   = v_sd * gasdev(&idum);
                vext[i][2]   = v_sd * gasdev(&idum);
                i++;
            }
 //remove center-of-mass velocity
    for (i = 0, vcm[0] = 0, vcm[1] = 0, vcm[2] = 0; i < natomAll; i++) { vcm[0] += vext[i][0]; vcm[1] += vext[i][1]; vcm[2] += vext[i][2]; }
    printf("Center of mass motion: %10.6f %10.6f %10.6f\n",vcm[0] / natomAll, vcm[1] / natomAll, vcm[2] / natomAll);
    for (i = 0; i < natomAll; i++) { vext[i][0] -= vcm[0] / natomAll; vext[i][1] -= vcm[1]/ natomAll; vext[i][2] -= vcm[2] / natomAll; }  
    Text = Temperature(vext, natomAll);
    printf("T=%5.1f\n", Text);
*/



//send atom data to FPGAs      
    printf("\nSend atom data\n");
    fprintf(logfile,"\nSend atom data\n");
    do {
        err = 0;
        for (iNode = 0; iNode < nNode; iNode++)
        {
            ReadStatus(status, iNode, 3, dest, sock, PacketNr);  //reset Errors and nAtom
        }
        for (iNode = 0; iNode < nNode; iNode++)
        {
            NodeNr(iNode, &ixNode, &iyNode, &izNode);
            natom[iNode] = 0;
            for (i = 0; i < natomAll; i++) if ((int)qext[i][0] == ixNode && (int)qext[i][1] == iyNode && (int)qext[i][2] == izNode)
            {
                qtmp[natom[iNode]][0] = qext[i][0] - ixNode;
                qtmp[natom[iNode]][1] = qext[i][1] - iyNode;
                qtmp[natom[iNode]][2] = qext[i][2] - izNode;
                vtmp[natom[iNode]][0] = vext[i][0];
                vtmp[natom[iNode]][1] = vext[i][1];
                vtmp[natom[iNode]][2] = vext[i][2];
                atomNrtmp[natom[iNode]] = atomNrExt[i];
                natom[iNode]++;
            }
            itmp = WriteAtomData(qtmp, vtmp, atomNrtmp, natom[iNode], iNode, dest, sock, PacketNr);
            if (itmp != 0)
            {
                err = itmp;
            }
        }
        if (err != 0)
        {
            printf("Transmission error during WriteAtomData; redo\n");
            fprintf(logfile,"Transmission error during WriteAtomData; redo\n");
        }
    } while (err != 0);
    
//read status of FPGAs as a check
    printf("\nRead status\n");
    fprintf(logfile,"\nRead status\n");
    for (iNode = 0; iNode < nNode; iNode++)
    {
        ReadStatus(status, iNode, 0, dest, sock, PacketNr);
        printf("Node %2d #Atoms:", iNode); for (j = 27; j < 54; j++) printf(" %3d", status[j]); printf("\n");
        fprintf(logfile,"Node %2d #Atoms:", iNode); for (j = 27; j < 54; j++) fprintf(logfile," %3d", status[j]); fprintf(logfile,"\n");
    }

 //main MD loop
    printf("\nRun MD\n");
    fprintf(logfile,"\nRun MD\n");
    for (iStep = 1; iStep <= nStep2+1; iStep++)
    {
        if (iStep <= nStep2) for (iNode = 0; iNode < nNode; iNode++)
        {
            StartMD(nStep1, iNode, dest, sock, PacketNr);
        }
        timer = clock();

//do all analysis from the previous step while MD is running
        if (iStep > 1)                  
        {
#ifdef RunIntMD      
            for (it1 = 1; it1 <= nStep1; it1++)
            {
                mdstep(qint, vint, natomAll);
            }
            Tint = Temperature(vint, natomAll);
#endif
#ifdef CalcQ6
            nconnect = Q6(connect, hist_cluster, qext, natomAll);
            histfile = fopen("../../cluster.dat", "w");
            for (i = MinCluster; i < natomAll / 10; i++) fprintf(histfile, "%4d %6d\n", i, hist_cluster[i]);
            fclose(histfile);
#endif
#ifdef CalcRDF
            Radial(gr, qext, natomAll);
#endif
            printf("Time step %4d at %10.3f ps: T=%7.2f Fraction solid-like: %6.4f\n", iStep - 1, (iStep - 1) * nStep1 * dt / 1000, Tconv * T_FPGA / natomAll, (float)nconnect / natomAll);
            fprintf(logfile,"Time step %4d at %10.3f ps: T=%7.2f Fraction solid-like: %6.4f\n", iStep - 1, (iStep - 1) * nStep1 * dt / 1000, Tconv * T_FPGA / natomAll, (float)nconnect / natomAll);
            fflush(logfile);
            for (i = 0, vcm[0] = 0, vcm[1] = 0, vcm[2] = 0; i < natomAll; i++) { vcm[0] += vext[i][0] / natomAll; vcm[1] += vext[i][1] / natomAll; vcm[2] += vext[i][2] / natomAll; }
            fprintf(enerfile, "%9.3f %6.2f %6.2f %6.4f  %12.9f %12.9f %12.9f\n", (iStep-1) * nStep1 * dt / 1000., Tint, Tconv * T_FPGA / natomAll, (float)nconnect / natomAll, vcm[0]*rcut/dt, vcm[1] * rcut / dt, vcm[2] * rcut / dt);
            fflush(enerfile);
            writetraj(atomNrExt, qext, vext, connect[1], iStep* nStep1* dt / 1000., Tconv* T_FPGA / natomAll, natomAll, trajfile);
            fflush(trajfile);
        }
                
//wait until MD is done on all nodes
        natomAll3 = 0;
        T_FPGA = 0;
        for (iNode = 0; iNode < nNode; iNode++)
        {
            errETH = 0;
            do
            {
                ReadStatus(status, iNode, 0, dest, sock, PacketNr);
            } while (status[statusBussy] % 2 == 1);

            T_FPGA+=int24_float_p1(&status[PosTemp]);

//test whether sum of atoms in neigboring boxes stays constant; is a good indicator of bugs 
            natomAll2 = 0;
            for(j=0;j<27;j++) natomAll2 += status[53 - j];
            if (natomAll2 != natomAll)
            {
                printf("\nERROR:Number of atoms in neighboring boxes not correct in node %2d: %4d %4d ", iNode, natomAll2, natomAll);
                fprintf(logfile,"\nERROR:Number of atoms in neighboring boxes not correct in node %2d: %4d %4d ", iNode, natomAll2, natomAll);
            }
            natom[iNode] = status[statusNatom];
            natomAll3 += natom[iNode];
        }
        calcTime += (float)(clock() - timer) / CLOCKS_PER_SEC;
//test whether sum of atoms is still the same; is a good indicator of bugs 
        if (natomAll != natomAll3)
        {
            printf("\nERROR: total number of atoms %d not the same as initially %d\n", natomAll3, natomAll);
            fprintf(logfile,"\nERROR: total number of atoms %d not the same as initially %d\n", natomAll3, natomAll);
        }
        
//read atom data         
        for (iNode = 0; iNode < nNode; iNode++)
        {
            ReadAtomData(qtmp, vtmp, atomNrtmp, natom[iNode], 0, iNode, dest, sock, PacketNr);
            NodeNr(iNode, &ixNode, &iyNode, &izNode);
            for (i = 0; i < natom[iNode]; i++)
            {
                atomNrExt[atomNrtmp[i]-1] = atomNrtmp[i];
                qext[atomNrtmp[i]-1][0] = qtmp[i][0] + ixNode;
                qext[atomNrtmp[i]-1][1] = qtmp[i][1] + iyNode;
                qext[atomNrtmp[i]-1][2] = qtmp[i][2] + izNode;
                vext[atomNrtmp[i]-1][0] = vtmp[i][0];
                vext[atomNrtmp[i]-1][1] = vtmp[i][1];
                vext[atomNrtmp[i]-1][2] = vtmp[i][2];
            }
        }

        if ((iStep > nStep2) || (nconnect > natomAll / 5)) break;
    }

//MD loop finished; read status
    printf("\nRead status\n");
    fprintf(logfile,"\nRead status\n");
    for (iNode = 0; iNode < nNode; iNode++)
    {
        ReadStatus(status, iNode, 0, dest, sock, PacketNr);
        printf("Node %2d #Atoms:", iNode); for (j = 27; j < 54; j++) printf(" %3d", status[j]); printf("\n");
        fprintf(logfile,"Node %2d #Atoms:", iNode); for (j = 27; j < 54; j++) fprintf(logfile," %3d", status[j]); fprintf(logfile,"\n");
        ErrorStat[iNode][0] = status[statusRestartCnt - 0];
        ErrorStat[iNode][1] = status[statusRestartCnt - 1];
        ErrorStat[iNode][3] = status[statusRestartCnt - 3];
        ErrorStat[iNode][4] = status[statusRestartCnt - 4];
        ErrorStat[iNode][2] = status[statusRestartCnt - 2];
        ErrorStat[iNode][5] = status[statusRestartCnt - 5];
    }
 
//evaluate transmission errors
    printf("\nTransmission error statistics:\n");
    fprintf(logfile,"\nTransmission error statistics:\n");
    itmp = 0;
    for (iNode = 0; iNode < nNode; iNode++)
    {
        if (ErrorStat[iNode][0] != 0 || ErrorStat[iNode][1] != 0 || ErrorStat[iNode][2] != 0 || ErrorStat[iNode][3] != 0 || ErrorStat[iNode][4] != 0 || ErrorStat[iNode][5] != 0)
        {
            itmp = 1;
            printf("Node %3d: ECC corr: ETH3: %3d ETH4: %3d|  SEQ error: ETH3: %3d ETH4: %3d|  ERC error: ETH3: %3d ETH4: %3d\n", iNode, ErrorStat[iNode][2], ErrorStat[iNode][5], ErrorStat[iNode][1], ErrorStat[iNode][4], ErrorStat[iNode][0], ErrorStat[iNode][3]);
            fprintf(logfile,"Node %3d: ECC corr: ETH3: %3d ETH4: %3d|  SEQ error: ETH3: %3d ETH4: %3d|  ERC error: ETH3: %3d ETH4: %3d\n", iNode, ErrorStat[iNode][2], ErrorStat[iNode][5], ErrorStat[iNode][1], ErrorStat[iNode][4], ErrorStat[iNode][0], ErrorStat[iNode][3]);
        }
    }
    if (itmp == 0)
    {
        printf("None\n");
        fprintf(logfile,"None\n");
    }

//evaluate claculation time
    printf("\nCalculation time for %4d atoms: %5.1f s/ns\n",natomAll,calcTime/nStep1/(iStep-1)*1000000/dt);
    fprintf(logfile,"\nCalculation time for %4d atoms: %5.1f s/ns\n", natomAll, calcTime / nStep1 / (iStep - 1) * 1000000 / dt);
    closesocket(sock);
    WSACleanup();

#ifdef CalcRDF
    grfile = fopen("../../gr.dat", "w");
    for (i = 0; i < n_gr; i++)
    {
        rc = ((float)i + .5) / n_gr * rcut;
        vb = (float)((i + 1) * (i + 1) * (i + 1) - i * i * i) / n_gr / n_gr / n_gr;
        nid = (4. / 3.) * pi * vb /27;
        fprintf(grfile, "%7.5f  %7.5f\n", rc, 2.*(float)gr[i]/nid/natomAll/(natomAll-1)/(nStep2-nEq));
    }
    fclose(grfile);
#endif

    fclose(trajfile);
    fclose(enerfile);
    fclose(logfile);

//write final structure
    printf("\nDone; write %s\n", outfile);
    fprintf(logfile,"\nDone; write %s\n", outfile);
    sprintf(filename, "%s%s", path, outfile);
    trajfile = fopen(filename, "w");
    writetraj(atomNrExt, qext, vext, connect[0], (iStep-1)* nStep1* dt / 1000., Text, natomAll, trajfile);
    fclose(trajfile);

    return 0;
}

//***********************************************************************************************************************************************************************************
//*****************************************************************         MD Routines        **************************************************************************************
//***********************************************************************************************************************************************************************************

//read MD parameters from parameter file
void readParam(FILE* paramfile)
{
    char linebuff[200];
    char ctmp[200];
    int  eof,itmp,linecnt;

    eof = 0;
    linecnt = 0;

//default values
    nStep1 = 500;
    nStep2 = 10;
    dt = 2;
    rcut = 2;
    T_coupl = 0;
    T_target = 300;
    tauT = 9;
    gen_vel = 0;
    gen_seed = 0;
    strcpy(startfile, "start.xyz");
    strcpy(ener_file, "ener.dat");
    strcpy(traj_file, "traj.xyz");

    do {
        if(fgets(linebuff, 100, paramfile)==NULL) eof=1;
        if (eof == 0)
        {
            itmp = sscanf(linebuff, "%s", ctmp);
            linecnt++;
            if (ctmp[0] != ';'&&itmp!=EOF)
            {
                if (strcmp(ctmp, "dt") == 0)
                {
                    itmp = sscanf(linebuff, "%s%f", ctmp, &dt);
                    printf("%2d: dt:        %5.3f\n", linecnt, dt);
                    fprintf(logfile, "%2d: dt:        %5.3f\n", linecnt, dt);
                }
                if (strcmp(ctmp, "nStep1") == 0)
                {
                    itmp = sscanf(linebuff, "%s%d", ctmp, &nStep1);
                    printf("%2d: nStep1:    %5d\n", linecnt, nStep1);
                    fprintf(logfile, "%2d: nStep1:    %5d\n", linecnt, nStep1);
                }
                if (strcmp(ctmp, "nStep2") == 0)
                {
                    itmp = sscanf(linebuff, "%s%d", ctmp, &nStep2);
                    printf("%2d: nStep2:    %5d\n", linecnt, nStep2);
                    fprintf(logfile, "%2d: nStep2:    %5d\n", linecnt, nStep2);
                }
                if (strcmp(ctmp, "rcut") == 0)
                {
                    itmp = sscanf(linebuff, "%s%f", ctmp, &rcut);
                    printf("%2d: rcut:      %5.3f\n", linecnt, rcut);
                    fprintf(logfile, "%2d: rcut:      %5.3f\n", linecnt, rcut);
                }
                if (strcmp(ctmp, "Tcoupl") == 0)
                {
                    itmp = sscanf(linebuff, "%s%d", ctmp, &T_coupl);
                    printf("%2d: Tcoupl:    %5d\n", linecnt, T_coupl);
                    fprintf(logfile, "%2d: Tcoupl:    %5d\n", linecnt, T_coupl);
                }
                if (strcmp(ctmp, "Tref") == 0)
                {
                    itmp = sscanf(linebuff, "%s%f", ctmp, &T_target);
                    printf("%2d: Tref:      %5.1f\n", linecnt, T_target);
                    fprintf(logfile, "%2d: Tref:      %5.1f\n", linecnt, T_target);
                }
                if (strcmp(ctmp, "tauT") == 0)
                {
                    itmp = sscanf(linebuff, "%s%d", ctmp, &tauT);
                    printf("%2d: tauT:      %5d\n", linecnt, tauT);
                    fprintf(logfile, "%2d: tauT:      %5d\n", linecnt, tauT);
                }
                if (strcmp(ctmp, "gen_vel") == 0)
                {
                    itmp = sscanf(linebuff, "%s%d", ctmp, &gen_vel);
                    printf("%2d: gen_vel:   %5d\n", linecnt, gen_vel);
                    fprintf(logfile, "%2d: gen_vel:   %5d\n", linecnt, gen_vel);
                }
                if (strcmp(ctmp, "gen_seed") == 0)
                {
                    itmp = sscanf(linebuff, "%s%d", ctmp, &gen_seed);
                    printf("%2d: gen_seed:  %5d\n", linecnt, gen_seed);
                    fprintf(logfile, "%2d: gen_seed:  %5d\n", linecnt, gen_seed);
                }
                if (strcmp(ctmp, "startfile") == 0)
                {
                    itmp = sscanf(linebuff, "%s%s", ctmp, startfile);
                    printf("%2d: startfile:     %s\n", linecnt, startfile);
                    fprintf(logfile, "%2d: startfile:     %s\n", linecnt, startfile);
                }
                if (strcmp(ctmp, "enerfile") == 0)
                {
                    itmp = sscanf(linebuff, "%s%s", ctmp, ener_file);
                    printf("%2d: enerfile:      %s\n", linecnt, ener_file);
                    fprintf(logfile, "%2d: enerfile:      %s\n", linecnt, ener_file);
                }
                if (strcmp(ctmp, "trajfile") == 0)
                {
                    itmp = sscanf(linebuff, "%s%s", ctmp, traj_file);
                    printf("%2d: trajfile:      %s\n", linecnt, traj_file);
                    fprintf(logfile, "%2d: trajfile:      %s\n", linecnt, traj_file);
                }
                if (strcmp(ctmp, "outfile") == 0)
                {
                    itmp = sscanf(linebuff, "%s%s", ctmp, outfile);
                    printf("%2d: outfile:       %s\n", linecnt, outfile);
                    fprintf(logfile, "%2d: outfile:       %s\n", linecnt, outfile);
                }
            }
        }
    } while (eof==0);
    printf("\n"); fprintf(logfile,"\n");
}

/****************************************************************************************************************************************/
//calculate Lennard Jones force prefactor in internal units; will be written to FPGA, and is also needed when internal MD is run
float LennardJones(float r2)
{
    //r2 is in internal units
    float f, r6, r8, eLJ_ul, rLJ_ul;

    rLJ_ul = rLJ / rcut;
    eLJ_ul = eLJ * 1E6 * 1E-12 * dt * dt / rcut / rcut / mO; //eLJ is in  kJ/mol -> eLJ/mu=0.65*10^6 m^2/s^2 -> 0.65*10^-6 dt^2/rcut [in rcut/dt^2] 
    r6 = r2 * r2 * r2;
    r8 = r6 * r2;
    f = 0;

    if (r2 == 0) f = 0;
    else if (r2 < 1)    
    {
        f =  12. * eLJ_ul * rLJ_ul * rLJ_ul * rLJ_ul * rLJ_ul * rLJ_ul * rLJ_ul * (1. - rLJ_ul * rLJ_ul * rLJ_ul * rLJ_ul * rLJ_ul * rLJ_ul / r6) / r8;
    }
    else f = 0;

    return(f);
}
/*********************************************************************************/
//accumulate histogram for radial distribution function
void Radial(int* gr, float** q, int natom)
{
    int i1, i2, i, r_int;
    float dx, dy, dz, r;

    for (i1 = 1; i1 < natom; i1++)
    {
        for (i2 = 0; i2 < i1; i2++)
        {
            dx = q[i2][0] - q[i1][0];
            dx -= floor(dx / nxNode + 0.5) * nxNode;
            dy = q[i2][1] - q[i1][1];
            dy -= floor(dy / nyNode + 0.5) * nyNode;
            dz = q[i2][2] - q[i1][2];
            dz -= floor(dz / nzNode + 0.5) * nzNode;
            r = sqrt(dx * dx + dy * dy + dz * dz);
            r_int = floor(r * n_gr);
            if (r_int < n_gr) gr[r_int] += 1 ;
        }
    }
}
/*********************************************************************************/
//do a single MD step internally, for comparison with the results from the FPGA
void mdstep(float** q, float** v, int natom)
{
    int i1, i2, i;
    float dx, dy, dz, r2, fLJ, vcm[3] = { 0,0,0 };

    for (i1 = 0; i1 < natom; i1++)
    {
        for (i2 = 0; i2 < natom; i2++)
        {
            dx = q[i2][0] - q[i1][0];
            dx -= floor(dx / nxNode + 0.5) * nxNode;
            dy = q[i2][1] - q[i1][1];
            dy -= floor(dy / nyNode + 0.5) * nyNode;
            dz = q[i2][2] - q[i1][2];
            dz -= floor(dz / nzNode + 0.5) * nzNode;
            r2 = dx * dx + dy * dy + dz * dz;
            fLJ = LennardJones(r2);
            if (fabs(fLJ) > .999) { fLJ = sign(fLJ) * .999; }
            v[i1][0] += fLJ * dx;
            v[i1][1] += fLJ * dy;
            v[i1][2] += fLJ * dz;
        }
        q[i1][0] = q[i1][0] + v[i1][0];
        q[i1][1] = q[i1][1] + v[i1][1];
        q[i1][2] = q[i1][2] + v[i1][2];
        //periodic boundary 
        if (q[i1][0] < 0)    q[i1][0]   += nxNode;
        if (q[i1][0] > nxNode) q[i1][0] -= nxNode;
        if (q[i1][1] < 0)    q[i1][1]   += nyNode;
        if (q[i1][1] > nyNode) q[i1][1] -= nyNode;
        if (q[i1][2] < 0)    q[i1][2]   += nzNode;
        if (q[i1][2] > nzNode) q[i1][2] -= nzNode;
    }

//remove center-of-mass velocity

   for (i = 0, vcm[0] = 0, vcm[1] = 0, vcm[2] = 0; i < natom; i++) { vcm[0] += v[i][0]; vcm[1] += v[i][1]; vcm[2] += v[i][2]; }
   for (i = 0; i < natom; i++) { v[i][0] -= vcm[0] / natom; v[i][1] -= vcm[1] / natom; v[i][2] -= vcm[2] / natom; }

}

/*********************************************************************************/
//calculate temperature from velocities
float Temperature(float** v, int natom)
{
    int i;
    float T;

    for (i = 0, T = 0; i < natom; i++)
    {
        T += mO / (3 * NA * 1E3) * (v[i][0] * v[i][0] + v[i][1] * v[i][1] + v[i][2] * v[i][2]) * rcut * rcut / (dt * dt) * 1E12 / kB;
    }
    return(T / natom);
}


//********************************************************************************
//write xyz-file; currently "atom type" is "O" or "C", with "C" indicating an atom that is in an solod-like cluster
//positions are in A, velocities in A/ps
void writetraj(int *atomNr, float** q, float** v, int* connect, float t, float T, int natom, FILE* out)
{
    int i;

    fprintf(out, "%d\ntime: %9.3f  Temp: %6.1f\n", natom,t, T);
    for (i = 0; i < natom; i++)
    {
        if(connect[i] == 0)
          fprintf(out, "O %11.7f %11.7f %11.7f   %11.8f %11.8f %11.8f %4d\n", 10 * rcut * q[i][0], 10 * rcut * q[i][1], 10 * rcut * q[i][2], 10 * rcut/dt * v[i][0], 10 * rcut/dt * v[i][1], 10 * rcut/dt * v[i][2], atomNr[i]);
        else 
          fprintf(out, "C %11.7f %11.7f %11.7f   %11.8f %11.8f %11.8f %4d\n", 10 * rcut * q[i][0], 10 * rcut * q[i][1], 10 * rcut * q[i][2], 10 * rcut/dt * v[i][0], 10 * rcut/dt * v[i][1], 10 * rcut/dt * v[i][2], atomNr[i]);
    }
}


//********************************************************************************
//calculate Q6 order parameter, and from that determine clusters

#define Max_Neighbor 20
#define ConnectMin   11
int Q6(int **connect, int* hist_cluster, float** q, int natom)
{
    double r, costheta, phi, dx, dy, dz, q6, dtmp1=0,q6tot;
    int i, j, k, m, *nclose, **iclose,iconnect,nconnect,icluster=0,*acluster,i1,i2,i3,i4,itmp,ncluster;
    double **Y6m_re;
    double **Y6m_im;

 
    Y6m_re =   dmatrix(natom, 13);
    Y6m_im =   dmatrix(natom, 13);
    nclose =   ivector(natom); 
    iclose =   imatrix(natom, Max_Neighbor);
    acluster = ivector(natom);

//calculate q6 of all atoms 
    q6tot = 0;
    for (i = 0; i < natom; i++)
    {   
        q6 = 0;
        nclose[i] = 0;
        for (m = -6; m <= 6; m++) { Y6m_re[i][m + 6] = 0; Y6m_im[i][m + 6] = 0; }
        for (j = 0; j < natom;j++) if (j != i)
        {
            dx = q[j][0] - q[i][0];
            dx -= floor(dx / nxNode + 0.5) * nxNode;
            dy = q[j][1] - q[i][1];
            dy -= floor(dy / nyNode + 0.5) * nyNode;
            dz = q[j][2] - q[i][2];
            dz -= floor(dz / nzNode + 0.5) * nzNode;
            r = sqrt(dx * dx + dy * dy + dz * dz);
            if (r < rLJ / rcut * 1.25)                 //cut-off=1.4*sigma
            {
                iclose[i][nclose[i]] = j;
                nclose[i]++;
                costheta = dz/r;
                phi = atan2(dy, dx);
                for (int m = -6; m <= 6; m++)
                {
                    dtmp1 = legendre(m, costheta);
                    Y6m_re[i][m + 6] += dtmp1 * cos(m * phi);
                    Y6m_im[i][m + 6] += dtmp1 * sin(m * phi);
                }
            }
        }
        for (m = -6; m <= 6; m++)
        {
            q6 += (Y6m_re[i][m + 6] * Y6m_re[i][m + 6] + Y6m_im[i][m + 6] * Y6m_im[i][m + 6]);
        }
        q6 = sqrt(q6);
        q6tot += sqrt(4. * PI / 13.)*q6/nclose[i]/natom;

//normalize Y6m
        for (m = -6; m <= 6; m++) {Y6m_re[i][m + 6] /= q6; Y6m_im[i][m + 6] /= q6;}
        dtmp1 = 0; 
        for (m = -6; m <= 6; m++)
        {
            dtmp1 += (Y6m_re[i][m + 6] * Y6m_re[i][m + 6] + Y6m_im[i][m + 6] * Y6m_im[i][m + 6]);
        }
  //      printf("%d  %f\n", i,  dtmp1);
    }

//search for solid-like atoms
    nconnect = 0;
    for (i = 0; i < natom; i++)
    {
        iconnect = 0;
        connect[0][i] = 0;
        for (j = 0; j < nclose[i]; j++)
        {
            dtmp1 = 0;
            for (m = -6; m <= 6; m++) dtmp1 += (Y6m_re[i][m + 6] * Y6m_re[iclose[i][j]][m + 6] + Y6m_im[i][m + 6] * Y6m_im[iclose[i][j]][m + 6]) ;
            if (fabs(dtmp1) > 0.5) iconnect++;
//            printf("%d %d %f\n", i, j, dtmp1);
        }
        if (iconnect >= ConnectMin)
        {
            connect[0][i] = 1;
            nconnect++;
        }
    }

//    printf("Number of solid-like atoms: %d\n", nconnect);

//cluster analysis    
    nconnect = 0;
    for (i = 0; i < natom; i++) connect[1][i] = 0;
    icluster = 0;
    for (i = 0; i < natom; i++)  
    {
        if (connect[0][i] == 1 && connect[1][i] == 0)
        {   
            ncluster = 1;
            icluster++;
            i1 = 0; 
            i2 = 1;
            i3 = 1;
            acluster[0] = i;                //root atom of cluster
            connect[1][i] = icluster;
            do {
                for (j = i1; j < i2; j++)
                {
 //                   printf("i1 = %4d, i2 = %4d: %4d\n", i1, i2, j);
                    for (k = 0; k < nclose[acluster[j]]; k++)
                    {
                        if (connect[0][iclose[acluster[j]][k]] == 1&& connect[1][iclose[acluster[j]][k]] == 0)
                        {
                                ncluster++;
                                acluster[i3] = iclose[acluster[j]][k];
                                connect[1][iclose[acluster[j]][k]] = icluster;
                                i3++;
                        }
                    }
                }
                i1 = i2;
                i2 = i3;
            } while (i2>i1);
            nconnect += ncluster;
            if (ncluster < natom / 10) hist_cluster[ncluster]++;
 //               printf("cluster %3d contains %4d atoms\n", icluster, ncluster);
        }
    }

  //  printf("Number of solid-like atoms in cluster 1: %d\nStarting atom: %d\n", icluster, acluster[0]);

   free_dmatrix(Y6m_re,natom);
   free_dmatrix(Y6m_im,natom);
   free_ivector(nclose);
   free_imatrix(iclose,natom); 
   free_ivector(acluster);

   return(nconnect);

}

double legendre(int m, double costheta)
//associated legendre polynomial of degree 6 
{
    double costheta2 = costheta * costheta;
    double sintheta2 = 1 - costheta2;
    double sintheta  = sqrt(sintheta2);
    double sintheta3 = sintheta2 * sintheta;
    double out=0;
    double sign;

    if (m < 0)
    {
        m = -m;
        sign = 1;
    }
    else
    {
        sign = -1;
    }

    switch (m)
    {
    case 6:
        out = 1. / 64. * sqrt(3003. / PI) * sintheta3 * sintheta3;
    break;
    case 5:
        out = sign * 3. / 32. * sqrt(1001. / PI) * sintheta3 * sintheta2 * costheta;
    break;
    case 4:
        out = 3. / 32. * sqrt(91. / 2. / PI) * sintheta3 * sintheta * (-1. + 11. * costheta2);
    break;
    case 3:
        out = sign * 1. / 32. * sqrt(1365. / PI) * sintheta3 * costheta * (-3. + 11. * costheta2);
    break;
    case 2:
        out = 1. / 64. * sqrt(1365. / PI) * sintheta2 * (1. - 18. * costheta2 + 33. * costheta2 * costheta2);
    break;
    case 1:
        out = sign * 1. / 16. * sqrt(273. / 2. / PI) * sintheta * costheta * (5. - 30. * costheta2 + 33. * costheta2 * costheta2);
    break;
    case 0:
        out = 1. / 32. * sqrt(13. / PI) * (-5. + 105. * costheta2 - 315. * costheta2 * costheta2 + 231 * costheta2 * costheta2 * costheta2);
    break;
    default: out = 0;
    }

    return(out);
}



//***********************************************************************************************************************************************************************************
//******************************************************           Communication with Nodes        **********************************************************************************
//***********************************************************************************************************************************************************************************

//Read Staus and/or reset nodes
int ReadStatus(uint8_t *inbuff, int iNode, uint8_t Reset, sockaddr_in* dest, SOCKET sock, uint8_t* PacketNr)
{
    uint32_t itmp, j;
    uint8_t outbuff[100];
    FD_SET ReadSet;
    struct timeval TimeOut;
    int destSize = sizeof(*dest);
    TimeOut.tv_sec = 0;
    TimeOut.tv_usec = 200000;
    int err = 0;
    int ReadError = 0;
   
    if (Reset % 2 != 0) PacketNr[iNode] = 1;    //initialize 
    else              PacketNr[iNode]++;
    
    do
        {
        ReadError = 0;
        outbuff[0] = PacketNr[iNode];
        outbuff[1] = 0;
        outbuff[2] = Reset;         //reset MD (bit 2), nAtom (bit 1) and Errors (bit 0)
        sendto(sock, (char*)outbuff, 3, 0, (sockaddr*)&dest[iNode], sizeof(*dest));


        FD_ZERO(&ReadSet);
        FD_SET(sock, &ReadSet);
        if (select(NULL, &ReadSet, NULL, NULL, &TimeOut) < 1)
        {
            printf("\nWARNING in ReadStatus: Node %d not responding; repeat\n", iNode);
            fprintf(logfile,"\nWARNING in ReadStatus: Node %d not responding; repeat\n", iNode);
            ReadError = 1;
        }
        else
        {
            itmp = recvfrom(sock, (char*)inbuff, 100, 0, (sockaddr*)&dest[iNode], &destSize);
        }
    } while (ReadError==1);

    err = CheckError(inbuff, PacketNr[iNode], iNode);
    return(err);
}


/********************************************************************************************/
//Set thermostat
int SetThermostat(int T_onoff, float T_target1, int T_tau, int natom,  uint8_t* inbuff, int iNode, sockaddr_in* dest, SOCKET sock, uint8_t* PacketNr)
{
    uint32_t itmp, j;
    uint8_t outbuff[100];
    FD_SET ReadSet;
    struct timeval TimeOut;
    int destSize = sizeof(*dest);
    TimeOut.tv_sec = 0;
    TimeOut.tv_usec = 200000;
    int err = 0;
    int ReadError = 0;
    float Tconv,T_target2;

 
    Tconv = mO / (3 * NA * 1E3) * rcut * rcut / (dt * dt) * 1E12 / kB / 512;

    T_target2 = T_target1 / Tconv * natom / 16;
    if (T_target2 > 1 || T_target2 < 1. / 256)
    {
        printf("WARNING: Target temperature out of range: %f\n", T_target2);
        fprintf(logfile,"WARNING: Target temperature out of range: %f\n", T_target2);
    }

    T_target2 = 1 / T_target2 / 256;

    do
    {
        ReadError = 0;
        PacketNr[iNode]++;
        outbuff[0] = PacketNr[iNode];
        outbuff[1] = 3;
        outbuff[2] = T_onoff;         //bit 0: velocity center-of-mass shift, bit 1: velocity scaling
        float_int24_p1(T_target2, &outbuff[3]);
        outbuff[6] = T_tau;
        sendto(sock, (char*)outbuff, 7, 0, (sockaddr*)&dest[iNode], sizeof(*dest));

        FD_ZERO(&ReadSet);
        FD_SET(sock, &ReadSet);
        if (select(NULL, &ReadSet, NULL, NULL, &TimeOut) < 1)
        {
            printf("\nWARNING in SetThermostat: Node %d not responding; repeat\n", iNode);
            fprintf(logfile,"\nWARNING in SetThermostat: Node %d not responding; repeat\n", iNode);
            ReadError = 1;
        }
        else
        {
            itmp = recvfrom(sock, (char*)inbuff, 100, 0, (sockaddr*)&dest[iNode], &destSize);
        }
    } while (ReadError == 1);

    err = CheckError(inbuff, PacketNr[iNode], iNode);
    return(err);
}


/*********************************************************************************/
//write force LUT
void WriteForceLUT(int iNode, sockaddr_in* dest, SOCKET sock, uint8_t* PacketNr)
{
    float       f0, f1, f2, a0, a1, a2;
    int         i1, i2, i, itmp, f0s, f2s;
    FILE* LUTforce;
    uint8_t outbuff[1500];
    uint8_t inbuff[100];
    int destSize = sizeof(*dest);
    FD_SET ReadSet;
    struct timeval TimeOut;
    TimeOut.tv_sec = 0;
    TimeOut.tv_usec = 200000;
    int err;

  //     LUTforce = fopen("../../../LUTforce.dat", "w");
    for (i = 0, i1 = 0; i1 < 4; i1++)
    {
        PacketNr[iNode]++;
        outbuff[0] = PacketNr[iNode];
        outbuff[1] = 2;          //command
        outbuff[2] = i1;         //block
        outbuff[3] = 0;          //select; 0: Lennard Jones; 1: Coulomb
        for (i2 = 0; i2 < 128; i2++, i++)
        {
            f0 = v_shift * LennardJones((float)i / 512);
            f1 = v_shift * LennardJones(((float)i + .5) / 512);
            f2 = v_shift * LennardJones(((float)i + 1) / 512);
            if (fabs(f0) > .999) { f0 = sign(f0) * .999; }
            if (fabs(f1) > .999)  f1 = sign(f1) * .999;
            if (fabs(f2) > .999) { f2 = sign(f2) * .999;  }
            if (i == 0) { f1 = f0; f2 = f0; }
            if (i == 511) { f2 = 0; f1 = f0 / 2; }
            if (f0 < -.3)                       
            {
                //initially, linear interpolation only; otherwise, it explodes
                a0 = f0;
                a1 = f2 - f0;
                a2 = 0;
            }
            else
            {
 //quadratic interpolation
                a0 = f0;
                a1 = 4 * f1 - f2 - 3 * f0;
                a2 = 2 * (f2 + f0) - 4 * f1;
            }
            float_int24_pm1(a0, &outbuff[4 + i2 * 9 + 0]);
            float_int24_pm1(a1, &outbuff[4 + i2 * 9 + 3]);
            float_int24_pm1(a2, &outbuff[4 + i2 * 9 + 6]);
     //                 printf("%3d  %10.7f %10.7f %10.7f: %02X %02X %02X %02X %02X %02X %02X %02X %02X\n", i, a0, a1, a2, outbuff[4+i2*9+0], outbuff[4+i2*9+1], outbuff[4+i2*9+2], outbuff[4+i2*9+3], outbuff[4+i2*9+4], outbuff[4+i2*9+5], outbuff[4+i2*9+6], outbuff[4+i2*9+7], outbuff[4+i2*9+8]);
    //                 fprintf(LUTforce, "%02X %02X %02X %02X %02X %02X %02X %02X %02X\n", outbuff[4+i2*9+0], outbuff[4+i2*9+1], outbuff[4+i2*9+2], outbuff[4+i2*9+3], outbuff[4+i2*9+4], outbuff[4+i2*9+5], outbuff[4+i2*9+6], outbuff[4+i2*9+7], outbuff[4+i2*9+8]);
        }
        sendto(sock, (char*)outbuff, 4 + 128 * 9, 0, (sockaddr*) &dest[iNode], sizeof(*dest));

        FD_ZERO(&ReadSet);
        FD_SET(sock, &ReadSet);
        if (select(NULL, &ReadSet, NULL, NULL, &TimeOut) < 1)
        {
            printf("ERROR in WriteForceLUT: Node %d not responding\n", iNode);
            fprintf(logfile,"ERROR in WriteForceLUT: Node %d not responding\n", iNode);
            exit(1);
        }
        else
        {
            itmp = recvfrom(sock, (char*)inbuff, 100, 0, (sockaddr*) &dest[iNode], &destSize);
            err=CheckError(inbuff, PacketNr[iNode], iNode);
        }
    }
  //     fclose(LUTforce);
}


/*********************************************************************************/
//write atom data into node
int WriteAtomData(float** q, float** v, int *atomNr, uint8_t natom, int iNode, sockaddr_in* dest, SOCKET sock, uint8_t* PacketNr)
{
    uint32_t itmp, i, j,iBlock,nLine,iSent;
    uint8_t outbuff[4096];  
    uint8_t inbuff[100];
    int destSize = sizeof(*dest);
    FD_SET ReadSet;
    struct timeval TimeOut;
    TimeOut.tv_sec = 0;
    TimeOut.tv_usec = 200000;
    int err;

    iSent = 0;
    do
    {
        if (iSent + nBlock >= natom) nLine = natom-iSent; else nLine = nBlock;
   //     printf("iSent=%3d, nLine=%3d\n",iSent,nLine);

        PacketNr[iNode]++;
        outbuff[0] = PacketNr[iNode];
        outbuff[1] = 5;    //command
        outbuff[2] = nLine;
        for (i = 0; i < nLine; i++)
        {
            for (j = 0; j < 27; j++) outbuff[3 + i * 27 + j] = 0;
            float_int24_pm2(q[i + iSent][0], &outbuff[3 + i * 27 + 24]);
            float_int24_pm2(q[i + iSent][1], &outbuff[3 + i * 27 + 21]);
            float_int24_pm2(q[i + iSent][2], &outbuff[3 + i * 27 + 18]);
            outbuff[3 + i * 27 + 17] = atomNr[i + iSent] % 0x100;
            outbuff[3 + i * 27 + 16] = atomNr[i + iSent] / 0x100;
   //         outbuff[3 + i * 27 + 14] = 1;
            float_int24_pm1(v_shift * v[i + iSent][0], &outbuff[3 + i * 27 + 6]);
            float_int24_pm1(v_shift * v[i + iSent][1], &outbuff[3 + i * 27 + 3]);
            float_int24_pm1(v_shift * v[i + iSent][2], &outbuff[3 + i * 27 + 0]);
        }
        sendto(sock, (char*)outbuff, 3 + 27 * natom, 0, (sockaddr*) &dest[iNode], sizeof(*dest));

        FD_ZERO(&ReadSet);
        FD_SET(sock, &ReadSet);
        if (select(NULL, &ReadSet, NULL, NULL, &TimeOut) < 1)
        {
            printf("ERROR in WriteAtomData: Node %d not responding\n", iNode);
            fprintf(logfile,"ERROR in WriteAtomData: Node %d not responding\n", iNode);
            exit(1);
        }
        else
        {
            itmp = recvfrom(sock, (char*)inbuff, 100, 0, (sockaddr*) &dest[iNode], &destSize);
            err=CheckError(inbuff, PacketNr[iNode], iNode);
            //printf("Status:"); for (j = 0; j < 27; j++)  printf("  %02X", (uint8_t)inbuff[j]); printf("\n");
        }

        iSent += nLine;
    } while (iSent < natom);
    return(err);
}


/*********************************************************************************/
//read atom data from node

void ReadAtomData(float** q, float** v, int* atomNr, uint8_t natom, uint8_t BoxNr, int iNode, sockaddr_in* dest, SOCKET sock, uint8_t* PacketNr)
{
    uint32_t itmp, i, j, iBlock, nLine=0, nLine_old, iLine,bufOffset;
    uint8_t outbuff[100];   
    uint8_t inbuff[4096];
    uint8_t status[54];
    int destSize = sizeof(*dest);
    FD_SET ReadSet;
    struct timeval TimeOut;
    TimeOut.tv_sec = 0;
    TimeOut.tv_usec = 200000;
    int err;
    int ReadError = 0;
    do
    {
        PacketNr[iNode]++;
        outbuff[0] = PacketNr[iNode];
        outbuff[1] = 8;    //command
        outbuff[2] = BoxNr;
        outbuff[3] = natom;
        sendto(sock, (char*)outbuff, 4, 0, (sockaddr*)&dest[iNode], sizeof(*dest));

        iBlock = 1;
        ReadError = 0;
        do   //chop into pieces of nBlock lines 
        {
            nLine_old = nLine;
            FD_ZERO(&ReadSet);
            FD_SET(sock, &ReadSet);
            if (select(NULL, &ReadSet, NULL, NULL, &TimeOut) < 1)
            {
                printf("\nWARNING in ReadAtomData: Node %d not responding; repeat\n", iNode);
                fprintf(logfile,"\nWARNING in ReadAtomData: Node %d not responding; repeat\n", iNode);
                ReadError = 1;
            }
            else
            {
                nLine = recvfrom(sock, (char*)inbuff, 4096, 0, (sockaddr*)&dest[iNode], &destSize) / 27;
                if (iBlock == 1) for (i = 0; i < 54; i++) status[i] = inbuff[i]; //err=CheckError(inbuff, PacketNr[iNode], iNode);
                if (iBlock == 1)
                {
                    //          printf("Status:"); for (j = 0; j < 27; j++)  printf("  %02X", inbuff[j]); printf("\n");
                    //          printf("#Atoms:"); for (j = 27; j < 54; j++) printf(" %3d", (uint8_t)inbuff[j]); printf("\n");
                    nLine -= 2;
                    iLine = 0;
                    bufOffset = 2;
                }
                else
                {
                    iLine += nLine_old;
                    bufOffset = 0;
                }
                //printf("iBlock=%2d, nLine=%3d, iLine=%3d\n", iBlock, nLine,iLine);
                for (i = bufOffset; i < nLine + bufOffset; i++)
                {
                    q[iLine + i - bufOffset][0] = int24_float_pm2(&inbuff[i * 27 + 24]);
                    q[iLine + i - bufOffset][1] = int24_float_pm2(&inbuff[i * 27 + 21]);
                    q[iLine + i - bufOffset][2] = int24_float_pm2(&inbuff[i * 27 + 18]);
                    atomNr[iLine + i - bufOffset] = inbuff[i * 27 + 17] + 0x100 * inbuff[i * 27 + 16];
                    v[iLine + i - bufOffset][0] = int24_float_pm1(&inbuff[i * 27 + 6]) / v_shift;
                    v[iLine + i - bufOffset][1] = int24_float_pm1(&inbuff[i * 27 + 3]) / v_shift;
                    v[iLine + i - bufOffset][2] = int24_float_pm1(&inbuff[i * 27 + 0]) / v_shift;
                }
            }
            iBlock++;
        } while ((iLine + nLine < natom)&&ReadError==0);
    } while (ReadError == 1);

    CheckError(status, PacketNr[iNode], iNode);
}


/*********************************************************************************/
//initiate MD run
void StartMD(uint16_t nStepMD,int iNode, sockaddr_in* dest, SOCKET sock, uint8_t* PacketNr)
{
    uint32_t itmp, j;
    uint8_t outbuff[100], inbuff[100];
    FD_SET ReadSet;
    struct timeval TimeOut;
    int destSize = sizeof(*dest);
    TimeOut.tv_sec = 0;
    TimeOut.tv_usec = 200000;
    int err;
    int ReadError = 0;

    do {
        ReadError = 0;
        PacketNr[iNode]++;
        outbuff[0] = PacketNr[iNode];
        outbuff[1] = 1;
        outbuff[2] = nStepMD / 0x100;
        outbuff[3] = nStepMD % 0x100;
        sendto(sock, (char*)outbuff, 4, 0, (sockaddr*)&dest[iNode], sizeof(*dest));

        FD_ZERO(&ReadSet);
        FD_SET(sock, &ReadSet);
        if (select(NULL, &ReadSet, NULL, NULL, &TimeOut) < 1)
        {
            printf("\nWARNING in StartMD: Node %d not responding. ", iNode);
            fprintf(logfile,"\nWARNING in StartMD: Node %d not responding. ", iNode);
//test whether is running already            
            ReadStatus(inbuff, iNode, 0, dest, sock, PacketNr);
            if (inbuff[statusBussy] % 2 != 1)
            {
                printf("Node %d not running yet, hence repeat.\n", iNode);
                fprintf(logfile,"Node %d not running yet, hence repeat.\n", iNode);
                ReadError = 1;
            }
            else printf("\n");
        }
        else
        {
            itmp = recvfrom(sock, (char*)inbuff, 100, 0, (sockaddr*)&dest[iNode], &destSize);
        }
    } while (ReadError==1);
    err = CheckError(inbuff, PacketNr[iNode], iNode);
}



//***********************************************************************************************************************************************************************************
//******************************************************         Utilities      *****************************************************************************************************
//***********************************************************************************************************************************************************************************

int CheckError(uint8_t* inbuff, uint8_t PacketNr, int iNode)
{
    uint8_t error;
 //   static uint8_t restart[nxNode * nyNode * nzNode][10] = {0,0,0,0,0,0,0,0};
    int stop,j,err;
    
    stop = 0;
    err = 0;

    if (PacketNr != inbuff[statusPcktCnt] || (uint8_t)(PacketNr - 1) != inbuff[statusPcktCnt - 1])
    {
        printf("\nPACKET ERROR in node %3d: PacketNr %3d, received %3d, previously received: %d\n", iNode, PacketNr, inbuff[statusPcktCnt], inbuff[statusPcktCnt - 1]);
        fprintf(logfile,"\nPACKET ERROR in node %3d: PacketNr %3d, received %3d, previously received: %d\n", iNode, PacketNr, inbuff[statusPcktCnt], inbuff[statusPcktCnt - 1]);
    }

   
        error = (uint8_t)inbuff[statusErr];
        if (error % 2 == 1) 
        { 
            printf("\nERROR in node %3d: Fan not running\n", iNode); 
            fprintf(logfile,"\nERROR in node %3d: Fan not running\n", iNode);
            stop = 1; 
        }
        error /= 2;
        if (error % 2 == 1) 
        { 
            printf("\nERROR in node %3d: ETH3 not connected\n", iNode); 
            fprintf(logfile,"\nERROR in node %3d: ETH3 not connected\n", iNode);
            stop = 1; 
        }
        error /= 2;
        if (error % 2 == 1) 
        { 
            printf("\nERROR in node %3d: ETH3, speed <1Gb/s\n", iNode); 
            fprintf(logfile,"\nERROR in node %3d: ETH3, speed <1Gb/s\n", iNode);
            stop = 1; 
        }
        error /= 2;
        if (error % 2 == 1) 
        { 
            printf("\nERROR in node %3d: ETH4 not connected\n", iNode); 
            fprintf(logfile,"\nERROR in node %3d: ETH4 not connected\n", iNode);
            stop = 1; 
        }
        error /= 2;
        if (error % 2 == 1) 
        { 
            printf("\nERROR in node %3d: ETH4, speed <1Gb/s\n", iNode); 
            fprintf(logfile,"\nERROR in node %3d: ETH4, speed <1Gb/s\n", iNode);
            stop = 1; 
        }
 //bit5-7 reserved
        error = (uint8_t)inbuff[statusErr - 1];
        if (error % 2 == 1) 
        { 
            printf("\nERROR in node %3d: ETH3, tx FIFO overflow\n", iNode); 
            fprintf(logfile,"\nERROR in node %3d: ETH3, tx FIFO overflow\n", iNode);
            stop = 1; 
        }
        error /= 2;
        if (error % 2 == 1) { err = 1; }     //ETH3, rx crc error 
        error /= 2;
        if (error % 2 == 1) { err = 1; }       //ETH3, seq error
        error /= 2;
// ecc error (which is no error, can be reserve bit)
        error /= 2;
        if (error % 2 == 1) 
        { 
            printf("\nERROR in node %3d: ETH4, tx FIFO overflow\n", iNode); 
            fprintf(logfile,"\nERROR in node %3d: ETH4, tx FIFO overflow\n", iNode);
            stop = 1; 
        }
        error /= 2;
        if (error % 2 == 1) { err = 1; }     //ETH4, rx ecc error 
        error /= 2;
        if (error % 2 == 1) { err = 1; }       //ETH4,seq error 
        error /= 2;
 // ecc error (which is no error, can be reserve bit)
        error = (uint8_t)inbuff[statusErr - 2];
        if (error % 2 == 1) 
        { 
            printf("\nERROR in node %3d: gtp0, tx FIFO overflow\n", iNode); 
            fprintf(logfile, "\nERROR in node %3d: gtp0, tx FIFO overflow\n", iNode);
            stop = 1; 
        }
        error /= 2;
        if (error % 2 == 1) 
        { 
            printf("\nERROR in node %3d: gtp1, tx FIFO overflow\n", iNode); 
            fprintf(logfile, "\nERROR in node %3d: gtp1, tx FIFO overflow\n", iNode);
            stop = 1; 
        }
        error /= 2;
        if (error % 2 == 1) 
        { 
            printf("\nERROR in node %3d: gtp2, tx FIFO overflow\n", iNode);
            fprintf(logfile, "\nERROR in node %3d: gtp2, tx FIFO overflow\n", iNode);
            stop = 1; 
        }
        error /= 2;
        if (error % 2 == 1) 
        { 
            printf("\nERROR in node %3d: gtp3, tx FIFO overflow\n", iNode); 
            fprintf(logfile, "\nERROR in node %3d: gtp3, tx FIFO overflow\n", iNode);
            stop = 1; 
        }
        error /= 2;
        if (error % 2 == 1) 
        { 
            printf("\nERROR in node %3d: gtp0, tx MUX overflow\n", iNode); 
            fprintf(logfile, "\nERROR in node %3d: gtp0, tx MUX overflow\n", iNode);
            stop = 1; 
        }
        error /= 2;
        if (error % 2 == 1) 
        { 
            printf("\nERROR in node %3d: gtp1, tx MUX overflow\n", iNode);
            fprintf(logfile, "\nERROR in node %3d: gtp1, tx MUX overflow\n", iNode);
            stop = 1; 
        }
        error /= 2;
        if (error % 2 == 1) 
        { 
            printf("\nERROR in node %3d: gtp2, tx MUX overflow\n", iNode); 
            fprintf(logfile, "\nERROR in node %3d: gtp2, tx MUX overflow\n", iNode);
            stop = 1; 
        }
        error /= 2;
        if (error % 2 == 1) 
        { 
            printf("\nERROR in node %3d: gtp3, tx MUX overflow\n", iNode); 
            fprintf(logfile,"\nERROR in node %3d: gtp3, tx MUX overflow\n", iNode);
            stop = 1; 
        }
        error = (uint8_t)inbuff[statusErr - 3]; 
        if (error % 2 == 1) {  err = 1; }   //gtp0, rx error(crc or sequence_cnt)
        error /= 2;
        if (error % 2 == 1) {  err = 1; }   //gtp1, rx error(crc or sequence_cnt)
        error /= 2;
        if (error % 2 == 1) {  err = 1; }   //gtp2, rx error(crc or sequence_cnt)
        error /= 2;
        if (error % 2 == 1) {  err = 1; }   //gtp3, rx error(crc or sequence_cnt)
        error /= 2;
        if (error % 2 == 1) 
        { 
            printf("\nERROR in node %3d: MUX overflow in Broadcast.v\n", iNode);
            fprintf(logfile,"\nERROR in node %3d: MUX overflow in Broadcast.v\n", iNode);
            stop = 1; 
        }
        error /= 2;
        if (error % 2 == 1) 
        { 
            printf("\nERROR in node %3d: homebox overflow >252 atoms\n", iNode);
            fprintf(logfile, "\nERROR in node %3d: homebox overflow >252 atoms\n", iNode);
            stop = 1; 
        }
        error /= 2;
        if (error % 2 == 1) 
        { 
            printf("\nERROR in node %3d: neighboring box overflow >252 atoms\n", iNode); 
            fprintf(logfile, "\nERROR in node %3d: neighboring box overflow >252 atoms\n", iNode);
            stop = 1; 
        }
        error /= 2;
        if (error % 2 == 1) 
        { 
            printf("\nERROR in node %3d: subbox overflow >15 atoms\n", iNode); 
            fprintf(logfile, "\nERROR in node %3d: subbox overflow >15 atoms\n", iNode);
            stop = 1; 
        }
 

    if (stop == 1)  //fatal error; stop
    {
        printf("Status:"); for (j = 0; j < 27; j++)  printf("  %02X", inbuff[j]); printf("\n");
        printf("#Atoms:"); for (j = 27; j < 54; j++) printf(" %3d", inbuff[j]); printf("\n");
        printf("Exit\n");
        fprintf(logfile,"Status:"); for (j = 0; j < 27; j++)  fprintf(logfile,"  %02X", inbuff[j]); fprintf(logfile,"\n");
        fprintf(logfile,"#Atoms:"); for (j = 27; j < 54; j++) fprintf(logfile," %3d", inbuff[j]); fprintf(logfile,"\n");
        fprintf(logfile,"Exit\n");
        exit(1);
    }



    return(err);
}





//***********************************************************************************
void  NodeNr(int iNode, int* ixNode, int* iyNode, int* izNode)
//converts iNode, which is number [0..nxNode*nyNode*nzNode-1], into (xyz) position of node
{
    int itmp= iNode;
   
    *ixNode = itmp % nxNode;
    itmp /= nxNode;
    *iyNode = itmp % nyNode;
    itmp /= nyNode;
    *izNode = itmp;
}




//****************************************fixed-point/float conversions*************************************************
void float_int24_pm2(float x, uint8_t* intbuff)
{
//float with range +/-2 to signed 24 bit int
    int32_t  qint;
    uint32_t* qint2;

    qint = x * 4194304+sign(x) * .5;  //2^22; the .5 is for round-off
    qint2 = (uint32_t*)&qint;  //transfered from signed to unsigend without changing bits

    intbuff[2] = (uint8_t)(*qint2 % 0x100);
    *qint2 /= 0x100;
    intbuff[1] = (uint8_t)(*qint2 % 0x100);
    *qint2 /= 0x100;
    intbuff[0] = (uint8_t)(*qint2 % 0x100);
}

void float_int24_pm1(float x, uint8_t* intbuff)
{
//float with range +/-1 to signed 24 bit int
    int32_t  qint;
    uint32_t* qint2;

    qint = x * 8388608 + sign(x) * .5;  //2^23
    qint2 = (uint32_t*)&qint;  //transfered from signed to unsigend without changing bits

    intbuff[2] = (uint8_t)(*qint2 % 0x100);
    *qint2 /= 0x100;
    intbuff[1] = (uint8_t)(*qint2 % 0x100);
    *qint2 /= 0x100;
    intbuff[0] = (uint8_t)(*qint2 % 0x100);
}

void float_int24_p1(float x, uint8_t* intbuff)
{
//float with range +/-1 to signed 24 bit int
    int32_t  qint;
    
    qint = x * 16777216 + .5;  //2^24
    
    intbuff[2] = (uint8_t)(qint % 0x100);
    qint /= 0x100;
    intbuff[1] = (uint8_t)(qint % 0x100);
    qint /= 0x100;
    intbuff[0] = (uint8_t)(qint % 0x100);
}

float int24_float_pm2(uint8_t* readbuff)
{
//signed 24 bit int to float with range +/-2
    uint8_t readbuff2[4];
    int32_t* qint;

    readbuff2[0] = readbuff[2];
    readbuff2[1] = readbuff[1];
    readbuff2[2] = readbuff[0];
    if (readbuff[0] > 127) readbuff2[3] = 0xff; else readbuff2[3] = 0x00; //make it 4 bytes and extend sign
    qint = (int32_t*)&readbuff2[0];
    return ((float)(*qint)) / 4194304;   //2^22
}

float int24_float_pm1(uint8_t* readbuff)
{
//signed 24 bit int to float with range +/-1
    uint8_t readbuff2[4];
    int32_t* qint;

    readbuff2[0] = readbuff[2];
    readbuff2[1] = readbuff[1];
    readbuff2[2] = readbuff[0];
    if (readbuff[0] > 127) readbuff2[3] = 0xff; else readbuff2[3] = 0x00; //make it 4 bytes and extend sign
    qint = (int32_t*)&readbuff2[0];
    return ((float)(*qint)) / 8388608;   //2^23
}

float int24_float_p1(uint8_t* readbuff)
{
//unsigned 24 bit int to float with range +1
    uint8_t readbuff2[4];
    int32_t* qint;

    readbuff2[0] = readbuff[2];
    readbuff2[1] = readbuff[1];
    readbuff2[2] = readbuff[0];
    readbuff2[3] = 0x00; //make it 4 bytes 
    qint = (int32_t*)&readbuff2[0];
    return ((float)(*qint)) / 16777216;   //2^24
}

/*********************************************************************************/
float sign(float in)
{
    float out;
    if (in == 0) out = 0;
    else if (in > 0) out = 1; else out = -1;
    return(out);
}
/*********************************************************************************/
//random generator producing Gaussian distributed values; from Numerical Recipes 
float gasdev(long* idum)
{
    float ran1(long* idum);
    static int iset = 0;
    static float gset;
    float fac, rsq, v1, v2;

    if (iset == 0) {
        do {
            v1 = 2.0 * ran1(idum) - 1.0;
            v2 = 2.0 * ran1(idum) - 1.0;
            rsq = v1 * v1 + v2 * v2;
        } while (rsq >= 1.0 || rsq == 0.0);
        fac = sqrt(-2.0 * log(rsq) / rsq);
        gset = v1 * fac;
        iset = 1;
        return v2 * fac;
    }
    else {
        iset = 0;
        return gset;
    }
}

#define IA 16807
#define IM 2147483647
#define AM (1.0/IM)
#define IQ 127773
#define IR 2836
#define NTAB 32
#define NDIV (1+(IM-1)/NTAB)
#define EPS 1.2e-7
#define RNMX (1.0-EPS)

//random generator with numbers [0...1]
float ran1(long* idum)
{
    int j;
    long k;
    static long iy = 0;
    static long iv[NTAB];
    float temp;

    if (*idum <= 0 || !iy) {
        if (-(*idum) < 1) *idum = 1;
        else *idum = -(*idum);
        for (j = NTAB + 7; j >= 0; j--) {
            k = (*idum) / IQ;
            *idum = IA * (*idum - k * IQ) - IR * k;
            if (*idum < 0) *idum += IM;
            if (j < NTAB) iv[j] = *idum;
        }
        iy = iv[0];
    }
    k = (*idum) / IQ;
    *idum = IA * (*idum - k * IQ) - IR * k;
    if (*idum < 0) *idum += IM;
    j = iy / NDIV;
    iy = iv[j];
    iv[j] = *idum;
    if ((temp = AM * iy) > RNMX) return RNMX;
    else return temp;
}
#undef IA
#undef IM
#undef AM
#undef IQ
#undef IR
#undef NTAB
#undef NDIV
#undef EPS
#undef RNMX
/* (C) Copr. 1986-92 Numerical Recipes Software ,2:. */

/*********************************************************************************/
//memory allocation for vectors an matrices; reduced version in comparison to Numerical Recipes; all indices start from 0.
int* ivector(long long nrow)
{
    int* m;

    m = (int*)malloc(nrow * sizeof(int));
    
    return (m);
}



float** matrix(long long nrow, long long ncol)
{
    long long i;
    float** m;

    m = (float**) malloc(nrow * sizeof(float*));
    for (i = 0; i < nrow; i++) m[i] = (float*) malloc(ncol * sizeof(float));

    return (m);
}

double** dmatrix(long long nrow, long long ncol)
{
    long long i;
    double** m;

    m = (double**)malloc(nrow * sizeof(double*));
    for (i = 0; i < nrow; i++) m[i] = (double*)malloc(ncol * sizeof(double));

    return (m);
}


int** imatrix(long long nrow, long long ncol)
{
    long long i;
    int** m;

    m = (int**)malloc(nrow * sizeof(int*));
    for (i = 0; i < nrow; i++) m[i] = (int*)malloc(ncol * sizeof(int));

    return (m);
}

float*** f3tensor(long long nrow, long long ncol, long long ndep)
{
    long long i, j;
    float*** t;

    /* allocate pointers to pointers to rows */
    t = (float***)malloc(nrow * sizeof(float**));
    
    /* allocate pointers to rows and set pointers to them */
    for (i = 0; i < nrow; i++) t[i] = (float**)malloc(ncol * sizeof(float*));
    
    /* allocate rows and set pointers to them */
    for (i = 0; i < nrow; i++) for (j = 0; j < ncol; j++) t[i][j] = (float*)malloc(ndep * sizeof(float));

    /* return pointer to array of pointers to rows */
    return t;
}


void free_ivector(int* v)
/* free a double vector allocated with ivector() */
{
    free(v);
}

void free_dmatrix(double** m, int nrow)
/* free a double matrix allocated by matrix() */
{
    int i;
    for (i = 0; i < nrow; i++) free(m[i]);
    free(m);
}

void free_imatrix(int** m,int nrow)
/* free a double matrix allocated by matrix() */
{
    int i;
    for (i = 0; i < nrow; i++) free(m[i]);
    free(m);
}