// UDP communication from https://stackoverflow.com/questions/679145/how-to-set-up-a-winsock-udp-socket

#include "../SharedLibrary/MDcontrol.h"


FILE *logfile;


int main() 
{
//IP stuff
    const char* srcIP = "192.168.1.131";  //IP adress of the ETH interface connectic to FPGAs; needs to be a static IP
    char        destIP[16];
    sockaddr_in dest[nxNode * nxNode * nxNode];
    sockaddr_in local;
    SOCKET      sock;
    WSAData     wsaddata;
    int         destSize = sizeof(dest[0]);

 //remaining stuff
    char        filename[100];
    uint8_t     status[100];                      //for maximum 3 status lines of 27 bytes each
    int         iNode,ixNode,iyNode,izNode,itmp;
    int         nNode;
    uint8_t     PacketNr[nxNode * nxNode * nxNode];
    uint8_t     version[nxNode * nxNode * nxNode];
    uint32_t    i, j, itmp2;
    float       **qext, **vext,  v_sd;
    int         *atomNrtmp;
    int         natomAll,natomAll2, natomAll3, nAtomProtein;
    uint8_t     natom[nxNode * nxNode * nxNode];
    uint16_t    iStep=0;
    long        idum = -1;
    FILE        *trajfile,*enerfile,*atomfile, *paramfile,*topolfile;
    uint8_t     outbuff[9];
    float       Tint=0,Text,vcm[3],T_FPGA,Tconv;
    int         err, errETH;
    int         **ErrorStat;
    clock_t     timer;
    float       calcTime = 0;
    char        tmpbuff[100];
   // atomType_t  listAtomType[maxAtomType];
    char        atomName[10],ctmp[20];
    int         **gr, nAtomType, *atomType, *atomNrExt2FPGA, *atomNrFPGA2Ext;
    float       mtot;
    float       dx01, dy01, dz01, r01;
    float       dx02, dy02, dz02, r02;
    float       dx23, dy23, dz23, r23;
    float       phi12;
    float       vcm0[3], mtot0;
    float       tmp;
    int         nIterTot, nShakeTot, ForceFieldCnt;
    param_t     simParam;
  

//open files and read parameter file  
    sprintf(filename, "%sMDRun.log", path);
    logfile = fopen(filename, "w");

    meta_t* meta = (meta_t*)malloc((maxAtomAll + 1) * sizeof * meta);
    atomNrFPGA2Ext = ivector(maxAtomAll + 1); for (i = 0;i <= maxAtomAll + 1;i++) atomNrFPGA2Ext[i] = 0;


 //read simulation parameters
    simParam = readParam();

 //read meta-data
    readMetaFile(meta, atomNrFPGA2Ext,&natomAll,&nAtomProtein);
    //for (i = 1;i <= 5000; i++)  printf("%5d %5d\n", i, atomNrFPGA2Ext[i]);

    sprintf(filename, "%s%s", path, simParam.trajfile);
    trajfile = fopen(filename, "w");

    sprintf(filename, "%s%s", path, simParam.enerfile);
    enerfile = fopen(filename, "w");

 //allocate memory  
    qext = matrix(natomAll+1, 3);
    vext = matrix(natomAll+1, 3);
 
//read atom data
    readGroFile(qext, vext, meta, &simParam, natomAll);

//remove center of mass motion
    for (i = 1, vcm[0] = 0, vcm[1] = 0, vcm[2] = 0, mtot = 0; i <= natomAll; i++)
    {
       vcm[0] += (float)meta[i].mass / m_ref * vext[i][0];
       vcm[1] += (float)meta[i].mass / m_ref * vext[i][1];
       vcm[2] += (float)meta[i].mass / m_ref * vext[i][2];
       mtot += (float)meta[i].mass / m_ref;
    }

   
    printf("total mass: %5.0f\n", mtot*m_ref);
    printf("Center of mass motion: %10.6f %10.6f %10.6f\n", vcm[0] / mtot, vcm[1] / mtot, vcm[2] / mtot);
    fprintf(logfile,"total mass: %5.0f\n", mtot * m_ref);
    fprintf(logfile,"Center of mass motion: %10.6f %10.6f %10.6f\n", vcm[0] / mtot, vcm[1] / mtot, vcm[2] / mtot);
    for (i = 1; i <= natomAll; i++) 
    { 
        vext[i][0] -= vcm[0] / mtot; 
        vext[i][1] -= vcm[1] / mtot; 
        vext[i][2] -= vcm[2] / mtot; 
    }
    Text = Temperature(vext, meta, simParam, natomAll);
    printf("Center of mass motion removed\nT=%5.1f\n", Text);
    fprintf(logfile,"Center of mass motion removed\nT=%5.1f\n", Text);
    writeGroFile(qext, vext, 0., Text, natomAll, meta, simParam, trajfile);

  //  exit(1);

//initialize UDP communication
    printf("\nInititialize nodes\n");
    fprintf(logfile, "\nInititialize nodes\n");
    if (WSAStartup(MAKEWORD(2, 2), &wsaddata) != 0) 
    { 
        printf("WSAStartup failed\n"); 
        fprintf(logfile,"WSAStartup failed\n");
        exit(1); 
    }
    local.sin_family = AF_INET;
    itmp = inet_pton(AF_INET, srcIP, &local.sin_addr.s_addr);
    local.sin_port = htons(8080);
    sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    bind(sock, (sockaddr*)&local, sizeof(local));


//initialize/open nodes
    nNode = nxNode * nxNode * nxNode;
    ErrorStat = imatrix(nNode, 6);
    for (iNode = 0; iNode < nNode; iNode++)
    {
        sprintf_s(destIP, "192.168.1.%d", 192 + iNode);    //IP adresses of FPGAs; start at 192.168.1.192 with node0, is set by dip switches
 //       printf("Initializing node %2d, IP: %s\n", iNode, destIP);
 //       fprintf(logfile,"Initializing node %2d, IP: %s\n", iNode, destIP);
        dest[iNode].sin_family = AF_INET;
        itmp = inet_pton(AF_INET, destIP, &dest[iNode].sin_addr.s_addr);
        dest[iNode].sin_port = htons(8080);
        ReadStatus(status, iNode, 7,dest,sock, PacketNr);   //test whether nodes respond, and if yes, report its status; reset nodes
        version[iNode] = status[statusVersion];
        if (version[iNode] != version[0])
        {
            printf("Warning: FPGA version of node %d (%d) is different from that of node 0 (%d).\n", iNode, version[iNode], version[0]);
            fprintf(logfile,"Warning: FPGA version of node %d (%d) is different from that of node 0 (%d).\n", iNode, version[iNode], version[0]);
        }
        ForceFieldCnt = 0x100 * status[status_ForceFieldCnt] + status[status_ForceFieldCnt + 1];  
        if (ForceFieldCnt != nAtomProtein + 1)                                                         //ForceFieldCnt should be  natomAll, since empty dataset is also written for atomNr=0
        {
            printf("ERROR in node %d: Number of force field data written to FPGA %d differs from number of protein atoms %d\n", iNode, ForceFieldCnt-1, nAtomProtein);
            fprintf(logfile,"ERROR in node %d: Number of force field data written to FPGA %d differs from number of protein atoms %d\n", iNode, ForceFieldCnt - 1, nAtomProtein);
            exit(1);
        }
    }
    printf("FPGA version %d\n",version[0]);
    fprintf(logfile,"FPGA version %d\n", version[0]);

 

//set thermostat
    Tconv = m_ref / (3 * NA * 1E3) * simParam.rcut * simParam.rcut / (simParam.dt * simParam.dt) * 1E12 / kB / 128;                            //convert tmeperature into internal coordinates
    printf("\nSet Thermostat: Tcoupl=%1d Tref=%5.1fK tau= %4.0f fs\n", simParam.Tcoupl, simParam.Tref, simParam.dt * pow(2, (simParam.tauT - 1)));
    fprintf(logfile, "\nSet Thermostat\n");
    for (iNode = 0; iNode < nNode; iNode++)
    {
        SetThermostat(simParam, mtot, natomAll, iNode, dest, sock, PacketNr);  //center of mass removal always on, but thermostat can be switched on/off
    }



//send atom data to FPGAs      
    printf("\nSend atom data\n");
    fprintf(logfile,"\nSend atom data\n");
    do {
        err = 0;
        itmp = WriteAtomData(qext, vext, meta, natomAll, dest, sock, PacketNr);
        if (itmp != 0) 
        {
            err = itmp;
            printf("Transmission error during WriteAtomData; redo\n");
            fprintf(logfile,"Transmission error during WriteAtomData; redo\n");
        }
    } while (err != 0);

    
//read status of FPGAs as a check
    printf("\nRead status\n");
    fprintf(logfile,"\nRead status\n");
    for (iNode = 0; iNode < nNode; iNode++)
    {
        ReadStatus(status, iNode, 0, dest, sock, PacketNr);
        printf("Node %2d #Atoms:", iNode); for (j = 27; j < 54; j++) printf(" %3d", status[j]); printf("\n");
        fprintf(logfile,"Node %2d #Atoms:", iNode); for (j = 27; j < 54; j++) fprintf(logfile," %3d", status[j]); fprintf(logfile,"\n");
    }



 //main MD loop
    printf("\nRun MD\n");
    fprintf(logfile,"\nRun MD\n");
    nIterTot = 0;
    nShakeTot = 0;
    for (iStep = 1; iStep <= simParam.nStep2+1; iStep++)
    {
        if (iStep <= simParam.nStep2) for (iNode = 0; iNode < nNode; iNode++)
        {
            StartMD(simParam.nStep1, iNode, dest, sock, PacketNr);
        }
        timer = clock();

//do all analysis from the previous step while MD is running
        if (iStep > 1)                  
        {

            Text = Temperature(vext, meta, simParam, natomAll);
            printf("Time step %4d at %10.3f ps: T=%7.2f \n", iStep - 1, (iStep - 1) * simParam.nStep1 * simParam.dt / 1000, Tconv * T_FPGA / natomAll);
            fprintf(logfile,"Time step %4d at %10.3f ps: T=%7.2f\n", iStep - 1, (iStep - 1) * simParam.nStep1 * simParam.dt / 1000, Tconv * T_FPGA / natomAll);
            fflush(logfile);
            for (i = 1, vcm[0] = 0, vcm[1] = 0, vcm[2] = 0, mtot = 0; i <= natomAll; i++)
            {
                vcm[0] += (float)meta[i].mass / m_ref * vext[i][0];
                vcm[1] += (float)meta[i].mass / m_ref * vext[i][1];
                vcm[2] += (float)meta[i].mass / m_ref * vext[i][2];
                mtot += (float)meta[i].mass / m_ref;
            }
   
            fprintf(enerfile, "%9.3f %6.2f %6.2f %12.9f %12.9f %12.9f\n", (iStep-1) * simParam.nStep1 * simParam.dt / 1000., Text, Tconv * T_FPGA / natomAll, vcm[0]/mtot* simParam.rcut/ simParam.dt,
                                                                                                                 vcm[1] / mtot * simParam.rcut / simParam.dt, vcm[2]/mtot * simParam.rcut / simParam.dt);
            fflush(enerfile);
            writeGroFile(qext, vext, (iStep-1) * simParam.nStep1 * simParam.dt / 1000., Tconv * T_FPGA / natomAll,  natomAll, meta, simParam, trajfile);
            fflush(trajfile);
        }
                
//wait until MD is done on all nodes
        natomAll3 = 0;
        T_FPGA = 0;
        for (iNode = 0; iNode < nNode; iNode++)
        {
            errETH = 0;
            do
            {
                ReadStatus(status, iNode, 0, dest, sock, PacketNr);
            } while (status[statusBusy] % 2 == 1);
            if (iStep <= simParam.nStep2)
            {
                nIterTot += 0x100 * status[status_nIterTot + 0] + status[status_nIterTot + 1];
                nShakeTot += status[status_nShakeTot];
            }

            T_FPGA+=int24_float_p1(&status[statusT]);

//test whether sum of atoms in neigboring boxes stays constant; is a good indicator of bugs 
            natomAll2 = 0;
            for(j=0;j<27;j++) natomAll2 += status[53 - j];
            if (natomAll2 != natomAll)
            {
                printf("\nERROR:Number of atoms in neighboring boxes not correct in node %2d: %4d %4d ", iNode, natomAll2, natomAll);
                fprintf(logfile,"\nERROR:Number of atoms in neighboring boxes not correct in node %2d: %4d %4d ", iNode, natomAll2, natomAll);
            }
            natom[iNode] = status[statusNatom];
            natomAll3 += natom[iNode];
        }
        calcTime += (float)(clock() - timer) / CLOCKS_PER_SEC;

//test whether sum of atoms is still the same; is a good indicator of bugs 
        if (natomAll != natomAll3)
        {
            printf("\nERROR: total number of atoms %d not the same as initially %d\n", natomAll3, natomAll);
            fprintf(logfile,"\nERROR: total number of atoms %d not the same as initially %d\n", natomAll3, natomAll);
        }
        
//read atom data
        ReadAtomData(qext, vext, atomNrFPGA2Ext, 0, dest, sock, PacketNr);

        if (iStep > simParam.nStep2) break;
    }

//MD loop finished; read status
    printf("\nRead status\n");
    fprintf(logfile,"\nRead status\n");
    for (iNode = 0; iNode < nNode; iNode++)
    {
        ReadStatus(status, iNode, 0, dest, sock, PacketNr);

        printf("Node %2d #Atoms:", iNode); for (j = 27; j < 54; j++) printf(" %3d", status[j]); printf("\n");
//        printf("StatusLine1:   "); for (j = 0; j < 27; j++)  printf("  %02X", status[j]); printf("\n");
//        printf("StatusLine2:   "); for (j = 54;j < 81; j++)  printf("  %02X", status[j]); printf("\n");
        

        fprintf(logfile,"Node %2d #Atoms:", iNode); for (j = 27; j < 54; j++) fprintf(logfile," %3d", status[j]); fprintf(logfile,"\n");
        ErrorStat[iNode][0] = status[statusRestartCnt - 0];
        ErrorStat[iNode][1] = status[statusRestartCnt - 1];
        ErrorStat[iNode][3] = status[statusRestartCnt - 3];
        ErrorStat[iNode][4] = status[statusRestartCnt - 4];
        
    }
 
    printf("\nAverage number of Shake iterations: %4.1f\n", (float)nIterTot / nShakeTot);

//evaluate transmission errors
    printf("\nTransmission error statistics:\n");
    fprintf(logfile,"\nTransmission error statistics:\n");
    itmp = 0;
    for (iNode = 0; iNode < nNode; iNode++)
    {
        if (ErrorStat[iNode][0] != 0 || ErrorStat[iNode][1] != 0 || ErrorStat[iNode][3] != 0 || ErrorStat[iNode][4] != 0)
        {
            itmp = 1;
            printf("Node %3d: SEQ error: ETH3: %3d ETH4: %3d|  ERC error: ETH3: %3d ETH4: %3d\n", iNode, ErrorStat[iNode][1], ErrorStat[iNode][4], ErrorStat[iNode][0], ErrorStat[iNode][3]);
            fprintf(logfile,"Node %3d: SEQ error: ETH3: %3d ETH4: %3d|  ERC error: ETH3: %3d ETH4: %3d\n", iNode, ErrorStat[iNode][1], ErrorStat[iNode][4], ErrorStat[iNode][0], ErrorStat[iNode][3]);
        }
    }
    if (itmp == 0)
    {
        printf("None\n");
        fprintf(logfile,"None\n");
    }

    

//evaluate calculation time

    tmp = calcTime / simParam.nStep1 / (iStep - 1) * 1000000 / simParam.dt;
    printf("\nCalculation speed for %4d atoms: %4.2f us/day\n",natomAll,86.4/tmp);
    fprintf(logfile,"\nCalculation speed for %4d atoms: %4.2f us/day\n", natomAll, 86.4 / tmp);
    closesocket(sock);
    WSACleanup();



    fclose(trajfile);
    fclose(enerfile);
    fclose(logfile);

//write final structure
    printf("\nDone; write %s\n", simParam.outfile);
    fprintf(logfile,"\nDone; write %s\n", simParam.outfile);
    sprintf(filename, "%s%s", path, simParam.outfile);
    trajfile = fopen(filename, "w");
    Text = Temperature(vext, meta, simParam, natomAll);
    writeGroFile(qext, vext, (iStep-1) * simParam.nStep1* simParam.dt / 1000., Text, natomAll, meta, simParam, trajfile);
    fclose(trajfile);

    return 0;
}

