// UDP communication from https://stackoverflow.com/questions/679145/how-to-set-up-a-winsock-udp-socket

//ToDos:
//-ions not implemented yet; probably need to change order with which molecule types is read, i.e., before ions and also water
//-might consider range of dihedral forces to be decreased a bit (pm1/1024); numbers are very small
//-catch when maximum number of dihedrals or maximum number of closeAtom is larger than what the FPGA code can do
//-implement constraints of XH, should alraedy work on the FPGA level, but needs adjustment of the C-progamm
//-calculate number of degrees of freedom, considering number of constraints
//-transmit all parameters from param.dat and gro-file via meta.dat that, when changed, would require rerunning SendForceField, such as dt and rcut 
//- make rLJ_ref and eLJ_ref a parameter of param.dat




#include "../SharedLibrary/MDcontrol.h"

void readTopol(char* projectName, LJtype_t* LJtype, atom_t* atom, atom_t* atomWater, int* atomNrExt2FPGA,  near14_t* near14, angle_t* angle, bond_t* bond, dihedral_t* dihedral, shake_t* shake, int* nAtomProtein, int* nAtomWater, int* nLJtype, int* nProtein, int* nWater, param_t simParam);

//gloobal variable
FILE* logfile;


int main()
{
    int itmp, i, j, iAtom;
    int nAtomProtein = 0, nAtomWater = 0, nLJtype = 0, nProtein = 0, nWater = 0, nAtomTot;
    char filename[30];
    float box;
    FILE* outfile;
    int iNode, nNode;
    uint8_t     PacketNr[nxNode * nxNode * nxNode];
    uint8_t     version[nxNode * nxNode * nxNode];
    int**       ErrorStat;
    uint8_t     status[100];                      //for maximum 3 status lines of 27 bytes each

 //IP stuff
    const char* srcIP = "192.168.1.131";  //IP adress of the ETH interface connectic to FPGAs; needs to be a static IP
    char        destIP[16];
    sockaddr_in dest[nxNode * nxNode * nxNode];
    sockaddr_in local;
    SOCKET      sock;
    WSAData     wsaddata;
    int         destSize = sizeof(dest[0]);

//allocate arrays
    LJtype_t* LJtype = (LJtype_t*) malloc((maxLJtype + 1) * sizeof * LJtype);
    atom_t* atomProtein = (atom_t*) malloc((maxAtomProtein + 1) * sizeof * atomProtein);
    atom_t* atomWater = (atom_t*) malloc((maxAtomWater + 1) * sizeof * atomWater);
    near14_t* near14 = (near14_t*) malloc((maxAtomProtein + 1) * sizeof * near14);
    angle_t* angle = (angle_t*) malloc((maxAtomProtein + 1) * sizeof * angle);
    bond_t* bond = (bond_t*) malloc((maxAtomProtein + 1) * sizeof * bond);
    dihedral_t* dihedral = (dihedral_t*) malloc((maxAtomProtein + 1) * sizeof * dihedral);
    pair_t*      pair = (pair_t*) malloc((maxAtomProtein + 1) * sizeof * pair);
    shake_t      shake;
    param_t      simParam;
    int* atomNrExt2FPGA = (int*) malloc((maxAtomAll + 1) * sizeof * atomNrExt2FPGA);
    //int* atomNrFPGA2Ext = (int*) malloc((maxAtomAll + 1) * sizeof * atomNrFPGA2Ext);

  
    sprintf(filename, "%sSendForceField.log", path);
    logfile = fopen(filename, "w");

//read parameters
    simParam = readParam();

//read topology files
    readTopol(simParam.topolfile, LJtype, atomProtein, atomWater, atomNrExt2FPGA,  near14, angle, bond, dihedral, &shake, &nAtomProtein, &nAtomWater, &nLJtype, &nProtein, &nWater, simParam);
    nAtomTot = nProtein * nAtomProtein + nWater * nAtomWater;

//analyze gro-file  
    analyzeGroFile(simParam.startfile, nAtomTot, &box);
    simParam.rcut = box / nxNode;

//write output file to be transferred to MDRun.cpp 
    writeMetaFile(atomNrExt2FPGA, atomProtein, atomWater, nAtomProtein, nWater, nAtomWater);

  //  exit(1);

//initialize UDP communication
    if (WSAStartup(MAKEWORD(2, 2), &wsaddata) != 0)
    {
        printf("WSAStartup failed\n");
        fprintf(logfile, "WSAStartup failed\n");
        exit(1);
    }
    local.sin_family = AF_INET;
    itmp = inet_pton(AF_INET, srcIP, &local.sin_addr.s_addr);
    local.sin_port = htons(8080);
    sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    bind(sock, (sockaddr*)&local, sizeof(local));

//initialize/open nodes
    printf("\nInititialize nodes\n");
    fprintf(logfile, "\nInititialize nodes\n");
    nNode = nxNode * nxNode * nxNode;
    ErrorStat = imatrix(nNode, 6);

    for (iNode = 0; iNode < nNode; iNode++)
    {
        sprintf_s(destIP, "192.168.1.%d", 192 + iNode);    //IP adresses of FPGAs; start at 192.168.1.192 with node0, is set by dip switches
 //       printf("Initializing node %2d, IP: %s\n", iNode, destIP);
 //       fprintf(logfile, "Initializing node %2d, IP: %s\n", iNode, destIP);
        dest[iNode].sin_family = AF_INET;
        itmp = inet_pton(AF_INET, destIP, &dest[iNode].sin_addr.s_addr);
        dest[iNode].sin_port = htons(8080);
        ReadStatus(status, iNode, 0xf, dest, sock, PacketNr);   //test whether nodes respond, and if yes, report its status; at the same fully reset all nodes, including force field counter 
        version[iNode] = status[statusVersion];
        if (version[iNode] != version[0])
        {
            printf("Warning: FPGA version of node %d (%d) is different from that of node 0 (%d).\n", iNode, version[iNode], version[0]);
            fprintf(logfile, "Warning: FPGA version of node %d (%d) is different from that of node 0 (%d).\n", iNode, version[iNode], version[0]);
        }
    }
    printf("FPGA version %d\n", version[0]);
    fprintf(logfile, "FPGA version %d\n", version[0]);

//write force LUTs
    printf("\nWrite force LUTs\n");
    fprintf(logfile, "\nWrite Force LUTs\n");
    for (iNode = 0; iNode < nNode; iNode++)
    {
        WriteNonBondForceLUT(simParam,iNode, LJtype, nLJtype, dest, sock, PacketNr);
    }

//set simulation parameters
    printf("\nWrite Shake and fudge parameters\n");
    fprintf(logfile, "\nWrite Shake and fudge parameters\n");
    for (iNode = 0; iNode < nNode; iNode++)
    {
        SetSimParam(shake, simParam, iNode, dest, sock, PacketNr);
    }

 
//write protein forcefield data
   printf("\nWrite protein force field\n\n");
   fprintf(logfile, "\nWrite Protein Force Field\n");
   for (iNode = 0; iNode < nNode; iNode++)
   {
       printf("\033[A");   // move up
       printf("\033[2K");  // clear line
       printf("iNode = %2d\n", iNode);
       WriteForceField(iNode, atomNrExt2FPGA, near14, angle, bond, dihedral, simParam, nAtomProtein, dest, sock, PacketNr);
//       ReadStatus(status, iNode, 0, dest, sock, PacketNr);   //check whether the right amount force field data have been written
   }
   printf("\033[A");   // move up
   printf("\033[2K");  // clear line
   printf("Done writing force field paramerters into all nodes\nExit\n");




}



//********************************************************************************************************************************************************************************************
#define ATOMTYPES     1  //in ffnonbonded.itp
#define BONDTYPES     2  //in ffbonded.itp
#define ANGLETYPES    3
#define DIHEDRALTYPES 4
#define ATOMS         5  //in actual topology file
#define BONDS         6
#define PAIRS         7
#define DIHEDRALS     8
#define ANGLES        9
#define SETTLES       10
#define MOLECULETYPE  11
#define MOLECULES     12


void  readTopol(char* projectName, LJtype_t* LJtype, atom_t* atom, atom_t* atomWater, int* atomNrExt2FPGA,  near14_t* near14, angle_t* angle, bond_t* bond, dihedral_t* dihedral, shake_t* shake, int* nAtomProtein, int* nAtomWater, int* nLJtype, int* nProtein, int* nWater, param_t simParam)
{

    int itmp, itmp1, itmp2, itmp3, itmp4, itmp5, i, j, iLine = 0, section = 0, nBond = 0, nPair = 0, nBondtypes = 0, nAngletypes = 0, nDihedraltypes = 0, nAtomtypes = 0, nMoleculetype = 0, nDihedral = 0, nAngle = 0, iAtom, nAtomTot;
    char stmp1[10], stmp2[10];
    char stmp[30];
    FILE* inFile;
    char fileName[30];
    char line[200];
    char* ctmp;
    char arg1_s[20];
    float tmp, tmp1, tmp2;
    float r0Stretch, kStretch, phi0Bend, kBend;
    float k1Dihed, k2Dihed, k3Dihed;
    float qtot;
    int funcDihed;

    atomtypes_t* atomtypes = (atomtypes_t*)malloc((maxAtomtypes + 1) * sizeof * atomtypes);
    bondtypes_t* bondtypes = (bondtypes_t*)malloc((maxBondtypes + 1) * sizeof * bondtypes);
    angletypes_t* angletypes = (angletypes_t*)malloc((maxAngletypes + 1) * sizeof * angletypes);
    dihedraltypes_t* dihedraltypes = (dihedraltypes_t*)malloc((maxDihedraltypes + 1) * sizeof * dihedraltypes);
    pair_t* pair = (pair_t*)malloc((maxAtomProtein + 1) * sizeof * pair);

    char** moleculetype;
    moleculetype = (char**)malloc((maxMoleculetype + 1) * sizeof(char*));
    for (i = 0; i <= maxMoleculetype; i++) moleculetype[i] = (char*)malloc(30 * sizeof(char));


    for (i = 1;i <= maxAtomProtein;i++)
    {
        bond[i].n = 0;
        pair[i].n = 0;
        angle[i].n = 0;
        dihedral[i].n = 0;
        near14[i].n = 0;
    }

    //initialize some of the variables
    (*shake).rCH = .1;
    (*shake).rOH = .1;
    (*shake).rNH = .1;
    (*shake).rSH = .1;

    //open ffnonbonded.itp
    sprintf(fileName, "%sffnonbonded.itp", path);
    printf("Open %s\n", fileName);
    fprintf(logfile,"Open %s\n", fileName);
    if ((inFile = fopen(fileName, "r")) == NULL)
    {
        printf("File %s not found, exit\n", fileName);
        fprintf(logfile, "File %s not found, exit\n", fileName);
        exit(1);
    }

    while (fgets(line, 200, inFile) != NULL)
    {
        iLine++;
        //strip off CR,LF, comments after ";"
        ctmp = strchr(line, 13);   //CR
        if (ctmp != NULL) *ctmp = 0;
        ctmp = strchr(line, 10);   //LF
        if (ctmp != NULL) *ctmp = 0;
        ctmp = strchr(line, ';');
        if (ctmp != NULL) *ctmp = 0;
        ctmp = strchr(line, '#');
        if (ctmp != NULL) *ctmp = 0;

        if (!lineEmptyQ(line))                    //not an empty line
        {
            if (line[0] == '[')                      //start new section
            {
                strcpy(arg1_s, "");
                itmp=sscanf(&line[1], "%s", arg1_s);
                if (strcmp(arg1_s, "atomtypes") == 0)
                {
                    printf("Read [ atomtypes ]\n");
                    fprintf(logfile, "Read [ atomtypes ]\n");
                    section = ATOMTYPES;
                }
                else
                {
                    section = 0;
                }
            }
            else
            {
                if (section == ATOMTYPES)
                {
                    //	  	  printf("%s\n",line);
                    nAtomtypes++;
                    if (nAtomtypes > maxAtomtypes) 
                    { 
                        printf("ERROR: Too many atom types\n");
                        fprintf(logfile, "ERROR: Too many atom types\n");
                        exit(1); 
                    }
                    itmp=sscanf(line, "%s %d %f %f %s %f %f", &atomtypes[nAtomtypes].type, &itmp1, &tmp1, &tmp2, &stmp1, &atomtypes[nAtomtypes].sigma, &atomtypes[nAtomtypes].epsilon);
                }
            }
        }
    }
    printf("Found %d atomtypes\n", nAtomtypes);
    fprintf(logfile, "Found %d atomtypes\n", nAtomtypes);
    fclose(inFile);

    //open ffbonded.itp
    sprintf(fileName, "%sffbonded.itp", path);
    printf("\nOpen %s\n", fileName);
    fprintf(logfile, "\nOpen %s\n", fileName);
    if ((inFile = fopen(fileName, "r")) == NULL)
    {
        printf("File %s not found, exit\n", fileName);
        fprintf(logfile, "File %s not found, exit\n", fileName);
        exit(1);
    }

    while (fgets(line, 200, inFile) != NULL)
    {
        iLine++;
        //strip off CR,LF, comments after ";"
        ctmp = strchr(line, 13);   //CR
        if (ctmp != NULL) *ctmp = 0;
        ctmp = strchr(line, 10);   //LF
        if (ctmp != NULL) *ctmp = 0;
        ctmp = strchr(line, ';');
        if (ctmp != NULL) *ctmp = 0;
        ctmp = strchr(line, '#');
        if (ctmp != NULL) *ctmp = 0;

        if (!lineEmptyQ(line))                    //not an empty line
        {
            if (line[0] == '[')                      //start new section
            {
                strcpy(arg1_s, "");
                itmp=sscanf(&line[1], "%s", arg1_s);
                if (strcmp(arg1_s, "bondtypes") == 0)
                {
                    printf("Read [ bondtypes ]\n");
                    fprintf(logfile, "Read [ bondtypes ]\n");
                    section = BONDTYPES;
                }
                else if (strcmp(arg1_s, "angletypes") == 0)
                {
                    printf("Read [ angletypes ]\n");
                    fprintf(logfile, "Read [ angletypes ]\n");
                    section = ANGLETYPES;
                }
                else if (strcmp(arg1_s, "dihedraltypes") == 0)
                {
                    printf("Read [ dihedraltypes ]\n");
                    fprintf(logfile, "Read [ dihedraltypes ]\n");
                    section = DIHEDRALTYPES;
                }
                else
                {
                    section = 0;
                }
            }
            else
            {
                if (section == BONDTYPES)
                {
                    //	     printf("%s\n",line);
                    nBondtypes++;
                    if (nBondtypes > maxBondtypes) 
                    { 
                        printf("ERROR: Too many bond types\n");
                        fprintf(logfile, "ERROR: Too many bond types\n");
                        exit(1); 
                    }
                    itmp=sscanf(line, "%s %s %d %f %f", &bondtypes[nBondtypes].type1, &bondtypes[nBondtypes].type2, &itmp1, &bondtypes[nBondtypes].r0, &bondtypes[nBondtypes].k);
                    if (itmp1 != 1) 
                    { 
                        printf("ERROR: Stretch func %d not supported\n", itmp1); 
                        fprintf(logfile, "ERROR: Stretch func %d not supported\n", itmp1);
                        exit(1); 
                    }
                }
                else if (section == ANGLETYPES)
                {
                    //	     printf("%s\n",line);
                    nAngletypes++;
                    if (nAngletypes > maxAngletypes) 
                    { 
                        printf("ERROR: Too many angle types\n");
                        fprintf(logfile, "ERROR: Too many angle types\n");
                        exit(1); 
                    }
                    itmp=sscanf(line, "%s %s %s %d %f %f", &angletypes[nAngletypes].type1, &angletypes[nAngletypes].type2, &angletypes[nAngletypes].type3, &itmp1, &angletypes[nAngletypes].phi0, &angletypes[nAngletypes].k);
                    if (itmp1 != 1) 
                    { 
                        printf("ERROR: Bend func %d not supported\n", itmp1); 
                        fprintf(logfile, "ERROR: Bend func %d not supported\n", itmp1);
                        exit(1); 
                    }
                }
                else if (section == DIHEDRALTYPES)
                {
      //              	     printf("%s\n",line);
                    nDihedraltypes++;
                    if (nDihedraltypes > maxDihedraltypes)
                    {
                        printf("ERROR: Too many dihedral types\n");
                        fprintf(logfile, "ERROR: Too many dihedral types\n");
                        exit(1);
                    }
                    itmp = sscanf(line, "%s %s %s %s %d %f %f %d", &dihedraltypes[nDihedraltypes].type1, &dihedraltypes[nDihedraltypes].type2, &dihedraltypes[nDihedraltypes].type3, &dihedraltypes[nDihedraltypes].type4, 
                                                                   &dihedraltypes[nDihedraltypes].func, &tmp1, &tmp2, &dihedraltypes[nDihedraltypes].m);

                    if (tmp1 == 0)      dihedraltypes[nDihedraltypes].k = tmp2;
                    else if (tmp1==180) dihedraltypes[nDihedraltypes].k = -tmp2;
                    else
                    {
                        printf("ERROR: Phase shift %f not supported\n", tmp1);
                        fprintf(logfile,"ERROR: Phase shift %f not supported\n", tmp1);
                        exit(1);
                    }
                    if ((dihedraltypes[nDihedraltypes].func != 4) && (dihedraltypes[nDihedraltypes].func != 9))
                    {
                        printf("ERROR: Dihedral func %d not supported\n", dihedraltypes[nDihedraltypes].func);
                        fprintf(logfile, "ERROR: Dihedral func %d not supported\n", dihedraltypes[nDihedraltypes].func);
                        exit(1);
                    }
                    if ((dihedraltypes[nDihedraltypes].m == 0) && (dihedraltypes[nDihedraltypes].k != 0))
                    {
                        printf("ERROR: Dihedral periodicity 0 not supported for non-zero force constant\n");
                        fprintf(logfile,"ERROR: Dihedral periodicity 0 not supported for non-zero force constant\n");
                        exit(1);
                    }
                    if ((dihedraltypes[nDihedraltypes].m < 0) || (dihedraltypes[nDihedraltypes].m>3))
                    {
                        printf("ERROR: Dihedral periodicity %d not supported\n", dihedraltypes[nDihedraltypes].m);
                        fprintf(logfile,"ERROR: Dihedral periodicity %d not supported\n", dihedraltypes[nDihedraltypes].m);
                        exit(1);
                    }
                }
            }
        }
    }
    printf("Found %d bond types\n", nBondtypes);
    printf("Found %d angle types\n", nAngletypes);
    printf("Found %d dihedral types\n", nDihedraltypes);
    fprintf(logfile, "Found %d bond types\n", nBondtypes);
    fprintf(logfile,"Found %d angle types\n", nAngletypes);
    fprintf(logfile,"Found %d dihedral types\n", nDihedraltypes);
    fclose(inFile);

    //open water-topology file
    sprintf(fileName, "%stip3p.itp", path);
    printf("\nOpen %s\n", fileName);
    fprintf(logfile, "\nOpen %s\n", fileName);
    if ((inFile = fopen(fileName, "r")) == NULL)
    {
        printf("File %s not found, exit\n", fileName);
        fprintf(logfile, "File %s not found, exit\n", fileName);
        exit(1);
    }

    while (fgets(line, 200, inFile) != NULL)
    {
        iLine++;
        //strip off CR,LF, comments after ";"
        ctmp = strchr(line, 13);   //CR
        if (ctmp != NULL) *ctmp = 0;
        ctmp = strchr(line, 10);   //LF
        if (ctmp != NULL) *ctmp = 0;
        ctmp = strchr(line, ';');
        if (ctmp != NULL) *ctmp = 0;
        ctmp = strchr(line, '#');
        if (ctmp != NULL) *ctmp = 0;

        if (!lineEmptyQ(line))                    //not an empty line
        {
            if (line[0] == '[')                      //start new section
            {
                strcpy(arg1_s, "");
                itmp=sscanf(&line[1], "%s", arg1_s);
                if (strcmp(arg1_s, "atoms") == 0)
                {
                    printf("Read [ atoms ]\n");
                    fprintf(logfile, "Read [ atoms ]\n");
                    section = ATOMS;
                }
                else if (strcmp(arg1_s, "settles") == 0)
                {
                    printf("Read [ settles ]\n");
                    fprintf(logfile, "Read [ settles ]\n");
                    section = SETTLES;
                }
                else if (strcmp(arg1_s, "moleculetype") == 0)
                {
                    printf("Read [ moleculetype ]\n");
                    fprintf(logfile, "Read [ moleculetype ]\n");
                    section = MOLECULETYPE;
                }
                else
                {
                    section = 0;
                }
            }
            else
            {
                if (section == ATOMS)
                {
                    //	  	  	  printf("%s\n",line);
                    (*nAtomWater)++;
                    if (*nAtomWater > maxAtomWater) 
                    { 
                        printf("ERROR: Too many water atoms\n");
                        fprintf(logfile, "ERROR: Too many water atoms\n");
                        exit(1); 
                    }
                    itmp=sscanf(line, "%d %s %d %s %s %d %f %f", &itmp1, &atomWater[*nAtomWater].type, &itmp2, &stmp1, &stmp2, &itmp3, &atomWater[*nAtomWater].charge, &tmp);
                    atomWater[*nAtomWater].mass = floor(tmp + .5);
                    atomWater[*nAtomWater].constraint = 6;             //initiates shake for water
                }
                if (section == SETTLES)
                {
                    //	  	  printf("%s\n",line);
                    itmp=sscanf(line, "%d %d %f %f", &itmp1, &itmp2, &shake[0].rOHw, &shake[0].rHHw);
                }
                if (section == MOLECULETYPE)
                {
                    //	  	  	  	  printf("%s\n",line);
                    nMoleculetype++;
                    if (nMoleculetype > maxMoleculetype) 
                    { 
                        printf("ERROR: Too many molecule types\n");
                        fprintf(logfile,"ERROR: Too many molecule types\n");
                        exit(1); 
                    }
                    itmp=sscanf(line, "%s", moleculetype[nMoleculetype]);
                }
            }
        }
    }

  

  //open topology file
    sprintf(fileName, "%s%s", path, projectName);
    printf("\nOpen %s\n", fileName);
    fprintf(logfile, "\nOpen %s\n", fileName);
    if ((inFile = fopen(fileName, "r")) == NULL)
    {
        printf("File %s not found, exit\n", fileName);
        fprintf(logfile, "File %s not found, exit\n", fileName);
        exit(1);
    }

    //read topology file line by line
    while (fgets(line, 200, inFile) != NULL)
    {
        iLine++;
        //strip off CR,LF, comments after ";"
        ctmp = strchr(line, 13);   //CR
        if (ctmp != NULL) *ctmp = 0;
        ctmp = strchr(line, 10);   //LF
        if (ctmp != NULL) *ctmp = 0;
        ctmp = strchr(line, ';');
        if (ctmp != NULL) *ctmp = 0;
        ctmp = strchr(line, '#');
        if (ctmp != NULL) *ctmp = 0;

        if (!lineEmptyQ(line))                    //not an empty line
        {
            if (line[0] == '[')                      //start new section
            {
                strcpy(arg1_s, "");
                itmp=sscanf(&line[1], "%s", arg1_s);
                if (strcmp(arg1_s, "atoms") == 0)
                {
                    printf("Read [ atoms ]\n");
                    fprintf(logfile, "Read [ atoms ]\n");
                    section = ATOMS;
                }
                else if (strcmp(arg1_s, "bonds") == 0)
                {
                    printf("Read [ bonds ]\n");
                    fprintf(logfile, "Read [ bonds ]\n");
                    section = BONDS;
                }
                else if (strcmp(arg1_s, "pairs") == 0)
                {
                    printf("Read [ pairs ]\n");
                    fprintf(logfile, "Read [ pairs ]\n");
                    section = PAIRS;
                }
                else if (strcmp(arg1_s, "dihedrals") == 0)
                {
                    printf("Read [ dihedrals ]\n");
                    fprintf(logfile, "Read [ dihedrals ]\n");
                    section = DIHEDRALS;
                }
                else if (strcmp(arg1_s, "angles") == 0)
                {
                    printf("Read [ angles ]\n");
                    fprintf(logfile, "Read [ angles ]\n");
                    section = ANGLES;
                }
                else if (strcmp(arg1_s, "moleculetype") == 0)
                {
                    printf("Read [ moleculetype ]\n");
                    fprintf(logfile, "Read [ moleculetype ]\n");
                    section = MOLECULETYPE;
                }
                else if (strcmp(arg1_s, "molecules") == 0)
                {
                    printf("Read [ molecules ]\n");
                    fprintf(logfile, "Read [ molecules ]\n");
                    section = MOLECULES;
                }
                else
                {
                    section = 0;
                }
            }
            else
            {
                if (section == MOLECULETYPE)
                {
                    //	  	  	  	  printf("%s\n",line);
                    nMoleculetype++;
                    if (nMoleculetype > maxMoleculetype) 
                    { 
                        printf("ERROR: Too many molecule types\n");
                        fprintf(logfile, "ERROR: Too many molecule types\n");
                        exit(1); 
                    }
                    itmp=sscanf(line, "%s", moleculetype[nMoleculetype]);
                }
                if (section == MOLECULES)
                {
                    //	  	  	  	  printf("%s\n",line);
                    itmp=sscanf(line, "%s %d", &stmp, &itmp1);
                    if (strcmp(stmp, moleculetype[1]) == 0)      *nWater = itmp1;        //that needs to be more sophisticated once ions are added
                    else if (strcmp(stmp, moleculetype[2]) == 0) *nProtein = itmp1;
                    if (*nProtein > 1)
                    {
                        printf("ERROR: Only one protein is supported\n");
                        fprintf(logfile, "ERROR: Only one protein is supported\n");
                        exit(1);
                    }
                }
                if (section == ATOMS)
                {
                    //	  printf("%s\n",line);
                    (*nAtomProtein)++;
                    if (*nAtomProtein > maxAtomProtein) 
                    { 
                        printf("ERROR: Too many atoms\n");
                        fprintf(logfile, "ERROR: Too many atoms\n");
                        exit(1); 
                    }
                    itmp=sscanf(line, "%d %s %d %s %s %d %f %f", &itmp1, &atom[*nAtomProtein].type, &itmp2, &stmp1, &stmp2, &itmp3, &atom[*nAtomProtein].charge, &tmp);
                    atom[*nAtomProtein].mass = floor(tmp + .5);
                    atom[*nAtomProtein].constraint = 0;                         //that will be more sophisticated once XH bonds are constraint
                }
                if (section == BONDS)
                {
                    //       printf("%s\n",line);
                    nBond++;
                    itmp=sscanf(line, "%d %d %d", &itmp1, &itmp2, &itmp3);
                    if (itmp3 != 1) 
                    { 
                        printf("ERROR: Stretch func %d not supported\n", itmp3); 
                        fprintf(logfile, "ERROR: Stretch func %d not supported\n", itmp3);
                        exit(1); 
                    }
                    SearchBondType(atom[itmp1].type, atom[itmp2].type, bondtypes, nBondtypes, &r0Stretch, &kStretch);
                    bond[itmp1].n++;
                    if (bond[itmp1].n > maxValence) 
                    { 
                        printf("ERROR: Too many bonds for atom %d\n", itmp1);
                        fprintf(logfile, "ERROR: Too many bonds for atom %d\n", itmp1);
                        exit(1); 
                    }
                    bond[itmp1].atom[bond[itmp1].n] = itmp2;
                    bond[itmp1].r0[bond[itmp1].n] = r0Stretch;
                    bond[itmp1].k[bond[itmp1].n] = kStretch;
                    bond[itmp2].n++;
                    if (bond[itmp2].n > maxValence) 
                    { 
                        printf("ERROR: Too many bonds for atom %d\n", itmp2);
                        fprintf(logfile, "ERROR: Too many bonds for atom %d\n", itmp2);
                        exit(1); 
                    }
                    bond[itmp2].atom[bond[itmp2].n] = itmp1;
                    bond[itmp2].r0[bond[itmp2].n] = r0Stretch;
                    bond[itmp2].k[bond[itmp2].n] = kStretch;
                }
                if (section == ANGLES)
                {
                    //	  printf("%s\n",line);
                    nAngle++;
                    itmp=sscanf(line, "%d %d %d %d", &itmp1, &itmp2, &itmp3, &itmp4);
                    if (itmp4 != 1) 
                    { 
                        printf("ERROR: angle func %d not supported\n", itmp4); 
                        fprintf(logfile, "ERROR: angle func %d not supported\n", itmp4);
                        exit(1); 
                    }
                    SearchAngleType(atom[itmp1].type, atom[itmp2].type, atom[itmp3].type, angletypes, nAngletypes, &phi0Bend, &kBend);
                    //first atom
                    angle[itmp1].n++;
                    if (angle[itmp1].n > maxNear14) 
                    { 
                        printf("ERROR: Too many angles for atom %d\n", itmp1);
                        fprintf(logfile, "ERROR: Too many angles for atom %d\n", itmp1);
                        exit(1); 
                    }
                    angle[itmp1].atom2[angle[itmp1].n] = itmp2;
                    angle[itmp1].atom3[angle[itmp1].n] = itmp3;
                    angle[itmp1].type[angle[itmp1].n] = 0;         //outer atom
                    angle[itmp1].phi0[angle[itmp1].n] = phi0Bend;
                    angle[itmp1].k[angle[itmp1].n] = kBend;
                    //2nd atom
                    angle[itmp2].n++;
                    if (angle[itmp2].n > maxNear14) 
                    { 
                        printf("ERROR: Too many angles for atom %d\n", itmp2);
                        fprintf(logfile, "ERROR: Too many angles for atom %d\n", itmp2);
                        exit(1); 
                    }
                    angle[itmp2].atom2[angle[itmp2].n] = itmp1;
                    angle[itmp2].atom3[angle[itmp2].n] = itmp3;
                    angle[itmp2].type[angle[itmp2].n] = 1;         //inner atom
                    angle[itmp2].phi0[angle[itmp2].n] = phi0Bend;
                    angle[itmp2].k[angle[itmp2].n] = kBend;
                    //3rd atom
                    angle[itmp3].n++;
                    if (angle[itmp3].n > maxNear14) 
                    { 
                        printf("ERROR: Too many angles for atom %d\n", itmp3);
                        fprintf(logfile, "ERROR: Too many angles for atom %d\n", itmp3);
                        exit(1); 
                    }
                    angle[itmp3].atom2[angle[itmp3].n] = itmp2;
                    angle[itmp3].atom3[angle[itmp3].n] = itmp1;
                    angle[itmp3].type[angle[itmp3].n] = 0;         //outer atom
                    angle[itmp3].phi0[angle[itmp3].n] = phi0Bend;
                    angle[itmp3].k[angle[itmp3].n] = kBend;
                }
                if (section == PAIRS)
                {
                    //         printf("%s\n",line);
                    nPair++;
                    itmp=sscanf(line, "%d %d %d", &itmp1, &itmp2, &itmp3);
                    if (itmp3 != 1) 
                    { 
                        printf("ERROR: pair func %d not supported\n", itmp3); 
                        fprintf(logfile, "ERROR: pair func %d not supported\n", itmp3);
                        exit(1); 
                    }
                    pair[itmp1].n++;
                    if (pair[itmp1].n > maxNear14) 
                    { 
                        printf("ERROR: Too many pairs for atom %d\n", itmp1);
                        fprintf(logfile, "ERROR: Too many pairs for atom %d\n", itmp1);
                        exit(1); 
                    }
                    pair[itmp1].atom[pair[itmp1].n] = itmp2;
                    pair[itmp2].n++;
                    if (pair[itmp2].n > maxNear14) 
                    { 
                        printf("ERROR: Too many pairs for atom %d\n", itmp2);
                        fprintf(logfile, "ERROR: Too many pairs for atom %d\n", itmp2);
                        exit(1); 
                    }
                    pair[itmp2].atom[pair[itmp2].n] = itmp1;
                }
                if (section == DIHEDRALS)
                {
                    //	  printf("%s\n",line);
                    nDihedral++;
                    itmp=sscanf(line, "%d %d %d %d %d", &itmp1, &itmp2, &itmp3, &itmp4, &funcDihed);
                    if ((funcDihed != 4) && (funcDihed != 9))
                    {
                        printf("ERROR: Dihedral func %d not supported\n", funcDihed);
                        fprintf(logfile, "ERROR: Dihedral func %d not supported\n", funcDihed);
                        exit(1);
                    }
                    SearchDihedralType(atom[itmp1].type, atom[itmp2].type, atom[itmp3].type, atom[itmp4].type, funcDihed, dihedraltypes, nDihedraltypes, &k1Dihed, &k2Dihed, &k3Dihed);
   //                 if (funcDihed == 4) { k1Dihed = 0;  k2Dihed = 0; k3Dihed = 0;}
                    if ((k1Dihed != 0) || (k2Dihed != 0) || (k3Dihed != 0))
                    {
                        //first atom
                        dihedral[itmp1].n++;
                        if (dihedral[itmp1].n > maxNear14)
                        {
                            printf("ERROR: Too many dihedrals for atom %d\n", itmp1);
                            fprintf(logfile, "ERROR: Too many dihedrals for atom %d\n", itmp1);
                            exit(1);
                        }
                        dihedral[itmp1].atom2[dihedral[itmp1].n] = itmp2;
                        dihedral[itmp1].atom3[dihedral[itmp1].n] = itmp3;
                        dihedral[itmp1].atom4[dihedral[itmp1].n] = itmp4;
                        dihedral[itmp1].type[dihedral[itmp1].n] = 0;         //outer atom
                        dihedral[itmp1].k1[dihedral[itmp1].n] = 3. * k3Dihed / 2 - k1Dihed / 2;
                        dihedral[itmp1].k2[dihedral[itmp1].n] = -2 * k2Dihed;
                        dihedral[itmp1].k3[dihedral[itmp1].n] = -6 * k3Dihed;
                        //2nd atom
                        dihedral[itmp2].n++;
                        if (dihedral[itmp2].n > maxNear14)
                        {
                            printf("ERROR: Too many dihedrals for atom %d\n", itmp2);
                            fprintf(logfile, "ERROR: Too many dihedrals for atom %d\n", itmp2);
                            exit(1);
                        }
                        dihedral[itmp2].atom2[dihedral[itmp2].n] = itmp1;
                        dihedral[itmp2].atom3[dihedral[itmp2].n] = itmp3;
                        dihedral[itmp2].atom4[dihedral[itmp2].n] = itmp4;
                        dihedral[itmp2].type[dihedral[itmp2].n] = 1;         //inner atom
                        dihedral[itmp2].k1[dihedral[itmp2].n] = 3. * k3Dihed / 2 - k1Dihed / 2;
                        dihedral[itmp2].k2[dihedral[itmp2].n] = -2 * k2Dihed;
                        dihedral[itmp2].k3[dihedral[itmp2].n] = -6 * k3Dihed;
                        //3rd atom
                        dihedral[itmp3].n++;
                        if (dihedral[itmp3].n > maxNear14)
                        {
                            printf("ERROR: Too many dihedrals for atom %d\n", itmp3);
                            fprintf(logfile, "ERROR: Too many dihedrals for atom %d\n", itmp3);
                            exit(1);
                        }
                        dihedral[itmp3].atom2[dihedral[itmp3].n] = itmp4;
                        dihedral[itmp3].atom3[dihedral[itmp3].n] = itmp2;
                        dihedral[itmp3].atom4[dihedral[itmp3].n] = itmp1;
                        dihedral[itmp3].type[dihedral[itmp3].n] = 1;         //inner atom
                        dihedral[itmp3].k1[dihedral[itmp3].n] = 3. * k3Dihed / 2 - k1Dihed / 2;
                        dihedral[itmp3].k2[dihedral[itmp3].n] = -2 * k2Dihed;
                        dihedral[itmp3].k3[dihedral[itmp3].n] = -6 * k3Dihed;
                        //4th atom
                        dihedral[itmp4].n++;
                        if (dihedral[itmp4].n > maxNear14)
                        {
                            printf("ERROR: Too many dihedrals for atom %d\n", itmp4);
                            fprintf(logfile, "ERROR: Too many dihedrals for atom %d\n", itmp4);
                            exit(1);
                        }
                        dihedral[itmp4].atom2[dihedral[itmp4].n] = itmp3;
                        dihedral[itmp4].atom3[dihedral[itmp4].n] = itmp2;
                        dihedral[itmp4].atom4[dihedral[itmp4].n] = itmp1;
                        dihedral[itmp4].type[dihedral[itmp4].n] = 0;         //outer atom
                        dihedral[itmp4].k1[dihedral[itmp4].n] = 3. * k3Dihed / 2 - k1Dihed / 2;
                        dihedral[itmp4].k2[dihedral[itmp4].n] = -2 * k2Dihed;
                        dihedral[itmp4].k3[dihedral[itmp4].n] = -6 * k3Dihed;
                    }
                }
            }
        }
    }

    AssignLJ(atom, nAtomProtein, atomtypes, nAtomtypes, LJtype, nLJtype);             //for protein atoms
    AssignLJ(atomWater, nAtomWater, atomtypes, nAtomtypes, LJtype, nLJtype);          //for water atoms


    //determine atom numbers
    for (i = 1; i <= *nAtomProtein; i++)
    {
        atomNrExt2FPGA[i] = i;                                                //will be more sophisticated once contraints in protein are considered as well
        //atomNrFPGA2Ext[atomNrExt2FPGA[i]] = i;
    }

    for (i = 0; i < (*nWater); i++) for (j = 0; j < (*nAtomWater); j++)
    {
        //          printf("%d %d\n",i,j);
        atomNrExt2FPGA[(*nAtomProtein) + i * (*nAtomWater) + j + 1] = maxAtomProtein + i * 4 + j;
    }

    nAtomTot = (*nProtein) * (*nAtomProtein) + (*nWater) * (*nAtomWater);
    printf("\nFound %d molecule types\n", nMoleculetype);
    printf("Found %d protein atoms in protein\n", *nAtomProtein);
    printf("Found %d water atoms\n", *nAtomWater);
    printf("Found %d Lennard Jones types\n", *nLJtype);
    printf("Found %d bonds\n", nBond);
    printf("Found %d pairs\n", nPair);
    printf("Found %d angles\n", nAngle);
    printf("Found %d dihedrals\n", nDihedral);
    printf("\nContains %d proteins and %d waters\n", *nProtein, *nWater);
    printf("Total number of Atoms: %d\n", nAtomTot);
    fprintf(logfile, "\nFound %d molecule types\n", nMoleculetype);
    fprintf(logfile, "Found %d protein atoms in protein\n", *nAtomProtein);
    fprintf(logfile, "Found %d water atoms\n", *nAtomWater);
    fprintf(logfile, "Found %d Lennard Jones types\n", *nLJtype);
    fprintf(logfile, "Found %d bonds\n", nBond);
    fprintf(logfile, "Found %d pairs\n", nPair);
    fprintf(logfile, "Found %d angles\n", nAngle);
    fprintf(logfile, "Found %d dihedrals\n", nDihedral);
    fprintf(logfile, "\nContains %d proteins and %d waters\n", *nProtein, *nWater);
    fprintf(logfile, "Total number of Atoms: %d\n", nAtomTot);

    

    printf("\n\n+-------------------+\n|LENNARD JONES TYPES|\n+-------------------+\nLJtype:   sigma     epsilon\n");
    fprintf(logfile, "\n\n+-------------------+\n|LENNARD JONES TYPES|\n+-------------------+\nLJtype:   sigma     epsilon\n");
    for (i = 0;i < *nLJtype;i++)
    {
        if (LJtype[i].epsilon == 0) LJtype[i].sigma = rLJ_ref;                       //epsilon of HW is 0 in some water models and then sigma as well. Would cause an error once 1/sigma^2 is written to FPGA 
        printf("    %2d  %3s:  %8.5f  %8.5f\n", i, LJtype[i].type, LJtype[i].sigma, LJtype[i].epsilon);
        fprintf(logfile, "    %2d  %3s:  %8.5f  %8.5f\n", i, LJtype[i].type, LJtype[i].sigma, LJtype[i].epsilon);
    }


    printf("\n\n+-----------------------+\n|PROTEIN ATOM PROPERTIES|\n+-----------------------+\natom Nr.:  type  mass  charge    LJ-type\n");
    fprintf(logfile, "\n\n+-----------------------+\n|PROTEIN ATOM PROPERTIES|\n+-----------------------+\natom Nr.:  type  mass  charge    LJ-type\n");
    qtot = 0;
    for (iAtom = 1;iAtom <= *nAtomProtein;iAtom++)
    {
        qtot += atom[iAtom].charge;
        printf("     %3d:    %2s    %2d   %7.4f   %2d\n", iAtom, atom[iAtom].type, atom[iAtom].mass, atom[iAtom].charge, atom[iAtom].LJtype);
        fprintf(logfile, "     %3d:    %2s    %2d   %7.4f   %2d\n", iAtom, atom[iAtom].type, atom[iAtom].mass, atom[iAtom].charge, atom[iAtom].LJtype);
    }
    printf("Total protein charge %6.3f\n", qtot);
    fprintf(logfile,"Total protein charge %6.3f\n", qtot);

    printf("\n\n+---------------------+\n|WATER ATOM PROPERTIES|\n+---------------------+\natom Nr.:  type  mass  charge    LJ-type\n");
    fprintf(logfile, "\n\n+---------------------+\n|WATER ATOM PROPERTIES|\n+---------------------+\natom Nr.:  type  mass  charge    LJ-type\n");
    for (iAtom = 1;iAtom <= *nAtomWater;iAtom++)
    {
        printf("     %3d:    %2s    %2d   %7.4f   %2d\n", iAtom, atomWater[iAtom].type, atomWater[iAtom].mass, atomWater[iAtom].charge, atomWater[iAtom].LJtype);
        fprintf(logfile, "     %3d:    %2s    %2d   %7.4f   %2d\n", iAtom, atomWater[iAtom].type, atomWater[iAtom].mass, atomWater[iAtom].charge, atomWater[iAtom].LJtype);
    }

    printf("\n\n+----------------+\n|SHAKE Parameters|\n+----------------+\nwater: r0H     rHH\n");
    printf("       %6.4f  %6.4f\n", (*shake).rOHw, (*shake).rHHw);
    fprintf(logfile, "\n\n+----------------+\n|SHAKE Parameters|\n+----------------+\nwater: r0H     rHH\n");
    fprintf(logfile, "       %6.4f  %6.4f\n", (*shake).rOHw, (*shake).rHHw);


    printf("\n\n+--------------+\n|EXCLUSION LIST|\n+--------------+\n");
    fprintf(logfile, "\n\n+--------------+\n|EXCLUSION LIST|\n+--------------+\n");

    FindNear14(near14, bond, nAtomProtein, simParam);

    //mark atoms that are in pair list. That is done in addition to FindNear14, where this is set already. might want to add switch gen-pairs in FindNear14, in which case it should do 
//what Gromacs seems to do.
    for (iAtom = 1;iAtom <= *nAtomProtein;iAtom++) for (j = 1;j <= near14[iAtom].n;j++) if(inPairQ(pair[iAtom], near14[iAtom].atom[j])) near14[iAtom].type[j] = 1;

    printf("atom Nr.: exclusion of 1-4 interactions; atoms listed as pairs are marked with (1)\n");
    fprintf(logfile, "atom Nr.: exclusion of 1-4 interactions; atoms listed as pairs are marked with (1)\n");
    itmp = 0;
    for (iAtom = 1;iAtom <= *nAtomProtein;iAtom++)
    {
        if (near14[iAtom].n > itmp)
        {
            itmp = near14[iAtom].n;
            itmp1 = iAtom;
        }
        printf("     %3d: ", iAtom);
        fprintf(logfile, "     %3d: ", iAtom);
        for (j = 1;j <= near14[iAtom].n;j++)
        {
            printf("%3d(%1d) ", near14[iAtom].atom[j], near14[iAtom].type[j]);
            fprintf(logfile, "%3d(%1d) ", near14[iAtom].atom[j], near14[iAtom].type[j]);
        }
        printf("\n");
        fprintf(logfile, "\n");
    }
    printf("Largest number of atoms within 3 bonds: %d for atom: %d\n", itmp, itmp1);
    fprintf(logfile, "Largest number of atoms within 3 bonds: %d for atom: %d\n", itmp, itmp1);


    printf("\n\n+-----+\n|BONDS|\n+-----+\n");
    printf("atom Nr.: bonded to atom\n");
    fprintf(logfile, "\n\n+-----+\n|BONDS|\n+-----+\n");
    fprintf(logfile, "atom Nr.: bonded to atom\n");
    itmp = 0;
    for (iAtom = 1;iAtom <= *nAtomProtein;iAtom++)
    {
        printf("     %3d: ", iAtom);
        fprintf(logfile, "     %3d: ", iAtom);
        for (j = 1;j <= bond[iAtom].n;j++)
        {
            itmp2 = inNear14P(near14[iAtom], bond[iAtom].atom[j]);
            if (itmp2 == 0) 
            { 
                printf("\nERROR: angle atom %d is not among 1-4 atoms\n", bond[iAtom].atom[j]);
                fprintf(logfile, "\nERROR: angle atom %d is not among 1-4 atoms\n", bond[iAtom].atom[j]);
                exit(1); 
            }
            bond[iAtom].atom[j] = itmp2;               //relable atom number so that it is the entry in the closeAtom list
            printf("(%2d|%6.4f|%6.0f) ", bond[iAtom].atom[j], bond[iAtom].r0[j], bond[iAtom].k[j]);
            fprintf(logfile, "(%2d|%6.4f|%6.0f) ", bond[iAtom].atom[j], bond[iAtom].r0[j], bond[iAtom].k[j]);
        }
        printf("\n");
        fprintf(logfile, "\n");
    }

    //exit(1);

    printf("\n\n+------+\n|ANGLES|\n+------+\natom Nr.:\n");
    fprintf(logfile, "\n\n+------+\n|ANGLES|\n+------+\natom Nr.:\n");
    itmp = 0;
    for (iAtom = 1;iAtom <= *nAtomProtein;iAtom++)
    {
        if (angle[iAtom].n > itmp)
        {
            itmp = angle[iAtom].n;
            itmp1 = iAtom;
        }
        printf("     %3d: ", iAtom);
        fprintf(logfile, "     %3d: ", iAtom);
        for (j = 1;j <= angle[iAtom].n;j++)
        {
            itmp2 = inNear14P(near14[iAtom], angle[iAtom].atom2[j]);
            if (itmp2 == 0) 
            { 
                printf("\nERROR: angle atom %d is not among 1-4 atoms\n", angle[iAtom].atom2[j]);
                fprintf(logfile, "\nERROR: angle atom %d is not among 1-4 atoms\n", angle[iAtom].atom2[j]);
                exit(1); 
            }
            angle[iAtom].atom2[j] = itmp2;
            itmp2 = inNear14P(near14[iAtom], angle[iAtom].atom3[j]);
            if (itmp2 == 0) 
            { 
                printf("\nERROR: angle atom %d is not among 1-4 atoms\n", angle[iAtom].atom3[j]);
                fprintf(logfile, "\nERROR: angle atom %d is not among 1-4 atoms\n", angle[iAtom].atom3[j]);
                exit(1); 
            }
            angle[iAtom].atom3[j] = itmp2;
            printf(" %2d|%2d|%1d|%5.1f|%5.1f ||", angle[iAtom].atom2[j], angle[iAtom].atom3[j], angle[iAtom].type[j], angle[iAtom].phi0[j], angle[iAtom].k[j]);
            fprintf(logfile, " %2d|%2d|%1d|%5.1f|%5.1f ||", angle[iAtom].atom2[j], angle[iAtom].atom3[j], angle[iAtom].type[j], angle[iAtom].phi0[j], angle[iAtom].k[j]);
            if (j < angle[iAtom].n && j % 6 == 0)
            {
                printf("\n          ");
                fprintf(logfile, "\n          ");
            }
        }
        printf("\n");
        fprintf(logfile, "\n");
    }
    printf("Largest number of angles: %d for atom: %d \n", itmp, itmp1);
    fprintf(logfile, "Largest number of angles: %d for atom: %d \n", itmp, itmp1);

    
    printf("\n\n+---------+\n|DIHEDRALS|\n+---------+\natom Nr.:\n");
    itmp=0;
    for(iAtom=1;iAtom<=*nAtomProtein;iAtom++) if(dihedral[iAtom].n >0)
    {
        if(dihedral[iAtom].n>itmp)
        {
           itmp=dihedral[iAtom].n;
           itmp1=iAtom;
        }
        printf("     %3d: ",iAtom);
        fprintf(logfile,"     %3d: ", iAtom);
        for(j=1;j<=dihedral[iAtom].n;j++)
        {
            itmp2=inNear14P(near14[iAtom],dihedral[iAtom].atom2[j]);
            if(itmp2==0) {printf("\nERROR: dihedral atom %d is not among 1-4 atoms\n",dihedral[iAtom].atom2[j]);exit(1);}
            dihedral[iAtom].atom2[j]=itmp2;
            itmp2=inNear14P(near14[iAtom],dihedral[iAtom].atom3[j]);
            if(itmp2==0) {printf("\nERROR: dihedral atom %d is not among 1-4 atoms\n",dihedral[iAtom].atom3[j]);exit(1);}
            dihedral[iAtom].atom3[j]=itmp2;
            itmp2=inNear14P(near14[iAtom],dihedral[iAtom].atom4[j]);
            if(itmp2==0) {printf("\nERROR: dihedral atom %d is not among 1-4 atoms\n",dihedral[iAtom].atom4[j]);exit(1);}
            dihedral[iAtom].atom4[j]=itmp2;
            printf(" %3d,%3d,%3d|%1d|%5.1f,%5.1f,%5.1f || ",dihedral[iAtom].atom2[j],dihedral[iAtom].atom3[j],dihedral[iAtom].atom4[j],dihedral[iAtom].type[j],dihedral[iAtom].k1[j], dihedral[iAtom].k2[j], dihedral[iAtom].k3[j]);
            fprintf(logfile," %3d,%3d,%3d|%1d|%5.1f,%5.1f,%5.1f || ", dihedral[iAtom].atom2[j], dihedral[iAtom].atom3[j], dihedral[iAtom].atom4[j], dihedral[iAtom].type[j], dihedral[iAtom].k1[j], dihedral[iAtom].k2[j], dihedral[iAtom].k3[j]);
            if (j < dihedral[iAtom].n && j % 4 == 0)
            {
               printf("\n          ");
               fprintf(logfile,"\n          ");
            }
        }
        printf("\n");
        fprintf(logfile,"\n");
    }
    printf("Largest number of dihedrals: %d for atom: %d \n",itmp,itmp1);
}