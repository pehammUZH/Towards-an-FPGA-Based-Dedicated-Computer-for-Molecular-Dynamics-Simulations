//***********************************************************************************************************************************************************************************
//******************************************************           Communication with FPGA Bodes   **********************************************************************************
//***********************************************************************************************************************************************************************************

#include "MDcontrol.h"

extern FILE* logfile;
extern float dt, rcut;

//Read Staus and/or reset nodes
int ReadStatus(uint8_t* inbuff, int iNode, uint8_t Reset, sockaddr_in* dest, SOCKET sock, uint8_t* PacketNr)
{
    uint32_t itmp, j;
    uint8_t outbuff[100];
    FD_SET ReadSet;
    struct timeval TimeOut;
    int destSize = sizeof(*dest);
    TimeOut.tv_sec = 0;
    TimeOut.tv_usec = 200000;
    int err = 0;
    int ReadError = 0;

    if (Reset % 2 != 0) PacketNr[iNode] = 1;    //initialize 
    else              PacketNr[iNode]++;

    do
    {
        ReadError = 0;
        outbuff[0] = PacketNr[iNode];
        outbuff[1] = 0;
        outbuff[2] = Reset;         //reset forcefield count (bit 3), MD (bit 2), nAtom (bit 1) and Errors (bit 0)
        sendto(sock, (char*)outbuff, 3, 0, (sockaddr*)&dest[iNode], sizeof(*dest));


        FD_ZERO(&ReadSet);
        FD_SET(sock, &ReadSet);
        if (select(NULL, &ReadSet, NULL, NULL, &TimeOut) < 1)
        {
            printf("\nWARNING in ReadStatus: Node %d not responding; repeat\n", iNode);
            fprintf(logfile, "\nWARNING in ReadStatus: Node %d not responding; repeat\n", iNode);
            ReadError = 1;
        }
        else
        {
            itmp = recvfrom(sock, (char*)inbuff, 100, 0, (sockaddr*)&dest[iNode], &destSize);
            //           printf("Node %2d: received %d data\n", iNode, itmp);
        }
    } while (ReadError == 1);

    err = CheckError(inbuff, PacketNr[iNode], iNode);
    return(err);
}


/********************************************************************************************/
//Set thermostat

int SetThermostat(param_t simParam, float mtot, int natom, int iNode, sockaddr_in* dest, SOCKET sock, uint8_t* PacketNr)
{
    int i;
    uint32_t itmp, j;
    uint8_t outbuff[100];
    uint8_t inbuff[100];
    FD_SET ReadSet;
    struct timeval TimeOut;
    int destSize = sizeof(*dest);
    TimeOut.tv_sec = 0;
    TimeOut.tv_usec = 200000;
    int err = 0;
    int ReadError = 0;
    float Tref_inv;
    float Tconv;
    int tau_vcm;
    
    Tconv = m_ref / (3 * NA * 1E3) * simParam.rcut * simParam.rcut / (simParam.dt * simParam.dt) * 1E12 / kB / 128;

    Tref_inv = simParam.Tref / Tconv * natom;


    Tref_inv = 1 / Tref_inv;
    tau_vcm = floor(log(mtot) / log(2.)-7);
    if (tau_vcm < 1) tau_vcm = 1;
  //  printf("mtot = %f, tau_vcm:%d\n", mtot, tau_vcm);

    do
    {
        ReadError = 0;
        PacketNr[iNode]++;
        outbuff[0] = PacketNr[iNode];
        outbuff[1] = 3;                             //command for writing themostat data
        outbuff[2] = 0;                             //not used
        outbuff[3] = 0;                             //not used
        outbuff[4] = tau_vcm;                   //tau_vcm; is internally already divided by 2^8, times 2^tau_vcm. Division should be larger than mtot 
        if (simParam.Tcoupl == 0)
            outbuff[5] = 0;                           //T_tau; when set to 0, it is switched off
        else
            outbuff[5] = simParam.tauT;
        float_int32_pm8(Tref_inv, &outbuff[6]);     //inverse reference temperature in internal units

        //        printf("%02x %02x %02x %02x:   ", outbuff[6], outbuff[7], outbuff[8], outbuff[9]);
        outbuff[10] = 0;                            //not used
        float_int24_p1(1. / Tref_inv, &outbuff[11]); //initial value of temperature in internal units. When read from previous MD run, should be exactly restartable (not tested). 
        //When set to 1/Tref_inv, no velocity scaling for the first MD step
//       printf("%02x %02x %02x\n", outbuff[11], outbuff[12], outbuff[13]);
        float_int32_pm1(0, &outbuff[14]);           //vzcm; when read from previous MD run, should be exactly restartable (not tested).
        float_int32_pm1(0, &outbuff[18]);           //vycm; when read from previous MD run, should be exactly restartable (not tested).
        float_int32_pm1(0, &outbuff[22]);           //vxcm; when read from previous MD run, should be exactly restartable (not tested).
        sendto(sock, (char*)outbuff, 6 * 4 + 2, 0, (sockaddr*)&dest[iNode], sizeof(*dest));

        FD_ZERO(&ReadSet);
        FD_SET(sock, &ReadSet);
        if (select(NULL, &ReadSet, NULL, NULL, &TimeOut) < 1)
        {
            printf("\nWARNING in SetThermostat: Node %d not responding; repeat\n", iNode);
            fprintf(logfile, "\nWARNING in SetThermostat: Node %d not responding; repeat\n", iNode);
            ReadError = 1;
        }
        else
        {
            itmp = recvfrom(sock, (char*)inbuff, 100, 0, (sockaddr*)&dest[iNode], &destSize);
        }
    } while (ReadError == 1);

    err = CheckError(inbuff, PacketNr[iNode], iNode);
    return(err);
}

/*********************************************************************************/
int SetSimParam(shake_t shake, param_t simParam, int iNode, sockaddr_in* dest, SOCKET sock, uint8_t* PacketNr)
{
    int i;
    uint32_t itmp, j;
    uint8_t outbuff[100];
    uint8_t inbuff[100];
    FD_SET ReadSet;
    struct timeval TimeOut;
    int destSize = sizeof(*dest);
    TimeOut.tv_sec = 0;
    TimeOut.tv_usec = 200000;
    int err = 0;
    int ReadError = 0;

    do
    {
        ReadError = 0;
        PacketNr[iNode]++;
        outbuff[0] = PacketNr[iNode];
        outbuff[1] = 4;                             //command for writing shake paramters
        outbuff[2] = 0;                             //not used
        outbuff[3] = 0;                             //not used
        outbuff[4] = 15;                            //shake accuracy
       // printf("%7.5f %7.5f %7.5f\n", simParam.rcut, shake.rOHw, shake.rHHw);
        float_int18_pm2(simParam.rcut * simParam.rcut / shake.rOHw / shake.rOHw / 256, &outbuff[5]);          //ir2_OHw
        float_int18_pm2(simParam.rcut * simParam.rcut / shake.rHHw / shake.rHHw / 256, &outbuff[8]);          //ir2_HHw
        float_int18_pm2(simParam.rcut * simParam.rcut / shake.rCH / shake.rCH / 256, &outbuff[11]);           //ir2_CH
        float_int18_pm2(simParam.rcut * simParam.rcut / shake.rOH / shake.rOH / 256, &outbuff[14]);           //ir2_OH
        float_int18_pm2(simParam.rcut * simParam.rcut / shake.rNH / shake.rNH / 256, &outbuff[17]);           //ir2_NH
        float_int18_pm2(simParam.rcut * simParam.rcut / shake.rSH / shake.rSH / 256, &outbuff[20]);           //ir2_SH
        float_int18_pm2(simParam.fudgeQQ, &outbuff[23]);                                                      //fudgeQQ
        outbuff[26] = 0;                                                                                      //not used
        outbuff[27] = 0;                                                                                      //not used
        if (simParam.fudgeLJ == 1) outbuff[28] = 1; else outbuff[28] = 0;                                     //fudgeLJ factor either 1 or 0.5, indicated by one bit
       
        sendto(sock, (char*)outbuff, 9 * 3 + 2, 0, (sockaddr*)&dest[iNode], sizeof(*dest));

        FD_ZERO(&ReadSet);
        FD_SET(sock, &ReadSet);
        if (select(NULL, &ReadSet, NULL, NULL, &TimeOut) < 1)
        {
            printf("\nWARNING in SetSimParam: Node %d not responding; repeat\n", iNode);
            fprintf(logfile, "\nWARNING in SetSimParam: Node %d not responding; repeat\n", iNode);
            ReadError = 1;
        }
        else
        {
            itmp = recvfrom(sock, (char*)inbuff, 100, 0, (sockaddr*)&dest[iNode], &destSize);
        }
    } while (ReadError == 1);

    err = CheckError(inbuff, PacketNr[iNode], iNode);
    return(err);
}




/*********************************************************************************/
//write nonbonded force LUT
void     WriteNonBondForceLUT(param_t simParam, int iNode, LJtype_t *LJtype, int nLJtype, sockaddr_in* dest, SOCKET sock, uint8_t* PacketNr)
{
    float       f0, f1, f2, a0, a1, a2, rLJ_rel, eLJ_rel, rLJ, eLJ;
    int         i1, i2, i, itmp, f0s, f2s;
    FILE* LUTforce;
    uint8_t outbuff[1500];
    uint8_t inbuff[100];
    uint32_t tmp32;
    int destSize = sizeof(*dest);
    FD_SET ReadSet;
    struct timeval TimeOut;
    TimeOut.tv_sec = 0;
    TimeOut.tv_usec = 200000;
    int err;

    //write LJ-LUT
    for (i = 0, i1 = 0; i1 < 4; i1++)
    {
        PacketNr[iNode]++;
        outbuff[0] = PacketNr[iNode];
        outbuff[1] = 2;          //command
        outbuff[2] = i1 * 4;       //start adress MSB
        outbuff[3] = 0;          //start adress LSB
        outbuff[4] = 128;        //number of lines written per block
        outbuff[5] = 8;          //number of 9bit words per line, number of 8bit data will be one more
        outbuff[6] = 0;          //select; 0: Lennard Jones; 1: Coulomb
        for (i2 = 0; i2 < 128; i2++, i++)
        {
            f0 = v_shift * LennardJones((float)i / 512, simParam);
            f1 = v_shift * LennardJones(((float)i + .5) / 512, simParam);
            f2 = v_shift * LennardJones(((float)i + 1) / 512, simParam);
            if (fabs(f0) > .999) { f0 = sign(f0) * .999; }
            if (fabs(f1) > .999)  f1 = sign(f1) * .999;
            if (fabs(f2) > .999) { f2 = sign(f2) * .999; }
            if (i == 0) { f1 = f0; f2 = f0; }
            if (i == 511) { f2 = 0; f1 = f0 / 2; }
            if (fabs(f0) > .3)
            {
                //initially, linear interpolation only; otherwise, it explodes
                a0 = f0;
                a1 = f2 - f0;
                a2 = 0;
            }
            else
            {
                //quadratic interpolation
                a0 = f0;
                a1 = 4 * f1 - f2 - 3 * f0;
                a2 = 2 * (f2 + f0) - 4 * f1;
            }
            float_int24_pm1(a0, &outbuff[7 + i2 * 9 + 0]);
            float_int24_pm1(a1, &outbuff[7 + i2 * 9 + 3]);
            float_int24_pm1(a2, &outbuff[7 + i2 * 9 + 6]);
            //                 printf("%3d  %10.7f %10.7f %10.7f: %02X %02X %02X %02X %02X %02X %02X %02X %02X\n", i, a0, a1, a2, outbuff[4+i2*9+0], outbuff[4+i2*9+1], outbuff[4+i2*9+2], outbuff[4+i2*9+3], outbuff[4+i2*9+4], outbuff[4+i2*9+5], outbuff[4+i2*9+6], outbuff[4+i2*9+7], outbuff[4+i2*9+8]);
           //                 fprintf(LUTforce, "%02X %02X %02X %02X %02X %02X %02X %02X %02X\n", outbuff[4+i2*9+0], outbuff[4+i2*9+1], outbuff[4+i2*9+2], outbuff[4+i2*9+3], outbuff[4+i2*9+4], outbuff[4+i2*9+5], outbuff[4+i2*9+6], outbuff[4+i2*9+7], outbuff[4+i2*9+8]);
        }
        sendto(sock, (char*)outbuff, 7 + 128 * 9, 0, (sockaddr*)&dest[iNode], sizeof(*dest));

        FD_ZERO(&ReadSet);
        FD_SET(sock, &ReadSet);
        if (select(NULL, &ReadSet, NULL, NULL, &TimeOut) < 1)
        {
            printf("ERROR in WriteForceLUT: Node %d not responding\n", iNode);
            fprintf(logfile, "ERROR in WriteForceLUT: Node %d not responding\n", iNode);
            exit(1);
        }
        else
        {
            itmp = recvfrom(sock, (char*)inbuff, 100, 0, (sockaddr*)&dest[iNode], &destSize);
            err = CheckError(inbuff, PacketNr[iNode], iNode);
        }
    }

    //write Coul-LUT 
    for (i = 0, i1 = 0; i1 < 4; i1++)
    {
        PacketNr[iNode]++;
        outbuff[0] = PacketNr[iNode];
        outbuff[1] = 2;          //command
        outbuff[2] = i1 * 4;     //start adress MSB
        outbuff[3] = 0;          //start adress LSB
        outbuff[4] = 128;        //number of lines written per block
        outbuff[5] = 8;          //number of 9bit words per line, number of 8bit data will be one more
        outbuff[6] = 1;          //select; 0: Lennard Jones; 1: Coulomb
        for (i2 = 0; i2 < 128; i2++, i++)
        {
            f0 = v_shift * Coulomb((float)i / 512, simParam);
            f1 = v_shift * Coulomb(((float)i + .5) / 512, simParam);
            f2 = v_shift * Coulomb(((float)i + 1) / 512, simParam);
            if (fabs(f0) > .999) { f0 = sign(f0) * .999; }
            if (fabs(f1) > .999)  f1 = sign(f1) * .999;
            if (fabs(f2) > .999) { f2 = sign(f2) * .999; }
            if (i == 0) { f1 = f0; f2 = f0; }
            if (i == 511) { f2 = 0; f1 = f0 / 2; }
            if (fabs(f0) > .3)
            {
                //initially, linear interpolation only; otherwise, it explodes
                a0 = f0;
                a1 = f2 - f0;
                a2 = 0;
            }
            else
            {
                //quadratic interpolation
                a0 = f0;
                a1 = 4 * f1 - f2 - 3 * f0;
                a2 = 2 * (f2 + f0) - 4 * f1;
            }
            float_int24_pm1(a0, &outbuff[7 + i2 * 9 + 0]);
            float_int24_pm1(a1, &outbuff[7 + i2 * 9 + 3]);
            float_int24_pm1(a2, &outbuff[7 + i2 * 9 + 6]);
            //                 printf("%3d  %10.7f %10.7f %10.7f: %02X %02X %02X %02X %02X %02X %02X %02X %02X\n", i, a0, a1, a2, outbuff[4+i2*9+0], outbuff[4+i2*9+1], outbuff[4+i2*9+2], outbuff[4+i2*9+3], outbuff[4+i2*9+4], outbuff[4+i2*9+5], outbuff[4+i2*9+6], outbuff[4+i2*9+7], outbuff[4+i2*9+8]);
           //                 fprintf(LUTforce, "%02X %02X %02X %02X %02X %02X %02X %02X %02X\n", outbuff[4+i2*9+0], outbuff[4+i2*9+1], outbuff[4+i2*9+2], outbuff[4+i2*9+3], outbuff[4+i2*9+4], outbuff[4+i2*9+5], outbuff[4+i2*9+6], outbuff[4+i2*9+7], outbuff[4+i2*9+8]);
        }
        sendto(sock, (char*)outbuff, 7 + 128 * 9, 0, (sockaddr*)&dest[iNode], sizeof(*dest));

        FD_ZERO(&ReadSet);
        FD_SET(sock, &ReadSet);
        if (select(NULL, &ReadSet, NULL, NULL, &TimeOut) < 1)
        {
            printf("ERROR in WriteForceLUT: Node %d not responding\n", iNode);
            fprintf(logfile, "ERROR in WriteForceLUT: Node %d not responding\n", iNode);
            exit(1);
        }
        else
        {
            itmp = recvfrom(sock, (char*)inbuff, 100, 0, (sockaddr*)&dest[iNode], &destSize);
            err = CheckError(inbuff, PacketNr[iNode], iNode);
        }
    }


    //write atomType data; 
    for (i1 = 0;i1 < nLJtype;i1++)
    {
        PacketNr[iNode]++;
        outbuff[0] = PacketNr[iNode];
        outbuff[1] = 2;                   //command
        tmp32 = i1 * maxLJtype * 4;     //start adress; each line is 4*9bit
        outbuff[3] = tmp32 % 0x100;       //start adress LSB
        tmp32 /= 0x100;
        outbuff[2] = tmp32 % 0x100;         //start adress MSB
        outbuff[4] = nLJtype;           //number of lines written per block
        outbuff[5] = 4;                   //number of 9bit words per line, number of 8bit data will be one more
        outbuff[6] = 3;                   //select; 3: atomTypeLUT

        for (i2 = 0;i2 < nLJtype;i2++)
        {
            rLJ = (LJtype[i1].sigma + LJtype[i2].sigma) / 2;  //might replace combination rules by explicit matrix
            eLJ = sqrt(LJtype[i1].epsilon * LJtype[i2].epsilon);
 //           printf("%2d %2d: %7.5f %7.5f: %7.5f %7.5f\n",i1, i2, LJtype[i1].sigma, LJtype[i2].sigma, rLJ, eLJ);
            rLJ_rel = rLJ_ref * rLJ_ref / rLJ / rLJ;
            if (rLJ_rel >= 8) 
            {   
                if (iNode == 0)
                {
                    printf("Warning: rLJ=%6.4f too small;", rLJ);
                    fprintf(logfile, "Warning: rLJ=%6.4f too small;", rLJ);
                }
                exit(1); 
/*
                rLJ = rLJ_ref / sqrt(8) * 1.001;
                rLJ_rel = rLJ_ref * rLJ_ref / rLJ / rLJ;
                if (iNode == 0)
                { 
                    printf(" replaced by rLJ=%6.4f.\n", rLJ);
                    fprintf(logfile, " replaced by rLJ=%6.4f.\n", rLJ);
                }
*/
            }
            tmp32 = rLJ_rel * 0x04000;                                    //equals to 1 for r2 scaling; unsigned 17bit number, so range 0....8
            outbuff[i2 * 5 + 11] = tmp32 % 0x100;
            tmp32 /= 0x100;
            outbuff[i2 * 5 + 10] = tmp32 % 0x100;
            tmp32 /= 0x100;
            outbuff[i2 * 5 + 9] = (tmp32 % 0x100) & 0x3;                   //only lowest 2 bits considered, so 18 bits in total
            eLJ_rel = eLJ / eLJ_ref * rLJ_ref / rLJ;
            if (eLJ_rel >= 2) { printf("Error: eLJ too large"); fprintf(logfile, "Error: eLJ too large"); exit(1); }
            tmp32 = eLJ_rel * 0x10000;                        //0x10000 equals to 1 for eLJ scaling, unsigned 17bit number, so range 0....2
            tmp32 = tmp32 << 2;                               //shift 2 up to accomodate the 18bit of rLJ
            outbuff[i2 * 5 + 9] = (tmp32 % 0x100) | outbuff[i2 * 5 + 9];
            tmp32 /= 0x100;
            outbuff[i2 * 5 + 8] = tmp32 % 0x100;
            tmp32 /= 0x100;
            outbuff[i2 * 5 + 7] = tmp32 % 0x100;
        }

        sendto(sock, (char*)outbuff, 7 + 5 * nLJtype, 0, (sockaddr*)&dest[iNode], sizeof(*dest));

        FD_ZERO(&ReadSet);
        FD_SET(sock, &ReadSet);
        if (select(NULL, &ReadSet, NULL, NULL, &TimeOut) < 1)
        {
            printf("ERROR in WriteForceLUT: Node %d not responding\n", iNode);
            fprintf(logfile, "ERROR in WriteForceLUT: Node %d not responding\n", iNode);
            exit(1);
        }
        else
        {
            itmp = recvfrom(sock, (char*)inbuff, 100, 0, (sockaddr*)&dest[iNode], &destSize);
            err = CheckError(inbuff, PacketNr[iNode], iNode);
        }
    }
}

/****************************************************************************************************************************************/
//calculate Lennard Jones force prefactor in internal units; will be written to FPGA, and is also needed when internal MD is run
float LennardJones(float r2, param_t simParam)
{
    //r2 is in internal units
    float f, r6, r8, eLJ_ul, rLJ_ul;

    rLJ_ul = rLJ_ref / simParam.rcut;
    eLJ_ul = eLJ_ref * 1E6 * 1E-12 * simParam.dt * simParam.dt / simParam.rcut / simParam.rcut / m_ref; //eLJ is in  kJ/mol -> eLJ/mu=0.65*10^6 m^2/s^2 -> 0.65*10^-6 dt^2/rcut [in rcut/dt^2] 
    r6 = r2 * r2 * r2;
    r8 = r6 * r2;
    f = 0;

    if (r2 == 0) f = 0;
    else if (r2 < 1)
    {
        f = 24. * eLJ_ul * rLJ_ul * rLJ_ul * rLJ_ul * rLJ_ul * rLJ_ul * rLJ_ul * (1. - 2. * rLJ_ul * rLJ_ul * rLJ_ul * rLJ_ul * rLJ_ul * rLJ_ul / r6) / r8;
    }
    else f = 0;

    return(f);
}


/*********************************************************************************/
float Coulomb(float r2, param_t simParam)
{
    //r2 in internal units

    float f, r3, V0_intunit;

    V0_intunit = e * e / (4 * PI * e0) / simParam.rcut * 1E12 * NA * 1E-12 * simParam.dt * simParam.dt / simParam.rcut / simParam.rcut / m_ref;
    //V0=1/4pie0 e^2/rcut is energy in J=kgm^2/s^2 -> multiplied with 1E3*NA is V0/mu in m^2/s^2
    //->multiplied with 1E-12*dt^2/rcut^2 is V0/mu in internal units. As for LJ, do everything 
    // for heaviest atom O, other masses have to be rescaled accordingly. 
    r3 = r2 * sqrt(r2);

    if (r2 == 0) f = 0;
    else if (r2 < 1)
    {
        f = -V0_intunit * (1 / r3 - 1);  //second term is reaction field
    }
    else f = 0;

    return(f);
}


/*********************************************************************************/
//write force field data
void  WriteForceField(int iNode, int* atomNrExt2FPGA, near14_t* near14, angle_t* angle, bond_t* bond, dihedral_t *dihedral, param_t simParam, int nProteinAtom, sockaddr_in* dest, SOCKET sock, uint8_t* PacketNr)
{
    int iAtom1,i1,i2,i,itmp,err;
    uint8_t outbuff[1500];
    uint8_t inbuff[100];
    FD_SET ReadSet;
    struct timeval TimeOut;
    TimeOut.tv_sec = 0;
    TimeOut.tv_usec = 200000;
    int destSize = sizeof(*dest);
    /*
    int r0Stretch = 50267;    //for flexible water, step size 1fs
    int kStretch = 7422;
    int phi0Bend = 79714;
    int kBend = 2836;
    */

    int r0Stretch;    
    int kStretch ;
    int phi0Bend ;
    int kBend ;
    float k1Dihed, k2Dihed, k3Dihed;


// send empty force field block for hypothetical atom with atomNr1=0; not really tested yet 
    PacketNr[iNode]++;
    outbuff[0] = PacketNr[iNode];
    outbuff[1] = 5;                               //command
    outbuff[2] = 0;                               //atomNr MSB    
    outbuff[3] = 0;                               //atomNr LSB
    for (i1 = 0, i = 4;i1 < FF_LENGTH;i1++) for (i2 = 0; i2 < DDR3_DATA_WIDTH / 8;i2++) {outbuff[i] = 0; i++; }  //empty

    sendto(sock, (char*)outbuff, 4 + DDR3_DATA_WIDTH / 8 * FF_LENGTH, 0, (sockaddr*)&dest[iNode], sizeof(*dest));
    FD_ZERO(&ReadSet);
    FD_SET(sock, &ReadSet);
    if (select(NULL, &ReadSet, NULL, NULL, &TimeOut) < 1)
    {
        printf("ERROR in WriteForceField: Node %d not responding\n", iNode);
        fprintf(logfile, "ERROR in WriteForceField: Node %d not responding\n", iNode);
        exit(1);
    }
    else
    {
        itmp = recvfrom(sock, (char*)inbuff, 100, 0, (sockaddr*)&dest[iNode], &destSize);
        err = CheckError(inbuff, PacketNr[iNode], iNode);
    }

//now, send force field of real atoms
    for (iAtom1 = 1; iAtom1 <= nProteinAtom; iAtom1++)
    {
        PacketNr[iNode]++;
        outbuff[0] = PacketNr[iNode];
        outbuff[1] = 5;                               //command
        outbuff[2] = atomNrExt2FPGA[iAtom1] / 0x100;   //atomNr MSB    
        outbuff[3] = atomNrExt2FPGA[iAtom1] % 0x100;   //atomNr LSB
        for (i1 = 0, i = 4;i1 < FF_LENGTH;i1++)       //loop over force field lines
        {
            if (i1 == 0)                                                //1st line of close Atoms
            {
                for (i2 = 0; i2 < DDR3_DATA_WIDTH/8;i2++) { outbuff[i] = 0; i++; }     //delete previous entries in line
                if (near14[iAtom1].n > 16) itmp = 16;
                else                       itmp = near14[iAtom1].n;
                for (i2 = 1; i2 <= itmp; i2++)                             
                {
                    outbuff[i - (i2 - 1) * 2 - 1] = (near14[iAtom1].atom[i2]) % 0x100;
                    outbuff[i - (i2 - 1) * 2 - 2] = (((near14[iAtom1].atom[i2]) / 0x100) & 0x7f) + near14[iAtom1].type[i2] * 0x80;  //near14-atom is 15bits maximum; highest bit indicates it is 3 bonds away
                }
            }
            else if (i1 == 1)                                           //2nd line for close Atoms
            {
                for (i2 = 0; i2 < DDR3_DATA_WIDTH / 8;i2++) { outbuff[i] = 0; i++; }       //for now assume near14[iAtom1].n<16, so 2nd line is empty
                if (near14[iAtom1].n > 16)
                {
                    for (i2 = 17; i2 <= near14[iAtom1].n; i2++)
                    {
                        outbuff[i - (i2 - 17) * 2 - 1] = (near14[iAtom1].atom[i2]) % 0x100;
                        outbuff[i - (i2 - 17) * 2 - 2] = (((near14[iAtom1].atom[i2]) / 0x100) & 0x7f) + near14[iAtom1].type[i2] * 0x80;  //near14-atom is 15bits maximum; highest bit indicates it is 3 bonds away
                    }
                }
            }

            else 
            {
                for (i2 = 0; i2 < DDR3_DATA_WIDTH / 8;i2++) { outbuff[i] = 0; i++; }     //delete previous entries in line
            //stretch forces
                if (i1 <= 1 + bond[iAtom1].n)
                {
                    r0Stretch = floor(bond[iAtom1].r0[i1 - 1] / simParam.rcut * 8 * 0x10000 + .5);                                 //17'h10000 corresponds to 1, defined relative to r_ref=rcut/8  
                    kStretch = floor(bond[iAtom1].k[i1 - 1] * v_shift * 1E-6 * simParam.dt * simParam.dt / m_ref * 0x2000 + .5);   //17'h02000 corresponds to 1, when k is given in kJ/mol, needs to be multiplied with vshift*(10^-6)*dt^2/m_ref 
                    // if (iNode == 0) printf("r0=%5.3f: %5d,  k=%8.1f: %5d\n", bond[iAtom1].r0[i1 - 1], r0Stretch, bond[iAtom1].k[i1 - 1], kStretch);
                    if (r0Stretch >= 0x20000)
                    {
                        printf("r0_Stretch too large\n");
                        fprintf(logfile,"r0_Stretch too large\n");
                        exit(1);
                    }
                    if (kStretch >= 0x20000)
                    {
                        printf("k_Stretch %6.0f too large\n", bond[iAtom1].k[i1 - 1]);
                        fprintf(logfile, "k_Stretch %6.0f too large\n", bond[iAtom1].k[i1 - 1]);
                        exit(1);
                    }
                    outbuff[i - 1] = bond[iAtom1].atom[i1 - 1] & 0x1f;     //max 5 bit for atom
                    outbuff[i - 1] = outbuff[i-1] +((r0Stretch % 4) << 6);         //upper two bit are the lower two bits of r0Stretch
                    outbuff[i - 2] = (r0Stretch/4)%0x100;
                    outbuff[i - 3] = (r0Stretch / 0x400) & 0x7f;            //max 7bits
                    outbuff[i - 3] = outbuff[i - 3] + ((kStretch % 2) << 7);  //upper bit is the lower bits kStretch 
                    outbuff[i - 4] = (kStretch / 2) % 0x100;
                    outbuff[i - 5] = (kStretch / 0x200);
                }
            //bend forces
                if (i1 <= 1 + angle[iAtom1].n)
                {
                    phi0Bend = floor(angle[iAtom1].phi0[i1 - 1] / 180 * 0x20000 + .5);                                                                              //range: 0....1 mapping onto 0...180�
                    kBend = floor (angle[iAtom1].k[i1 - 1] * v_shift * 1E-6 * simParam.dt * simParam.dt / m_ref / simParam.rcut / simParam.rcut * 128 * 0x10000 + .5);   //17'h10000 corresponds to 1/128, when k is given in kJ/mol/rad^2, needs to be multiplied with vshift*(10^-6)*dt^2/m_ref/rcut^2 
                    // if(iNode==0) printf("phi0=%5.1f: %5d,  k=%5.1f: %5d\n", angle[iAtom1].phi0[i1 - 1], phi0Bend, angle[iAtom1].k[i1 - 1], kBend);
                    if (phi0Bend >= 0x20000)
                    {
                        printf("phi0_Bend too large\n");
                        fprintf(logfile, "phi0_Bend too large\n");
                        exit(1);
                    }
                    if (kBend >= 0x20000)
                    {
                        printf("k_Bend too large\n");
                        fprintf(logfile, "k_Bend too large\n");
                        exit(1);
                    }
                    itmp = angle[iAtom1].atom3[i1 - 1] * 0x40 + angle[iAtom1].atom2[i1 - 1];                                    
                    outbuff[i - 6] = itmp % 0x100;
                    outbuff[i - 7] = (itmp / 0x100) & 0x0f;                                       //iatom'1 and iatom'2 together is 12 bits
                    itmp = phi0Bend << 4;                                       //shift up by 4 bit
                    outbuff[i - 7] = outbuff[i - 7] + itmp % 0x100;
                    itmp /= 0x100;
                    outbuff[i - 8] = itmp % 0x100;
                    itmp /= 0x100;
                    outbuff[i - 9] = (itmp % 0x100) & 0x1f;                   //5 bits into that byte 
                    itmp = kBend << 5;                                       //shift up by 5 bit
                    outbuff[i - 9] = outbuff[i - 9] + itmp % 0x100;
                    itmp /= 0x100;
                    outbuff[i - 10] = itmp % 0x100;
                    itmp /= 0x100;
                    outbuff[i - 11] = (itmp % 0x100) & 0x3f;                   //6 bits into that byte
                    if(angle[iAtom1].type[i1 - 1]==1) outbuff[i - 11] = outbuff[i - 11] + 0x80;   //is middle atom
                }
//dihedral forces
                if (i1 <= 1 + dihedral[iAtom1].n)
           //     if (i1 <= 1 + dihedral[iAtom1].n&&i1 <= 10)
                {
                    k1Dihed =  dihedral[iAtom1].k1[i1 - 1] * v_shift * 1E-6 * simParam.dt * simParam.dt / m_ref / simParam.rcut / simParam.rcut * 1024 ; //17'h10000 corresponds to 1/1024; when k is given in kJ/mol, needs to be multiplied with vshift*(10^-6)*dt^2/m_ref/rcut^2 
                    k2Dihed =  dihedral[iAtom1].k2[i1 - 1] * v_shift * 1E-6 * simParam.dt * simParam.dt / m_ref / simParam.rcut / simParam.rcut * 1024 ;
                    k3Dihed =  dihedral[iAtom1].k3[i1 - 1] * v_shift * 1E-6 * simParam.dt * simParam.dt / m_ref / simParam.rcut / simParam.rcut * 1024 ;
   //                 if (iAtom1 <= 12 && iNode == 0) printf("%f %f %f\n", k1Dihed, k2Dihed, k3Dihed);
                    if (fabs(k1Dihed) >= 2)
                    {
                        printf("Dihedral force k1 too large\n");
                        fprintf(logfile, "Dihedral force k1 too large\n");
                        exit(1);
                    }
                    if (fabs(k2Dihed) >=2)
                    {
                        printf("Dihedral force k2 too large\n");
                        fprintf(logfile, "Dihedral force k2 too large\n");
                        exit(1);
                    }
                    if (fabs(k3Dihed) >= 2)
                    {
                        printf("Dihedral force k3 too large\n");
                        fprintf(logfile, "Dihedral force k3 too large\n");
                        exit(1);
                    }
                    itmp= (dihedral[iAtom1].atom4[i1 - 1] * 0x400 + dihedral[iAtom1].atom3[i1 - 1] * 0x20 + dihedral[iAtom1].atom2[i1 - 1] + dihedral[iAtom1].type[i1 - 1] * 0x8000);
                    outbuff[i - 12] = itmp % 0x100;
                    outbuff[i - 13] = (itmp / 0x100);
                    float_int18_pm2(k1Dihed, &outbuff[i - 16]);
                    float_int18_pm2(k2Dihed, &outbuff[i - 19]);
                    float_int18_pm2(k3Dihed, &outbuff[i - 22]);
                }
            }
        }
/*
        if (iAtom1 <= 12&&iNode==0)
        {
            printf("atom %3d\n", iAtom1);
            for (i = 0;i < 4;i++) printf("%02x ", outbuff[i]);
            printf("\n");
            for (i1 = 0, i = 4;i1 < FF_LENGTH;i1++)       //loop over force field lines
            {
                for (i2 = 0; i2 < DDR3_DATA_WIDTH/8;i2++) { printf("%02x ", outbuff[i]); i++; }
                printf("\n");
            }
            printf("\n");
        }
  */      

        sendto(sock, (char*)outbuff, 4 + DDR3_DATA_WIDTH / 8 * FF_LENGTH, 0, (sockaddr*)&dest[iNode], sizeof(*dest));
        FD_ZERO(&ReadSet);
        FD_SET(sock, &ReadSet);
        if (select(NULL, &ReadSet, NULL, NULL, &TimeOut) < 1)
        {
            printf("ERROR in WriteForceField: Node %d not responding\n", iNode);
            fprintf(logfile, "ERROR in WriteForceField: Node %d not responding\n", iNode);
            exit(1);
        }
        else
        {
            itmp = recvfrom(sock, (char*)inbuff, 100, 0, (sockaddr*)&dest[iNode], &destSize);
            err = CheckError(inbuff, PacketNr[iNode], iNode);
        }

    }
}

/*********************************************************************************/
//write atom data into node

int WriteAtomData(float** qext, float** vext,  meta_t *meta, int natomAll,  sockaddr_in* dest, SOCKET sock, uint8_t* PacketNr)
{
    uint32_t itmp, i, j, iBlock, nLine, iSent,igroup;
    uint8_t outbuff[4096];
    uint8_t inbuff[100];
    int destSize = sizeof(*dest);
    FD_SET ReadSet;
    struct timeval TimeOut;
    TimeOut.tv_sec = 0;
    TimeOut.tv_usec = 200000;
    int err,ReadError;
    int nNode = nxNode * nxNode * nxNode;
    int iNode,ixNode,iyNode,izNode,natom;
    float q[256][3], v[256][3],charge[256];
    int   atomNr[256],atomTypeLJ[256],mass[256];
    uint8_t constraint[256]; 

//first, read status in order to reset Errors and nAtom; needs to be done for all nodes before starting to write into nodes
    for (iNode = 0; iNode < nNode; iNode++)
    {
        ReadStatus(inbuff, iNode, 3, dest, sock, PacketNr);  //reset Errors and nAtom
    }

    err = 0;
    for (iNode = 0; iNode < nNode; iNode++)
    {
//assign atoms for that node
        NodeNr(iNode, &ixNode, &iyNode, &izNode);
 //       printf("\n\nNode %2d: %2d %2d %2d\n", iNode, ixNode, iyNode, izNode);
        natom = 0;
        for (i = 1; i <= natomAll; i++)
        {
            if (meta[i].constraint == 0)
            {
                igroup = i;       //each atom is on its own
            }
            else if (meta[i].constraint == 6 && meta[i].mass == 16)
            {
                igroup = i;   //store igroup of the oxygen for the subsequent hydrogens, so that they will be sent to the same node even if they are slightly outside
            }
        //    printf("%4d: %5d %5d\n", i, igroup, meta[i].atomNrExt2FPGA);  //still need to test that

            if ((int)qext[igroup][0] == ixNode && (int)qext[igroup][1] == iyNode && (int)qext[igroup][2] == izNode)
            {
                q[natom][0] = qext[i][0] - ixNode;
                q[natom][1] = qext[i][1] - iyNode;
                q[natom][2] = qext[i][2] - izNode;
                if (q[natom][0] > 1.5) q[natom][0] -= nxNode;   //take care of periodic boundary  in a loose sense
                if (q[natom][1] > 1.5) q[natom][1] -= nxNode;
                if (q[natom][2] > 1.5) q[natom][2] -= nxNode;
                if (q[natom][0] < -.5) q[natom][0] += nxNode;
                if (q[natom][1] < -.5) q[natom][1] += nxNode;
                if (q[natom][2] < -.5) q[natom][2] += nxNode;
           //     if (q[natom][0] < 0)
             //     printf("%1d %1d %1d|%4d %4d %4d: %10.7f->%10.7f  %10.7f->%10.7f  %10.7f->%10.7f\n", ixNode,iyNode,izNode,igroup, i, meta[i].atomNrExt2FPGA,qext[i][0], q[natom][0], qext[i][1], q[natom][1], qext[i][2], q[natom][2]);
                v[natom][0] = vext[i][0];
                v[natom][1] = vext[i][1];
                v[natom][2] = vext[i][2];
                atomNr[natom] = meta[i].atomNrExt2FPGA;
                atomTypeLJ[natom] = meta[i].LJtype;
                charge[natom] = meta[i].charge;
                mass[natom] = meta[i].mass;
                constraint[natom] = meta[i].constraint;
  //              printf("%4d %4d %2d %6.4f %2d\n", natom, atomNr[natom], atomTypeLJ[natom], charge[natom], mass[natom], constraint[natom]);
                natom++;
                if (natom >= 256)
                {
                    printf("ERROR in WriteAtomData: Too many atoms in node %d\n", iNode);
                    fprintf(logfile,"ERROR in WriteAtomData: Too many atoms in node %d\n", iNode);
                    exit(1); 
                }
            }
        }
   //     exit(1);
//now, write to node
        iSent = 0;
        do
        {
            if (iSent + nBlock >= natom) nLine = natom - iSent; else nLine = nBlock;
            //     printf("iSent=%3d, nLine=%3d\n",iSent,nLine);

            PacketNr[iNode]++;
            outbuff[0] = PacketNr[iNode];
            outbuff[1] = 6;    
            outbuff[2] = nLine;
            for (i = 0; i < nLine; i++)
            {
                for (j = 0; j < 27; j++) outbuff[3 + i * 27 + j] = 0;
                float_int24_pm2(q[i + iSent][0], &outbuff[3 + i * 27 + 24]);
                float_int24_pm2(q[i + iSent][1], &outbuff[3 + i * 27 + 21]);
                float_int24_pm2(q[i + iSent][2], &outbuff[3 + i * 27 + 18]);
                outbuff[3 + i * 27 + 17] = atomNr[i + iSent] % 0x100;
                outbuff[3 + i * 27 + 16] = atomNr[i + iSent] / 0x100;
                outbuff[3 + i * 27 + 15] = (atomTypeLJ[i + iSent] << 2);                //currently max 5bit. lower two bits reserved for 18bit atomNr, highest bit reserved for possibly 6bits of atomTypeLJ
                float_int18_pm2(charge[i + iSent], &outbuff[3 + i * 27 + 12]);
                outbuff[3 + i * 27 + 12] = (outbuff[3 + i * 27 + 12] & 0x03) | ((mass[i + iSent] << 2) & 0xfc);
                outbuff[3 + i * 27 + 11] = constraint[i + iSent];
                outbuff[3 + i * 27 + 10] = 0;                                         //currently reserve
                outbuff[3 + i * 27 + 9] = 0;                                          //routing byte; is zero since all atoms sent to home box
                float_int24_pm1(v_shift * v[i + iSent][0], &outbuff[3 + i * 27 + 6]);
                float_int24_pm1(v_shift * v[i + iSent][1], &outbuff[3 + i * 27 + 3]);
                float_int24_pm1(v_shift * v[i + iSent][2], &outbuff[3 + i * 27 + 0]);
            }
            sendto(sock, (char*)outbuff, 3 + 27 * natom, 0, (sockaddr*)&dest[iNode], sizeof(*dest));

            FD_ZERO(&ReadSet);
            FD_SET(sock, &ReadSet);
            if (select(NULL, &ReadSet, NULL, NULL, &TimeOut) < 1)
            {
                printf("ERROR in WriteAtomData: Node %d not responding\n", iNode);
                fprintf(logfile, "ERROR in WriteAtomData: Node %d not responding\n", iNode);
                exit(1);
            }
            else
            {
                itmp = recvfrom(sock, (char*)inbuff, 100, 0, (sockaddr*)&dest[iNode], &destSize);
                itmp = CheckError(inbuff, PacketNr[iNode], iNode); 
                if (itmp != 0)
                {
 //                   printf("Communication error in node %d\n", iNode);
 //                   fprintf(logfile, "Communication error in node %d\n", iNode);
                    err = itmp;  //if there has been a communication error in one of the previous nodes, don't set it back to 0.
                }
                //printf("Status:"); for (j = 0; j < 27; j++)  printf("  %02X", (uint8_t)inbuff[j]); printf("\n");
            }

            iSent += nLine;
        } while (iSent < natom);
    }
    return(err);
}


/*********************************************************************************/

void ReadAtomData(float** qext, float** vext, int *atomNrFPGA2Ext, uint8_t BoxNr, sockaddr_in* dest, SOCKET sock, uint8_t* PacketNr)
{
    uint32_t itmp, i, j, iBlock, nLine = 0, nLine_old, iLine=0, bufOffset;
    uint8_t outbuff[100];
    uint8_t inbuff[4096];
    uint8_t status[100];
    int destSize = sizeof(*dest);
    FD_SET ReadSet;
    struct timeval TimeOut;
    TimeOut.tv_sec = 0;
    TimeOut.tv_usec = 200000;
    int err;
    int ReadError = 0;
    int nNode = nxNode * nxNode * nxNode;
    int ixNode, iyNode, izNode, natom, iNode;
    float q[256][3], v[256][3];
    int   atomNr[256];

    for (iNode = 0; iNode < nNode; iNode++)
    {
//first, read status to determine number of atoms in node
        do
        {
            ReadError = 0;
            PacketNr[iNode]++;
            outbuff[0] = PacketNr[iNode];
            outbuff[1] = 0;
            outbuff[2] = 0;         //no resets
            sendto(sock, (char*)outbuff, 3, 0, (sockaddr*)&dest[iNode], sizeof(*dest));


            FD_ZERO(&ReadSet);
            FD_SET(sock, &ReadSet);
            if (select(NULL, &ReadSet, NULL, NULL, &TimeOut) < 1)
            {
                printf("\nWARNING in ReadStatus: Node %d not responding; repeat\n", iNode);
                fprintf(logfile, "\nWARNING in ReadStatus: Node %d not responding; repeat\n", iNode);
                ReadError = 1;
            }
            else
            {
                itmp = recvfrom(sock, (char*)inbuff, 100, 0, (sockaddr*)&dest[iNode], &destSize);
            }
        } while (ReadError == 1);
        CheckError(inbuff, PacketNr[iNode], iNode);
        natom = inbuff[statusNatom];

//now, read atoms
        do
        {
            PacketNr[iNode]++;
            outbuff[0] = PacketNr[iNode];
            outbuff[1] = 8;    //command
            outbuff[2] = BoxNr;
            outbuff[3] = natom;            //the FPGA knows natom, hence is not needed. If that would be changed, the previous request to just read natom could be saved which should close to double the read-out speed
            sendto(sock, (char*)outbuff, 4, 0, (sockaddr*)&dest[iNode], sizeof(*dest));

            iBlock = 1;
            ReadError = 0;
            do   //chop into pieces of nBlock lines 
            {
                nLine_old = nLine;
                FD_ZERO(&ReadSet);
                FD_SET(sock, &ReadSet);
                if (select(NULL, &ReadSet, NULL, NULL, &TimeOut) < 1)
                {
                    printf("\nWARNING in ReadAtomData: Node %d not responding; repeat\n", iNode);
                    fprintf(logfile, "\nWARNING in ReadAtomData: Node %d not responding; repeat\n", iNode);
                    ReadError = 1;
                }
                else
                {
                    nLine = recvfrom(sock, (char*)inbuff, 4096, 0, (sockaddr*)&dest[iNode], &destSize) / 27;
                    if (iBlock == 1) for (i = 0; i < 81; i++) status[i] = inbuff[i];
                    if (iBlock == 1)
                    {
                        nLine -= 3;
                        iLine = 0;
                        bufOffset = 3;
                    }
                    else
                    {
                        iLine += nLine_old;
                        bufOffset = 0;
                    }
                    //printf("iBlock=%2d, nLine=%3d, iLine=%3d\n", iBlock, nLine,iLine);
                    for (i = bufOffset; i < nLine + bufOffset; i++)
                    {
                        q[iLine + i - bufOffset][0] = int24_float_pm2(&inbuff[i * 27 + 24]);
                        q[iLine + i - bufOffset][1] = int24_float_pm2(&inbuff[i * 27 + 21]);
                        q[iLine + i - bufOffset][2] = int24_float_pm2(&inbuff[i * 27 + 18]);
                        atomNr[iLine + i - bufOffset] = inbuff[i * 27 + 17] + 0x100 * inbuff[i * 27 + 16];
                        v[iLine + i - bufOffset][0] = int24_float_pm1(&inbuff[i * 27 + 6]) / v_shift;
                        v[iLine + i - bufOffset][1] = int24_float_pm1(&inbuff[i * 27 + 3]) / v_shift;
                        v[iLine + i - bufOffset][2] = int24_float_pm1(&inbuff[i * 27 + 0]) / v_shift;
                    }
                }
                iBlock++;
            } while ((iLine + nLine < natom) && ReadError == 0);
        } while (ReadError == 1);
        CheckError(status, PacketNr[iNode], iNode);

        NodeNr(iNode, &ixNode, &iyNode, &izNode);
        for (i = 0; i < natom; i++)
        {
            qext[atomNrFPGA2Ext[atomNr[i]]][0] = q[i][0] + ixNode;
            qext[atomNrFPGA2Ext[atomNr[i]]][1] = q[i][1] + iyNode;
            qext[atomNrFPGA2Ext[atomNr[i]]][2] = q[i][2] + izNode;
            vext[atomNrFPGA2Ext[atomNr[i]]][0] = v[i][0];
            vext[atomNrFPGA2Ext[atomNr[i]]][1] = v[i][1];
            vext[atomNrFPGA2Ext[atomNr[i]]][2] = v[i][2];
        }
    }
}


/*********************************************************************************/
//initiate MD run
void StartMD(uint16_t nStepMD, int iNode, sockaddr_in* dest, SOCKET sock, uint8_t* PacketNr)
{
    uint32_t itmp, j;
    uint8_t outbuff[100], inbuff[100];
    FD_SET ReadSet;
    struct timeval TimeOut;
    int destSize = sizeof(*dest);
    TimeOut.tv_sec = 0;
    TimeOut.tv_usec = 200000;
    int err;
    int ReadError = 0;

    do {
        ReadError = 0;
        PacketNr[iNode]++;
        outbuff[0] = PacketNr[iNode];
        outbuff[1] = 1;
        outbuff[2] = nStepMD / 0x100;
        outbuff[3] = nStepMD % 0x100;
        sendto(sock, (char*)outbuff, 4, 0, (sockaddr*)&dest[iNode], sizeof(*dest));

        FD_ZERO(&ReadSet);
        FD_SET(sock, &ReadSet);
        if (select(NULL, &ReadSet, NULL, NULL, &TimeOut) < 1)
        {
            printf("\nWARNING in StartMD: Node %d not responding. ", iNode);
            fprintf(logfile, "\nWARNING in StartMD: Node %d not responding. ", iNode);
            //test whether is running already            
            ReadStatus(inbuff, iNode, 0, dest, sock, PacketNr);
            if (inbuff[statusBusy] % 2 != 1)
            {
                printf("Node %d not running yet, hence repeat.\n", iNode);
                fprintf(logfile, "Node %d not running yet, hence repeat.\n", iNode);
                ReadError = 1;
            }
            else printf("\n");
        }
        else
        {
            itmp = recvfrom(sock, (char*)inbuff, 100, 0, (sockaddr*)&dest[iNode], &destSize);
        }
    } while (ReadError == 1);
    err = CheckError(inbuff, PacketNr[iNode], iNode);
}
