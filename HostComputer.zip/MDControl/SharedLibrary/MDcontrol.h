
#define _CRT_SECURE_NO_WARNINGS

#pragma once

#include <string>
#include <WinSock2.h>
#include <Ws2tcpip.h>
#include <windows.h>
#include <stdint.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <cstdlib> 
#include <time.h> 

//parameters that are mostly relevant for reading the topolgy files
#define maxAtomProtein 4096    //must agree with nProteinAtom in FPGA code
#define maxAtomAll     20000   //must include all space of atomNr, i.e. the maximum atomNr on FPGA which can be significantly larger than number od atoms due to the fact that constraint
                               //groups count as 4 reagrdless how big it is (in case of water is 3), and the fact that waters are above maxAtomProtein. Current limit in FPGA is 2^16  
#define maxAtomWater     4
#define maxValence       6
#define maxNear14        40
#define maxLJtype        32     //currently, 5bit; could be extended to 6bit (64)
#define maxAtomtypes     100
#define maxBondtypes     100
#define maxAngletypes    230
#define maxMoleculetype  4
#define maxDihedraltypes 300

//parameters specific to the hardware configuration and FPGA program
#define nBlock      50              //number of lines writen in a single block; must be the same as in FPGA code
#define nxNode      3               //number of nodes in (x,y,z)-directions; assumed to be all the same
//#define nxNode      3               //number of nodes in x-direction
//#define nyNode      3               //number of nodes in y-direction
//#define nzNode      3               //number of nodes in z-direction
#define v_shift     16              //velocities shifted down by 4 bit relative to position +1 extra bit, since positions are defined in +/-2. must coincide with the corresponding parameter in the FPGA code         

#define status_nIterTot      0       //position of nIterTot in status line
#define status_nShakeTot     2       //position of nShakeTot in status line
#define status_ForceFieldCnt 3       //position of ForceFieldCnt in status line
#define statusBusy           7       //position of busy bits in status line
#define statusRestartCnt    17       //position of restart counts in status line
#define statusErr           23       //position of error word in status line
#define statusPcktCnt       26       //position of PacketNr's in status line
#define statusVersion       24       //position of Version in status line 
#define statusNatom         53       //position of natom[inode] in status line
#define statusT             78       //position of temperature in status line                    
#define statusvxcm          75       //position of vxcm in status line  
#define statusvycm          72       //position of vycm in status line
#define statusvzcm          69       //position of vzcm in status line

#define rLJ_ref    0.28              //reference LennardJones parameter,  in nm, can be changed                  
#define eLJ_ref    0.65              //reference LennardJones parameter, in kJ/mol, taken from SPC-water, can be changed              
#define m_ref      16                //reference mass; is also used internally in FPGA during mass multiplication, and cannot (!!!) be changed                                                    
#define e0         8.854188E-12      //vacuum permetivity, in SI units
#define e          1.602177E-19      //elementary charge, in SI units
#define NA         6.022141E23    //avogdro constant
#define kB         1.380649E-23   //Boltzmann constant in J/K
#define PI         3.14159265358979323846

#define DDR3_DATA_WIDTH  256            //width of one line of the DDR3 Ram, ehich holds forcefield data; must be the same as in FPGA code
#define FF_LENGTH        36              //number of force field lines; must be the same as in FPGA code


#define path      "../../"        //path of in/output file


#pragma comment(lib, "ws2_32.lib")
using namespace std;

typedef struct { char type[10]; float sigma; float epsilon; } atomtypes_t;
typedef struct { char type1[10]; char type2[10]; float r0; float k; } bondtypes_t;
typedef struct { char type1[10]; char type2[10]; char type3[10]; float phi0; float k; } angletypes_t;
typedef struct { char type1[10]; char type2[10]; char type3[10]; char type4[10]; int func; float k;  int m; } dihedraltypes_t;
typedef struct { char type[10]; float charge; int mass; int LJtype; int constraint; } atom_t;
typedef struct { int atom[maxNear14 + 1]; int type[maxNear14 + 1]; int n; } near14_t;
typedef struct { int atom[maxNear14 + 1]; int n; } pair_t;
typedef struct { int atom2[maxNear14 + 1]; int atom3[maxNear14 + 1]; int atom4[maxNear14 + 1]; int type[maxNear14 + 1]; float k1[maxNear14 + 1]; float k2[maxNear14 + 1]; float k3[maxNear14 + 1]; int n; } dihedral_t; 
typedef struct { int atom[maxValence + 1]; float r0[maxValence + 1]; float k[maxValence + 1]; int n; } bond_t;
typedef struct { int atom2[maxNear14 + 1]; int atom3[maxNear14 + 1]; int type[maxNear14 + 1]; float phi0[maxNear14 + 1]; float k[maxNear14 + 1]; int n; } angle_t;
typedef struct { float sigma; float epsilon; char type[10];} LJtype_t;
typedef struct { float rOHw; float rHHw; float rCH; float rNH; float rOH; float rSH;} shake_t;
typedef struct { float fudgeQQ; float fudgeLJ; int genpairs; float dt; int nStep1; int nStep2; float rcut; int Tcoupl; float Tref; int tauT; char startfile[20]; char topolfile[20]; int gen_vel; int gen_seed; char enerfile[20]; char trajfile[20]; char outfile[20]; } param_t;
typedef struct { char name1[10]; char name2[10]; int atomNrExt2FPGA; int LJtype; float charge; int mass; int constraint; } meta_t;
//typedef struct { char name[10]; int mass; float charge; float eLJ; float rLJ; } atomType_t;

bool     lineEmptyQ(char* line);
void     FindNear14(near14_t* near14, bond_t* bond, int* nAtom, param_t simParam);
int      inNear14Q(near14_t near14, int iAtomRoot, int iAtom);
int      inNear14P(near14_t near14, int iAtom);
int      inPairQ(pair_t pair, int iAtom);
void     AssignLJ(atom_t* atom, int* nAtom, atomtypes_t* atomtypes, int nAtomtype, LJtype_t* LJtype, int* nLJtype);
void     SearchBondType(char* type1, char* type2, bondtypes_t* bondtypes, int nBondtypes, float* r0, float* k);
void     SearchAngleType(char* type1, char* type2, char* type3, angletypes_t* angletypes, int nAngletypes, float* phi0, float* k);
void     SearchDihedralType(char* type1, char* type2, char* type3, char* type4, int func, dihedraltypes_t* dihedraltypes, int nDihedraltypes, float* k1, float* k2, float* k3);

void     analyzeGroFile(char* groFile, int nAtomTot, float* box);
void     readGroFile(float **qext, float **vext, meta_t* meta, param_t *simParam, int natomAll);
void     writeGroFile(float** q, float** v, float t, float T, int natom, meta_t* meta, param_t simParam, FILE* out);
param_t  readParam();
void     writeMetaFile(int* atomNrExt2FPGA, atom_t* atomProtein, atom_t* atomWater, int nAtomProtein, int nWater, int nAtomWater);
void     readMetaFile(meta_t* meta, int* atomNrFPGA2Ext, int* natomAll, int *nAtomProtein);
float    Temperature(float** v, meta_t* meta, param_t simParam, int natom);

int      ReadStatus(uint8_t* inbuff, int iNode, uint8_t Reset, sockaddr_in* dest, SOCKET sock, uint8_t* PacketNr);
int      SetThermostat(param_t simParam, float mtot, int natom, int iNode, sockaddr_in* dest, SOCKET sock, uint8_t* PacketNr);
int      SetSimParam(shake_t watershake, param_t simParam, int iNode, sockaddr_in* dest, SOCKET sock, uint8_t* PacketNr);
int      WriteAtomData(float** qext, float** vext, meta_t *meta, int natomAll, sockaddr_in* dest, SOCKET sock, uint8_t* PacketNr);
void     WriteNonBondForceLUT(param_t simParam, int iNode, LJtype_t *LJtype, int nLJtype, sockaddr_in* dest, SOCKET sock, uint8_t* PacketNr);
void     WriteForceField(int iNode, int* atomNrExt2FPGA, near14_t *near14, angle_t *angle, bond_t *bond, dihedral_t *dihedral, param_t simParam, int nProteinAtom, sockaddr_in* dest, SOCKET sock, uint8_t* PacketNr);
void     ReadAtomData(float** qext, float** vext, int* atomNrFPGA2Ext, uint8_t BoxNr, sockaddr_in* dest, SOCKET sock, uint8_t* PacketNr);
void     StartMD(uint16_t nStepMD, int iNode, sockaddr_in* dest, SOCKET sock, uint8_t* PacketNr);
int      CheckError(uint8_t* inbuff, uint8_t PacketNr, int iNode);
void     NodeNr(int iNode, int* ixNode, int* iyNode, int* izNode);
float    LennardJones(float r2, param_t simParam);
float    Coulomb(float r2, param_t simParam);

float    sign(float in);
float    gasdev(long* idum);
float    ran1(long* idum);
int*     ivector(long long nrow);
float*   vector(long long nrow);
float**  matrix(long long nrow, long long ncol);
double** dmatrix(long long nrow, long long ncol);
int**    imatrix(long long nrow, long long ncol);
float*** f3tensor(long long nrow, long long ncol, long long ndep);
void     free_ivector(int* v);
void     free_dmatrix(double** m, int nrow);
void     free_imatrix(int** m, int nrow);

void     float_int32_pm8(float x, uint8_t* intbuff);
void     float_int32_pm1(float x, uint8_t* intbuff);
void     float_int24_pm2(float x, uint8_t* intbuff);
void     float_int24_pm1(float x, uint8_t* intbuff);
void     float_int24_p1(float x, uint8_t* intbuff);
float    int24_float_pm2(uint8_t* readbuff);
float    int24_float_pm1(uint8_t* readbuff);
float    int24_float_p1(uint8_t* readbuff);
void     float_int18_pm2(float x, uint8_t* intbuff);
