
//***********************************************************************************************************************************************************************************
//******************************************************         Utilities      *****************************************************************************************************
//***********************************************************************************************************************************************************************************

#include "pch.h"
#include "MDcontrol.h"

extern FILE* logfile;

//************************************************************************************************
void writeMetaFile(int* atomNrExt2FPGA, atom_t* atomProtein, atom_t* atomWater, int nAtomProtein, int nWater, int nAtomWater)
{
    char filename[50];
    FILE* outfile;
    int i, iAtom, j;

    //write output file to be transferred to MDRun.cpp 
    sprintf(filename, "%smeta.dat", path);

    if ((outfile = fopen(filename, "w")) == NULL)
    {
        printf("ERROR: Cannot open file %s, exit\n", filename);
        fprintf(logfile, "ERROR: Cannot open file %s, exit\n", filename);
        exit(1);
    }
    else
    {
        printf("\nWriting file %s\n", filename);
        fprintf(logfile, "\nWriting file %s\n", filename);
    }

    fprintf(outfile, "%6d %6d\n", nAtomProtein + nWater * nAtomWater, nAtomProtein);               
    for (i = 1, iAtom = 1; i <= nAtomProtein; i++, iAtom++)
        fprintf(outfile, "%5d: %5d  %2d  %7.4f  %2d  %1d\n", iAtom, atomNrExt2FPGA[iAtom], atomProtein[i].LJtype, atomProtein[i].charge, atomProtein[i].mass, atomProtein[i].constraint);

    for (i = 1; i <= nWater; i++) for (j = 1; j <= nAtomWater; j++, iAtom++)
        fprintf(outfile, "%5d: %5d  %2d  %7.4f  %2d  %1d\n", iAtom, atomNrExt2FPGA[iAtom], atomWater[j].LJtype, atomWater[j].charge, atomWater[j].mass, atomWater[j].constraint);

    fclose(outfile);
}


//***********************************************************************************
void     readMetaFile(meta_t* meta, int* atomNrFPGA2Ext, int* natomAll, int* nAtomProtein)
{
    char filename[100];
    char ctmp[20];
    int i, itmp;
    FILE* infile;
    param_t simParam;

    sprintf(filename, "%smeta.dat", path);


    if ((infile = fopen(filename, "r")) == NULL)
    {
        printf("ERROR: File %s not found, exit\n", filename);
        fprintf(logfile, "ERROR: File %s not found, exit\n", filename);
        exit(1);
    }
    else 
    {
        printf("\nOpened file %s\n", filename);
        fprintf(logfile, "\nOpened file %s\n", filename);
    }

    itmp= fscanf(infile, "%d %d", natomAll, nAtomProtein);
    printf("Found %d atoms in total and %d protein atoms\n", *natomAll, *nAtomProtein);
    fprintf(logfile, "Found %d atoms in total and %d protein atoms\n", *natomAll, *nAtomProtein);
    
    for (i = 1;i <= *natomAll;i++)
    {
        itmp=fscanf(infile, "%s %d %d %f %d %d", ctmp, &meta[i].atomNrExt2FPGA, &meta[i].LJtype, &meta[i].charge, &meta[i].mass, &meta[i].constraint);
        atomNrFPGA2Ext[meta[i].atomNrExt2FPGA] = i;                         //generate lists for back-translation of atomnumbers
    }

  //  for (i = 1;i <= natomAll;i++) printf("%5d: %5d %2d %7.4f %2d %1d\n", i, meta[i].atomNrExt2FPGA, meta[i].LJtype, meta[i].charge, meta[i].mass, meta[i].constraint);
   
    
    fclose(infile);
}

   

//***********************************************************************************
param_t readParam()
{
    char linebuff[200], filename[100];
    char ctmp[200];
    int  eof, itmp, linecnt;

    FILE* paramfile;
    param_t simParam;

    sprintf(filename, "%sparam.dat", path);


    if ((paramfile = fopen(filename, "r")) == NULL)
    {
        printf("ERROR: File %s not found, exit\n", filename);
        fprintf(logfile,"ERROR: File %s not found, exit\n", filename);
        exit(1);
    }
    else
    {
        printf("\nOpened file %s\n", filename);
        fprintf(logfile,"\nOpened file %s\n", filename);
    }

    eof = 0;
    linecnt = 0;

    //default values

    simParam.genpairs = 0;
    simParam.fudgeQQ = 0.8333;
    simParam.fudgeLJ = 0.5;
    simParam.dt = 2;
    simParam.nStep1 = 2;
    simParam.nStep2 = 100;
    simParam.Tcoupl = 0;
    simParam.Tref = 300;
    simParam.tauT = 9;
    simParam.gen_vel = 0;
    simParam.gen_seed = 0;
    strcpy(simParam.startfile, "start.xyz");
    strcpy(simParam.enerfile, "ener.dat");
    strcpy(simParam.trajfile, "traj.xyz");

    do {
        if (fgets(linebuff, 100, paramfile) == NULL) eof = 1;
        if (eof == 0)
        {
            itmp = sscanf(linebuff, "%s", ctmp);
            linecnt++;
            if (ctmp[0] != ';' && itmp != EOF)
            {
                if (strcmp(ctmp, "fudgeQQ") == 0)
                {
                    itmp = sscanf(linebuff, "%s%f", ctmp, &simParam.fudgeQQ);
                    printf("%2d: fudgeQQ:        %6.4f\n", linecnt, simParam.fudgeQQ);
                }
                if (strcmp(ctmp, "fudgeLJ") == 0)
                {
                    itmp = sscanf(linebuff, "%s%f", ctmp, &simParam.fudgeLJ);
                    printf("%2d: fudgeLJ:        %3.1f\n", linecnt, simParam.fudgeLJ);
                }
                if (strcmp(ctmp, "gen_pairs") == 0)
                {
                    itmp = sscanf(linebuff, "%s%d", ctmp, &simParam.genpairs);
                    printf("%2d: gen_pairs:      %1d\n", linecnt, simParam.genpairs);
                }
                if (strcmp(ctmp, "dt") == 0)
                {
                    itmp = sscanf(linebuff, "%s%f", ctmp, &simParam.dt);
                    printf("%2d: dt:             %4.2f\n", linecnt, simParam.dt);
                }
                if (strcmp(ctmp, "nStep1") == 0)
                {
                    itmp = sscanf(linebuff, "%s%d", ctmp, &simParam.nStep1);
                    printf("%2d: nStep1:         %-5d\n", linecnt, simParam.nStep1);
                }
                if (strcmp(ctmp, "nStep2") == 0)
                {
                    itmp = sscanf(linebuff, "%s%d", ctmp, &simParam.nStep2);
                    printf("%2d: nStep2:         %-5d\n", linecnt, simParam.nStep2);
                }
                if (strcmp(ctmp, "Tcoupl") == 0)
                {
                    itmp = sscanf(linebuff, "%s%d", ctmp, &simParam.Tcoupl);
                    printf("%2d: Tcoupl:     %5d\n", linecnt, simParam.Tcoupl);
                }
                if (strcmp(ctmp, "Tref") == 0)
                {
                    itmp = sscanf(linebuff, "%s%f", ctmp, &simParam.Tref);
                    printf("%2d: Tref:           %5.1f\n", linecnt, simParam.Tref);
                }
                if (strcmp(ctmp, "tauT") == 0)
                {
                    itmp = sscanf(linebuff, "%s%d", ctmp, &simParam.tauT);
                    printf("%2d: tauT:       %5d\n", linecnt, simParam.tauT);
                }
                if (strcmp(ctmp, "gen_vel") == 0)
                {
                    itmp = sscanf(linebuff, "%s%d", ctmp, &simParam.gen_vel);
                    printf("%2d: gen_vel:    %5d\n", linecnt, simParam.gen_vel);
                }
                if (strcmp(ctmp, "gen_seed") == 0)
                {
                    itmp = sscanf(linebuff, "%s%d", ctmp, &simParam.gen_seed);
                    printf("%2d: gen_seed:   %5d\n", linecnt, simParam.gen_seed);
                }
                if (strcmp(ctmp, "startfile") == 0)
                {
                    itmp = sscanf(linebuff, "%s%s", ctmp, simParam.startfile);
                    printf("%2d: startfile:      %s\n", linecnt, simParam.startfile);
                }
                if (strcmp(ctmp, "topolfile") == 0)
                {
                    itmp = sscanf(linebuff, "%s%s", ctmp, simParam.topolfile);
                    printf("%2d: topology file:  %s\n", linecnt, simParam.topolfile);
                }
                if (strcmp(ctmp, "enerfile") == 0)
                {
                    itmp = sscanf(linebuff, "%s%s", ctmp, simParam.enerfile);
                    printf("%2d: enerfile:       %s\n", linecnt, simParam.enerfile);
                }
                if (strcmp(ctmp, "trajfile") == 0)
                {
                    itmp = sscanf(linebuff, "%s%s", ctmp, simParam.trajfile);
                    printf("%2d: trajfile:       %s\n", linecnt, simParam.trajfile);
                }
                if (strcmp(ctmp, "outfile") == 0)
                {
                    itmp = sscanf(linebuff, "%s%s", ctmp, simParam.outfile);
                    printf("%2d: outfile:        %s\n", linecnt, simParam.outfile);
                }
            }
        }
    } while (eof == 0);
    printf("\n");

    fclose(paramfile);
    return(simParam);
}

//***************************************************************************

void analyzeGroFile(char* groFile, int nAtomTot, float* box)
{
    //read coordinates and velocities from starting gro file

    char filename[100], ctmp[10], atomName[10], tmpbuff[100];
    int itmp2, itmp, i;
    float ftmp;
    float box_x, box_y, box_z;


    FILE* inFile;
    sprintf(filename, "%s%s", path, groFile);

    if ((inFile = fopen(filename, "r")) == NULL)
    {
        printf("ERROR: File %s not found, exit\n", filename);
        fprintf(logfile, "ERROR: File %s not found, exit\n", filename);
        exit(1);
    }
    else
    {
        printf("\nOpened file %s\n", filename);
        fprintf(logfile, "\nOpened file %s\n", filename);
    }

    fgets(tmpbuff, 100, inFile);                              //skip 1st line, needed when gro file
    fgets(tmpbuff, 100, inFile);
    itmp = sscanf(tmpbuff, "%d", &itmp2);
    if (itmp2 != nAtomTot)
    {
        printf("ERROR in gro-file:File %s does not contain %4d atoms\n", groFile, nAtomTot);
        fprintf(logfile, "File %s does not contain %4d atoms\n", groFile, nAtomTot);
        exit(1);
    }


    for (i = 1; i <= nAtomTot; i++)
    {
        itmp = fscanf(inFile, "%s %s %d %f %f %f %f %f %f", ctmp, atomName, &itmp2, &ftmp, &ftmp, &ftmp, &ftmp, &ftmp, &ftmp);  //for gro file
    }
    itmp = fscanf(inFile, "%f %f %f", &box_x, &box_y, &box_z);

    if ((box_x != box_y) || (box_x != box_z) || (box_y != box_z))
    {
        printf("ERROR in gro-file: box is not cubic\n");
        fprintf(logfile, "ERROR in gro-file: box is not cubic\n");
        exit(1);
    }

    *box = box_x;
    printf("Box size: %7.4f\n", *box);
    fprintf(logfile, "Box size: %7.4f\n", *box);

    fclose(inFile);
}
//********************************************************************************

void readGroFile(float** qext, float** vext, meta_t *meta, param_t *simParam, int natomAll)
{
    
        //read coordinates and velocities from starting gro file

        char filename[100], ctmp[10], atomName[10], tmpbuff[100];
        int itmp2, itmp, i;
        float v_sd, box_x,box_y,box_z;
        long  idum = -1;

        FILE* atomfile;


        sprintf(filename, "%s%s", path, (*simParam).startfile);

        if ((atomfile = fopen(filename, "r")) == NULL)
        {
            printf("ERROR: File %s not found, exit\n", filename);
            fprintf(logfile, "ERROR: File %s not found, exit\n", filename);
            exit(1);
        }
        else
        {
            printf("\nOpened file %s\n", filename);
            fprintf(logfile, "\nOpened file %s\n", filename);
        }

        fgets(tmpbuff, 100, atomfile);                              
        fgets(tmpbuff, 100, atomfile);
        itmp = sscanf(tmpbuff, "%d", &itmp2);
        if (itmp2 != natomAll)
        {
            printf("File %s does not contain %4d atoms\n", filename, natomAll);
            fprintf(logfile, "File %s does not contain %4d atoms\n", filename, natomAll);
            exit(1);
        }

  
        for (i = 1; i <= natomAll; i++)
        {
            itmp = fscanf(atomfile, "%s %s %d %f %f %f %f %f %f", &meta[i].name1, &meta[i].name2, &itmp2, &qext[i][0], &qext[i][1], &qext[i][2], &vext[i][0], &vext[i][1], &vext[i][2]);  //for gro file
        }
        itmp = fscanf(atomfile, "%f %f %f", &box_x, &box_y, &box_z);

        if ((box_x != box_y) || (box_x != box_z) || (box_y != box_z))
        {
            printf("ERROR in gro-file: box is not cubic\n");
            fprintf(logfile, "ERROR in gro-file: box is not cubic\n");
            exit(1);
        }
        (*simParam).rcut = box_x/nxNode;
        printf("Box size: %7.4f\n", box_x);
        fprintf(logfile, "Box size: %7.4f\n", box_x);


        for (i = 0; i <= 4; i++) gasdev(&idum);
        v_sd = sqrt(kB * (*simParam).Tref * NA * 1E3 / m_ref) * (*simParam).dt * 1E-15 / ((*simParam).rcut * 1E-9);
        for (i = 0; i <= (*simParam).gen_seed; i++) gasdev(&idum);
//translate into internal units
        for (i = 1; i <= natomAll; i++)
        {
            qext[i][0] /= (*simParam).rcut;
            qext[i][1] /= (*simParam).rcut;
            qext[i][2] /= (*simParam).rcut;
            qext[i][0] = qext[i][0] - floor(qext[i][0] / nxNode) * nxNode;     //particles can be slightly out of box
            qext[i][1] = qext[i][1] - floor(qext[i][1] / nxNode) * nxNode;
            qext[i][2] = qext[i][2] - floor(qext[i][2] / nxNode) * nxNode;

            vext[i][0] *= (*simParam).dt / 1000 / (*simParam).rcut;
            vext[i][1] *= (*simParam).dt / 1000 / (*simParam).rcut;
            vext[i][2] *= (*simParam).dt / 1000 / (*simParam).rcut;

            if ((*simParam).gen_vel != 0)
            {
                vext[i][0] = v_sd * gasdev(&idum);
                vext[i][1] = v_sd * gasdev(&idum);
                vext[i][2] = v_sd * gasdev(&idum);
            }
            // printf("%4d %4d: %3s  %6.3f %6.3f %6.3f   %10.7f %10.7f %10.7f\n", i, meta[i].atomNrExt2FPGA, meta[i].name, qext[i][0], qext[i][1], qext[i][2], vext[i][0], vext[i][1], vext[i][2]);
        }
}

//calculate temperature from velocities
float Temperature(float** v, meta_t *meta, param_t simParam, int natom)
{
    int i;
    float T;
     
    for (i = 1, T = 0; i <= natom; i++)
    {
        T += meta[i].mass / (3 * NA * 1E3) * (v[i][0] * v[i][0] + v[i][1] * v[i][1] + v[i][2] * v[i][2]) * simParam.rcut * simParam.rcut / (simParam.dt * simParam.dt) * 1E12 / kB;
    }
    return(T / natom);  //need to replace natom by number of degrees of freedom
}

//***********************************************************************************

void writeGroFile(float** q, float** v, float t, float T, int natom, meta_t* meta, param_t simParam, FILE* out)
{
    int i;

    fprintf(out, "time: %9.3f  Temp: %6.1f\n%d\n", t, T, natom);
    for (i = 1; i <= natom; i++)
    {
        fprintf(out, "%8s%7s%5d%8.3f%8.3f%8.3f%8.4f%8.4f%8.4f\n", meta[i].name1, meta[i].name2, i , simParam.rcut * q[i][0], simParam.rcut * q[i][1], simParam.rcut * q[i][2], 1000 * simParam.rcut / simParam.dt * v[i][0], 1000 * simParam.rcut / simParam.dt * v[i][1], 1000 * simParam.rcut / simParam.dt * v[i][2]);
       
    }
    fprintf(out, "%10.5f%10.5f%10.5f\n", simParam.rcut * nxNode, simParam.rcut * nxNode, simParam.rcut * nxNode);
}


//********************************************************************************
void SearchBondType(char* type1, char* type2, bondtypes_t* bondtypes, int nBondtypes, float* r0, float* k)
{
    int i;

    //  printf("%s %s\n",type1,type2);

    for (i = 1; i <= nBondtypes; i++)
    {
        if ((strcmp(type1, bondtypes[i].type1) == 0 && strcmp(type2, bondtypes[i].type2) == 0) || (strcmp(type2, bondtypes[i].type1) == 0 && strcmp(type1, bondtypes[i].type2) == 0))
        {
            *r0 = bondtypes[i].r0;
            *k = bondtypes[i].k;
            break;
        }
    }
    if (i == nBondtypes + 1)
    {
        printf("ERROR: bond type: (%s %s) not found in ffbonded.itp\n", type1, type2);
        fprintf(logfile, "ERROR: bond type: (%s %s) not found in ffbonded.itp\n", type1, type2);
        exit(1);
    }
}

void SearchAngleType(char* type1, char* type2, char* type3, angletypes_t* angletypes, int nAngletypes, float* phi0, float* k)
{
    int i;

    //  printf("%s %s %s\n\n",type1,type2,type3);

    for (i = 1; i <= nAngletypes; i++)
    {
        //     printf("%3d: %s %s %s\n",i,angletypes[i].type1,angletypes[i].type2,angletypes[i].type3);

        if ((strcmp(type1, angletypes[i].type1) == 0 && strcmp(type2, angletypes[i].type2) == 0 && strcmp(type3, angletypes[i].type3) == 0)
            || (strcmp(type3, angletypes[i].type1) == 0 && strcmp(type2, angletypes[i].type2) == 0 && strcmp(type1, angletypes[i].type3) == 0))
        {
            *phi0 = angletypes[i].phi0;
            *k = angletypes[i].k;
            break;
        }
    }
    if (i == nAngletypes + 1) 
    { 
        printf("ERROR: angle type (%s %s %s) not found in ffbonded.itp\n", type1, type2, type3);
        fprintf(logfile, "ERROR: angle type (%s %s %s) not found in ffbonded.itp\n", type1, type2, type3);
        exit(1); 
    }
}


//SearchDihedralType(atom[itmp1].type, atom[itmp2].type, atom[itmp3].type, atom[itmp3].type, itmp5, dihedraltypes, nDihedraltypes, &k1Dihed, &k2Dihed, &k3Dihed);


void SearchDihedralType(char* type1, char* type2, char* type3, char* type4, int func, dihedraltypes_t* dihedraltypes, int nDihedraltypes, float* k1, float* k2, float *k3)
{
    int i;
    bool test0, test1, test2, test1_1, test2_1, test3_1, test4_1, test1_2, test2_2, test3_2, test4_2, found;

    //  printf("%s %s %s\n\n",type1,type2,type3,type4);
    *k1 = 0;
    *k2 = 0;
    *k3 = 0;
    found = 0;

    for (i = 1; i <= nDihedraltypes; i++)
    {
        //     printf("%3d: %s %s %s\n",i,angletypes[i].type1,angletypes[i].type2,angletypes[i].type3);

        test0   = (dihedraltypes[i].func == func);
        test1_1 = (strcmp(type1, dihedraltypes[i].type1) == 0) || (strcmp("X", dihedraltypes[i].type1) == 0);
        test2_1 = (strcmp(type2, dihedraltypes[i].type2) == 0) || (strcmp("X", dihedraltypes[i].type2) == 0);
        test3_1 = (strcmp(type3, dihedraltypes[i].type3) == 0) || (strcmp("X", dihedraltypes[i].type3) == 0);
        test4_1 = (strcmp(type4, dihedraltypes[i].type4) == 0) || (strcmp("X", dihedraltypes[i].type4) == 0);
        test1 = test1_1 && test2_1 && test3_1 && test4_1;
        test1_2 = (strcmp(type1, dihedraltypes[i].type4) == 0) || (strcmp("X", dihedraltypes[i].type4) == 0);
        test2_2 = (strcmp(type2, dihedraltypes[i].type3) == 0) || (strcmp("X", dihedraltypes[i].type3) == 0);
        test3_2 = (strcmp(type3, dihedraltypes[i].type2) == 0) || (strcmp("X", dihedraltypes[i].type2) == 0);
        test4_2 = (strcmp(type4, dihedraltypes[i].type1) == 0) || (strcmp("X", dihedraltypes[i].type1) == 0);
        test2 = test1_2 && test2_2 && test3_2 && test4_2;


        if(test0&&(test1||test2))
 //       if (test0 && (test1||(test2&&(func==9))))
        {
            if (dihedraltypes[i].m == 0)
            {
                found = 1;
            }
            if (dihedraltypes[i].m == 1)
            {
                *k1 += dihedraltypes[i].k;
                found = 1;
            }
            else if (dihedraltypes[i].m == 2)
            {
                *k2 += dihedraltypes[i].k;
                found = 1;
            }
            else if (dihedraltypes[i].m == 3)
            {
                *k3 += dihedraltypes[i].k;
                found = 1;
            }
        }
    }
    if (!found)
    {
        printf("ERROR: dihedral type (%s %s %s %s) with func %d not found in ffbonded.itp\n",type1,type2,type3,type4, func);
        fprintf(logfile, "ERROR: dihedral type (%s %s %s %s)  with func %d not found in ffbonded.itp\n", type1, type2, type3, type4, func);
        exit(1);
    }
}

//*************************************************************************************
void AssignLJ(atom_t* atom, int* nAtom, atomtypes_t* atomtypes, int nAtomtypes, LJtype_t* LJtype, int* nLJtype)
{
    int i, iAtom, j, itmp = 0, itmp2 = 0;

    for (iAtom = 1;iAtom <= *nAtom;iAtom++)
    {
        itmp = 0;
        for (j = 1;j <= nAtomtypes;j++)
        {
            if (strcmp(atom[iAtom].type, atomtypes[j].type) == 0)
            {
                itmp = 1;
                for (i = 0, itmp2 = 0;i < *nLJtype;i++) if (atomtypes[j].sigma == LJtype[i].sigma && atomtypes[j].epsilon == LJtype[i].epsilon) { itmp2 = 1;break; }
                if (itmp2 == 0)                              //new Lennard Jones type found
                {
                    LJtype[*nLJtype].sigma = atomtypes[j].sigma;
                    LJtype[*nLJtype].epsilon = atomtypes[j].epsilon;
                    strcpy(LJtype[*nLJtype].type,atom[iAtom].type);
                    atom[iAtom].LJtype = *nLJtype;
                    (*nLJtype)++;
                    if (*nLJtype > maxLJtype) 
                    { 
                        printf("ERROR: too many Lennard Jones types\n");
                        fprintf(logfile, "ERROR: too many Lennard Jones types\n");
                        exit(1); 
                    }
                }
                else
                {
                    atom[iAtom].LJtype = i;
                }
            }
        }
        if (itmp == 0) 
        { 
            printf("ERROR in AssignLJ: atomtype %s not found\n", atom[iAtom].type);
            fprintf(logfile, "ERROR in AssignLJ: atomtype %s not found\n", atom[iAtom].type);
            exit(1);
        }
    }

}

void FindNear14(near14_t* near14, bond_t* bond, int* nAtom, param_t simParam)
{
    int iAtom, i1, i2, i3, itmp1, itmp2, itmp3;

    for (iAtom = 1;iAtom <= *nAtom;iAtom++)
    {
        for (i1 = 1;i1 <= bond[iAtom].n;i1++)
        {
            near14[iAtom].n++;
            itmp1 = bond[iAtom].atom[i1];
            near14[iAtom].atom[near14[iAtom].n] = itmp1;
            near14[iAtom].type[near14[iAtom].n] = 0;           //is within 1 bonds
        }
        for (i1 = 1;i1 <= bond[iAtom].n;i1++)
        {
            itmp1 = bond[iAtom].atom[i1];
            for (i2 = 1;i2 <= bond[itmp1].n;i2++) if (inNear14Q(near14[iAtom], iAtom, bond[itmp1].atom[i2]) == 0)
            {
                near14[iAtom].n++;
                itmp2 = bond[itmp1].atom[i2];
                near14[iAtom].atom[near14[iAtom].n] = itmp2;
                near14[iAtom].type[near14[iAtom].n] = 0;           //is within 2 bonds
            }
        }
        for (i1 = 1;i1 <= bond[iAtom].n;i1++)
        {
            itmp1 = bond[iAtom].atom[i1];
            for (i2 = 1;i2 <= bond[itmp1].n;i2++)
            {
                itmp2 = bond[itmp1].atom[i2];
                for (i3 = 1;i3 <= bond[itmp2].n;i3++) if (inNear14Q(near14[iAtom], iAtom, bond[itmp2].atom[i3]) == 0)
                {
                    near14[iAtom].n++;
                    itmp3 = bond[itmp2].atom[i3];
                    near14[iAtom].atom[near14[iAtom].n] = itmp3;
                    if(simParam.genpairs==1) near14[iAtom].type[near14[iAtom].n] = 1;           //is within 3 bonds; 
                    else                     near14[iAtom].type[near14[iAtom].n] = 0;
                }
            }
        }
    }
}

int inNear14Q(near14_t near14, int iAtomRoot, int iAtom)
{
    int i;
    int result = 0;
    if (iAtomRoot == iAtom) result = 1;
    for (i = 1;i <= near14.n;i++) if (near14.atom[i] == iAtom) result = 1;
    return(result);
}

int inNear14P(near14_t near14, int iAtom)
{
    int i;
    for (i = 1;i <= near14.n;i++) if (near14.atom[i] == iAtom) break;
    if (i > near14.n) i = 0;                                       //indicates that it is not found
    return(i);
}

int inPairQ(pair_t pair, int iAtom)
{
    int i;
    int result = 0;
    for (i = 1;i <= pair.n;i++) if (pair.atom[i] == iAtom) result = 1;
    return(result);
}

bool lineEmptyQ(char* line)
{
    int  i = 0;
    bool empty = true;

    while (i < 200 && line[i] != 0)
    {
        if (line[i] > 0x20) empty = false;
        i++;
    }
    return (empty);
}


//***************************************************************************

int CheckError(uint8_t* inbuff, uint8_t PacketNr, int iNode)
{
    uint8_t error;
    //   static uint8_t restart[nxNode * nyNode * nzNode][10] = {0,0,0,0,0,0,0,0};
    int stop, j, err;

    stop = 0;
    err = 0;

    if (PacketNr != inbuff[statusPcktCnt] || (uint8_t)(PacketNr - 1) != inbuff[statusPcktCnt - 1])
    {
        printf("\nPACKET ERROR in node %3d: PacketNr %3d, received %3d, previously received: %d\n", iNode, PacketNr, inbuff[statusPcktCnt], inbuff[statusPcktCnt - 1]);
        fprintf(logfile, "\nPACKET ERROR in node %3d: PacketNr %3d, received %3d, previously received: %d\n", iNode, PacketNr, inbuff[statusPcktCnt], inbuff[statusPcktCnt - 1]);
    }


    error = (uint8_t)inbuff[statusErr];
    if (error % 2 == 1)
    {
        printf("\nERROR in node %3d: Fan not running\n", iNode);
        fprintf(logfile, "\nERROR in node %3d: Fan not running\n", iNode);
        stop = 1;
    }
    error /= 2;
    if (error % 2 == 1)
    {
        printf("\nERROR in node %3d: ETH3 not connected\n", iNode);
        fprintf(logfile, "\nERROR in node %3d: ETH3 not connected\n", iNode);
        stop = 1;
    }
    error /= 2;
    if (error % 2 == 1)
    {
        printf("\nERROR in node %3d: ETH3, speed <1Gb/s\n", iNode);
        fprintf(logfile, "\nERROR in node %3d: ETH3, speed <1Gb/s\n", iNode);
        stop = 1;
    }
    error /= 2;
    if (error % 2 == 1)
    {
        printf("\nERROR in node %3d: ETH4 not connected\n", iNode);
        fprintf(logfile, "\nERROR in node %3d: ETH4 not connected\n", iNode);
        stop = 1;
    }
    error /= 2;
    if (error % 2 == 1)
    {
        printf("\nERROR in node %3d: ETH4, speed <1Gb/s\n", iNode);
        fprintf(logfile, "\nERROR in node %3d: ETH4, speed <1Gb/s\n", iNode);
        stop = 1;
    }
    //bit5-7 reserved



    error = (uint8_t)inbuff[statusErr - 1];
    if (error % 2 == 1)
    {
        printf("\nERROR in node %3d: ETH3, tx FIFO overflow\n", iNode);
        fprintf(logfile, "\nERROR in node %3d: ETH3, tx FIFO overflow\n", iNode);
        stop = 1;
    }
    error /= 2;
    if (error % 2 == 1) { err = 1; }     //ETH3, rx crc error 
    error /= 2;
    if (error % 2 == 1) { err = 1; }       //ETH3, seq error
    error /= 2;
    // bit reserved, used to be ecc correction
    error /= 2;
    if (error % 2 == 1)
    {
        printf("\nERROR in node %3d: ETH4, tx FIFO overflow\n", iNode);
        fprintf(logfile, "\nERROR in node %3d: ETH4, tx FIFO overflow\n", iNode);
        stop = 1;
    }
    error /= 2;
    if (error % 2 == 1) { err = 1; }     //ETH4, rx ecc error 
    error /= 2;
    if (error % 2 == 1) { err = 1; }       //ETH4,seq error 
    error /= 2;
    // bit reserved, used to be ecc correction



    error = (uint8_t)inbuff[statusErr - 2];
    if (error % 2 == 1)
    {
        printf("\nERROR in node %3d: gtp0, tx FIFO overflow\n", iNode);
        fprintf(logfile, "\nERROR in node %3d: gtp0, tx FIFO overflow\n", iNode);
        stop = 1;
    }
    error /= 2;
    if (error % 2 == 1)
    {
        printf("\nERROR in node %3d: gtp1, tx FIFO overflow\n", iNode);
        fprintf(logfile, "\nERROR in node %3d: gtp1, tx FIFO overflow\n", iNode);
        stop = 1;
    }
    error /= 2;
    if (error % 2 == 1)
    {
        printf("\nERROR in node %3d: gtp2, tx FIFO overflow\n", iNode);
        fprintf(logfile, "\nERROR in node %3d: gtp2, tx FIFO overflow\n", iNode);
        stop = 1;
    }
    error /= 2;
    if (error % 2 == 1)
    {
        printf("\nERROR in node %3d: gtp3, tx FIFO overflow\n", iNode);
        fprintf(logfile, "\nERROR in node %3d: gtp3, tx FIFO overflow\n", iNode);
        stop = 1;
    }
    error /= 2;
    if (error % 2 == 1)
    {
        printf("\nERROR in node %3d: gtp0, tx MUX overflow\n", iNode);
        fprintf(logfile, "\nERROR in node %3d: gtp0, tx MUX overflow\n", iNode);
        stop = 1;
    }
    error /= 2;
    if (error % 2 == 1)
    {
        printf("\nERROR in node %3d: gtp1, tx MUX overflow\n", iNode);
        fprintf(logfile, "\nERROR in node %3d: gtp1, tx MUX overflow\n", iNode);
        stop = 1;
    }
    error /= 2;
    if (error % 2 == 1)
    {
        printf("\nERROR in node %3d: gtp2, tx MUX overflow\n", iNode);
        fprintf(logfile, "\nERROR in node %3d: gtp2, tx MUX overflow\n", iNode);
        stop = 1;
    }
    error /= 2;
    if (error % 2 == 1)
    {
        printf("\nERROR in node %3d: gtp3, tx MUX overflow\n", iNode);
        fprintf(logfile, "\nERROR in node %3d: gtp3, tx MUX overflow\n", iNode);
        stop = 1;
    }



    error = (uint8_t)inbuff[statusErr - 3];
    if (error % 2 == 1) { err = 1; }   //gtp0, rx error(crc or sequence_cnt)
    error /= 2;
    if (error % 2 == 1) { err = 1; }   //gtp1, rx error(crc or sequence_cnt)
    error /= 2;
    if (error % 2 == 1) { err = 1; }   //gtp2, rx error(crc or sequence_cnt)
    error /= 2;
    if (error % 2 == 1) { err = 1; }   //gtp3, rx error(crc or sequence_cnt)
    error /= 2;
    if (error % 2 == 1)
    {
        printf("\nERROR in node %3d: MUX overflow in Broadcast.v\n", iNode);
        fprintf(logfile, "\nERROR in node %3d: MUX overflow in Broadcast.v\n", iNode);
        stop = 1;
    }
    error /= 2;
    if (error % 2 == 1)
    {
        printf("\nERROR in node %3d: homebox overflow >252 atoms\n", iNode);
        fprintf(logfile, "\nERROR in node %3d: homebox overflow >252 atoms\n", iNode);
        stop = 1;
    }
    error /= 2;
    if (error % 2 == 1)
    {
        printf("\nERROR in node %3d: neighboring box overflow >252 atoms\n", iNode);
        fprintf(logfile, "\nERROR in node %3d: neighboring box overflow >252 atoms\n", iNode);
        stop = 1;
    }
    error /= 2;
    if (error % 2 == 1)
    {
        printf("\nERROR in node %3d: subbox overflow >15 atoms\n", iNode);
        fprintf(logfile, "\nERROR in node %3d: subbox overflow >15 atoms\n", iNode);
        stop = 1;
    }



    error = (uint8_t)inbuff[statusErr - 4];
    if (error % 2 == 1)
    {
        printf("\nERROR in node %3d: velocity overflow\n", iNode);
        fprintf(logfile, "\nERROR in node %3d: velocity overflow\n", iNode);
        stop = 1;
    }

    error /= 2;
    if (error % 2 == 1)
    {
        printf("\nERROR in node %3d: overflow error in CollectContraintGroup\n", iNode);
        fprintf(logfile, "\nERROR in node %3d: overflow error in CollectContraintGroup\n", iNode);
        stop = 1;
    }

    error /= 2;
    
    if (error % 2 == 1)
    {
        printf("\nERROR in node %3d: Shake error, velocity too large\n", iNode);
        fprintf(logfile, "\nERROR in node %3d: Shake error, velocity too large\n", iNode);
        stop = 1;
    }
    

    error /= 2;
    if (error % 2 == 1)
    {
        printf("\nERROR in node %3d: Shake error, too many iterations\n", iNode);
        fprintf(logfile, "\nERROR in node %3d: Shake error, too many iterations\n", iNode);
        stop = 1;
    }

    error /= 2;
    if (error % 2 == 1)
    {
        printf("\nERROR in node %3d: MUX overflow in MDmachine\n", iNode);
        fprintf(logfile, "\nERROR in node %3d: MUX overflow in MDmachine\n", iNode);
        stop = 1;
    }

    error /= 2;
    if (error % 2 == 1)
    {
        printf("\nERROR in node %3d: BondedInteractions error1\n", iNode);
        fprintf(logfile, "\nERROR in node %3d: BondedInteractions errro1\n", iNode);
        stop = 1;
    }

    error /= 2;

    if (error % 2 == 1)
    {
        printf("\nERROR in node %3d: BondedInteractions error2\n", iNode);
        fprintf(logfile, "\nERROR in node %3d: BondedInteractions errro2\n", iNode);
        stop = 1;
    }


    error /= 2;
    if (error % 2 == 1)
    {
        printf("\nERROR in node %3d: BondedInteractions error3\n", iNode);
        fprintf(logfile, "\nERROR in node %3d: BondedInteractions errro3\n", iNode);
        stop = 1;
    }


    if (stop == 1)  //fatal error; stop
    {
        printf("Status:"); for (j = 0; j < 27; j++)  printf("  %02X", inbuff[j]); printf("\n");
        printf("#Atoms:"); for (j = 27; j < 54; j++) printf(" %3d", inbuff[j]); printf("\n");
        printf("Exit\n");
        fprintf(logfile, "Status:"); for (j = 0; j < 27; j++)  fprintf(logfile, "  %02X", inbuff[j]); fprintf(logfile, "\n");
        fprintf(logfile, "#Atoms:"); for (j = 27; j < 54; j++) fprintf(logfile, " %3d", inbuff[j]); fprintf(logfile, "\n");
        fprintf(logfile, "Exit\n");
        exit(1);
    }



    return(err);
}





//***********************************************************************************
void  NodeNr(int iNode, int* ixNode, int* iyNode, int* izNode)
//converts iNode, which is number [0..nxNode*nyNode*nzNode-1], into (xyz) position of node
{
    int itmp = iNode;

    *ixNode = itmp % nxNode;
    itmp /= nxNode;
    *iyNode = itmp % nxNode;
    itmp /= nxNode;
    *izNode = itmp;
}




//****************************************fixed-point/float conversions*************************************************
void float_int32_pm8(float x, uint8_t* intbuff)
{
    //float with range +/-8 to signed 32 bit int
    int32_t  qint;
    uint32_t* qint2;

    qint = x * 268435456 + sign(x) * .5;  //2^28
    qint2 = (uint32_t*)&qint;  //transfered from signed to unsigend without changing bits

    intbuff[3] = (uint8_t)(*qint2 % 0x100);
    *qint2 /= 0x100;
    intbuff[2] = (uint8_t)(*qint2 % 0x100);
    *qint2 /= 0x100;
    intbuff[1] = (uint8_t)(*qint2 % 0x100);
    *qint2 /= 0x100;
    intbuff[0] = (uint8_t)(*qint2 % 0x100);
}

void float_int32_pm1(float x, uint8_t* intbuff)
{
    //float with range +/-1 to signed 32 bit int
    int32_t  qint;
    uint32_t* qint2;

    qint = x * 2147483648 + sign(x) * .5;  //2^31   //is beyond float precision
    qint2 = (uint32_t*)&qint;  //transfered from signed to unsigend without changing bits

    intbuff[3] = (uint8_t)(*qint2 % 0x100);
    *qint2 /= 0x100;
    intbuff[2] = (uint8_t)(*qint2 % 0x100);
    *qint2 /= 0x100;
    intbuff[1] = (uint8_t)(*qint2 % 0x100);
    *qint2 /= 0x100;
    intbuff[0] = (uint8_t)(*qint2 % 0x100);
}

void float_int24_pm2(float x, uint8_t* intbuff)
{
    //float with range +/-2 to signed 24 bit int
    int32_t  qint;
    uint32_t* qint2;

    qint = x * 4194304 + sign(x) * .5;  //2^22; the .5 is for round-off
    qint2 = (uint32_t*)&qint;  //transfered from signed to unsigend without changing bits

    intbuff[2] = (uint8_t)(*qint2 % 0x100);
    *qint2 /= 0x100;
    intbuff[1] = (uint8_t)(*qint2 % 0x100);
    *qint2 /= 0x100;
    intbuff[0] = (uint8_t)(*qint2 % 0x100);
}

void float_int18_pm2(float x, uint8_t* intbuff)
{
    //float with range +/-2 to signed 24 bit int
    int32_t  qint;
    uint32_t* qint2;

    qint = x * 65536 + sign(x) * .5;  //2^16; the .5 is for round-off
    qint2 = (uint32_t*)&qint;  //transfered from signed to unsigend without changing bits

    intbuff[2] = (uint8_t)(*qint2 % 0x100);
    *qint2 /= 0x100;
    intbuff[1] = (uint8_t)(*qint2 % 0x100);
    *qint2 /= 0x100;
    intbuff[0] = (intbuff[0] & 0xfc) | ((uint8_t)(*qint2 % 0x100)) & 0x03;
}


void float_int24_pm1(float x, uint8_t* intbuff)
{
    //float with range +/-1 to signed 24 bit int
    int32_t  qint;
    uint32_t* qint2;

    qint = x * 8388608 + sign(x) * .5;  //2^23
    qint2 = (uint32_t*)&qint;  //transfered from signed to unsigend without changing bits

    intbuff[2] = (uint8_t)(*qint2 % 0x100);
    *qint2 /= 0x100;
    intbuff[1] = (uint8_t)(*qint2 % 0x100);
    *qint2 /= 0x100;
    intbuff[0] = (uint8_t)(*qint2 % 0x100);
}

void float_int24_p1(float x, uint8_t* intbuff)
{
    //float with range +/-1 to signed 24 bit int
    int32_t  qint;

    qint = x * 16777216 + .5;  //2^24

    intbuff[2] = (uint8_t)(qint % 0x100);
    qint /= 0x100;
    intbuff[1] = (uint8_t)(qint % 0x100);
    qint /= 0x100;
    intbuff[0] = (uint8_t)(qint % 0x100);
}

float int24_float_pm2(uint8_t* readbuff)
{
    //signed 24 bit int to float with range +/-2
    uint8_t readbuff2[4];
    int32_t* qint;

    readbuff2[0] = readbuff[2];
    readbuff2[1] = readbuff[1];
    readbuff2[2] = readbuff[0];
    if (readbuff[0] > 127) readbuff2[3] = 0xff; else readbuff2[3] = 0x00; //make it 4 bytes and extend sign
    qint = (int32_t*)&readbuff2[0];
    return ((float)(*qint)) / 4194304;   //2^22
}

float int24_float_pm1(uint8_t* readbuff)
{
    //signed 24 bit int to float with range +/-1
    uint8_t readbuff2[4];
    int32_t* qint;

    readbuff2[0] = readbuff[2];
    readbuff2[1] = readbuff[1];
    readbuff2[2] = readbuff[0];
    if (readbuff[0] > 127) readbuff2[3] = 0xff; else readbuff2[3] = 0x00; //make it 4 bytes and extend sign
    qint = (int32_t*)&readbuff2[0];
    return ((float)(*qint)) / 8388608;   //2^23
}

float int24_float_p1(uint8_t* readbuff)
{
    //unsigned 24 bit int to float with range +1
    uint8_t readbuff2[4];
    int32_t* qint;

    readbuff2[0] = readbuff[2];
    readbuff2[1] = readbuff[1];
    readbuff2[2] = readbuff[0];
    readbuff2[3] = 0x00; //make it 4 bytes 
    qint = (int32_t*)&readbuff2[0];
    return ((float)(*qint)) / 16777216;   //2^24
}

/*********************************************************************************/
float sign(float in)
{
    float out;
    if (in == 0) out = 0;
    else if (in > 0) out = 1; else out = -1;
    return(out);
}
/*********************************************************************************/
//random generator producing Gaussian distributed values; from Numerical Recipes 
float gasdev(long* idum)
{
    float ran1(long* idum);
    static int iset = 0;
    static float gset;
    float fac, rsq, v1, v2;

    if (iset == 0) {
        do {
            v1 = 2.0 * ran1(idum) - 1.0;
            v2 = 2.0 * ran1(idum) - 1.0;
            rsq = v1 * v1 + v2 * v2;
        } while (rsq >= 1.0 || rsq == 0.0);
        fac = sqrt(-2.0 * log(rsq) / rsq);
        gset = v1 * fac;
        iset = 1;
        return v2 * fac;
    }
    else {
        iset = 0;
        return gset;
    }
}

#define IA 16807
#define IM 2147483647
#define AM (1.0/IM)
#define IQ 127773
#define IR 2836
#define NTAB 32
#define NDIV (1+(IM-1)/NTAB)
#define EPS 1.2e-7
#define RNMX (1.0-EPS)

//random generator with numbers [0...1]
float ran1(long* idum)
{
    int j;
    long k;
    static long iy = 0;
    static long iv[NTAB];
    float temp;

    if (*idum <= 0 || !iy) {
        if (-(*idum) < 1) *idum = 1;
        else *idum = -(*idum);
        for (j = NTAB + 7; j >= 0; j--) {
            k = (*idum) / IQ;
            *idum = IA * (*idum - k * IQ) - IR * k;
            if (*idum < 0) *idum += IM;
            if (j < NTAB) iv[j] = *idum;
        }
        iy = iv[0];
    }
    k = (*idum) / IQ;
    *idum = IA * (*idum - k * IQ) - IR * k;
    if (*idum < 0) *idum += IM;
    j = iy / NDIV;
    iy = iv[j];
    iv[j] = *idum;
    if ((temp = AM * iy) > RNMX) return RNMX;
    else return temp;
}
#undef IA
#undef IM
#undef AM
#undef IQ
#undef IR
#undef NTAB
#undef NDIV
#undef EPS
#undef RNMX
/* (C) Copr. 1986-92 Numerical Recipes Software ,2:. */

/*********************************************************************************/
//memory allocation for vectors an matrices; reduced version in comparison to Numerical Recipes; all indices start from 0.
int* ivector(long long nrow)
{
    int* m;

    m = (int*)malloc(nrow * sizeof(int));

    return (m);
}

float* vector(long long nrow)
{
    float* m;

    m = (float*)malloc(nrow * sizeof(float));

    return (m);
}



float** matrix(long long nrow, long long ncol)
{
    long long i;
    float** m;

    m = (float**)malloc(nrow * sizeof(float*));
    for (i = 0; i < nrow; i++) m[i] = (float*)malloc(ncol * sizeof(float));

    return (m);
}

double** dmatrix(long long nrow, long long ncol)
{
    long long i;
    double** m;

    m = (double**)malloc(nrow * sizeof(double*));
    for (i = 0; i < nrow; i++) m[i] = (double*)malloc(ncol * sizeof(double));

    return (m);
}


int** imatrix(long long nrow, long long ncol)
{
    long long i;
    int** m;

    m = (int**)malloc(nrow * sizeof(int*));
    for (i = 0; i < nrow; i++) m[i] = (int*)malloc(ncol * sizeof(int));

    return (m);
}

float*** f3tensor(long long nrow, long long ncol, long long ndep)
{
    long long i, j;
    float*** t;

    /* allocate pointers to pointers to rows */
    t = (float***)malloc(nrow * sizeof(float**));

    /* allocate pointers to rows and set pointers to them */
    for (i = 0; i < nrow; i++) t[i] = (float**)malloc(ncol * sizeof(float*));

    /* allocate rows and set pointers to them */
    for (i = 0; i < nrow; i++) for (j = 0; j < ncol; j++) t[i][j] = (float*)malloc(ndep * sizeof(float));

    /* return pointer to array of pointers to rows */
    return t;
}


void free_ivector(int* v)
/* free a double vector allocated with ivector() */
{
    free(v);
}

void free_dmatrix(double** m, int nrow)
/* free a double matrix allocated by matrix() */
{
    int i;
    for (i = 0; i < nrow; i++) free(m[i]);
    free(m);
}

void free_imatrix(int** m, int nrow)
/* free a double matrix allocated by matrix() */
{
    int i;
    for (i = 0; i < nrow; i++) free(m[i]);
    free(m);
}