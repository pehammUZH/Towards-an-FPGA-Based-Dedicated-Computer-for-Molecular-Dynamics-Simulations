Visual Studio C++ project, that generates two executable files, SendForceField.exe and MDRun.exe: 

- SendForceField.exe reads the file param.dat, which contains simulation parameters, as well as Gromacs topology files, translates them into the information the FPGA-cluster needs, and 
  sends them to the FPGA cluster. In addition, it generates a file meta.dat, which transfers information to MDRun.exe.

- MDRun.exe initiates an MD run on the FPGA cluster, with parameters contained in param.dat (such as the number of time steps nStep1 and nStep2), and in meta.dat. Note that the step size 
  dt is implicitly a force field parameter and if changed, SendForceField.exe needs to be re-run.

File villin.zip contains parameter file, topology files and initial file for the villin headpiece demonstration example. Depending on the directory structure, paths in MDcontrol.h might
need to be changed.
